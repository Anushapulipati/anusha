import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddEmployeeComponent } from './Employee/add-employee.component';
import { EmployeeListComponent } from './Employee/employee-list.component';

const routes: Routes = [
  {path:'emplist',component:EmployeeListComponent},
  {path:'addemp',component:AddEmployeeComponent}
 
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
