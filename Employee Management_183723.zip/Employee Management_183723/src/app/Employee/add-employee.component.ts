import { Component, OnInit } from '@angular/core';
import {Router} from "@angular/router";
import { EmployeeService } from './employee.service';
import { IEmployee } from './employee.interface';

@Component({
  selector: 'app-add-employee',
  templateUrl: './add-employee.component.html',
  styleUrls: ['./add-employee.component.css']
})
export class AddEmployeeComponent implements OnInit {

  constructor(private employeeService:EmployeeService,private router:Router) { }

  ngOnInit() {
  }
  onSubmit(value:IEmployee){
    this.employeeService.addEmployee(value);
   
    this.router.navigate(['/emplist']);
  }

}
