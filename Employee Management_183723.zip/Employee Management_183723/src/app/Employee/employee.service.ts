import { Injectable } from '@angular/core';
import { Observable } from '../../../node_modules/rxjs';
import { IEmployee } from './employee.interface';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees:IEmployee[]=[];
  

  constructor(private http:HttpClient) { }
  getAllEmployees(){
  
   return this.employees;
  }
  getEmployees():Observable<IEmployee[]>{
  
   return this.http.get<IEmployee[]>("./assets/emp.json");
    
  }
addEmployee(empl){
  this.employees.push(empl); 

}

}
