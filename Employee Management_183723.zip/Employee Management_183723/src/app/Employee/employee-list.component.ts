import { Component, OnInit } from '@angular/core';
import { IEmployee } from './employee.interface';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employees:IEmployee[];
  emp:IEmployee[];
  empl:IEmployee[];
  constructor(private employeeService:EmployeeService) { }

  ngOnInit() {
    this.employeeService.getEmployees().subscribe((data)=>{
      this.employees=data;
      let emp=this.employeeService.getAllEmployees();
      for(let empl of emp){
        this.employees.push(empl);
      } 
    })
  }
  
  onDelete(emp){
    let index=this.employees.indexOf(emp);
    this.employees.splice(index,1);
  }



}
