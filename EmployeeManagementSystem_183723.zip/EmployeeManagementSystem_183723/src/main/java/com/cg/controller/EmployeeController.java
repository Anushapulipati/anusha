package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;
import com.cg.service.IEmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	private IEmployeeService service;
	//purpose:creating employee
	@RequestMapping(value="/create",method = RequestMethod.POST)
	public List<Employee> createEmployee(@RequestBody Employee employee) throws EmployeeException
	{
		return service.createEmployee(employee);
	}
	
	/*to get all employees*/
	@RequestMapping(value="/employees",method = RequestMethod.GET)
	public List<Employee> viewEmployeeList()
	{
		return service.viewEmployeeList();
	}
	/*delete employee*/
	@RequestMapping(value="/delete/{id}",method = RequestMethod.DELETE)
	public String deleteEmployee(@PathVariable("id") Integer id)
	{
		service.deleteEmployee(id);
		return  id+" is deleted";
		
	}
	
	/*get employee by id*/
	@RequestMapping(value = "/getbyid",method = RequestMethod.GET)
	public Employee findEmployee(@RequestParam("empId") Integer id)
	{
		return service.findEmployee(id);
	}
	
	/*update employee*/
	@RequestMapping(value = "/updateemployee",method = RequestMethod.PUT)
	public String updateEmployee(@RequestBody Employee employee) {
		 service.updateEmployee(employee);
		return "Employee updated successfully\n"+employee;
	}
	/*get employeeby department name*/
	@RequestMapping(value = "/employees/{dept}", method = RequestMethod.GET)

	public List<Employee> viewEmployeesByDepartmentName(@PathVariable("dept") String department) {
	 return service.viewEmployeesByDepartmentName(department);
	}
	

}
