package com.cg.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.Employee;
import com.cg.dao.IEmployeeRepo;
import com.cg.exception.EmployeeException;
import com.cg.exception.ExceptionMessages;

@Service
public class EmployeeServiceImpl implements IEmployeeService{
	@Autowired
	private IEmployeeRepo repo;

	@Override
	public List<Employee> createEmployee(Employee employee) throws EmployeeException {
		try {
		repo.save(employee);
		}catch(Exception e) {
			throw new EmployeeException(ExceptionMessages.MESSAGE1);
		}
		return repo.findAll();
	}

	@Override
	public List<Employee> viewEmployeeList() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public Employee updateEmployee(Employee emp) {
	   
		repo.save(emp);
		return emp;
	}

	@Override
	public void deleteEmployee(Integer id) {
		// TODO Auto-generated method stub
		repo.deleteById(id);
	}

	@Override
	public Employee findEmployee(Integer id) {
		// TODO Auto-generated method stub
		return repo.findById(id).get();
	}

	@Override
	public List<Employee> viewEmployeesByDepartmentName(String departmentName) {
		 List<Employee> list=repo.findAll();
		 List<Employee> list1=new ArrayList<>();
		 for(Employee emp:list) {
		  if(emp.getDeptName().equals(departmentName)) {
		   list1.add(emp); 
		  }
		 }
		 return list1;
	}

}
