package com.cg.service;

import java.util.List;

import com.cg.bean.Employee;
import com.cg.exception.EmployeeException;

public interface IEmployeeService {
List<Employee> createEmployee(Employee employee) throws EmployeeException;
	

	
	List<Employee> viewEmployeeList();

   Employee updateEmployee(Employee employee);
	
	void deleteEmployee(Integer id);
	
	Employee findEmployee(Integer id);
	public List<Employee> viewEmployeesByDepartmentName(String productName);
	

}
