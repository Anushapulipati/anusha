package com.cg.exception;

public interface ExceptionMessages {
	String MESSAGE1="data not found";
}
