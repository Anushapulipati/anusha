const fs = require('fs');
const child_process = require('child_process');

let data = {
    "timestamp": getTimestamp(),
    "version": getVersion(),
    "commit": getCommit()
}

saveBuildInfoFile();

function getTimestamp() {
    console.log('Getting timestamp');
    const currentTime = Date(Date.now());
    const currentTimeFormatted = currentTime.toString();
    console.log('Got timestamp: ' + currentTimeFormatted);
    return currentTimeFormatted;
}

function getVersion() {
    console.log('Getting version');
    const content = fs.readFileSync('./package.json', 'utf8');
    const packageJson = JSON.parse(content);
    const version = packageJson["version"];
    console.log('Got version: ' + version);
    return version;
}

function getCommit() {
    console.log('Getting commit');
    const commit = child_process.execSync('git rev-parse HEAD').toString().split('\n')[0];
    console.log('Got commit: ' + commit);
    return commit;
}

function saveBuildInfoFile() {
    const folderPath = './src/assets';    
    if (!fs.existsSync(folderPath)) {
        console.log('Creating folder: ' + folderPath);
        fs.mkdirSync(folderPath);
        console.log('Created folder: ' + folderPath);
    }
    const filePath = folderPath + '/build-info.json';
    console.log('Saving file: ' + filePath);
    const prettyJson = JSON.stringify(data, null, 2);
    fs.writeFileSync(filePath, prettyJson);
    console.log('Saved file: ' + filePath);
}
