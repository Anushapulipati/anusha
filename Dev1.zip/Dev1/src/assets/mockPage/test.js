
function test() {

	var myVariable = {
		"istitutoCodice": "05387",
		"codiceFamiglia": "PFITA",
		"tipoEntita": "RAP",
		"sottotipoEntita": "PTF",
		"keyEntita": "000000000254",
		"enteCodice": "00032",
		"ndg": "016861855",
		"naturaGiuridica": "PG",
		"formaTecnica": "PF300",
		"codicePropostaBstore": "98979"
	};
	window.open("http://10.26.20.243/engine2-fe/#/login?data=" + JSON.stringify(myVariable) + "", "", "");

}

function testBack() {
	var data = {
		"idProcesso": 13073,
		"codicePropostaEsterna": 1,
		"famiglia": "PFITA",
		"numeroRapporto": "000",
		"enteRapporto": "0032",
		"tipoEntita": "RAP",
		"sottotipoEntita": "PTF"

	};

	var mapForm = document.createElement("form");
	mapForm.target = "";
	mapForm.method = "POST";
	mapForm.action = "http://localhost:8080/bstore-vendita/returnFromExternalApp/saveDeroghe";

	var mapInput = document.createElement("input");
	mapInput.type = "text";
	mapInput.name = "idProcesso";
	mapInput.value = 13073;
	mapForm.appendChild(mapInput);


	var mapInput2 = document.createElement("input");
	mapInput2.type = "text";
	mapInput2.name = "codicePropostaEsterna";
	mapInput2.value = 1;
	mapForm.appendChild(mapInput2);

	var mapInput3 = document.createElement("input");
	mapInput3.type = "text";
	mapInput3.name = "famiglia";
	mapInput3.value = "PFITA";
	mapForm.appendChild(mapInput3);

	var mapInput4 = document.createElement("input");
	mapInput4.type = "text";
	mapInput4.name = "numeroRapporto";
	mapInput4.value = "00000";
	mapForm.appendChild(mapInput4);

	var mapInput5 = document.createElement("input");
	mapInput5.type = "text";
	mapInput5.name = "enteRapporto";
	mapInput5.value = "0032";
	mapForm.appendChild(mapInput5);

	var mapInput6 = document.createElement("input");
	mapInput6.type = "text";
	mapInput6.name = "tipoEntita";
	mapInput6.value = "RAP";
	mapForm.appendChild(mapInput6);

	var mapInput7 = document.createElement("input");
	mapInput7.type = "text";
	mapInput7.name = "sottotipoEntita";
	mapInput7.value = "PTF";
	mapForm.appendChild(mapInput7);


	document.body.appendChild(mapForm);


	mapForm.submit();


}