import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './shared/components/login/login.component';
import { LoginfailedComponent } from './shared/components/loginfailed/loginfailed.component';
import { AuthGuard } from './shared/guards/auth.guard';
import { InsertionInputDataComponent } from './shared/components/insertion-input-data/insertion-input-data.component';



const routes: Routes = [
  {
    path: '', redirectTo: '/login', pathMatch: 'full',
  },
  {
    path: 'login', component: LoginComponent
  },
  {
    path: 'insertionInputData', component: InsertionInputDataComponent
  },
  {
    path: 'loginfailed', component: LoginfailedComponent
  },
  {
    path: 'inserimento-deroga',
    loadChildren: './modules/inserimento-deroga/inserimento-deroga.module#InserimentoDerogaModule',
    canActivate: [AuthGuard]
  },
  {
    path: 'inserimento-conferma',
    loadChildren: './modules/inserimento-conferma/inserimento-conferma.module#InserimentoConfermaModule',
    canActivate: [AuthGuard]
  }



];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
