/**
 * Languages used by the application.
 */
export enum AttributoType {

    ALFANUMERICO = 'A',
    NUMERICO = 'N',
    TASSO = 'T',
    SEGNATO = 'S',
    IMPORTO = 'I',
    PROGRESSIVO = 'P',
    CODIFICATO = 'C',
    LISTINO = 'L',
    FILTRO = 'F',
    DATA = 'D'

}
