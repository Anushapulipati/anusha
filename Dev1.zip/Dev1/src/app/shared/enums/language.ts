/**
 * Languages used by the application.
 */
export enum Language {
    EN = 'en',
    IT = 'it'
}
