/**
 * Search used by the application.
 */
export enum SearchType {

    ATTRIBUTE = 'ATTR.',
    GROUP = 'GR.COND.',
    CONDITION = 'COND.'

}
