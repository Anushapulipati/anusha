/**
 * Languages used by the application.
 */
export enum CondizioneType {

    LISTA_FISSA = 'F',
    LISTA_SEMPLICE = 'S',
    LISTA_VARIABILE = 'V'

}
