import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { InputData } from '../../models/input-data';
import { MockDataService } from '../../services/mock-data.service';
import { LoginService } from '../../services/login.service';
import { GroupDetail } from 'pricelab-angular-library';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private mockData: MockDataService,
    private loginService: LoginService
  ) {
    sessionStorage.clear();
    if (!environment.developmentMode) {
      //  caso reale
      route.queryParams.subscribe(
        params => {
          console.log('queryParams', JSON.parse(params['data']));
          sessionStorage.setItem('inputData', params['data']);
          console.log('getted', sessionStorage.getItem('inputData'));
        });
    } else if (!environment.inputDataCompilationRequired) {
      this.loadMockInputData();
    }
  }

  loadMockInputData() {
    this.mockData.loadMockInputData().subscribe(result => {
      sessionStorage.setItem('inputData', JSON.stringify(result));
      console.log('getted', sessionStorage.getItem('inputData'));
    });
  }

  ngOnInit() {
    // chiamata a authenticate --> loginController (/api/login/authenticate (no input))
    // if ok we have userVm returned, we can go to inserimentoDeroghePage and load all else we display erorr page
    this.loginService.login().subscribe(response => {
      console.log(response);
      let mappa: Map<string, GroupDetail> = new Map();
      sessionStorage.setItem('gruppi', JSON.stringify(Array.from(mappa)));

      if (environment.inputDataCompilationRequired) {
        this.router.navigate(['insertionInputData']);
      } else {
        this.router.navigate(['inserimento-deroga']);
      }
    }, (error) => {
      console.log(error);
      this.router.navigate(['loginfailed']);
    });
  }
}
