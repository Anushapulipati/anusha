import { Component, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Language } from '../../enums/language';

@Component({
  selector: 'app-loginfailed',
  templateUrl: './loginfailed.component.html',
  styleUrls: ['./loginfailed.component.scss']
})
export class LoginfailedComponent implements OnInit {

  errorMessage: string;
  constructor(private translate: TranslateService) {
    translate.get('login.LOGINFAILED').subscribe((message: string) => {
      this.errorMessage = message;
    });
  }
  ngOnInit() {
  }

}
