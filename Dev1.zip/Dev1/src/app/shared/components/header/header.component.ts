import { Component, OnInit } from '@angular/core';
import { TopbarService } from '../../services/topbar.service';
import { UserVm } from '../../models/user-vm.model';
import { InputData } from '../../models/input-data';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  userVm: UserVm;
  userid = '9999';
  today: number;
  openedByBstoreFlag = false;
  bper: any;
  pricelab: any;

  constructor(
    private topbarService: TopbarService
  ) { }

  ngOnInit(): void {
    const inputData: InputData = JSON.parse(sessionStorage.getItem('inputData'));
    if (inputData) {
      this.openedByBstoreFlag = inputData.openedByBstore;
    }
    this.today = Date.now();
    this.bper = 'assets/bper_logo.png';
    this.pricelab = 'assets/Pricelab.png';
    this.topbarService.topHeaderiformativa(this.userid).subscribe(userVm => {
      this.userVm = userVm;
    }, (error) => {
      console.log(error);
    });

  }
}
