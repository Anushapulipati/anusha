import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HeaderComponent } from './header.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MockDataService } from '../../services/mock-data.service';
import { of } from 'rxjs';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let fixture: ComponentFixture<HeaderComponent>;
  let serviceMock: MockDataService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [ MockDataService ],
      declarations: [ HeaderComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
    serviceMock = TestBed.get(MockDataService);
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HeaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call json openedByBstore flag', () => {
    const jsonFlag = [
      {
        openedByBstore: true
      }
    ];
    let responseFlag;
    spyOn(serviceMock, 'loadMockInputData').and.returnValue(of(jsonFlag));
    serviceMock.loadMockInputData().subscribe(result => {
      responseFlag = result;
    });
  });
});
