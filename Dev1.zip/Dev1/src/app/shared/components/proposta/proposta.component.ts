import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-proposta',
  templateUrl: './proposta.component.html',
  styleUrls: ['./proposta.component.css']
})
export class PropostaComponent implements OnInit {
  propostaId = '98979';
  constructor() { }

  ngOnInit() {
  }

}
