import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { InputData } from '../../models/input-data';
import { Router } from '@angular/router';

@Component({
  selector: 'app-insertion-input-data',
  templateUrl: './insertion-input-data.component.html',
  styleUrls: ['./insertion-input-data.component.scss']
})
export class InsertionInputDataComponent {

  generalDataForm = new FormGroup({
    istitutoCodice: new FormControl('', Validators.required),
    codiceFamiglia: new FormControl('', Validators.required),
    tipoEntita: new FormControl('', Validators.required),
    sottotipoEntita: new FormControl('', Validators.required),
    keyEntita: new FormControl('', Validators.required),
    enteCodice: new FormControl('', Validators.required),
    ndg: new FormControl('', Validators.required),
    naturaGiuridica: new FormControl('', Validators.required),
    formaTecnica: new FormControl('', Validators.required),
    codicePropostaBstore: new FormControl('', Validators.required),
    codiceProdotto: new FormControl('', Validators.required),
    openedByBstore: new FormControl('', Validators.required),
    enteRapportoRegolamento: new FormControl('', Validators.required),
    rapportoRegolamento: new FormControl('', Validators.required)
  });

  constructor(private router: Router) { }

  prosegui() {
    let inputData: InputData = this.generalDataForm.value;
    inputData.openedByBstore = this.generalDataForm.get('openedByBstore').value === 'true';
    sessionStorage.setItem('inputData', JSON.stringify(inputData));
    console.log('getted', sessionStorage.getItem('inputData'));
    this.router.navigate(['inserimento-deroga']);
  }

  getControlValidation(controlName: string): boolean {
    const control = this.generalDataForm.get(controlName);
    let valid: boolean = (control.touched && control.invalid) || (control.dirty && control.invalid) ? true : false;
    return valid;
  }
}
