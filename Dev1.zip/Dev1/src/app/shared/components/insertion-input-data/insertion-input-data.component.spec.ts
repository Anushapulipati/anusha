import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InsertionInputDataComponent } from './insertion-input-data.component';

describe('InsertionInputDataComponent', () => {
  let component: InsertionInputDataComponent;
  let fixture: ComponentFixture<InsertionInputDataComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InsertionInputDataComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InsertionInputDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
