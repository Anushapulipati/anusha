import { Component, OnInit, Input } from '@angular/core';
import { Router } from '@angular/router';
import { GoBackService } from '../../services/go-back.service';

@Component({
  selector: 'app-title-header',
  templateUrl: './title-header.component.html',
  styleUrls: ['./title-header.component.scss']
})
export class TitleHeaderComponent implements OnInit {
  @Input() redirectTo: string;
  @Input() subTitle: string;
  @Input() goBackOtherApplication = false;
  constructor(private router: Router, private goBackService: GoBackService) { }

  navigateToPage() {
    if (this.redirectTo) {
      this.router.navigate([this.redirectTo]);
    }
  }

  goBackFunction() {
    this.goBackService.generateUrlBack(false);
  }



  ngOnInit() { }

}

