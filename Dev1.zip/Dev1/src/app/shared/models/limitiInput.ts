import { Entita } from './entita';

export class LimitiInput {

    istituto: string;
    famiglia: string;
    gruppo: string;
    entita: Entita;
    filiale: string;
    progressivo: number;
}
