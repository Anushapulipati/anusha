export class ERapportiPaginaPerNdgClienteInput {
    datiRapportoIstitutoCodice: string;
    datiRapportoDatiAnagraficiRapportoDatiAnagraficiClienteIdentificativoNdg: string;
    funzInput: string;
}
