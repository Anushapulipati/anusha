import { ProfileVm } from './profile-vm.model';

export class UserVm {
  name: string;
  surname: string;
  matricola: string;
  office: string;
  profile: ProfileVm;
}
