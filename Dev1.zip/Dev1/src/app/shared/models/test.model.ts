export class TestModel {
    testInput: string;
    id: number;
    code: string;
    description: string;
}
