export class Caratterizzazioni {
    contoRegolamento: string;
    grazCode: string;
    grazDescription: string;
    formaTecnicaCode: string;
    formaTecnicaDescription: string;

    public get graz(): string {
        return '[' + this.grazCode + '] ' + this.grazDescription;
    }

    public set graz(value: string) {
        this.graz = value;
    }

    public get formaTecnica(): string {
        return '[' + this.formaTecnicaCode + '] ' + this.formaTecnicaDescription;
    }

    public set formaTecnica(value: string) {
        this.formaTecnica = value;
    }

}
