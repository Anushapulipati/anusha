export class InputData {
  istitutoCodice: string;
  codiceFamiglia: string;
  tipoEntita: string;
  sottotipoEntita: string;
  keyEntita: string;
  enteCodice: string;
  ndg: string;
  naturaGiuridica: string;
  formaTecnica: string;
  codicePropostaBstore: string;
  codiceProdotto: string;
  openedByBstore: boolean;
  enteRapportoRegolamento: string;
  rapportoRegolamento: string;
  url: string;

}
