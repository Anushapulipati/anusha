import { ERapportiPerNdgClienteWBODatiVm } from './erapporti-perndg-clienteWBOdati-vm';

export class ERapportiPaginaPerNdgClienteOutput {
    elencoRapporti: Array<ERapportiPerNdgClienteWBODatiVm>;
}
