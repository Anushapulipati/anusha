export class CaratterizzazioniInputVm {
    istitutoCodice: string;
    famigliaCodice: string;
    tipoEntita: string;
    sottotipoEntita: string;
    chiaveEntita: string;
    enteCodice: string;
    formaTecnica: string;
    ndg: string;
    groupCodice: string;
    contoDiRegolamento: string;
    funzione: string;
}
