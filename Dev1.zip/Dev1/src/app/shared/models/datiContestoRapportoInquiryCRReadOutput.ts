export class DatiContestoRapportoInquiryCRReadOutput {
    datiRapportoNumeriDataAperturaRapporto: Date;
    datiRapportoNumeriDataUltimaElaborazione: Date;
    datiRapportoNumeriCodiceSegmento: string;
    datiRapportoNumeriImportoFormaTecnicaAmm: number;
    datiRapportoNumeriImportoFormaTecnicaGestFondi: number;
    datiRapportoNumeriImportoFormaTecnicaGestPatrimoniali: number;
    datiRapportoNumeriImportoFormaTecnicaPolizzeRamo1: number;
    datiRapportoNumeriImportoFormaTecnicaPolizzeRamo3: number;
    datiRapportoNumeriImportoFormaTecnicaRaccoltaDiretta: number;
    datiRapportoNumeriImportoCommTotaliAnnoPrec: number;
    datiRapportoNumeriImportoCommPrimoTrimestreCorrente: number;
    datiRapportoNumeriImportoCommSecondoTrimestreCorrente: number;
    datiRapportoNumeriImportoCommTerzoTrimestreCorrente: number;
}
