export class NoteEAllegati {

    constructor(private idParam: number, private fileNameParam: string, private idFilenetParam: string) { }

    public get id(): number {
        return this.idParam;
    }
    public set id(value: number) {
        this.idParam = value;
    }

    public get fileName(): string {
        return this.fileNameParam;
    }
    public set fileName(value: string) {
        this.fileNameParam = value;
    }

    public get idFilenet(): string {
        return this.idFilenetParam;
    }
    public set idFilenet(value: string) {
        this.idFilenetParam = value;
    }

}
