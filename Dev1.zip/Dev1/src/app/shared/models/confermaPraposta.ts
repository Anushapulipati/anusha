export class ConfermaPrapostaVm {
    DeskWorkflowProposalCode: string;
}
