export class ERapportiPerNdgClienteWBODatiVm {
    datiAnagraficiNdg: string;
    famigliaCodice: string;
    servizioCodice: string;
    ambitoEnteCodice: string;
    numeroRapporto: number;
    datiAnagraficiRapportoCategoriaContoCodice: string;
    ambitoTipoEntitaCodice: string;
    ambitoSottotipoEntitaCodice: string;
    ambitoChiaveEntita: string;
    direzioneTerritorialeDescrizione: string;
    ambitoInizioValidita: string;
    ambitoFineValidita: string;
    datiOperativiRapportoDataApertura: string;
    datiAnagraficiRapportoFormaTecnicaCodice: string;
}
