export class SelectByFamiglia {
	ambitoIstitutoCodice: String;
	famigliaCodice: String;
	ambitoEnteCodice: String;
	ambitoTipoEntitaCodice: String;
	ambitoSottotipoEntitaCodice: String;
	ambitoChiaveEntita: String;
	dataRiferimento: Date;
	//operatoreCodiceOperatore : String;
	funzione: String;
	gruppoCodiceGruppo: String;
	formaTecnicaCodice: String;
}