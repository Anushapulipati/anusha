export class CreateAndVerifyProposal {

  istitutoCodice: string;
  famigliaCodice: string;
  tipoEntita: string;
  sottotipoEntita: string;
  chiaveEntita: string;
  enteCodice: string;
  formaTecnica: string;
  naturaGiuridica: string;
  ndg: string;
  codicePropostaBstore: string;
  codiceProdotto: string;
  codicePropostaDesk: number;
  codiceRelazioneDesk: number;
}


