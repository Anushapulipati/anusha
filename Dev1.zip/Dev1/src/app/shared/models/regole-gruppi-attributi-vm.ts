export class RegoleGruppiAttributiVm {

  valoreFiltro: string;
  condzDaVisualizz: number;

}
