export class DatiContestoRapportoInquiryCRReadInput {

    datiRapportoIstitutoCodice: string;
    datiRapportoFamigliaCodice: string;
    datiRapportoEnteCodice: string;
    datiRapportoAmbitoTipoEntitaCodice: string;
    datiRapportoAmbitoSottotipoEntitaCodice: string;
    datiRapportoAmbitoChiaveEntita: string;
    data: Date;
}
