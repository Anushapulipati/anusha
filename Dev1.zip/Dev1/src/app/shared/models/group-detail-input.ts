export class GroupDetailInput {
  istitutoCodice: string;
  famigliaCodice: string;
  gruppoCodice: string;
  dataInizio: Date;
  dataFine: Date;
  tipoEntita: string;
  sottotipoEntita: string;
  chiaveEntita: string;
  enteCodice: string;
}


