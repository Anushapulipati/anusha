import { GruppoCondizioniVm } from './gruppo-condizioni';
import { Entita } from './entita';

export class GruppiListInputVm {
    istituto: string;
    famiglia: string;
    ente: string;
    entita: Entita;
    formaTecnica: string;
}

export class GruppiListOutputVm {
    livello: number;
    gruppi: GruppoCondizioniVm[];
}