export class TestModelResult {
    testOutput: string;
}
