import { SearchType } from './../enums/search.type';
export class GruppoCondizioniVm {
  code: string;
  description: string;
  sigla: string;
  protected: boolean;
}

export class SearchGroupCondizioniAttributeVm {
  istitute: string;
  family: string;
  entityType: string;
  entitySubType: string;
  searchValue: string;
}

export class GroupConditionAttributeVm {
  type: SearchType;
  description: string;
  groupCodes: string[];
}


