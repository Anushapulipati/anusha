export interface DocumentResultModel {
    ocrGuid: string;
}
