export interface SecurityModel {

    applicazione: string;
    banca: string;
    esbIdCed: string;
    esbIp: string;
    esbOperatore: string;
    filiale: string;
    host: string;
    nomeUtente: string;
    ruolo: string;
    sezione: string;
    terminale: string;
    ufficio: string;
    utente: string;

}
