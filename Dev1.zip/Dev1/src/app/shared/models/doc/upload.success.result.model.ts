import { DocumentResultModel } from './document.result.model';

export interface UploadSuccessResultModel {
    uploadResultList: DocumentResultModel[];
    wasCancelled: string;
}
