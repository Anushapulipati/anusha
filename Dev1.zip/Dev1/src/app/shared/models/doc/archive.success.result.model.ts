export interface ArchiveSuccessResultModel {

    documentId: string;
    documentUrl: string;
    wasCancelled: boolean;
}
