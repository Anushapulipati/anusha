import { UploadSuccessResultModel } from './upload.success.result.model';

export interface UploadDocInputModel {
    base64: string;
    fileName: string;
    ltpa2Auth: string;
    onError: (error: any) => void;
    onSuccess: (successResult: UploadSuccessResultModel) => void;

}
