import { MetadataDocInputModel } from './metadata.doc.model';

export class AddAllAllegatiFileNetModel {

    proposalCodeDesk: string;
    fileName: string;
    idFilenet: string;
    metaDataList: MetadataDocInputModel[];
}