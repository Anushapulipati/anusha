import { ArchiveSuccessResultModel } from './archive.success.result.model';

export interface ArchiveDocInputModel {

    documentType: string;
    fileName: string;
    ltpa2Auth: string;
    metadata: string;
    ocrGuid: string;

    onError: (error: any) => void;
    onSuccess: (successResult: ArchiveSuccessResultModel) => void;

    service: string;
    type: string;
}
