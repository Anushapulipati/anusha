export interface MetadataDocInputModel {

    dataType: string;
    dataTypeFormat: string;
    name: string;
    value: string[];

}
