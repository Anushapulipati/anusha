
export class RemoveAllegatiFileNetInputVm {
    proposalCodeDesk: string;
    idFilenet: string;
}
