export class Entita {

    tipEntita: string;
    subEntita: string;
    chiaveEntita: string;

}
