export declare class Famiglia {
    id: number;
    istituto: string;
    codice: string;
    descrizione: string;
}
