import { tipoClienteType } from '../enums/tipoCliente.type';

export class DatiCliente {

  constructor(private _ndg: string, private _intestazione: string, private _codiceNaturaGiuridica: string, private _descrizioneNaturaGiuridica: string,
    private _dataNascitaApertura: string, private _codiceModelloServizio: string, private _descrizioneModelloServizio: string
    , private _codiceSegmentoRischio: string, private _descrizioneSegmentoRischio: string, private _codiceSottosegmento: string, private _codiceRatingUfficiale: string
    , private _descrizioneRatingUfficiale: string, private _codiceRatingAndamentale: string, private _descrizioneRatingAndamentale: string, private _codiceEnteRelazione: string
    , private _descrizioneEnteRelazione: string, private _codiceDirezioneTerritoriale: string, private _descrizioneDirezioneTerritoriale: string,
    private _codiceAreaCommerciale: string, private _descrizioneAreaCommerciale: string, private _portafoglio: string, private _segmentoCodice: string, private _segmentoDescrizione: string) {
  }


  public get ndg(): string {
    return this._ndg;
  }
  public set ndg(value: string) {
    this._ndg = value;
  }

  public get intestazione(): string {
    return this._intestazione;
  }
  public set intestazione(value: string) {
    this._intestazione = value;
  }

  public get naturaGiuridica(): string {
    return "[" + this.codiceNaturaGiuridica + "] " + tipoClienteType[this.codiceNaturaGiuridica];
  }
  public get codiceNaturaGiuridica(): string {
    return this._codiceNaturaGiuridica;
  }
  public set codiceNaturaGiuridica(value: string) {
    this._codiceNaturaGiuridica = value;
  }
  public get descrizioneNaturaGiuridica(): string {
    return this._descrizioneNaturaGiuridica;
  }
  public set descrizioneNaturaGiuridica(value: string) {
    this._descrizioneNaturaGiuridica = value;
  }

  public get dataNascitaApertura(): string {
    return this._dataNascitaApertura;
  }
  public set dataNascitaApertura(value: string) {
    this._dataNascitaApertura = value;
  }

  public get modelloServizio(): string {
    return "[" + this.codiceModelloServizio + "] " + this.descrizioneModelloServizio;
  }
  public get codiceModelloServizio(): string {
    return this._codiceModelloServizio;
  }
  public set codiceModelloServizio(value: string) {
    this._codiceModelloServizio = value;
  }
  public get descrizioneModelloServizio(): string {
    return this._descrizioneModelloServizio;
  }
  public set descrizioneModelloServizio(value: string) {
    this._descrizioneModelloServizio = value;
  }

  public get segmentoRischio(): string {
    return "[" + this.codiceSegmentoRischio + "]";
  }
  public get codiceSegmentoRischio(): string {
    return this._codiceSegmentoRischio;
  }
  public set codiceSegmentoRischio(value: string) {
    this._codiceSegmentoRischio = value;
  }
  public get descrizioneSegmentoRischio(): string {
    return this._descrizioneSegmentoRischio;
  }
  public set descrizioneSegmentoRischio(value: string) {
    this._descrizioneSegmentoRischio = value;
  }

  public get codiceSottosegmento(): string {
    return this._codiceSottosegmento;
  }
  public set codiceSottosegmento(value: string) {
    this._codiceSottosegmento = value;
  }

  public get ratingUfficiale(): string {
    return "[" + this.codiceRatingUfficiale + "] " + (this.descrizioneRatingUfficiale ? this.descrizioneRatingUfficiale : "");
  }
  public get codiceRatingUfficiale(): string {
    return this._codiceRatingUfficiale;
  }
  public set codiceRatingUfficiale(value: string) {
    this._codiceRatingUfficiale = value;
  }
  public get descrizioneRatingUfficiale(): string {
    return this._descrizioneRatingUfficiale;
  }
  public set descrizioneRatingUfficiale(value: string) {
    this._descrizioneRatingUfficiale = value;
  }

  public get ratingAndamentale(): string {
    return "[" + this.codiceRatingAndamentale + "] " + (this.descrizioneRatingAndamentale ? this.descrizioneRatingAndamentale : "");
  }
  public get codiceRatingAndamentale(): string {
    return this._codiceRatingAndamentale;
  }
  public set codiceRatingAndamentale(value: string) {
    this._codiceRatingAndamentale = value;
  }
  public get descrizioneRatingAndamentale(): string {
    return this._descrizioneRatingAndamentale;
  }
  public set descrizioneRatingAndamentale(value: string) {
    this._descrizioneRatingAndamentale = value;
  }

  public get enteRelazione(): string {
    return "[" + this.codiceEnteRelazione + "] " + this.descrizioneEnteRelazione;
  }
  public get codiceEnteRelazione(): string {
    return this._codiceEnteRelazione;
  }
  public set codiceEnteRelazione(value: string) {
    this._codiceEnteRelazione = value;
  }
  public get descrizioneEnteRelazione(): string {
    return this._descrizioneEnteRelazione;
  }
  public set descrizioneEnteRelazione(value: string) {
    this._descrizioneEnteRelazione = value;
  }

  public get direzioneTerritoriale(): string {
    return "[" + this.codiceDirezioneTerritoriale + "] " + this.descrizioneDirezioneTerritoriale;
  }
  public get codiceDirezioneTerritoriale(): string {
    return this._codiceDirezioneTerritoriale;
  }
  public set codiceDirezioneTerritoriale(value: string) {
    this._codiceDirezioneTerritoriale = value;
  }
  public get descrizioneDirezioneTerritoriale(): string {
    return this._descrizioneDirezioneTerritoriale;
  }
  public set descrizioneDirezioneTerritoriale(value: string) {
    this._descrizioneDirezioneTerritoriale = value;
  }

  public get areaCommerciale(): string {
    return "[" + this.codiceAreaCommerciale + "] " + this.descrizioneAreaCommerciale;
  }
  public get codiceAreaCommerciale(): string {
    return this._codiceAreaCommerciale;
  }
  public set codiceAreaCommerciale(value: string) {
    this._codiceAreaCommerciale = value;
  }
  public get descrizioneAreaCommerciale(): string {
    return this._descrizioneAreaCommerciale;
  }
  public set descrizioneAreaCommerciale(value: string) {
    this._descrizioneAreaCommerciale = value;
  }

  public get portafoglio(): string {
    return this._portafoglio;
  }
  public set portafoglio(value: string) {
    this._portafoglio = value;
  }

  public get segmentoCodice(): string {
    return this._segmentoCodice;
  }
  public set segmentoCodice(value: string) {
    this._segmentoCodice = value;
  }

  public get segmentoDescrizione(): string {
    return this._segmentoDescrizione;
  }
  public set segmentoDescrizione(value: string) {
    this._segmentoDescrizione = value;
  }

  public get filieraSegmento(): string {
    return "[" + this.segmentoCodice + "] " + this.segmentoDescrizione;
  }
}
