export class ConfamaDetailsVm {
  codiceProposta: string;
  attachementList: string[];
  note: string;
  naturaGiuridica: string;
  ndg: string;
}
