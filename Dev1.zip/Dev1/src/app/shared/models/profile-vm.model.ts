export class ProfileVm {
  code: string;
  description: string;
}
