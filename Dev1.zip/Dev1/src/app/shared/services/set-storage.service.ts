import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class SetStorageService {


  constructor() { }


  getlocalItem(): boolean {
    const proposalData = JSON.parse(sessionStorage.getItem('proposalData'));
    return proposalData.inAutonomia;
  }


}
