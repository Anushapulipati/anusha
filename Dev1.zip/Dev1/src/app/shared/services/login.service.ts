import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UrlProviderService } from './url-provider.service';
import { map, catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoginService {


  constructor(
    private httpClient: HttpClient,
    private urlProviderService: UrlProviderService
  ) { }



  public login() {
    return this.httpClient.get(this.urlProviderService.getLoginUrl);

    // below line is to test loginfailed component
    // return this.httpClient.get(this.urlProviderService.getLoginUrl).pipe(map(data => {
    //   throw new Error('Valid token not returned');
    // }));
  }


}
