import { Injectable } from '@angular/core';
import { InputData } from '../models/input-data';

@Injectable({
  providedIn: 'root'
})
export class GoBackService {

  constructor() { }


  public generateUrlBack(passCodPropsota: boolean) {
    const inputData: InputData = JSON.parse(sessionStorage.getItem('inputData'));
    const proposalData = JSON.parse(sessionStorage.getItem('proposalData'));
    const data = {
      idProcesso: inputData.codicePropostaBstore,
      codicePropostaEsterna: proposalData ? proposalData.codiceProposta : null,
      famiglia: inputData.codiceFamiglia,
      numeroRapporto: inputData.keyEntita,
      enteRapporto: inputData.enteCodice,
      tipoEntita: inputData.tipoEntita,
      sottotipoEntita: inputData.sottotipoEntita,
      url: inputData.url ? inputData.url : ''
    };

    if (!passCodPropsota) {
      data.codicePropostaEsterna = null;
    }

    const mapForm = document.createElement('form');
    mapForm.target = '';
    mapForm.method = 'POST';
    mapForm.action = data.url;

    const mapInput = document.createElement('input');
    mapInput.type = 'hidden';
    mapInput.name = 'idProcesso';
    mapInput.value = data.idProcesso;
    mapForm.appendChild(mapInput);


    const mapInput2 = document.createElement('input');
    mapInput2.type = 'hidden';
    mapInput2.name = 'codicePropostaEsterna';
    mapInput2.value = data.codicePropostaEsterna;
    mapForm.appendChild(mapInput2);

    const mapInput3 = document.createElement('input');
    mapInput3.type = 'hidden';
    mapInput3.name = 'famiglia';
    mapInput3.value = data.famiglia;
    mapForm.appendChild(mapInput3);

    const mapInput4 = document.createElement('input');
    mapInput4.type = 'hidden';
    mapInput4.name = 'numeroRapporto';
    mapInput4.value = data.numeroRapporto;
    mapForm.appendChild(mapInput4);

    const mapInput5 = document.createElement('input');
    mapInput5.type = 'hidden';
    mapInput5.name = 'enteRapporto';
    mapInput5.value = data.enteRapporto;
    mapForm.appendChild(mapInput5);

    const mapInput6 = document.createElement('input');
    mapInput6.type = 'hidden';
    mapInput6.name = 'tipoEntita';
    mapInput6.value = data.tipoEntita;
    mapForm.appendChild(mapInput6);

    const mapInput7 = document.createElement('input');
    mapInput7.type = 'hidden';
    mapInput7.name = 'sottotipoEntita';
    mapInput7.value = data.sottotipoEntita;
    mapForm.appendChild(mapInput7);


    document.body.appendChild(mapForm);


    mapForm.submit();

    // return inputData.callbackUrl + data;

  }
}
