import { Injectable } from '@angular/core';
import { InputData } from '../models/input-data';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MockDataService {

  constructor(private httpClient: HttpClient) { }


  private inputData = 'assets/mockData/sampleInput.json';

  public loadMockInputData(): Observable<InputData> {
    return this.httpClient.get<InputData>(this.inputData);
  }

}
