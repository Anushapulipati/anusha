import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { UrlProviderService } from './url-provider.service';
import { UserVm } from '../models/user-vm.model';

@Injectable({
  providedIn: 'root'
})
export class TopbarService {

  constructor(
    private httpClient: HttpClient,
    private urlProviderService: UrlProviderService
  ) { }

  public topHeaderiformativa(userId: string): Observable<UserVm> {
    const params = new HttpParams();
    const parameters = params.append('userId', userId);
    return this.httpClient.get<UserVm>(this.urlProviderService.getLoggedInUserDetails, { params: parameters });
  }
}
