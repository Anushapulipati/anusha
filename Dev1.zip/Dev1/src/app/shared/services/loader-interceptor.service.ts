import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { PricelabInterceptorService } from 'pricelab-angular-library';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable()
export class LoaderInterceptorService implements HttpInterceptor {

  constructor(
    private pricelabInterceptorService: PricelabInterceptorService
  ) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    var ignoreInterceptor = false;
    if (req.params.get('ignoreInterceptor') === 'true') {
      ignoreInterceptor = true;
      req.params.delete('ignoreInterceptor');
    }
    if (!ignoreInterceptor) {
      req = this.pricelabInterceptorService.modifyRequest(req);
      this.pricelabInterceptorService.showLoader();
    }
    return Observable.create(observer => {
      const subscription = next.handle(req).subscribe(event => {
        if (event instanceof HttpResponse) {
          this.pricelabInterceptorService.removeRequest(req);
          observer.next(event);
        }
      }, (err) => {
        this.pricelabInterceptorService.handleError(err, '');
        this.pricelabInterceptorService.removeRequest(req);
        observer.error(err);
      }, () => {
        this.pricelabInterceptorService.removeRequest(req);
        observer.complete();
      });
      return () => {
        this.pricelabInterceptorService.removeRequest(req);
        subscription.unsubscribe();
      };
    });
  }
}
