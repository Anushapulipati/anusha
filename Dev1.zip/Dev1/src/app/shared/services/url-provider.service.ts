import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UrlProviderService {

  constructor() { }

  public get getLoginUrl() {
    return environment.enviromentsUrl.api + '/login/authenticate';
  }

  public get getLoggedInUserDetails() {
    return `${environment.enviromentsUrl.api}/securityData/getLoggedInUserDetails`;
  }

  public get getGroupListByFamigliaCode() {
    return environment.enviromentsUrl.api + '/condizLettura/getGroupListByFamigliaCode';
  }

  public get getClientDataUrl() {
    return environment.enviromentsUrl.api + '/condizLettura/getClientDataByNdg';
  }

  public get getSearchDropDownList() {
    return environment.enviromentsUrl.api + '/search/getSearchDropDownList';
  }

  public get getAddAttachedFileUrl() {
    return environment.enviromentsUrl.api + '/deskWorkflow/addAttachedFile';
  }

  public get getRemoveAttachedFileUrl() {
    return environment.enviromentsUrl.api + '/deskWorkflow/removeAttachedFile';
  }

  public get getGroupDetail() {
    return environment.enviromentsUrl.api + '/condizLettura/getGroupDetail';
  }

  public get getLimitiByRapporto() {
    return environment.enviromentsUrl.api + '/condizLettura/getLimitiByRapporto';
  }

  public get getGestioneValoriCondizioniCalcolaTasso() {
    return environment.enviromentsUrl.api + '/condizLettura/getGestioneValoriCondizioniCalcolaTasso';
  }

  public get createProposalOnProsegui() {
    return environment.enviromentsUrl.api + '/navigate/createProposalOnProsegui';
  }
  public get getAutonomia() {
    return environment.enviromentsUrl.api + '/navigate/verificaAutonomia';
  }

  public get searchByFamigliaCode() {
    return environment.enviromentsUrl.api + '/search/searchByFamigliaCode';
  }

  public get archiveLoadSecurity() {
    return environment.enviromentsUrl.api + '/archive-doc/load-security';
  }

  public get confermaButton() {
    return environment.enviromentsUrl.api + '/navigate/confermaProposta';
  }

  public get mandatoryNote() {
    return environment.enviromentsUrl.api + '/navigate/checkNoteConditions';
  }

  public get getBoxCaratterizzazioniContent() {
    return environment.enviromentsUrl.api + '/navigate/getBoxCaratterizzazioniContent';
  }

  public get getERegoleGruppiAttributiUrl() {
    return environment.enviromentsUrl.api + '/condizLettura/getERegoleGruppiAttributiInquiryRead';
  }

  public get getHistoricalData() {
    return environment.enviromentsUrl.api + '/condizLettura/searchHistoricalData';
  }

  public get getGroupList() {
    return environment.enviromentsUrl.api + '/condizLettura/getGroupList';
  }

  public get getPaginaPerNdg() {
    return environment.enviromentsUrl.api + '/condizLettura/getPagina';
  }

  public get getdatiContestoRapportoInquiryCRReadData() {
    return environment.enviromentsUrl.api + '/condizLettura/getDatiContestoRapportoInquiryCRRead';
  }
}
