import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, RouterStateSnapshot, CanActivate, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(
    private router: Router,
  ) { }

  canActivate(): boolean {
    const isLoggedIn = this.getCookieByName('ENGINE_TOKEN');
    if (isLoggedIn) {
      return true;
    }
    this.router.navigate(['/login']);
    return false;
  }

  getCookieByName(name: string): string | boolean {
    const cookieNameLength = (name.length + 1);
    return document.cookie.split(';')
    .map(c => c.trim())
    .filter(cookie => {
      return cookie.substring(0, cookieNameLength) === `${name}=`;
    }).map(cookie => {
      return decodeURIComponent(cookie.substring(cookieNameLength));
    })[0] || false;
  }
}
