import { TitleHeaderComponent } from './components/title-header/title-header.component';
import { NgModule } from '@angular/core';
import { CommonModule, DatePipe, HashLocationStrategy, LocationStrategy } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HeaderComponent } from './components/header/header.component';
import { PropostaComponent } from './components/proposta/proposta.component';
import { PricelabAngularLibraryModule } from 'pricelab-angular-library';
import { LoaderInterceptorService } from './services/loader-interceptor.service';
import { HttpClientModule, HTTP_INTERCEPTORS, } from '@angular/common/http';
import { LoginComponent } from './components/login/login.component';
import { CredentialInterceptor } from '../credentialInterceptor';
import { LoginfailedComponent } from './components/loginfailed/loginfailed.component';
import { TranslateModule } from '@ngx-translate/core';
import { InsertionInputDataComponent } from './components/insertion-input-data/insertion-input-data.component';


@NgModule({
  declarations: [
    HeaderComponent,
    PropostaComponent,
    TitleHeaderComponent,
    LoginComponent,
    LoginfailedComponent,
    InsertionInputDataComponent
  ],
  imports: [
    CommonModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    PricelabAngularLibraryModule,
    HttpClientModule,
    TranslateModule
  ],
  exports: [
    NgbModule,
    PricelabAngularLibraryModule,
    FormsModule,
    ReactiveFormsModule,
    HeaderComponent,
    PropostaComponent,
    PricelabAngularLibraryModule,
    HttpClientModule,
    TitleHeaderComponent,
    TranslateModule
  ],
  providers: [
    { provide: LocationStrategy, useClass: HashLocationStrategy },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: LoaderInterceptorService,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: CredentialInterceptor,
      multi: true
    },
    DatePipe
  ],
})
export class SharedModule { }



