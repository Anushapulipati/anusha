import { Component, OnInit, OnDestroy, Input, Output } from '@angular/core';
import { InputData } from 'src/app/shared/models/input-data';
import { CondizioniService } from '../../services/condizioni.service';
import { DatiCliente } from 'src/app/shared/models/dati-cliente';
import { Caratterizzazioni } from 'src/app/shared/models/caratterizzazioni';
import { CaratterizzazioniInputVm } from 'src/app/shared/models/caratterizzazioniInput';
import { TranslateService } from '@ngx-translate/core';
import { GoBackService } from 'src/app/shared/services/go-back.service';
import { DatiContestoRapportoInquiryCRReadInput } from 'src/app/shared/models/datiContestoRapportoInquiryCRReadInput';
import { DatiContestoRapportoInquiryCRReadOutput } from 'src/app/shared/models/datiContestoRapportoInquiryCRReadOutput';

@Component({
  selector: 'app-inserimento-deroghe-page',
  templateUrl: './inserimento-deroghe-page.component.html',
  styleUrls: ['./inserimento-deroghe-page.component.scss'],
})

export class InserimentoDeroghePageComponent implements OnInit, OnDestroy {
  ndg: string;
  naturaGiuridica: string;
  istituto: string;
  clientData: DatiCliente;
  loadFailure: boolean = false;
  showLoader: boolean = false;
  backGotoOtherApplication: boolean = false;
  private isAlive = true;
  datiContestoRapportoInquiryCRReadInput: DatiContestoRapportoInquiryCRReadInput = new DatiContestoRapportoInquiryCRReadInput();
  datiContestoRapportoInquiryCRReadoutput: DatiContestoRapportoInquiryCRReadOutput = new DatiContestoRapportoInquiryCRReadOutput();
  caratterizzazioni: Caratterizzazioni = new Caratterizzazioni();
  caratterizzazioniInput: CaratterizzazioniInputVm = new CaratterizzazioniInputVm();
  inserimentoValori: string;
  subTitle: string;
  constructor(
    private condizioniService: CondizioniService,
    private translate: TranslateService,
    private gobackService: GoBackService

  ) {
    translate.get('inserimento-deroga-page.INSERIMENTOVALORI').subscribe((message: string) => {
      this.subTitle = message;
    });
  }

  ngOnInit() {
    const inputData: InputData = JSON.parse(sessionStorage.getItem('inputData'));
    this.ndg = inputData.ndg;
    this.naturaGiuridica = inputData.naturaGiuridica;
    this.istituto = inputData.istitutoCodice;
    this.backGotoOtherApplication = inputData.openedByBstore;
    this.setValues(inputData);
    this.caricaDati();
    this.caricaCaratterizzazioni();
    this.getdatiContestoRapportoInquiryCRReadData();
  }

  setValues(inputData: InputData) {
    this.caratterizzazioniInput.istitutoCodice = inputData.istitutoCodice;
    this.caratterizzazioniInput.famigliaCodice = inputData.codiceFamiglia;
    this.caratterizzazioniInput.tipoEntita = inputData.tipoEntita;
    this.caratterizzazioniInput.sottotipoEntita = inputData.sottotipoEntita;
    this.caratterizzazioniInput.chiaveEntita = inputData.keyEntita;
    this.caratterizzazioniInput.enteCodice = inputData.enteCodice;
    this.caratterizzazioniInput.formaTecnica = inputData.formaTecnica;
    this.caratterizzazioniInput.ndg = inputData.ndg;
    //this.caratterizzazioniInput.groupCodice = inputData;
    this.caratterizzazioniInput.contoDiRegolamento = inputData.enteRapportoRegolamento + '/' + inputData.rapportoRegolamento;
    this.caratterizzazioniInput.funzione = 'INQ';
  }


  ngOnDestroy() {
    this.isAlive = false;
  }

  async caricaDati() {
    this.loadFailure = false;
    try {
      this.condizioniService.getClientData(this.ndg, this.naturaGiuridica, this.istituto).subscribe(datiCliente => {
        this.clientData = new DatiCliente(datiCliente.ndg, datiCliente.intestazione, datiCliente.codiceNaturaGiuridica, datiCliente.descrizioneNaturaGiuridica, datiCliente.dataNascitaApertura,
          datiCliente.codiceModelloServizio, datiCliente.descrizioneModelloServizio, datiCliente.codiceSegmentoRischio, datiCliente.descrizioneSegmentoRischio, datiCliente.codiceSottosegmento,
          datiCliente.codiceRatingUfficiale, datiCliente.descrizioneRatingUfficiale, datiCliente.codiceRatingAndamentale, datiCliente.descrizioneRatingAndamentale, datiCliente.codiceEnteRelazione,
          datiCliente.descrizioneEnteRelazione, datiCliente.codiceDirezioneTerritoriale, datiCliente.descrizioneDirezioneTerritoriale, datiCliente.codiceAreaCommerciale, datiCliente.descrizioneAreaCommerciale,
          datiCliente.portafoglio, datiCliente.segmentoCodice, datiCliente.segmentoDescrizione);
      }, () => {
        this.loadFailure = true;
      });
    } catch (error) {
      this.loadFailure = true;
      await this.handleError(error);
    }
  }

  async caricaCaratterizzazioni() {
    // this.caratterizzazioni.contoRegolamento = '00032/1023091849042';
    // this.caratterizzazioni.grazCode = '010';
    // this.caratterizzazioni.grazDescription = 'Graz';
    this.condizioniService.getBoxCaratterizzazioniContent(this.caratterizzazioniInput).subscribe((data) => {
      this.caratterizzazioni = data;
    }, (error) => {
      this.handleError(error);
    });
    // } catch (error) {
    //   await this.handleError(error);
    // }
  }

  async getdatiContestoRapportoInquiryCRReadData() {
      const date = new Date();
      this.datiContestoRapportoInquiryCRReadInput.datiRapportoIstitutoCodice = '05387';
      this.datiContestoRapportoInquiryCRReadInput.datiRapportoFamigliaCodice = 'CRITA';
      this.datiContestoRapportoInquiryCRReadInput.datiRapportoEnteCodice = '00032';
      this.datiContestoRapportoInquiryCRReadInput.datiRapportoAmbitoTipoEntitaCodice = 'RAP';
      this.datiContestoRapportoInquiryCRReadInput.datiRapportoAmbitoSottotipoEntitaCodice = 'CON';
      this.datiContestoRapportoInquiryCRReadInput.datiRapportoAmbitoChiaveEntita = '000000001381';
      this.datiContestoRapportoInquiryCRReadInput.data = date;
      this.condizioniService.getdatiContestoRapportoInquiryCRRead(this.datiContestoRapportoInquiryCRReadInput).subscribe((data) => {
      this.datiContestoRapportoInquiryCRReadoutput = data;
    }, (error) => {
      this.handleError(error);
    });
    }



  handleError(error: any) {
    // throw new Error('Method not implemented.');
  }


}
