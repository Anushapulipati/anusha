import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InserimentoDeroghePageComponent } from './inserimento-deroghe-page.component';
import { DatiClienteComponent } from '../../components/dati-cliente/dati-cliente.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { GruppiCondizioniComponent } from '../../components/gruppi-condizioni/gruppi-condizioni.component';
import { SidebarModule } from 'ng-sidebar';
import { HttpClientModule } from '@angular/common/http';
import { CondizioniService } from '../../services/condizioni.service';

describe('InserimentoDeroghePageComponent', () => {
  let component: InserimentoDeroghePageComponent;
  let fixture: ComponentFixture<InserimentoDeroghePageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatiClienteComponent, InserimentoDeroghePageComponent, GruppiCondizioniComponent],
      imports: [
        SharedModule,
        HttpClientModule,
        SidebarModule
      ],
      providers : [CondizioniService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InserimentoDeroghePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    fixture = TestBed.createComponent(InserimentoDeroghePageComponent);
    component = fixture.componentInstance;
    expect(component).toBeTruthy();
  });
});
