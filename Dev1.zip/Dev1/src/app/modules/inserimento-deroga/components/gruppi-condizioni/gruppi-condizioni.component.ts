import { Component, OnInit, ChangeDetectorRef, AfterContentChecked, OnDestroy, ViewChild } from '@angular/core';
import { CondizioniService } from '../../services/condizioni.service';
import { GruppoCondizioniVm, GroupConditionAttributeVm, SearchGroupCondizioniAttributeVm } from 'src/app/shared/models/gruppo-condizioni';
import { takeWhile, map } from 'rxjs/operators';
import { InputData } from 'src/app/shared/models/input-data';
import { GroupDetailInput } from 'src/app/shared/models/group-detail-input';
import { GroupDetail, CondizioneType, AttributoType, CalcolaTassoRequestVm } from 'pricelab-angular-library';
import { Limite } from 'pricelab-angular-library/lib/models/groupCondition/limite';
import { LimitiInput } from 'src/app/shared/models/limitiInput';
import { Router } from '@angular/router';
import { CreateAndVerifyProposal } from 'src/app/shared/models/create-check-proposal-input';
import { SelectByFamiglia } from 'src/app/shared/models/selectByFamiglia.model';
import { SearchType } from 'src/app/shared/enums/search.type';
import { TranslateService } from '@ngx-translate/core';
import { ListiniStoriciOutputVm } from 'pricelab-angular-library';
import { GruppiListInputVm } from 'src/app/shared/models/gruppi-list-io';
import { NgModel } from '@angular/forms';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-gruppi-condizioni',
  templateUrl: './gruppi-condizioni.component.html',
  styleUrls: ['./gruppi-condizioni.component.scss']
})
export class GruppiCondizioniComponent implements OnInit, AfterContentChecked, OnDestroy {
  famigliaDescription: string = "";
  private isAlive = true;
  private elem: HTMLElement;
  opened = true;
  mode = 'push';
  selectedGroup: GruppoCondizioniVm;
  groups: GruppoCondizioniVm[];
  groupConditionAttributes: GroupConditionAttributeVm[];
  historicalData: ListiniStoriciOutputVm[];
  searchValue: string;
  inputData: InputData;
  currentGroupDetailData: GroupDetail;
  gruppiInSessione: Map<string, GroupDetail>;
  limitiGruppo: Array<Limite>;
  setAutonomiaFlag = undefined;
  selectByFamiglia: SelectByFamiglia;
  isShowGruppiCondizioni: boolean;
  isGroupProtected: boolean;
  condizioniPerValoreFiltro: Map<string, number[]>;
  condizioniPerDecorrenzaFiltrate: Map<number, Number[]>;
  private gruppiModified: string[] = [];
  livelloUtente: number;

  @ViewChild('gruppoRef') gruppoRef: NgModel;

  constructor(
    private cdRef: ChangeDetectorRef,
    private condizioniService: CondizioniService,
    private router: Router,
    private translate: TranslateService,
    public datepipe: DatePipe
  ) {
    this.inputData = JSON.parse(sessionStorage.getItem('inputData'));
  }

  toggleSidePanel() {
    this.opened = !this.opened;
  }

  async selectdGroupConditionAttribute(selectedGroupConditionAttribute, isSearchResult) {
    await this.clearHighlighted();
    if (selectedGroupConditionAttribute) {
      if (selectedGroupConditionAttribute.groupCodes.length === 1) {
        const selectedGroup: GruppoCondizioniVm = {
          code: selectedGroupConditionAttribute.groupCodes[0],
          description: selectedGroupConditionAttribute.description,
          sigla: '',
          protected: false
        };
        this.selectedGroup = selectedGroup;
        this.selectGroup(selectedGroup, isSearchResult);
        this.applyClass(selectedGroupConditionAttribute, selectedGroupConditionAttribute.groupCodes[0]);
      } else {
        this.highlightSelectedGroups(selectedGroupConditionAttribute);
      }
    }
  }

  highlightSelectedGroups(selectedGroupConditionAttribute) {
    this.groups.forEach(group => {
      this.applyClass(selectedGroupConditionAttribute, group.code);
    });
  }

  applyClass(selectedGroupConditionAttribute, code) {
    const groupElement = document.getElementById(code);
    selectedGroupConditionAttribute.groupCodes.forEach(groupCode => {
      if (code === groupCode) {
        document.getElementById(code).classList.add('active');
      }
    });
  }

  async clearHighlighted() {
    const groups = (this.selectedGroup)
      ? this.groups.filter(group => group.code !== this.selectedGroup.code)
      : this.groups;
    if (groups) {
      groups.forEach(group => {
        document.getElementById(group.code).classList.remove('active');
      });
    }
  }

  selectGroup(selectedGroup, isSearchResult) {
    this.gruppoRef = null;
    this.selectedGroup = isSearchResult
      ? selectedGroup
      : this.groups.filter(group => group.code === selectedGroup.code)[0];
    this.getLimitiByRapporto(selectedGroup);
    this.isGroupProtected = selectedGroup.protected;
    if (isSearchResult) {
      this.toggleSidePanel();
    }
  }

  getLimitiByRapporto(selectedGroup: GruppoCondizioniVm) {
    if (selectedGroup.protected) {
      this.loadGruppo(selectedGroup.code);
    } else {
      const limitiInput = this.generateInputForLimitiService(selectedGroup.code);
      this.condizioniService.getLimitiByRapporto(limitiInput)
        .pipe(takeWhile(() => this.isAlive))
        .subscribe((response) => {
          this.limitiGruppo = response;
        }, (error) => {
          this.loadGruppo(selectedGroup.code);
        }, () => {
          this.loadGruppo(selectedGroup.code);
        });
    }
  }

  async reloadGruppiFromSession(gruppoCodice) {
    if (gruppoCodice) {
      this.gruppiInSessione = await this.getGruppiInSessione();
      this.gruppiInSessione.forEach(async gruppo => {
        if (gruppo.gruppoCodice === gruppoCodice) {
          this.gruppiInSessione.delete(gruppo.gruppoCodice);
        }
      });
      sessionStorage.setItem('gruppi', JSON.stringify(Array.from(this.gruppiInSessione)));
      this.loadGruppo(gruppoCodice);
      const index: number = this.gruppiModified.indexOf(gruppoCodice);
      if (index !== -1) {
        this.gruppiModified.splice(index, 1);
      }
    }
  }

  async loadGruppo(selectedGroupCode) {
    const request: GroupDetailInput = new GroupDetailInput();
    request.chiaveEntita = this.inputData.keyEntita;
    request.dataFine = new Date();
    request.dataInizio = new Date();
    request.enteCodice = this.inputData.enteCodice;
    request.famigliaCodice = this.inputData.codiceFamiglia;
    request.gruppoCodice = selectedGroupCode;
    request.istitutoCodice = this.inputData.istitutoCodice;
    request.sottotipoEntita = this.inputData.sottotipoEntita;
    request.tipoEntita = this.inputData.tipoEntita;
    this.currentGroupDetailData = null;
    this.gruppiInSessione = await this.getGruppiInSessione();
    if (this.gruppiInSessione.has(selectedGroupCode)) {
      this.currentGroupDetailData = this.gruppiInSessione.get(selectedGroupCode);
      if (this.currentGroupDetailData.gruppoFiltro) {
        this.condizioniService.getRegoleFiltri(this.currentGroupDetailData.gruppoCodice, this.inputData.codiceFamiglia,
          this.inputData.istitutoCodice).subscribe(result => {
            let regole: Map<string, number[]> = new Map<string, number[]>();
            result.forEach(regola => {
              if (regole.has(regola.valoreFiltro)) {
                regole.get(regola.valoreFiltro).push(regola.condzDaVisualizz);
              } else {
                let tmp: number[] = [];
                tmp.push(regola.condzDaVisualizz);
                regole.set(regola.valoreFiltro, tmp);
              }
            });
            this.condizioniPerValoreFiltro = regole;
          }, null, () => {
            this.condizioniPerDecorrenzaFiltrate = new Map<number, number[]>();
            this.initFiltro();
          });
      }
    }
    if (!this.currentGroupDetailData) {
      this.condizioniService.getGroupDetail(request)
        .pipe(takeWhile(() => this.isAlive))
        .subscribe(response => {
          // this.currentGroupDetailData = response;
          this.currentGroupDetailData = response;
        }, null, () => {
          if (this.currentGroupDetailData.gruppoFiltro) {
            this.condizioniService.getRegoleFiltri(this.currentGroupDetailData.gruppoCodice, this.inputData.codiceFamiglia,
              this.inputData.istitutoCodice).subscribe(result => {
                let regole: Map<string, number[]> = new Map<string, number[]>();
                result.forEach(regola => {
                  if (regole.has(regola.valoreFiltro)) {
                    regole.get(regola.valoreFiltro).push(regola.condzDaVisualizz);
                  } else {
                    let tmp: number[] = [];
                    tmp.push(regola.condzDaVisualizz);
                    regole.set(regola.valoreFiltro, tmp);
                  }
                });
                this.condizioniPerValoreFiltro = regole;
              }, null, () => {
                this.condizioniPerDecorrenzaFiltrate = new Map<number, number[]>();
                this.initFiltro();
              });
          }
        });
    }
  }

  /*this method makes the current line bold and underlined*/
  isActive(groupCode) {
    return (this.selectedGroup) ? this.selectedGroup.code === groupCode : false;
  }

  /*this method checks is desciption is truncated and allows tooltip */
  isTextOverflow(elementId: string): boolean {
    this.elem = document.getElementById(elementId);
    if (this.elem) {
      return (this.elem.offsetWidth < this.elem.scrollWidth);
    } else {
      return false;
    }
  }

  searchGroupCondizioniAttributes() {
    const searchData: SearchGroupCondizioniAttributeVm = {
      istitute: this.inputData.istitutoCodice,
      family: this.inputData.codiceFamiglia,
      entityType: this.inputData.enteCodice,
      entitySubType: this.inputData.sottotipoEntita,
      searchValue: this.searchValue
    };
    return this.condizioniService.searchGroupCondizioniAttribute(searchData)
      .pipe(map(groupCodes => this.mapGroupConditionAttributes(groupCodes)));
  }

  async saveGropuModified() {
    this.gruppiInSessione.set(this.currentGroupDetailData.gruppoCodice, this.currentGroupDetailData);
    sessionStorage.setItem('gruppi', JSON.stringify(Array.from(this.gruppiInSessione)));
  }

  async createProposalOnProsegui() {
    const proposalDetails = await this.prepareProposalData();
    this.condizioniService.createProposalOnProsegui(proposalDetails)
      .pipe(takeWhile(() => this.isAlive))
      .subscribe((proposalData: any) => {
        const proposalDataResponse = {
          inAutonomia: proposalData.inAutonomia,
          codiceProposta: proposalData.eventoProposta.propostaDto
            ? proposalData.eventoProposta.propostaDto.codiceProposta
            : '',
          codiceRelazioneProposta: proposalData.eventoProposta.propostaDto
            ? proposalData.eventoProposta.propostaDto.codiceRelazioneProposta
            : ''
        };
        sessionStorage.setItem('proposalData', JSON.stringify(proposalDataResponse));
        this.router.navigate(['/inserimento-conferma']);
      });
  }

  detectGroupRealChanges() {
    const gruppiDaRimuovere: Array<string> = [];
    if (this.gruppiInSessione) {
      this.gruppiInSessione.forEach(gruppo => {
        let changed = false;
        gruppo.elencoDecorrenze.forEach(decorrenza => {
          decorrenza.elencoCondizioniInProposta.forEach(condizione => {
            condizione.elencoOccorrenze.forEach(occorrenza => {
              occorrenza.elencoAttributi.forEach((attributo: any) => {
                if (attributo.changed) {
                  changed = true;
                }
              });
              if (!changed) {
                occorrenza.changed = false;
              }
            });
            if (!changed) {
              condizione.changed = false;
            }
          });
        });
        if (!changed) {
          gruppiDaRimuovere.push(gruppo.gruppoCodice);
        }
      });
      gruppiDaRimuovere.forEach(gruppoDaRimuovere => {
        this.gruppiInSessione.delete(gruppoDaRimuovere);
      });
      sessionStorage.setItem('gruppi', JSON.stringify(Array.from(this.gruppiInSessione)));
    }
  }

  async autonomiaBtn() {
    const proposalDetails = await this.prepareProposalData();
    this.condizioniService.getAutonomia(proposalDetails).subscribe(data => {
      this.setAutonomiaFlag = data;
    });
  }

  checkModifiedGroupForFuschiaColor() {
    const grpMap = this.getGruppiInSessione();
    this.gruppiModified = [];
    if (grpMap) {
      grpMap.forEach(gruppo => {
        this.gruppiModified.push(gruppo.gruppoCodice)
      })
    }
  }

  searchPopUpInformation(selectedCode: string): Promise<ListiniStoriciOutputVm[]> {
    const searchData = {
      istitute: this.inputData.istitutoCodice,
      family: this.inputData.codiceFamiglia,
      entityType: this.inputData.enteCodice,
      entitySubType: this.inputData.sottotipoEntita,
      searchValue: selectedCode
    };

    let promise: Promise<ListiniStoriciOutputVm[]> = new Promise((resolve, reject) => {
      this.condizioniService.searchHistoricalData(searchData)
        .pipe(takeWhile(() => this.isAlive)).toPromise().then(historicalData => {
          const historicalDataArray: ListiniStoriciOutputVm[] = [];
          historicalData.forEach(popUpData => {
            const line: ListiniStoriciOutputVm = new ListiniStoriciOutputVm();
            line.dataAsString = this.datepipe.transform(popUpData.dataDecorrenzaDA, 'dd/MM/yyyy');
            line.valore = popUpData.valore;

            historicalDataArray.push(line);
          });

          resolve(historicalDataArray);
        }).catch(err => console.log(err));
    });
    return promise;
  }

  async removeGruppiFromSession(gruppoCodice) {
    this.gruppiInSessione = await this.getGruppiInSessione();
    this.gruppiInSessione.forEach(async gruppo => {
      if (gruppo.gruppoCodice === gruppoCodice) {
        this.gruppiInSessione.delete(gruppo.gruppoCodice);
      }
    });
    sessionStorage.setItem('gruppi', JSON.stringify(Array.from(this.gruppiInSessione)));
    this.currentGroupDetailData = null;
    this.selectedGroup = null;
    this.detectGroupRealChanges();
    this.checkModifiedGroupForFuschiaColor();
  }

  async ngOnInit() {
    this.loadGroups();
    this.checkModifiedGroupForFuschiaColor();
  }

  ngOnDestroy() {
    this.isAlive = false;
  }

  ngAfterContentChecked() {
    this.cdRef.detectChanges();
  }

  private loadGroups() {
    const inputData: InputData = JSON.parse(sessionStorage.getItem('inputData'));
    this.prepareSelectByFamigliaInput(inputData);
    this.checkFamigliaGestita(this.selectByFamiglia);
  }

  private loadGroupListByFamigliaCode() {
    this.condizioniService.getGroupList(this.generateInputForGruppiList())
      .pipe(takeWhile(() => this.isAlive))
      .subscribe(async (result) => {
        this.groups = await this.mapGroups(result.gruppi);
        this.livelloUtente = await result.livello;
      }, (error) => {
        console.log(error);
      });
  }

  private mapGroups(groups) {
    return groups.map(group => {
      return {
        ...group,
        key: group.code,
        value: group.description,
      };
    });
  }

  private mapGroupConditionAttributes(groupConditionAttributes) {
    return groupConditionAttributes.map(groupConditionAttribute => {
      return {
        ...groupConditionAttribute,
        key: groupConditionAttribute.groupCodes,
        value: groupConditionAttribute.description + ' (' + SearchType[groupConditionAttribute.type] + ')',
      };
    });
  }


  private generateInputForLimitiService(codiceGruppo) {
    const limitiInput: LimitiInput = {
      istituto: this.inputData.istitutoCodice,
      famiglia: this.inputData.codiceFamiglia,
      gruppo: codiceGruppo,
      entita: {
        tipEntita: this.inputData.tipoEntita,
        subEntita: this.inputData.sottotipoEntita,
        chiaveEntita: this.inputData.keyEntita,
      },
      filiale: this.inputData.enteCodice,
      progressivo: this.livelloUtente,
    };
    return limitiInput;
  }

  private async prepareProposalData() {
    const gruppiInSessione = await this.getGruppiInSessione();
    const modifiedGroupList: GroupDetail[] = [];
    gruppiInSessione.forEach((data: any) => {
      modifiedGroupList.push(data);
    });
    const createVerifyProposal: CreateAndVerifyProposal = {
      istitutoCodice: this.inputData.istitutoCodice,
      famigliaCodice: this.inputData.codiceFamiglia,
      tipoEntita: this.inputData.tipoEntita,
      sottotipoEntita: this.inputData.sottotipoEntita,
      chiaveEntita: this.inputData.keyEntita,
      enteCodice: this.inputData.enteCodice,
      formaTecnica: this.inputData.formaTecnica,
      naturaGiuridica: this.inputData.naturaGiuridica,
      ndg: this.inputData.ndg,
      codicePropostaBstore: this.inputData.codicePropostaBstore,
      codiceProdotto: this.inputData.codiceProdotto,
      codicePropostaDesk: null,
      codiceRelazioneDesk: null
    };
    // this will be used to avoid genereting multiple proposal when coming back from page 2
    if (sessionStorage.getItem('proposalData')) {
      const proposalData = JSON.parse(sessionStorage.getItem('proposalData'));
      if (proposalData) {
        createVerifyProposal.codicePropostaDesk = proposalData.codiceProposta;
        createVerifyProposal.codiceRelazioneDesk = proposalData.codiceRelazioneProposta;
      }
    }
    return { creaVerifica: createVerifyProposal, modifiedGroupList };
  }

  private getGruppiInSessione(): Map<string, GroupDetail> {
    return new Map(JSON.parse(sessionStorage.getItem('gruppi')));
  }

  async prepareSelectByFamigliaInput(inputData: InputData) {
    this.selectByFamiglia = {
      ambitoIstitutoCodice: inputData.istitutoCodice,
      famigliaCodice: inputData.codiceFamiglia,
      ambitoEnteCodice: inputData.enteCodice,
      ambitoTipoEntitaCodice: inputData.tipoEntita,
      ambitoSottotipoEntitaCodice: inputData.sottotipoEntita,
      ambitoChiaveEntita: inputData.keyEntita,
      dataRiferimento: new Date(),
      funzione: "VAR",
      gruppoCodiceGruppo: "",
      formaTecnicaCodice: ""
    };
  }

  checkFamigliaGestita(selectByFamiligia: SelectByFamiglia) {
    this.condizioniService.searchByFamigliaCode(selectByFamiligia)
      .pipe(takeWhile(() => this.isAlive))
      .subscribe(data => {
        if (data && data[0]) {
          this.famigliaDescription = data[0].descrizione;
          this.loadGroupListByFamigliaCode();
          this.isShowGruppiCondizioni = true;
        } else {
          this.isShowGruppiCondizioni = false;
        }
      }, err => {
        console.log('err', err);
        this.isShowGruppiCondizioni = false;
      });
  }

  calcolaTasso(calcolaTassoReq: CalcolaTassoRequestVm) {
    calcolaTassoReq.keyEntita = this.inputData.keyEntita;
    calcolaTassoReq.filiale = this.inputData.enteCodice;
    this.condizioniService.getGestioneValoriCondizioniCalcolaTasso(calcolaTassoReq).subscribe(response => {
      this.currentGroupDetailData.elencoDecorrenze.forEach(decorrenza => {
        decorrenza.elencoCondizioniInProposta.forEach((condizione, index) => {
          if (condizione.codCondiz === calcolaTassoReq.condizione) {
            decorrenza.elencoCondizioniInProposta[index].elencoOccorrenze = response.elencoOccorrenze;
          }
        });
      });
    });
  }

  initFiltro() {
    if (this.currentGroupDetailData.gruppoFiltro) {
      this.currentGroupDetailData.elencoDecorrenze.forEach(decorrenza => {
        decorrenza.elencoCondizioniInProposta.forEach(condizione => {
          if (condizione.tipoCondizione === CondizioneType.S) {
            condizione.elencoOccorrenze.forEach(occorrenza => {
              occorrenza.elencoAttributi.forEach(attributo => {
                if (attributo.tipoFormatoAttributo === AttributoType.F) {
                  let tmp: number[] = [];
                  if (this.condizioniPerValoreFiltro.get(attributo.valAttrForm)) {
                    tmp = this.condizioniPerValoreFiltro.get(attributo.valAttrForm);
                  }
                  tmp.push(condizione.codCondiz);
                  this.condizioniPerDecorrenzaFiltrate.set(decorrenza.progressivoDecorrenza, tmp);
                }
              })
            });
          }
        })
      })
    }
  }

  private generateInputForGruppiList() {
    const gruppiList: GruppiListInputVm = {
      istituto: this.inputData.istitutoCodice,
      famiglia: this.inputData.codiceFamiglia,
      ente: this.inputData.enteCodice,
      entita: {
        tipEntita: this.inputData.tipoEntita,
        subEntita: this.inputData.sottotipoEntita,
        chiaveEntita: this.inputData.keyEntita,
      },
      formaTecnica: this.inputData.formaTecnica
    };
    return gruppiList;
  }

  disabilitaButton(): boolean {
    if (!this.gruppiInSessione || (this.gruppiInSessione && this.gruppiInSessione.size < 1)) {
      return true;
    }

    if (this.gruppoRef && !this.gruppoRef.valid) {
      // if (this.gruppiInSessione.has(this.currentGroupDetailData.gruppoCodice)) {}
      return true;
    }
    return false;
  }
}

