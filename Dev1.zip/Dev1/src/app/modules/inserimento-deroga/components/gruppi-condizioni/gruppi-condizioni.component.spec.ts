import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GruppiCondizioniComponent } from './gruppi-condizioni.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { HttpClientModule } from '@angular/common/http';
import { SidebarModule } from 'ng-sidebar';
import { CondizioniService } from '../../services/condizioni.service';
import { GruppoCondizioniVm } from 'src/app/shared/models/gruppo-condizioni';
import { observable, Observable } from 'rxjs';
import { By } from '@angular/platform-browser';

fdescribe('GruppiCondizioniComponent', () => {
  let component: GruppiCondizioniComponent;
  let fixture: ComponentFixture<GruppiCondizioniComponent>;
  let service: CondizioniService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [GruppiCondizioniComponent],
      imports: [
        SharedModule,
        HttpClientModule,
        SidebarModule
      ],
      providers: [CondizioniService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GruppiCondizioniComponent);
    component = fixture.componentInstance;
    service = TestBed.get(CondizioniService);
    component.condizioniGroup = [{ code: 'PSTAS', description: 'TASSO SCONTO', sigla: 'TASSO SCONTO', protected: false },
    { code: 'PBVRV', description: 'VALUTE SBF E MV SEPA B2B', sigla: 'VAL.SBF MV R V', protected: false },
    { code: 'PDCCA', description: 'COMMISSIONI DOPO INCASSO CAMBIALI', sigla: 'COMM.D.I. CAM.', protected: false }];
    component.selectedCondizioni = {
      code: 'PDCCA',
      description: 'COMMISSIONI DOPO INCASSO CAMBIALI',
      sigla: 'COMM.D.I. CAM.', protected: false
    };
    fixture.detectChanges();
  });

  fit('should create', () => {
    expect(component).toBeTruthy();
  });

  fit('should call searched function', () => {
    spyOn(component, 'searchCondizioni');
    component.searchCondizioni();
    expect(component.searchCondizioni).toHaveBeenCalled();
  });


  fit('should test creation of lisst of description passed to', () => {
    expect(fixture.debugElement.queryAll(By.css('li')).length).toBe(3);
  });

  fit('should set the object of selected condizioni', () => {
    const selectedCondizioniCode = {
      code: 'PDCCA', description: 'COMMISSIONI DOPO INCASSO CAMBIALI',
      sigla: 'COMM.D.I. CAM.', protected: false
    };
    spyOn(component, 'selectCondizioni');
    component.selectCondizioni(selectedCondizioniCode, false);
    fixture.detectChanges();
    expect(component.selectCondizioni).toHaveBeenCalled();
  });

  fit('check if is active cuurent one', () => {
    spyOn(component, 'isActive');
    component.isActive('PDCCA');
    fixture.detectChanges();
    expect(component.isActive).toHaveBeenCalledWith('PDCCA');
    expect(component.selectedCondizioni.code).toEqual('PDCCA');
  });

});
