import { Component, OnInit, Input } from '@angular/core';
import { ERapportiPaginaPerNdgClienteOutput } from 'src/app/shared/models/erapportipagina-output';
import { CondizioniService } from '../../services/condizioni.service';
import { ERapportiPaginaPerNdgClienteInput } from 'src/app/shared/models/erapportipagina-input';
import { ERapportiPerNdgClienteWBODatiVm } from 'src/app/shared/models/erapporti-perndg-clienteWBOdati-vm';
import { map } from 'rxjs/operators';
import { formatDate } from '@angular/common';

@Component({
  selector: 'app-erapporti-perndg',
  templateUrl: './erapporti-perndg.component.html',
  styleUrls: ['./erapporti-perndg.component.scss']
})
export class ErapportiPerndgComponent implements OnInit {
  erapportiperndg: ERapportiPaginaPerNdgClienteOutput = new ERapportiPaginaPerNdgClienteOutput();
  paginPerNdg: ERapportiPaginaPerNdgClienteInput = new ERapportiPaginaPerNdgClienteInput();
  columnName: Array<string>;

  constructor(private condizioniService: CondizioniService) {
    this.columnName = [
      'datiAnagraficiRapportoDatiAnagraficiClienteAssociatoIdentificativoNdg',
      'famigliaCodice',
      'servizioCodice',
      'ambitoEnteCodice',
      'numeroRapporto',
      'datiAnagraficiRapportoCategoriaContoCodice',
      'ambitoTipoEntitaCodice',
      'ambitoSottotipoEntitaCodice',
      'ambitoChiaveEntita',
      'direzioneTerritorialeDescrizione',
      'ambitoInizioValidita',
      'ambitoFineValidita',
      'datiOperativiRapportoDataApertura',
      'datiAnagraficiRapportoFormaTecnicaCodice'
    ];

    this.getPagina();
  }

  ngOnInit() {
  }


  getPagina() {
    this.paginPerNdg.datiRapportoIstitutoCodice = '05387';
    this.paginPerNdg.datiRapportoDatiAnagraficiRapportoDatiAnagraficiClienteIdentificativoNdg = '000155688';
    this.paginPerNdg.funzInput = 'I';

    this.condizioniService.getPaginaPerNdg(this.paginPerNdg).pipe(map((data: ERapportiPaginaPerNdgClienteOutput) => {
      data.elencoRapporti.forEach((metadata) => {
        metadata.ambitoInizioValidita = formatDate(metadata.ambitoInizioValidita, 'dd/MM/yyyy', 'en-US');
        metadata.ambitoFineValidita = formatDate(metadata.ambitoFineValidita, 'dd/MM/yyyy', 'en-US');
        metadata.datiOperativiRapportoDataApertura = formatDate(metadata.datiOperativiRapportoDataApertura, 'dd/MM/yyyy', 'en-EUR');
      });
      return data;
    })).subscribe((data) => {
      this.erapportiperndg = data;
    });

  }

}
