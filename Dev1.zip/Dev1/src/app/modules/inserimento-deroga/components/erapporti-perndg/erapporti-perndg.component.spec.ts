import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ErapportiPerndgComponent } from './erapporti-perndg.component';

describe('ErapportiPerndgComponent', () => {
  let component: ErapportiPerndgComponent;
  let fixture: ComponentFixture<ErapportiPerndgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ErapportiPerndgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErapportiPerndgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
