import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, Input } from '@angular/core';
import { CaratterizzaizoniComponent } from './caratterizzaizoni.component';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { Observable, of } from 'rxjs';
import { Caratterizzazioni } from 'src/app/shared/models/caratterizzazioni';
import { By } from '@angular/platform-browser';
import { CondizioniService } from '../../services/condizioni.service';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

const caratterizzazioni: Caratterizzazioni = {
  formaTecnica: ' string',
  graz: 'string',
  contoRegolamento: '00032/8930272099',
  grazCode: '000000000',
  grazDescription: 'CONTO CORRENTE ORDINARIO A NON CONSUMATORI',
  formaTecnicaCode: 'PF000',
  formaTecnicaDescription: 'FT SCONTO'
};

fdescribe('BoxCaratterizzaizoniComponent', () => {
  let component: CaratterizzaizoniComponent;
  let fixture: ComponentFixture<CaratterizzaizoniComponent>;
  let condizioniService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [CaratterizzaizoniComponent],
      // tslint:disable-next-line: deprecation
      imports: [TranslateModule.forRoot({
        loader: {
          provide: TranslateLoader,
          useClass: FakeLoader
        }
      }), FormsModule, NgbModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [CondizioniService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    condizioniService = jasmine.createSpyObj('CondizioniService', ['getBoxCaratterizzazioniContent']);

    TestBed.configureTestingModule({
      declarations: [CaratterizzaizoniComponent],
      providers: [
        { provide: CondizioniService, useValue: condizioniService }
      ]
    });
    fixture = TestBed.createComponent(CaratterizzaizoniComponent);
    component = fixture.componentInstance;
    component.caratterizzazioni = caratterizzazioni;
    fixture.detectChanges();
  });

  fit('should create', () => {
    component.caratterizzazioni = caratterizzazioni;
    fixture.detectChanges();
    expect(component).toBeTruthy();
  });

  fit('check value of textbox', () => {
    const inputBoxValue = '[000000000] CONTO CORRENTE ORDINARIO A NON CONSUMATORI';
    expect(fixture.debugElement.queryAll(By.css('input'))[1].nativeElement.value).toBe(inputBoxValue);
    expect(fixture.debugElement.queryAll(By.css('input'))[2].nativeElement.value).toBe('[PF000] FT SCONTO');
  });

  fit('should create multiple spy methods', () => {
    expect(condizioniService.getBoxCaratterizzazioniContent).toBeDefined();
  });

  fit('should track the invoked spy methods', () => {
    condizioniService.getBoxCaratterizzazioniContent();
    expect(condizioniService.getBoxCaratterizzazioniContent).toHaveBeenCalled();
  });
});
