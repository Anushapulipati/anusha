import { Component, OnInit, Input } from '@angular/core';
import { Caratterizzazioni } from 'src/app/shared/models/caratterizzazioni';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-caratterizzaizoni',
  templateUrl: './caratterizzaizoni.component.html',
  styleUrls: ['./caratterizzaizoni.component.scss']
})
export class CaratterizzaizoniComponent implements OnInit {

  @Input() caratterizzazioni: Caratterizzazioni;
  caratterTitle: string;

  constructor(private translate: TranslateService) {
    translate.get('inserimento-deroga-page.caratterizzazioniLabelList.Caratterizzazioni').subscribe((message: string) => {
      this.caratterTitle = message;
    });
  }

  ngOnInit() {

  }

  toggleAccordion($event) {
  }

}
