import { Component, OnInit, Input } from '@angular/core';
import { DatiContestoRapportoInquiryCRReadOutput } from 'src/app/shared/models/datiContestoRapportoInquiryCRReadOutput';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-dati-contesto-rapporto-inquiry-crread',
  templateUrl: './dati-contesto-rapporto-inquiry-crread.component.html',
  styleUrls: ['./dati-contesto-rapporto-inquiry-crread.component.scss']
})
export class DatiContestoRapportoInquiryCRReadComponent implements OnInit {

  @Input() datiContestoRapporto: DatiContestoRapportoInquiryCRReadOutput;
  open = false;
  datiContestoRapportoCRReadTitle: string;
  constructor(private translate: TranslateService) { 
    translate.get('inserimento-deroga-page.datiContestoRapportoInquiryCRReadLabelList.datiContestoRapportoCRReadTitle').subscribe((message: string) => {
      this.datiContestoRapportoCRReadTitle = message;
    });
  }

  ngOnInit() {
  }

  toggleAccordion($event) {
    this.open = !this.open;
  }


}
