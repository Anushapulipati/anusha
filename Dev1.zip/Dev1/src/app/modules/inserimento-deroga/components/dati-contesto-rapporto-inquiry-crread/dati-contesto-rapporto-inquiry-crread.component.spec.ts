import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatiContestoRapportoInquiryCRReadComponent } from './dati-contesto-rapporto-inquiry-crread.component';

describe('DatiContestoRapportoInquiryCRReadComponent', () => {
  let component: DatiContestoRapportoInquiryCRReadComponent;
  let fixture: ComponentFixture<DatiContestoRapportoInquiryCRReadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatiContestoRapportoInquiryCRReadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatiContestoRapportoInquiryCRReadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
