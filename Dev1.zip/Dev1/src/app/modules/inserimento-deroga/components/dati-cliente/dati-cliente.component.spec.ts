import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, Input } from '@angular/core';
import { DatiClienteComponent } from './dati-cliente.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { HttpClientModule } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { CondizioniService } from '../../services/condizioni.service';
import { DatiCliente } from 'src/app/shared/models/dati-cliente';
import { By } from '@angular/platform-browser';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

fdescribe('DatiClienteComponent', () => {
  let component: DatiClienteComponent;
  let fixture: ComponentFixture<DatiClienteComponent>;
  let condizioniService;
  const testResult: DatiCliente = new DatiCliente('013682965',
    'SGANZERLA AIM',
    'PF', '', '2018-12-05', '13', 'POE', '', '', '', '0', '', '0', '', '',
    'MODENA 11', 'MD-DREG',
    'DR EMILIA CENTRO', 'MO-AREA', 'AREA MANAGER MODENA CENTRO', 'PTF-PO-05387-0068-000100', '', '');

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [DatiClienteComponent],
      imports: [
        SharedModule,
        HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        }), FormsModule, NgbModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [CondizioniService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    condizioniService = jasmine.createSpyObj('CondizioniService', ['getClientData']);

    TestBed.configureTestingModule({
      declarations: [DatiClienteComponent],
      providers: [
        { provide: CondizioniService, useValue: condizioniService }
      ]
    });

    fixture = TestBed.createComponent(DatiClienteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  fit('calls the fake getSound() method created by createSpy()', () => {
    const b = new CondizioniService(null, null, null);
    b.getClientData = jasmine.createSpy();
    b.getClientData('', '', '');
    expect(b.getClientData).toHaveBeenCalled();
  });

  fit('calls the fake getSound() created by createSpy() with return value', () => {
    let b = new CondizioniService(null, null, null);
    b.getClientData = jasmine.createSpy().and.returnValue(testResult);
    component.toggleAccordion(null);
    expect(b.getClientData('', '', '')).toBe(testResult);
  });

  fit('should create multiple spy methods', () => {
    expect(condizioniService.getClientData).toBeDefined();
  });

  fit('should track the invoked spy methods', () => {
    condizioniService.getClientData();
    expect(condizioniService.getClientData).toHaveBeenCalled();
  });

  fit('should create multiple spy methods', () => {
    expect(condizioniService.getClientData).toBeDefined();
  });

  fit('should track the invoked spy methods', () => {
    condizioniService.getClientData();
    expect(condizioniService.getClientData).toHaveBeenCalled();
  });

  fit('should create', async(() => {
    component.clientData = testResult;
    fixture.detectChanges();
    expect(component).toBeTruthy();
    fixture.whenStable().then(() => {
      expect(fixture.debugElement.queryAll(By.css('input')).length).toBe(13);
    });
  }));

});
