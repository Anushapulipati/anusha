import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { LoaderService } from 'pricelab-angular-library';
import { DatiCliente } from 'src/app/shared/models/dati-cliente';
import { CondizioniService } from 'src/app/modules/inserimento-deroga/services/condizioni.service';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-dati-cliente',
  templateUrl: './dati-cliente.component.html',
  styleUrls: ['./dati-cliente.component.scss']
})
export class DatiClienteComponent implements OnInit {
  @Input() clientData: DatiCliente;
  @Input() loadFailure: boolean;
  @Output() caricaDati: EventEmitter<void> = new EventEmitter();
  open: boolean = false;
  datiTitle: string;
  ricaricaDati: string;

  constructor(private translate: TranslateService) {
    translate.get('inserimento-deroga-page.datiClienteLabelList.DatiCliente').subscribe((message: string) => {
      this.datiTitle = message;
    }),
      translate.get('inserimento-deroga-page.datiClienteLabelList.RicaricaDati').subscribe((message: string) => {
        this.ricaricaDati = message;
      });

  }

  ngOnInit() {
  }

  toggleAccordion($event) {
    this.open = !this.open;
  }

  rechargeClientData() {
    this.caricaDati.emit();
  }
}
