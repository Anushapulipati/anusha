import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InserimentoDerogaRoutingModule } from './inserimento-deroga-routing.module';
import { InserimentoDeroghePageComponent } from './pages/inserimento-deroghe-page/inserimento-deroghe-page.component';
import { DatiClienteComponent } from './components/dati-cliente/dati-cliente.component';
import { GruppiCondizioniComponent } from './components/gruppi-condizioni/gruppi-condizioni.component';
import { SidebarModule } from 'ng-sidebar';
import { SharedModule } from 'src/app/shared/shared.module';
import { CondizioniService } from 'src/app/modules/inserimento-deroga/services/condizioni.service';
import { GroupDetailInput } from 'src/app/shared/models/group-detail-input';
import { CaratterizzaizoniComponent } from './components/caratterizzaizoni/caratterizzaizoni.component';
import { ErapportiPerndgComponent } from './components/erapporti-perndg/erapporti-perndg.component';
import { DatiContestoRapportoInquiryCRReadComponent } from './components/dati-contesto-rapporto-inquiry-crread/dati-contesto-rapporto-inquiry-crread.component';
@NgModule({
  declarations: [
    InserimentoDeroghePageComponent,
    DatiClienteComponent,
    GruppiCondizioniComponent,
    CaratterizzaizoniComponent,
    ErapportiPerndgComponent,
    DatiContestoRapportoInquiryCRReadComponent
  ],
  imports: [
    CommonModule,
    InserimentoDerogaRoutingModule,
    SidebarModule.forRoot(),
    SharedModule
  ],
  providers: [
    CondizioniService,
    GroupDetailInput
  ]
})
export class InserimentoDerogaModule { }
