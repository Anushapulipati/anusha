import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { DatiCliente } from 'src/app/shared/models/dati-cliente';
import { GruppoCondizioniVm, GroupConditionAttributeVm } from 'src/app/shared/models/gruppo-condizioni';
import { Observable } from 'rxjs';
import { GroupDetailInput } from 'src/app/shared/models/group-detail-input';
import { GroupDetail, CalcolaTassoRequestVm, CalcolaTassoResponseVm } from 'pricelab-angular-library';
import { LimitiInput } from 'src/app/shared/models/limitiInput';
import { Limite } from 'pricelab-angular-library/lib/models/groupCondition/limite';
import { UrlProviderService } from '../../../shared/services/url-provider.service';
import { Famiglia } from 'src/app/shared/models/famiglia';
import { SelectByFamiglia } from 'src/app/shared/models/selectByFamiglia.model';
import { Caratterizzazioni } from 'src/app/shared/models/caratterizzazioni';
import { CaratterizzazioniInputVm } from 'src/app/shared/models/caratterizzazioniInput';
import { DatePipe } from '@angular/common';
import { ListiniStoriciOutputVm } from 'pricelab-angular-library';
import { RegoleGruppiAttributiVm } from 'src/app/shared/models/regole-gruppi-attributi-vm';
import { GruppiListInputVm, GruppiListOutputVm } from 'src/app/shared/models/gruppi-list-io';
import { ERapportiPaginaPerNdgClienteInput } from 'src/app/shared/models/erapportipagina-input';
import { ERapportiPaginaPerNdgClienteOutput } from 'src/app/shared/models/erapportipagina-output';
import { DatiContestoRapportoInquiryCRReadOutput } from 'src/app/shared/models/datiContestoRapportoInquiryCRReadOutput';
import { DatiContestoRapportoInquiryCRReadInput } from 'src/app/shared/models/datiContestoRapportoInquiryCRReadInput';

@Injectable()
export class CondizioniService {

  constructor(
    private http: HttpClient,
    private urlProvider: UrlProviderService,
    public datepipe: DatePipe
  ) { }

  getClientData(ndg: string, naturaGiuridica: string, identificativoIstituto: string): Observable<DatiCliente> {
    const params = new HttpParams().set('clientNdg', ndg).set('naturaGiuridicaCode', naturaGiuridica)
      .set('identificativoIstitutoCode', identificativoIstituto);
    return this.http.get<DatiCliente>(this.urlProvider.getClientDataUrl, { params });
  }

  getGroupListByFamigliaCode(codFamiglia: string, istituto: string): Observable<GruppoCondizioniVm[]> {
    const params = new HttpParams().set('codFamiglia', codFamiglia).set('istituto', istituto);
    return this.http.get<GruppoCondizioniVm[]>(this.urlProvider.getGroupListByFamigliaCode, { params });
  }

  searchGroupCondizioniAttribute(searchData) {
    const params = new HttpParams().set('istitute', searchData.istitute)
      .set('family', searchData.family)
      .set('entityType', searchData.entityType)
      .set('entitySubType', searchData.entitySubType)
      .set('search', searchData.searchValue);
    return this.http.get<GroupConditionAttributeVm[]>(this.urlProvider.getSearchDropDownList, { params });
  }

  getGroupDetail(groupRequetInput: GroupDetailInput): Observable<GroupDetail> {
    return this.http.post<GroupDetail>(this.urlProvider.getGroupDetail, groupRequetInput);
  }

  getLimitiByRapporto(limitiInput: LimitiInput): Observable<Limite[]> {
    return this.http.post<Limite[]>(this.urlProvider.getLimitiByRapporto, limitiInput);
  }

  searchByFamigliaCode(selectByFamiglia: SelectByFamiglia): Observable<Famiglia> {
    return this.http.post<Famiglia>(this.urlProvider.searchByFamigliaCode, selectByFamiglia);
  }

  createProposalOnProsegui(proposalDetails) {
    return this.http.post(this.urlProvider.createProposalOnProsegui, proposalDetails);
  }

  getAutonomia(proposalDetails): Observable<boolean> {
    return this.http.post<boolean>(this.urlProvider.getAutonomia, proposalDetails);
  }

  getRegoleFiltri(codiceGruppo: string, famiglia: string, istituto: string): Observable<RegoleGruppiAttributiVm[]> {
    const params = new HttpParams().set('codiceGruppo', codiceGruppo).set('famiglia', famiglia).set('istituto', istituto);
    return this.http.get<RegoleGruppiAttributiVm[]>(this.urlProvider.getERegoleGruppiAttributiUrl, { params });
  }
  getGestioneValoriCondizioniCalcolaTasso(calcolaTassoRequest: CalcolaTassoRequestVm): Observable<CalcolaTassoResponseVm> {
    return this.http.post<CalcolaTassoResponseVm>(this.urlProvider.getGestioneValoriCondizioniCalcolaTasso, calcolaTassoRequest);
  }

  searchHistoricalData(searchData): Observable<ListiniStoriciOutputVm[]> {
    const dateNow: Date = new Date();
    let day = dateNow.getDay();
    let month = dateNow.getMonth();
    // const dateString = dateNow.getFullYear() + '-' + ++month + '-' + ++day;
    const dateString: string = this.datepipe.transform(dateNow, 'yyyy-MM-dd');
    const params = new HttpParams().set('istituto', searchData.istitute)
      .set('dataRif', dateString)
      .set('codiceListino', searchData.searchValue);
    return this.http.get<ListiniStoriciOutputVm[]>(this.urlProvider.getHistoricalData, { params });
  }

  getBoxCaratterizzazioniContent(inputDetails: CaratterizzazioniInputVm): Observable<Caratterizzazioni> {
    return this.http.post<Caratterizzazioni>(this.urlProvider.getBoxCaratterizzazioniContent, inputDetails);
  }

  getGroupList(input: GruppiListInputVm): Observable<GruppiListOutputVm> {
    return this.http.post<GruppiListOutputVm>(this.urlProvider.getGroupList, input);
  }

  getPaginaPerNdg(input: ERapportiPaginaPerNdgClienteInput): Observable<ERapportiPaginaPerNdgClienteOutput> {
    return this.http.post<ERapportiPaginaPerNdgClienteOutput>(this.urlProvider.getPaginaPerNdg, input);
  }

  getdatiContestoRapportoInquiryCRRead(inputDetails: DatiContestoRapportoInquiryCRReadInput): Observable<DatiContestoRapportoInquiryCRReadOutput> {
    return this.http.post<DatiContestoRapportoInquiryCRReadOutput>(this.urlProvider.getdatiContestoRapportoInquiryCRReadData, inputDetails);
  }

}
