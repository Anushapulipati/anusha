import { TestBed } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CondizioniService } from './condizioni.service';

describe('CondizioniService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports: [HttpClientTestingModule],
    providers: [CondizioniService]
  }));

  it('should be created', () => {
    const service: CondizioniService = TestBed.get(CondizioniService);
    expect(service).toBeTruthy();
  });
});
