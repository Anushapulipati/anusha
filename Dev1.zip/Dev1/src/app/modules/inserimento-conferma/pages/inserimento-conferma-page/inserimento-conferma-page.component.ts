import { Component, OnInit } from '@angular/core';
import { NoteEAllegatiService } from '../../services/note-e-allegati.service';
import { ConfamaDetailsVm } from 'src/app/shared/models/conferma.response';
import { InputData } from 'src/app/shared/models/input-data';
import { UserVm } from 'src/app/shared/models/user-vm.model';
import { TranslateService } from '@ngx-translate/core';
import { MessageModel, PopUpDisplayService } from 'pricelab-angular-library';
import { environment } from 'src/environments/environment';
import { GoBackService } from 'src/app/shared/services/go-back.service';

@Component({
  selector: 'app-inserimento-conferma-page',
  templateUrl: './inserimento-conferma-page.component.html',
  styleUrls: ['./inserimento-conferma-page.component.scss']
})
export class InserimentoConfermaPageComponent implements OnInit {
  userFlag: boolean = false;
  noteConditionFlag: boolean;
  flag: boolean = false;

  confermaDetails: ConfamaDetailsVm = {
    codiceProposta: null,
    attachementList: [],
    note: null,
    naturaGiuridica: null,
    ndg: null
  };
  subTitle: string;
  constructor(
    private noteEAllegatiService: NoteEAllegatiService,
    private popUpDisplayService: PopUpDisplayService,
    private translate: TranslateService,
    private gobackService: GoBackService
  ) {
    translate.get('inserimento-deroga-conferma.INSERIMENTOINFORMAZIONI').subscribe((message: string) => {
      this.subTitle = message;
    });
  }

  ngOnInit() {
    const proposalData = JSON.parse(sessionStorage.getItem('proposalData'));
    const inputData: InputData = JSON.parse(sessionStorage.getItem('inputData'));
    const istitute = inputData.istitutoCodice;
    this.confermaDetails.codiceProposta = proposalData.codiceProposta;
    this.confermaDetails.naturaGiuridica = inputData.naturaGiuridica;
    this.confermaDetails.ndg = inputData.ndg;
    this.checkForMandatoryNote(istitute);
  }

  noteEAllegatiList(event) {
    if (!this.userFlag) {
      this.observeEvent(event);
    }
    this.confermaDetails = {
      ...this.confermaDetails,
      attachementList: event.noteEAllegatiList,
      note: event.propostaNote,
    };
  }

  observeEvent(event) {
    if (this.noteConditionFlag && event.propostaNote.length > 0) {
      this.flag = true;
    } else {
      this.flag = false;
    }
  }
  submitConferma() {
    this.noteEAllegatiService.submitConfermaButtonDetails(this.confermaDetails)
      .subscribe(
        result => {
          console.log('result', result);
          if (environment.showConfirmationPopup) {
            this.showConfermaPopUp();
          } else {
            this.gobackService.generateUrlBack(true);
          }
        }, err => {
          console.log(err);
        });
  }

  showConfermaPopUp() {
    const message: MessageModel = {
      title: 'Proposta Ok',
      message: 'Proposta ' + this.confermaDetails.codiceProposta + ' creata correttamente'
    };
    this.popUpDisplayService.display(message);
  }

  checkForMandatoryNote(istituto: string) {
    this.noteEAllegatiService.checkForMandatoryNote(istituto).subscribe(
      flag => {
        this.noteConditionFlag = flag;
        if (!this.noteConditionFlag) {
          this.flag = true;
          this.userFlag = true;
        }
      }, err => {
        console.log(err);
      });
  }
}
