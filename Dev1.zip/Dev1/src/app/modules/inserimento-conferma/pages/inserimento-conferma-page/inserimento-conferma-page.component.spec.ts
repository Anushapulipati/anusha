import { TitleHeaderComponent } from './../../../../shared/components/title-header/title-header.component';
import { HttpClientModule } from '@angular/common/http';
import { SharedModule } from './../../../../shared/shared.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { InserimentoConfermaPageComponent } from './inserimento-conferma-page.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('InserimentoConfermaPageComponent', () => {
  let component: InserimentoConfermaPageComponent;
  let fixture: ComponentFixture<InserimentoConfermaPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InserimentoConfermaPageComponent ],
      imports: [
        SharedModule,
        HttpClientModule
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InserimentoConfermaPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
