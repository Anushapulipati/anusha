import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InserimentoConfermaPageComponent } from './pages/inserimento-conferma-page/inserimento-conferma-page.component';
import { NoteEAllegatiComponent } from './components/note-e-allegati/note-e-allegati.component';
import { SimulazioneDerogaComponent } from './components/simulazione-deroga/simulazione-deroga.component';

const routes: Routes = [
  {
    path: '',
    component: InserimentoConfermaPageComponent,
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InserimentoConfermaRoutingModule { }
