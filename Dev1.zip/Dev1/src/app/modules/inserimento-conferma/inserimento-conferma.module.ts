import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from './../../shared/shared.module';
import { InserimentoConfermaRoutingModule } from './inserimento-conferma-routing.module';
import { InserimentoConfermaPageComponent } from './pages/inserimento-conferma-page/inserimento-conferma-page.component';
import { SimulazioneDerogaComponent } from './components/simulazione-deroga/simulazione-deroga.component';
import { NoteEAllegatiService } from './services/note-e-allegati.service';
import { NoteEAllegatiComponent } from './components/note-e-allegati/note-e-allegati.component';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoaderInterceptorService } from 'src/app/shared/services/loader-interceptor.service';
import { CondizioniService } from 'src/app/modules/inserimento-deroga/services/condizioni.service';
import { RiepilogoVariazioniComponent } from './components/riepilogo-variazioni/riepilogo-variazioni.component';

@NgModule({
  declarations: [
    InserimentoConfermaPageComponent,
    SimulazioneDerogaComponent,
    NoteEAllegatiComponent,
    RiepilogoVariazioniComponent
  ],
  imports: [
    CommonModule,
    InserimentoConfermaRoutingModule,
    SharedModule
  ],
  providers: [CondizioniService, NoteEAllegatiService,
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptorService, multi: true }],

  entryComponents: [
    InserimentoConfermaPageComponent
  ]

})
export class InserimentoConfermaModule { }
