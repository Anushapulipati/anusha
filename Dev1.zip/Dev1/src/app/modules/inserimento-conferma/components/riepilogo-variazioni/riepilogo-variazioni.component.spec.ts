import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RiepilogoVariazioniComponent } from './riepilogo-variazioni.component';

describe('DemoGruppoComponent', () => {
  let component: RiepilogoVariazioniComponent;
  let fixture: ComponentFixture<RiepilogoVariazioniComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RiepilogoVariazioniComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RiepilogoVariazioniComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
