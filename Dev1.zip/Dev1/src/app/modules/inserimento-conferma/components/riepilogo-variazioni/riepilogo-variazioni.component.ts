import { Component, OnInit } from '@angular/core';
import { GroupDetail } from 'pricelab-angular-library';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-riepilogo-variazioni',
  templateUrl: './riepilogo-variazioni.component.html',
  styleUrls: ['./riepilogo-variazioni.component.scss']
})
export class RiepilogoVariazioniComponent implements OnInit {
  gruppoList: GroupDetail[] = [];
  riepilogoVariazioni: string;
  constructor(private translate: TranslateService) {
    translate.get('inserimento-deroga-conferma.RiepilogoVariazioni').subscribe((message: string) => {
      this.riepilogoVariazioni = message;
    });
  }
  counter = 0;
  ngOnInit() {
    const mappaGruppi: Map<string, GroupDetail> = this.getGruppiInSessione();

    mappaGruppi.forEach(groupDetails => {
      this.gruppoList.push(groupDetails);
    });

  }

  private getGruppiInSessione(): Map<string, GroupDetail> {
    return new Map(JSON.parse(sessionStorage.getItem('gruppi')));
  }


  toggleAccordion($event) {
  }



}
