import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SimulazioneDerogaComponent } from './simulazione-deroga.component';
import { By } from '@angular/platform-browser';

describe('SimulazioneDerogaComponent', () => {
  let component: SimulazioneDerogaComponent;
  let fixture: ComponentFixture<SimulazioneDerogaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SimulazioneDerogaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SimulazioneDerogaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should have content in left ', () => {
    const leftlabel = fixture.debugElement.query(By.css('.alignleft')).nativeElement;
    expect(leftlabel.innerHTML).not.toBeNull();
    expect(leftlabel.innerHTML.length).toBeGreaterThan(0);
  });
  it('should have content in right ', () => {
    const rightlabel = fixture.debugElement.query(By.css('.align_right_if')).nativeElement;
    expect(rightlabel.innerHTML).not.toBeNull();
    expect(rightlabel.innerHTML.length).toBeGreaterThan(0);

  });
  it('should have content in right ', () => {
    const rightlabel = fixture.debugElement.query(By.css('.align_right_else')).nativeElement;
    expect(rightlabel.innerHTML).not.toBeNull();
    expect(rightlabel.innerHTML.length).toBeGreaterThan(0);

  });

});
