import { Component, OnInit } from '@angular/core';
import { SetStorageService } from 'src/app/shared/services/set-storage.service';

@Component({
  selector: 'app-simulazione-deroga',
  templateUrl: './simulazione-deroga.component.html',
  styleUrls: ['./simulazione-deroga.component.scss']
})
export class SimulazioneDerogaComponent implements OnInit {

  constructor(public storageService: SetStorageService) { }

  ngOnInit() { }

}
