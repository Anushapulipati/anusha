import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { NoteEAllegati } from '../../../../shared/models/note-e-allegati.model';
import { NoteEAllegatiService } from 'src/app/modules/inserimento-conferma/services/note-e-allegati.service';
import { BpertwainIntegrationService } from '../../services/bpertwain-integration.service';
import { SecurityModel } from 'src/app/shared/models/doc/security.model';
import { MetadataDocInputModel } from 'src/app/shared/models/doc/metadata.doc.model';
import { environment } from 'src/environments/environment';
import { UrlProviderService } from 'src/app/shared/services/url-provider.service';
import { InputData } from 'src/app/shared/models/input-data';
import { AddAllAllegatiFileNetModel } from 'src/app/shared/models/doc/add.all.allegati.file.net.model';
import { PricelabInterceptorService } from 'pricelab-angular-library';

@Component({
  selector: 'app-note-e-allegati',
  templateUrl: './note-e-allegati.component.html',
  styleUrls: ['./note-e-allegati.component.scss']
})
export class NoteEAllegatiComponent implements OnInit {
  @Output() noteEAllegatiOutputList: any = new EventEmitter();
  fileName: string;
  dateNow: Date = new Date();
  date = `${this.dateNow.getDay()}/${this.dateNow.getMonth()}/${this.dateNow.getFullYear()}`;
  propostaCodeDesk: string;
  propostaNote: string;
  noteEAllegatiList: Array<NoteEAllegati> = [];

  constructor(private noteEAllegatiService: NoteEAllegatiService, private bpertwainService: BpertwainIntegrationService, private pricelabInterceptorService: PricelabInterceptorService) { }

  getFileName(event: any) {
    this.pricelabInterceptorService.showLoader();
    this.addFileToDeskWorkFlow(event.target.files[0]);
  }

  removeFile(noteEAllegati: NoteEAllegati) {
    if (!environment.bpertwain.useMock) {
      this.noteEAllegatiService.removeFile(this.propostaCodeDesk, noteEAllegati.idFilenet).subscribe(() => {
        this.noteEAllegatiList.splice(this.noteEAllegatiList.indexOf(noteEAllegati), 1);
      }, () => { });
    } else {
      this.noteEAllegatiList.splice(this.noteEAllegatiList.indexOf(noteEAllegati), 1);
    }
  }

  ngOnInit() {
    const proposalData = JSON.parse(sessionStorage.getItem('proposalData'));
    this.propostaCodeDesk = proposalData.codiceProposta;
  }
  prepareOutputData() {
    const prepareOutputData = {
      propostaNote: this.propostaNote ? this.propostaNote : '',
      noteEAllegatiList: this.noteEAllegatiList.map((attachment: NoteEAllegati) => attachment.idFilenet)
    };
    this.noteEAllegatiOutputList.emit(prepareOutputData);
  }

  private addFileToDeskWorkFlow(attachedFile: File) {
    // first call bpertwain for get the idFilenet, then call the service /deskWorkflow/addAttachedFile
    this.noteEAllegatiService.archiveLoadSecurity().subscribe((security: SecurityModel) => {
      const metadata: MetadataDocInputModel[] = this.createMetadataList();
      security.host = environment.bpertwain.host;
      this.pricelabInterceptorService.showLoader();
      this.bpertwainService.uploadDocument(attachedFile.name, 'BperProposta', attachedFile, metadata, security)
        .then((docUrl) => {
          const input: AddAllAllegatiFileNetModel = new AddAllAllegatiFileNetModel();
          input.proposalCodeDesk = this.propostaCodeDesk;
          input.fileName = attachedFile.name;
          input.idFilenet = docUrl;
          input.metaDataList = metadata;

          if (!environment.bpertwain.useMock) {
            this.noteEAllegatiService.attachFile(input).subscribe(() => {
              const noteEAllegati = new NoteEAllegati(this.noteEAllegatiList.length + 1, attachedFile.name, docUrl);
              this.noteEAllegatiList.unshift(noteEAllegati);
              this.pricelabInterceptorService.hideLoader();
            }, () => { });
          } else {
            const noteEAllegati = new NoteEAllegati(this.noteEAllegatiList.length + 1, attachedFile.name, docUrl);
            this.noteEAllegatiList.unshift(noteEAllegati);
            this.pricelabInterceptorService.hideLoader();

          }
        }).catch((error: any) => {
          console.error('Error during archiving pdf: ', error);
        });
    });
  }

  private createMetadataList(): MetadataDocInputModel[] {
    const result: MetadataDocInputModel[] = [];
    const inputData: InputData = JSON.parse(sessionStorage.getItem('inputData'));
    if (inputData) {
      result.push({
        dataType: 'string',
        dataTypeFormat: '',
        name: 'ABI',
        value: [inputData.istitutoCodice]
      });
      result.push({
        dataType: 'string',
        dataTypeFormat: '',
        name: 'NDG',
        value: [inputData.ndg]
      });
      result.push({
        dataType: 'string',
        dataTypeFormat: '',
        name: 'CODICE_RACCOGLITORE',
        value: []
      });
      result.push({
        dataType: 'string',
        dataTypeFormat: '',
        name: 'CATEGORIA_RAPPORTO',
        value: ['']
      });
      result.push({
        dataType: 'string',
        dataTypeFormat: '',
        name: 'FILIALE_RAPPORTO',
        value: [inputData.enteCodice]
      });
      result.push({
        dataType: 'string',
        dataTypeFormat: '',
        name: 'NUMERO_RAPPORTO',
        value: [inputData.keyEntita]
      });
      result.push({
        dataType: 'string',
        dataTypeFormat: '',
        name: 'SERVIZIO_RAPPORTO',
        value: ['']
      });
      result.push({
        dataType: 'string',
        dataTypeFormat: '',
        name: 'NUMERO_PROPOSTA',
        value: [this.propostaCodeDesk]
      });
      return result;
    } else {
      console.error('Error during create metadata inputData: ', inputData);
      return null;
    }
  }

}
