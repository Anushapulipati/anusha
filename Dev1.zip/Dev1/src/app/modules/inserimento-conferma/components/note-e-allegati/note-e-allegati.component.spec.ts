import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { NoteEAllegatiComponent } from './note-e-allegati.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { NoteEAllegatiService } from '../../services/note-e-allegati.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NoteEAllegati } from 'src/app/shared/models/note-e-allegati.model';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';

describe('NoteEAllegatiComponent', () => {
  let component: NoteEAllegatiComponent;
  let fixture: ComponentFixture<NoteEAllegatiComponent>;
  let element;
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        FormsModule,
        HttpClientTestingModule
      ],
      declarations: [ NoteEAllegatiComponent ],
      schemas : [CUSTOM_ELEMENTS_SCHEMA],
      providers : [NoteEAllegatiService , HttpClient]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NoteEAllegatiComponent);
    component = fixture.componentInstance;
    element = fixture.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should be able to call service to attach a file', () => {
    fixture = TestBed.createComponent(NoteEAllegatiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    const service: NoteEAllegatiService = TestBed.get(NoteEAllegatiService);
    spyOn(service, 'attachFile').and.callThrough();
    component.addFileToDeskWorkFlow(null);
    expect(service.attachFile).toHaveBeenCalled();
  });

  it('should be able to call service to remove a file', () => {
    fixture = TestBed.createComponent(NoteEAllegatiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    const service: NoteEAllegatiService = TestBed.get(NoteEAllegatiService);
    spyOn(service, 'removeFile').and.callThrough();
    const allegati = new NoteEAllegati(1, 'Test.txt', '45672798');
    component.noteEAllegatiList.push(allegati);
    component.removeFile(allegati);
    expect(service.removeFile).toHaveBeenCalled();
  });

  it('should be able to attach a file', () => {
    fixture = TestBed.createComponent(NoteEAllegatiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    const client: HttpClient = TestBed.get(HttpClient);
    spyOn(client, 'post').and.returnValue(of('45672798'));
    const file = new File(['3555'], 'test-file.jpg', null);
    component.addFileToDeskWorkFlow(file);
    expect(component.noteEAllegatiList.length).toEqual(1);
  });

  it('should be able to remove a file', () => {
    fixture = TestBed.createComponent(NoteEAllegatiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    const client: HttpClient = TestBed.get(HttpClient);
    spyOn(client, 'post').and.returnValue(of(true));
    const noteEAllegati = new NoteEAllegati(1, 'Test.txt', '45672798');
    component.noteEAllegatiList.push(noteEAllegati);
    component.removeFile(noteEAllegati);
    expect(component.noteEAllegatiList.length).toEqual(0);
  });
});
