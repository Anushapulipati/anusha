import { TestBed } from '@angular/core/testing';
import { NoteEAllegatiService } from './note-e-allegati.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { HttpClient } from '@angular/common/http';


describe('NoteEAllegatiService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    imports : [HttpClientTestingModule],
    providers : [NoteEAllegatiService, HttpClient]
  }));

  it('should be created', () => {
    const service: NoteEAllegatiService = TestBed.get(NoteEAllegatiService);
    expect(service).toBeTruthy();
  });

  it('should be able to attach a file', () => {
    let response;
    const service: NoteEAllegatiService = TestBed.get(NoteEAllegatiService);
    const client: HttpClient = TestBed.get(HttpClient);
    spyOn(client, 'post').and.returnValue(of('45672798'));
    service.attachFile('1234', null).subscribe(res => {
      response = res;
    });
    expect(response).toEqual('45672798');
  });

  it('should be able to remove a file', () => {
    let response;
    const service: NoteEAllegatiService = TestBed.get(NoteEAllegatiService);
    const client: HttpClient = TestBed.get(HttpClient);
    spyOn(client, 'post').and.returnValue(of(true));
    service.removeFile('1234', '45672798').subscribe(res => {
      response = res;
    });
    expect(response).toEqual(true);
  });
});
