import { TestBed } from '@angular/core/testing';

import { BpertwainMockService } from './bpertwain-mock.service';

describe('BpertwainMockService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BpertwainMockService = TestBed.get(BpertwainMockService);
    expect(service).toBeTruthy();
  });
});
