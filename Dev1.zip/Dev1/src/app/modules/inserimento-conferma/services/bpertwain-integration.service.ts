import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { BpertwainMockService } from './bpertwain-mock.service';
import { BpertwainJsService } from './bpertwain-js.service';
import { MetadataDocInputModel } from 'src/app/shared/models/doc/metadata.doc.model';
import { SecurityModel } from 'src/app/shared/models/doc/security.model';
import { UploadDocInputModel } from 'src/app/shared/models/doc/upload.doc.input.model';
import { UploadSuccessResultModel } from 'src/app/shared/models/doc/upload.success.result.model';
import { ArchiveDocInputModel } from 'src/app/shared/models/doc/archive.doc.input.model';
import { ArchiveSuccessResultModel } from 'src/app/shared/models/doc/archive.success.result.model';

@Injectable({
  providedIn: 'root'
})
export class BpertwainIntegrationService {

  constructor(private bpertwainMock: BpertwainMockService, private bpertwainJs: BpertwainJsService) { }

  private initBperTwain() {
    if (window['BPERTwain']) {
      return;
    }
    const euronovate = environment.bpertwain.useMock ? this.bpertwainMock.init() : this.bpertwainJs.init();
    window['BPERTwain'] = new euronovate.BPER.Engine({
      objectName: 'BPERTwain',
      logToConsole: true,
      logLevel: 0
    });

    console.log('BperTwain initialized');
  }

  private toBase64(file: Blob): Promise<string | ArrayBuffer> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = error => reject(error);
    });
  }

  public async uploadDocument(fileName: string, documentType: string, file: Blob, metadata: MetadataDocInputModel[], security: SecurityModel): Promise<string> {

    this.initBperTwain();

    const base64 = await this.toBase64(file);
    console.log('base64: ', base64);
    return new Promise((resolve, reject) => {

      const ltpa2Auth = JSON.stringify(security);
      const inputData: UploadDocInputModel = {
        base64: base64.toString(),
        fileName,
        ltpa2Auth,
        onError: error => reject(error),
        onSuccess: (uploadResult: UploadSuccessResultModel) => {

          if (uploadResult.wasCancelled) {
            reject(uploadResult.wasCancelled);
          } else {
            const archiveInput: ArchiveDocInputModel = {
              documentType,
              fileName,
              ltpa2Auth,
              metadata: JSON.stringify(metadata),
              ocrGuid: uploadResult.uploadResultList[0].ocrGuid,

              onError: error => reject(error),
              onSuccess: (archiveResult: ArchiveSuccessResultModel) => {
                if (archiveResult.wasCancelled) {
                  reject(archiveResult.wasCancelled);
                } else {
                  resolve(archiveResult.documentId);
                }
              },

              service: 'FILENET',
              type: 'ocr',
            };
            window['BPERTwain'].Archive(archiveInput);

          }

        }
      };

      window['BPERTwain'].UploadFileToOcr(inputData);
    });

  }

}
