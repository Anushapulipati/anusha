import { Injectable } from '@angular/core';
import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import { UrlProviderService } from '../../../shared/services/url-provider.service';
import { Observable } from 'rxjs';
import { SecurityModel } from 'src/app/shared/models/doc/security.model';
import { MetadataDocInputModel } from 'src/app/shared/models/doc/metadata.doc.model';
import { ConfermaPrapostaVm } from 'src/app/shared/models/confermaPraposta';
import { AddAllAllegatiFileNetModel } from 'src/app/shared/models/doc/add.all.allegati.file.net.model';
import { RemoveAllegatiFileNetInputVm } from 'src/app/shared/models/remove.allegati.file.net.model';

@Injectable()
export class NoteEAllegatiService {

  constructor(
    private http: HttpClient,
    private urlProvider: UrlProviderService) { }

  attachFile(input: AddAllAllegatiFileNetModel): Observable<void> {
    const params = new HttpParams();
    const parameters = params.append('input', JSON.stringify(input)).append('ignoreInterceptor', 'true');
    return this.http.post<void>(this.urlProvider.getAddAttachedFileUrl, { params: parameters });
  }

  removeFile(proposalCode: string, idFilenetValue: string): Observable<void> {
    const inputVm: RemoveAllegatiFileNetInputVm = {
      proposalCodeDesk: proposalCode,
      idFilenet: idFilenetValue
    };
    return this.http.post<void>(this.urlProvider.getRemoveAttachedFileUrl, inputVm);
  }

  archiveLoadSecurity(): Observable<SecurityModel> {
    const params = new HttpParams();
    const parameters = params.append('ignoreInterceptor', 'true');
    return this.http.get<SecurityModel>(this.urlProvider.archiveLoadSecurity, { params: parameters });
  }

  submitConfermaButtonDetails(confamaDetails): Observable<ConfermaPrapostaVm> {
    return this.http.post<ConfermaPrapostaVm>(this.urlProvider.confermaButton, confamaDetails);
  }

  checkForMandatoryNote(istituto: string): Observable<boolean> {
    const params = new HttpParams().set('istitute', istituto);
    return this.http.get<boolean>(this.urlProvider.mandatoryNote, { params });
  }


}
