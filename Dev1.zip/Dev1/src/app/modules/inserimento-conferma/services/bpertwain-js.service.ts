import { Injectable } from '@angular/core';
declare function bperTwainService(): any;
@Injectable({
  providedIn: 'root'
})
export class BpertwainJsService {

  constructor() { }

  init() {
    return bperTwainService();
  }
}