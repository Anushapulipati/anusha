import { TestBed } from '@angular/core/testing';

import { BpertwainIntegrationService } from './bpertwain-integration.service';

describe('BpertwainIntegrationService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BpertwainIntegrationService = TestBed.get(BpertwainIntegrationService);
    expect(service).toBeTruthy();
  });
});
