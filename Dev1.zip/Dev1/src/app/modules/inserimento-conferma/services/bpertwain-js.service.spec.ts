import { TestBed } from '@angular/core/testing';

import { BpertwainJsService } from './bpertwain-js.service';

describe('BpertwainJsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: BpertwainJsService = TestBed.get(BpertwainJsService);
    expect(service).toBeTruthy();
  });
});
