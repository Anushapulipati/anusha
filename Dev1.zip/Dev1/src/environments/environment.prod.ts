export const environment = {
  production: true,

  developmentMode: false,

  inputDataCompilationRequired: false,


  enviromentsUrl: {
    api: '/${giunzione}/api'
  },

  bpertwain: {
    useMock: false,
    host: 'os02.gbbper.priv'
  },

  showConfirmationPopup: false

};