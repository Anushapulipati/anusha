import { Component, OnInit, Input, EventEmitter, Output, ViewChild, AfterContentChecked } from '@angular/core';
import { NG_VALUE_ACCESSOR, NG_VALIDATORS, NgModel } from '@angular/forms';
import { DateModel } from '../../models/date-model';
import { NgbDateStruct, NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from './dateFormat';
import { isNumber, toInteger, padNumber } from './dateUtil';
import { faCalendar } from '@fortawesome/free-solid-svg-icons';

@Component({
  selector: 'pl-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.css'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: DatepickerComponent, multi: true },
    { provide: NG_VALIDATORS, useExisting: DatepickerComponent, multi: true },
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})
export class DatepickerComponent implements OnInit, AfterContentChecked {
  @ViewChild('dateModel') templateRef: NgModel;
  @Input() inline: true | false;
  @Input() title: string;
  @Input() name: string;
  @Input() label: string;
  @Input() errorMessage: string;
  @Output() change: EventEmitter<any> = new EventEmitter<any>();
  @Input() required: true | false;
  @Input() disabled: true | false;
  @Input() hint: string;
  @Input() placeholder: string;
  @Input() showErrorMessages: true | false = false;
  @Input() customValidation: true | false = false;
  @Input() showErrorOnLoad: true | false = false;
  @Output() errorChange: EventEmitter<any> = new EventEmitter<any>();
  onChange: (value: DateModel) => void;
  onTouched: () => void;
  errorArray: any[];
  dataModel: DateModel;
  faCalendar = faCalendar;

  constructor() { }

  ngOnInit() {
    if (this.showErrorOnLoad) {
      this.templateRef.control.markAsTouched({ onlySelf: true });
    }
  }

  ngAfterContentChecked() {
    this.populateErrorsArray();
    this.validate();
  }

  writeValue(value: DateModel) {
    this.dataModel = value;
  }

  registerOnTouched(onTouched: () => void) {
    this.onTouched = onTouched;
  }

  registerOnChange(onChange: any) {
    this.onChange = onChange;
  }

  populateErrorsArray() {
    this.errorArray = [];
    for (const key in this.templateRef.control.errors) {
      if (this.templateRef.control.errors.hasOwnProperty(key)) {
        this.errorArray.push(key);
      }
    }
  }

  validate() {
    if (this.customValidation === true) {
      const error = this.customValidation;
      this.templateRef.control.setErrors({ error: this.customValidation });
      this.templateRef.control.markAsTouched({ onlySelf: true });
    } else {
      if (this.templateRef.control.hasError('error')) {
        this.templateRef.control.setErrors(null);
        this.templateRef.control.markAsTouched({ onlySelf: true });
      }
    }

    if (this.errorArray !== undefined && this.errorArray !== null) {
      if (this.errorArray.length > 0) {
        this.errorChange.emit(this.errorArray);
        return this.templateRef.control.errors;
      } else {
        this.errorChange.emit(this.errorArray);
      }
    }
    return null;
  }

  modelChange(date: DateModel) {
    if (this.onChange !== undefined && this.onChange != null && date) {
      this.onChange(this.dataModel);
    }
    this.change.emit(this.dataModel);
  }

  formatModel(event) {
    if (event.target.value.length === 2 || event.target.value.length === 5) {
      if (event.key !== 'Backspace') {
        event.target.value = event.target.value + '/';
      }
    }
  }
}
