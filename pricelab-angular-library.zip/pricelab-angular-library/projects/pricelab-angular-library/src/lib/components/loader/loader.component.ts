import { Component, OnInit, Input } from '@angular/core';
import { Subscription } from 'rxjs';
import { LoaderService } from './loader.service';

@Component({
  selector: 'pl-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.css']
})
export class LoaderComponent implements OnInit {
  private subscription: Subscription;
  @Input() showLoader: boolean;
  @Input() width: number;
  @Input() height: number;
  @Input() size: 'default' | 'small';
  @Input() customClass: string;
  
  constructor(
    private loaderService: LoaderService
  ) { }

  ngOnInit() {
    if (this.size && this.size === 'default') {
      this.height = 5;
      this.width = 5;
    }
    if (!this.showLoader) {
      this.showLoader = false;
      this.subscription = this.loaderService.loaderState.subscribe((data) => {
        this.showLoader = data;
      });
    }
  }
   ngOnDestroy() {
     this.subscription.unsubscribe();
   }
}
