import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
	providedIn: 'root'
})

export class LoaderService {
	private loaderSubject = new Subject<boolean>();
	loaderState = this.loaderSubject.asObservable();
	constructor() { }
	show() {
		document.body.style.overflow = 'hidden';
		this.loaderSubject.next(true);
	}
	hide() {
		document.body.style.overflow = '';
		this.loaderSubject.next(false);
	}
}
