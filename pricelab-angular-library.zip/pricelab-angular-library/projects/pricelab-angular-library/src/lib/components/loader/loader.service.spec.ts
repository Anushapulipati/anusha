import { TestBed } from '@angular/core/testing';

import { LoaderService } from './loader.service';

describe('LoaderService', () => {
  let loaderService;
  beforeEach(() => TestBed.configureTestingModule({}));

  beforeEach(() => {
    loaderService = new LoaderService();
  });

  it('should be created', () => {
    const service: LoaderService = TestBed.get(LoaderService);
    expect(service).toBeTruthy();
  });

  it('if show method called loaderState should return true', () => {
    loaderService.show();
    loaderService.loaderState
    .subscribe((data) => {
      expect(data).toBe(true);
    });
  });

  it('if hide method called loaderState should return false', () => {
    loaderService.hide();
    loaderService.loaderState
    .subscribe((data) => {
      expect(data).toBe(false);
    });
  });
});
