import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoaderComponent } from './loader.component';
import { By } from '@angular/platform-browser';

describe('LoaderComponent', () => {
  let component: LoaderComponent;
  let fixture: ComponentFixture<LoaderComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoaderComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoaderComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create  in lib directory', () => {
    expect(component).toBeTruthy();
  });
  
  it('should check height and width when size is default',()=>{
    component.size="default";
    component.ngOnInit();
    expect(component.height).toEqual(5);
    expect(component.width).toEqual(5);
  })

  

  it('if showLoader is true  loader should be visible ', () => {
    component.showLoader = true;
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      const compiled = fixture.debugElement.nativeElement;
      if (compiled.querySelector('.span')) {
        expect(compiled.querySelector('.span')).toBe(true);
      }
    });
  });

  it('if showLoader is false loader should not be visible ', () => {
    component.showLoader = false;
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      const compiled = fixture.debugElement.nativeElement;
      if (compiled.querySelector('.span')) {
        expect(compiled.querySelector('.span')).toBe(false);
      }
    });
  });

  it('if custom class given it should be added to loader div', () => {
    component.customClass = 'text-primary';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(fixture.debugElement.query(By.css('.text-primary')).nativeElement).toBeTruthy();
    });
  });




});
