import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'pl-accordion',
  templateUrl: './accordion.component.html',
  styleUrls: ['./accordion.component.css']
})
export class AccordionComponent implements OnInit {
  @Input() title: string;
  @Input() isOpened: boolean = false;
  @Input() isDisabled: boolean;

  @Output() toggleEvent: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  ngOnInit() {
  }

  toggled(opened) {
    this.toggleEvent.next(!opened);
  }

  panelChange(event) {
    console.log(event);
  }

}
