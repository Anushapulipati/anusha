import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FileUploaderComponent } from './file-uploader.component';
import { By } from '@angular/platform-browser/src/dom/debug/by';
import { first } from 'rxjs/operators';

describe('FileUploaderComponent', () => {
  let component: FileUploaderComponent;
  let fixture: ComponentFixture<FileUploaderComponent>;
  let params;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FileUploaderComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FileUploaderComponent);
    component = fixture.componentInstance;
    params ={
      event:{

      }
    }
    fixture.detectChanges();
  });


  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the file selected date', () => {
    component.date = "11/06/2020";
    fixture.detectChanges();
    expect(component.date).toEqual("11/06/2020");
  });
  
  it('should render title in a b tag', () => {
    // const fixture = TestBed.createComponent(FileUploadComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('b').textContent).toContain('Allega');
  });

  it('testing call of function', async(()=> {
    spyOn(component,'attachFile');
    component.attachFile(params.event);
    expect(component.attachFile).toHaveBeenCalled();
  }));
});
