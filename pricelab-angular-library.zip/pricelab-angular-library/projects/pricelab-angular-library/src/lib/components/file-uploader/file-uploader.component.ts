import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'pl-file-uploader',
  templateUrl: './file-uploader.component.html',
  styleUrls: ['./file-uploader.component.css']
})
export class FileUploaderComponent implements OnInit {
  @Output() selectedFile = new EventEmitter<any>();
  // fileName:string;
  dateNow: Date = new Date();
  date = `${this.dateNow.getDay()}/${this.dateNow.getMonth()}/${this.dateNow.getFullYear()}`;
  // reader:FileReader;
  // url:string;
  constructor() { }

  attachFile(event:any) {
    // this.fileName = event.target.files[0].name;
    this.selectedFile.emit(event);
  }

  ngOnInit() {
  }
}
