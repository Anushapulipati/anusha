import { Component, OnInit, ViewChildren, QueryList } from '@angular/core';
import { NgModel, AbstractControl, ValidationErrors, NG_VALUE_ACCESSOR, NG_VALIDATORS } from '@angular/forms';
import { ValueAccessorBase } from '../../models/abstract-class/value-accessor';
import { Condizione } from '../../models/classes/condizione';
import { TipoFormatoAttributo } from '../../models/classes/tipo-formato-attributo.enum';

@Component({
  selector: 'app-lista-semplice',
  templateUrl: './lista-semplice.component.html',
  styleUrls: ['./lista-semplice.component.sass'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    multi: true,
    useExisting: ListaSempliceComponent
  }, {
    provide: NG_VALIDATORS,
    useExisting: ListaSempliceComponent,
    multi: true
  }]
})
export class ListaSempliceComponent extends ValueAccessorBase<Condizione> implements OnInit {

  @ViewChildren(NgModel) model: QueryList<NgModel>;

  tipoFormatoAttributo = TipoFormatoAttributo;

  constructor() {
    super();
  }

  validate(control: AbstractControl): ValidationErrors {
    let isNotValid: boolean;
    for (let unitModel of this.model.toArray()) {
      if (!unitModel.valid) {
        isNotValid = true;
      }
    }
    return isNotValid && {
      valid: false
    }
  }

  ngOnInit() {
  }

}
