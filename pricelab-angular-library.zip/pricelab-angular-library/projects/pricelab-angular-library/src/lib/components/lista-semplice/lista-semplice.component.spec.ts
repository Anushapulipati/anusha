import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaSempliceComponent } from './lista-semplice.component';

describe('ListaSempliceComponent', () => {
  let component: ListaSempliceComponent;
  let fixture: ComponentFixture<ListaSempliceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaSempliceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaSempliceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
