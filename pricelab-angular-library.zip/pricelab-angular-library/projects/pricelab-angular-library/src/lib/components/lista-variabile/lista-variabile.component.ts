import { Component, OnInit, QueryList, ViewChildren, AfterContentChecked } from '@angular/core';
import { AbstractControl, ValidationErrors, NgModel, NG_VALUE_ACCESSOR, NG_VALIDATORS } from '@angular/forms';
import { ValueAccessorBase } from '../../models/abstract-class/value-accessor';
import { Condizione } from '../../models/classes/condizione';
import { TipoFormatoAttributo } from '../../models/classes/tipo-formato-attributo.enum';
import { Occorrenza } from '../../models/classes/occorrenza';
import { Attributo } from '../../models/classes/attributo';

@Component({
  selector: 'app-lista-variabile',
  templateUrl: './lista-variabile.component.html',
  styleUrls: ['./lista-variabile.component.sass'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    multi: true,
    useExisting: ListaVariabileComponent
  }, {
    provide: NG_VALIDATORS,
    useExisting: ListaVariabileComponent,
    multi: true
  }]
})
export class ListaVariabileComponent extends ValueAccessorBase<Condizione> implements OnInit, AfterContentChecked {

  @ViewChildren(NgModel) model: QueryList<NgModel>;

  tipoFormatoAttributo = TipoFormatoAttributo;

  private occorrenzaDaAggiungere: Occorrenza;
  private validatedOnLoad: boolean;

  constructor() {
    super();
  }

  validate(control: AbstractControl): ValidationErrors {
    let isNotValid: boolean;
    let daNonValidare;

    if (this.occorrenzaDaAggiungere && this.occorrenzaDaAggiungere.valori) {
      daNonValidare = this.occorrenzaDaAggiungere.valori.length;
    }
    for (let index = 0; index < (this.model.toArray().length - daNonValidare); index++) {
      if (!this.model.toArray()[index].valid) {
        isNotValid = true;
      }
    }
    return isNotValid && {
      valid: false
    }
  }

  ngOnInit() {
  }

  ngAfterContentChecked(): void {
    if (this.value && !this.occorrenzaDaAggiungere) {
      this.inizializzaOccorrenza();
    }
  }

  ngAfterViewChecked(): void {
    if (this.model && this.model.length > 0 && !this.validatedOnLoad) {
      let caricati = false;
      this.model.forEach(unitModel => {
        if (unitModel.value && unitModel.dirty) {
          caricati = true;
        }
      });
      if (caricati) {
        Promise.resolve(null).then(() => {
          this.valida(null);
          this.validatedOnLoad = true;
        });
      }
    }
  }


  onSubmit() {
    console.log("LISTA-VARIABILE-MODEL");
    console.log(this.model);
    // console.log(this.value)
  }

  addRaw() {
    this.value.elencoOccorrenze.occorrenze.push(this.occorrenzaDaAggiungere);
    this.inizializzaOccorrenza();
  }

  removeRaw(index) {
    this.value.elencoOccorrenze.occorrenze.splice(index, 1);
  }

  inizializzaOccorrenza() {
    let temp: Occorrenza = this.value.elencoOccorrenze.occorrenze[0];

    let nuoviAttributi: Array<Attributo> = new Array<Attributo>();
    temp.valori.forEach(attributo => {
      let nuovoValore: Attributo = new Attributo("", attributo.tipoFormatoAttributo, [], attributo.codiceAttributo, attributo.descrizioneAttributo);
      nuoviAttributi.push(nuovoValore);
    });

    this.occorrenzaDaAggiungere = new Occorrenza(nuoviAttributi, this.value.elencoOccorrenze.occorrenze.length + 1);
  }

  // addColumn() {
  //   let temp: Array<Occorrenza> = this.value.elencoOccorrenze.occorrenze;
  //   let n = temp[0].valori.length + 1;
  //   temp.forEach(occorrenza => {
  //     let nuovoValore: Attributo = new Attributo("", this.tipoFormatoAttributo.N, [], "", "Attrinuto " + n);
  //     occorrenza.valori.push(nuovoValore);
  //   });
  // }
}
