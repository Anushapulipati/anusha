import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaVariabileComponent } from './lista-variabile.component';

describe('ListaVariabileComponent', () => {
  let component: ListaVariabileComponent;
  let fixture: ComponentFixture<ListaVariabileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaVariabileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaVariabileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
