import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaFissaComponent } from './lista-fissa.component';

describe('ListaFissaComponent', () => {
  let component: ListaFissaComponent;
  let fixture: ComponentFixture<ListaFissaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaFissaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaFissaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
