import { Component, OnInit, ViewChildren, QueryList } from '@angular/core';
import { NG_VALUE_ACCESSOR, NgModel, AbstractControl, ValidationErrors, NG_VALIDATORS } from '@angular/forms';
import { ValueAccessorBase } from '../../models/abstract-class/value-accessor';
import { Condizione } from '../../models/classes/condizione';
import { TipoFormatoAttributo } from '../../models/classes/tipo-formato-attributo.enum';

@Component({
  selector: 'app-lista-fissa',
  templateUrl: './lista-fissa.component.html',
  styleUrls: ['./lista-fissa.component.sass'],
  providers: [{
    provide: NG_VALUE_ACCESSOR,
    multi: true,
    useExisting: ListaFissaComponent
  }, {
    provide: NG_VALIDATORS,
    useExisting: ListaFissaComponent,
    multi: true
  }]
})
export class ListaFissaComponent extends ValueAccessorBase<Condizione> implements OnInit {

  @ViewChildren(NgModel) model: QueryList<NgModel>;

  private tipoFormatoAttributo = TipoFormatoAttributo;
  private validatedOnLoad: boolean = false;

  constructor() {
    super();
  }

  validate(control: AbstractControl): ValidationErrors {
    let isNotValid: boolean;

    for (let unitModel of this.model.toArray()) {
      if (!unitModel.valid) {
        isNotValid = true;
      }
    }

    return isNotValid && {
      valid: false
    }
  }

  ngOnInit() {
  }

  ngAfterViewChecked(): void {
    if (this.model && this.model.length > 0 && !this.validatedOnLoad) {
      let caricati = false;
      this.model.forEach(unitModel => {
        if (unitModel.value && unitModel.dirty) {
          caricati = true;
        }
      });
      if (caricati) {
        Promise.resolve(null).then(() => {
          this.valida(null);
          this.validatedOnLoad = true;
        });
      }
    }
  }


  onSubmit() {
    console.log("LISTA-FISSA-MODEL");
    console.log(this.model);
    // console.log(this.value)
  }
}
