import {Component, Input, OnInit, Output, EventEmitter, ViewEncapsulation, ViewChild} from '@angular/core';
import {Observable, Subject, merge} from 'rxjs';
import {debounceTime, distinctUntilChanged, map, filter} from 'rxjs/operators';
import { NgbTypeahead } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'pl-typeahead-input',
  templateUrl: './typeahead.component.html',
  styleUrls: ['./typeahead.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class TypeaheadComponent implements OnInit{
  @ViewChild('instance') instance: NgbTypeahead;
  @Input() listData;
  @Input() searchLabel: String;
  @Output() selectedValue: EventEmitter<String> = new EventEmitter<String>();
  focus$ = new Subject<string>();
  click$ = new Subject<string>();
  formatter = (result: string) => result.toUpperCase();
  
  public model: any;

  ngOnInit(){

  }
  inputFormatter = (x: {key: string}) => x.key;

  search = (text$: Observable<string>) => {
    const debouncedText$ = text$.pipe(debounceTime(200), distinctUntilChanged());
    const clicksWithClosedPopup$ = this.click$.pipe(filter(() => !this.instance.isPopupOpen()));
    const inputFocus$ = this.focus$;
    return merge(debouncedText$, inputFocus$, clicksWithClosedPopup$).pipe(
      map(term => (term === '' ? this.listData
        : this.listData.filter(v => v.key.toLowerCase().indexOf(term.toLowerCase()) > -1)).slice(0, 10))
    );
  }

  selectedItem(item){
    const value=item.item;
    this.selectedValue.emit(value.key);
    console.log('Sent Item '+value.key);
  }

}
