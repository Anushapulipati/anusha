import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { CUSTOM_ELEMENTS_SCHEMA, DebugElement } from '@angular/core';
import { NgbModule, NgbTypeaheadModule } from '@ng-bootstrap/ng-bootstrap';
import { TypeaheadComponent } from './typeahead.component';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';


describe('TypeaheadComponent', () => {
  let component: TypeaheadComponent;
  let fixture: ComponentFixture<TypeaheadComponent>;
  let links =
  [
    {
        "key": "Alabama",
        "value": "1"
    },
    {
        "key": "California",
        "value": "2"
    },
    {
        "key": "Delaware",
        "value": "3"
    },
    {
        "key": "Federated States Of Micronesia",
        "value": "4"
    },
    {
        "key": "Guam",
        "value": "5"
    },
    {
        "key": "Hawaii",
        "value": "6"
    },
    {
        "key": "Illinois",
        "value": "7"
    },
    {
        "key": "Kentucky",
        "value": "8"
    },
    {
        "key": "Louisiana",
        "value": "9"
    },
    {
        "key": "Marshall Islands",
        "value": "10"
    },
    {
        "key": "Nevada",
        "value": "11"
    },
    {
        "key": "Pennsylvania",
        "value": "12"
    },
    {
        "key": "Texas",
        "value": "12"
    }
  ];

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TypeaheadComponent ],
      imports:[NgbModule,FormsModule,NgbTypeaheadModule],
      schemas:[CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TypeaheadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should model be available to the custom formatter provided', async(() => {
    fixture = TestBed.createComponent(TypeaheadComponent);
    const el = fixture.nativeElement;
    const comp = fixture.componentInstance;
    expectInputValue(el, '');

    comp.model = null;
    fixture.detectChanges();
    fixture.whenStable()
        .then(() => {
          expectInputValue(el, '');

          comp.model = {key: 'text'};
          fixture.detectChanges();
          return fixture.whenStable();
        })
        .then(() => { expectInputValue(el, 'text'); });
  }));

  it('should be closed by default', () => {
    fixture = TestBed.createComponent(TypeaheadComponent);
    const compiled = fixture.nativeElement;
    expect(getWindow(compiled)).toBeNull();
  });

  it('should not be opened when the model changes', async(() => {
    fixture = TestBed.createComponent(TypeaheadComponent);
    const compiled = fixture.nativeElement;

    fixture.componentInstance.model = 'one';
    fixture.detectChanges();
    fixture.whenStable().then(() => { expect(getWindow(compiled)).toBeNull(); });
  }));

  it('should be closed when there no results', () => {
    fixture = TestBed.createComponent(TypeaheadComponent);
    const compiled = fixture.nativeElement;
    expect(getWindow(compiled)).toBeNull();
  });

  it('should work when returning null as results', async(() => {
    fixture = TestBed.createComponent(TypeaheadComponent);
    const compiled = fixture.nativeElement;

    fixture.whenStable().then(() => {
      sendInput('one').then(() => {    
        fixture.detectChanges();
        expect(getWindow(compiled)).toBeNull();
      });
    });
  }));


  it('check menu length when query input', async(() => {
    fixture = TestBed.createComponent(TypeaheadComponent);
    const compiled = fixture.nativeElement;
    fixture.componentInstance.listData=links;
    fixture.whenStable().then(() => {
      let input = fixture.debugElement.query(By.css('input'));
      input.nativeElement.value = 'c';
      fixture.detectChanges();
      expect(getWindowLinks(fixture.debugElement).length).toEqual(0);
    });
  }));

  it('should filter group conditions based on input', async(() => {
    const hostElement = fixture.nativeElement;
    fixture.componentInstance.listData=links;
    sendInput('ala').then(() => {    
        fixture.detectChanges();
        expect(fixture.nativeElement.querySelectorAll('.dropdown-item').length).toBe(1);
        expect(hostElement.textContent).toContain('Alabama');
    });
  }));

  it('selected item should be set on the input feild', async(() => {
    const hostElement = fixture.nativeElement;
    fixture.componentInstance.listData=links;
    sendInput('c').then(() => {    
        fixture.detectChanges();
        const typeaheadOptions = document.querySelectorAll('.dropdown-item');
        const optionToClick = typeaheadOptions[0] as HTMLElement;
        optionToClick.click();
        fixture.detectChanges();
        const inputElement = fixture.nativeElement.querySelector('input');
        expect(inputElement.value).toContain('California');
    });
  }));

    function sendInput(text: string) {
      let inputElement: HTMLInputElement;

      inputElement = fixture.nativeElement.querySelector('input');
      inputElement.focus();
      inputElement.value = text;
      inputElement.click();
      inputElement.dispatchEvent(new Event('input'));
      fixture.detectChanges();
      return fixture.whenStable();
    }

    function expectInputValue(element: HTMLElement, value: string) {
      expect(getNativeInput(element).value).toBe(value);
    }

    function getWindowLinks(element: DebugElement): DebugElement[] {
      return Array.from(element.queryAll(By.css('.dropdown-item')));
    }

    function getWindow(element): HTMLDivElement {
      return <HTMLDivElement>element.querySelector('.dropdown-menu');
    }

    function getNativeInput(element: HTMLElement): HTMLInputElement {
      return <HTMLInputElement>element.querySelector('input');
    }

});