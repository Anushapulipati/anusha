import {
  Component, Input, ElementRef, Renderer2, ViewChild,
  AfterContentChecked, AfterViewInit, EventEmitter, Output, OnInit, OnDestroy, ChangeDetectorRef,
} from '@angular/core';
import { NgModel, ControlValueAccessor, NG_VALUE_ACCESSOR, Validator, NG_VALIDATORS, ValidationErrors } from '@angular/forms';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { EventsModel } from '../../models/event-model';

@Component({
  selector: 'pl-input-type',
  templateUrl: './input-type.component.html',
  styleUrls: ['./input-type.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: ImportoInputBoxComponent, multi: true },
    { provide: NG_VALIDATORS, useExisting: ImportoInputBoxComponent, multi: true }
  ]
})
export class ImportoInputBoxComponent implements OnInit, AfterViewInit, AfterContentChecked, ControlValueAccessor, Validator, OnDestroy {

  @Input() required: true | false;
  @Input() disabled: true | false;
  @Input() readonly: true | false;
  @Input() maxImporto: any;
  @Input() minImporto: any;
  @Input() title: string;
  @Input() name: string;
  @Input() events: EventsModel[];
  @Input() label: string;
  @Input() errorMessage: string;
  @ViewChild('templateRef') templateRef: NgModel;
  errorArray: any[];
  dataModel: string;
  onChange: (value: string) => void;
  onTouched: () => void;
  @Output() errorChange: EventEmitter<any> = new EventEmitter<any>();
  @Output() amount: EventEmitter<any> = new EventEmitter<any>();
  @Input() decimal: boolean;
  @Input() hint: string;
  @Input() placeholder: string;
  @Input() showErrorMessages: boolean;
  @Input() showErrorOnLoad: true | false = false;
  @Input() emptyLabel: boolean;
  @Input() customValidation: boolean;
  suffix = '€';
  @Input() referance: any;
  pattern: string;
  
  constructor(
    public elRef: ElementRef,
    private renderer: Renderer2,
    private cdr: ChangeDetectorRef) {
    this.pattern = '^[$]{0,1}([0-9]+[,]?([0-9]?)+|[0-9]{1,3}([.][0-9]{3})*([,]?([0-9]?)+)?)$';
  }
  converted: boolean;
  valueSubscription: any;

  ngOnInit(): void {
    // if (this.referance.control) {
    //   this.referance = this.referance.control;
    // }
  }

  ngAfterViewInit() {
    if (this.events !== undefined && this.events != null && this.events.length > 0) {
      this.events.forEach(event => {
        this.renderer.listen(this.elRef.nativeElement.querySelector('input'), event.eventName, (evt) => {
          event.eventCallBack(this.elRef.nativeElement, evt);
        });
      });
    }
    this.cdr.detectChanges();
  }

  ngAfterContentChecked() {
   // this.populateErrorsArray();
    this.validate();
    this.minMaxCheck();
    this.populateErrorsArray();
    this.errorChange.emit(this.errorArray);
  }

  modelChange(event) {
    if (this.onChange !== undefined && this.onChange != null) {
      this.onChange(this.dataModel);
    }
  }
  
  minMaxCheck() {
    console.log(this.minImporto);
    if (this.minImporto && this.maxImporto) {
      if (!this.decimal) {
       
        if (this.dataModel !== '' && this.templateRef.control.dirty) {
          if ((this.minImporto.replace(new RegExp('[.]', 'g'), '').replace(',', '.') > this.toDecimal(this.dataModel)) ||
            (this.maxImporto.replace(new RegExp('[.]', 'g'), '').replace(',', '.') < this.toDecimal(this.dataModel))) {
            this.templateRef.control.setErrors({ formatError: true });
            //this.referance.setErrors({ formatError: true });
          } else {
            this.templateRef.control.setErrors(null);
            //this.referance.setErrors(null);
          }
        } else {
          this.templateRef.control.setErrors(null);
          //this.referance.setErrors(null);
        }
      } else {
        if (this.dataModel !== ''  && this.templateRef.control.dirty) {
          if ((this.minImporto) > this.toDecimal(this.dataModel) ||
            (this.maxImporto) < this.toDecimal(this.dataModel)) {
            this.templateRef.control.setErrors({ formatError: true });
            //this.referance.setErrors({ formatError: true });
          } else {
            this.templateRef.control.setErrors(null);
            //this.referance.setErrors(null);
          }
        } else {
          this.templateRef.control.setErrors(null);
          //this.referance.setErrors(null);
        }
      }
    }
  }

  populateErrorsArray() {
    this.errorArray = [];
    for (const key in this.templateRef.control.errors) {
      if (this.templateRef.control.errors.hasOwnProperty(key)) {
        this.errorArray.push(key);
      }
    }
  }

  writeValue(value: string) {
    if (!this.required && (value == null || value === '')) {
      this.dataModel = '';
    } else
      if (value) {
        this.dataModel = value;
        this.templateRef.control.markAsDirty();
        this.templateRef.control.markAsTouched();
        this.templateRef.control.setErrors(null);
        this.modifyField(this.dataModel.toString());

      }
  }

  registerOnTouched(onTouched: () => void) {
    this.onTouched = onTouched;
  }

  registerOnChange(onChange: any) {
    this.onChange = onChange;
  }

  validate() {
    if (this.referance) {
      if (this.customValidation) {
        this.referance.setErrors({ error: this.customValidation });
        this.errorMessage="enter valid value";
        this.referance.markAsTouched({ onlySelf: true });
        this.templateRef.control.setErrors({ error: this.customValidation });
        this.templateRef.control.markAsTouched({ onlySelf: true });
      } else {
        if (this.referance.hasError('error') && this.templateRef.control.hasError('error')) {
          this.referance.setErrors(null);
          this.referance.markAsTouched({ onlySelf: true });
          this.templateRef.control.setErrors(null);
          this.templateRef.control.markAsTouched({ onlySelf: true });
        }
      }
    }
    if (this.errorArray !== undefined && this.errorArray !== null) {
      if (this.errorArray.length > 0) {
        this.errorChange.emit(this.errorArray);
        return this.templateRef.control.errors;
      } else {
        this.errorChange.emit(this.errorArray);
      }
    }
    return null;
  }

  markTouched() {
    if (this.onTouched !== undefined && this.onTouched != null) {
      this.onTouched();
    }
  }

  toImporto(number) {
    let result;
    if (!this.templateRef.control.errors && this.dataModel !== undefined && this.dataModel !== null) {
      if (number.indexOf('.') > -1 || number.indexOf(',') > -1) {
        result =
          (new Intl.NumberFormat('it-IT', {
            style: 'currency', currency: 'EUR', useGrouping: true,
            maximumFractionDigits: 4
          }).format(parseFloat(number.replace(new RegExp('[.]', 'g'), '').replace(',', '.'))));
        if (result.indexOf('NaN') === -1) {
          result = result.substring(0, result.length - 2);
        }
      } else {
        result = (new Intl.NumberFormat('it-IT', {
          style: 'currency', currency: 'EUR', useGrouping: true,
          maximumFractionDigits: 4
        })
          .format(parseFloat(number)));
        if (result.indexOf('NaN') === -1) {
          result = result.substring(0, result.length - 2);
        }
      }
    } else {
      this.populateErrorsArray();
      result = number;
    }
    return result;
  }

  modifyField(number) {
    if (number === '' || number == null) {
      this.dataModel = '';
      this.amount.emit(0);
    } else {
      this.dataModel = this.toImporto(number);
      this.amount.emit(this.toDecimal(this.dataModel));
    }
  }

  toDecimal(number) {
    if (!this.templateRef.control.errors) {
      if ((parseFloat(number).toString()).indexOf('NaN')) {
        return parseFloat(number.replace(new RegExp('[.]', 'g'), '').replace(',', '.'));
      }
      this.errorChange.emit(this.errorArray);
      return 0;
    }
    this.errorChange.emit(this.errorArray);
    return '';
  }

  ngOnDestroy(): void {
    if (this.valueSubscription) {
      this.valueSubscription.unsubscribe();
    }
  }
}
