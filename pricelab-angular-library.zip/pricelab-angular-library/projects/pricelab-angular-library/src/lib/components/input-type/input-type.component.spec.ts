import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ImportoInputBoxComponent } from './input-type.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

describe('ImportoInputBoxComponent', () => {
  let component: ImportoInputBoxComponent;
  let fixture: ComponentFixture<ImportoInputBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ImportoInputBoxComponent],
      imports: [
        CommonModule,
        FormsModule,
        NgbModule
      ],
      schemas:[CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));


  beforeEach(() => {
    fixture = TestBed.createComponent(ImportoInputBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('template ref should have some control errors for invalid data', () => {
    component.name = 'some-name';
    component.pattern = '[0-9]*';
    component.dataModel = '1234abc';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(component.templateRef.control.errors).toBeTruthy();
    });
  });

  it('template ref should have no control error for valid data', () => {
    component.name = 'some-name';
    component.pattern = '[0-9]*';
    component.dataModel = '1234';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(component.templateRef.control.errors).toBe(null);
    });
  });

});
