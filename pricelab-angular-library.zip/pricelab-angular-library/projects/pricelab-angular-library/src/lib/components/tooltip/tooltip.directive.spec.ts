import { TooltipDirective } from './tooltip.directive';
import { TestBed, ComponentFixture, async } from '@angular/core/testing';
import { Component, DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { TooltipComponent } from 'src/app/components/tooltip/tooltip.component';
@Component({
  template: `<button plTooltip="Ekansh" placement="top" labelInput="Limiti statici" price="4444">tooltip top</button>`,
  styles: [`.ng-lbl{
    // margin-left: -10px;
    margin-bottom: 0;
  }
  
  .ng-price {
    // margin-left: 10px;
    padding: 0 1rem;
  }
  
  .ng-tooltip {
    position: absolute;
    max-width: 150px;
    font-size: 14px;
    text-align: left;
    // color: #9F8B92;
    padding: 0.6rem 1rem;
    background: #fafdff;
    border: 1px solid #BAB7BA;
    border-radius: 1px;
    z-index: 1000;
    opacity: 0;
    word-wrap: normal;
  }
  
  .ng-tooltip:after {
    content: "";
    position: absolute;
    border-style: solid;
  }
  
  .ng-tooltip-top:after {
    top: 100%;
    left: 46%;
    border-width: 7px;
    border-color: #BAB7BA transparent transparent transparent;
  }
  
  .ng-tooltip-bottom:after {
    bottom: 100%;
    left: 50%;
    // margin-left: -7px;
    border-width: 7px;
    border-color: transparent transparent #BAB7BA transparent;
    border-bottom-color: #BAB7BA; /* black */
    border-width: 0 5px 5px;
  }
  
  .ng-tooltip-left:after {
    top: 50%;
    left: 100%;
    margin-top: -7px;
    border-width: 7px;
    border-color: transparent transparent transparent #BAB7BA;
  }
  
  .ng-tooltip-right:after {
    top: 50%;
    right: 100%;
    margin-top: -7px;
    border-width: 7px;
    border-color: transparent #BAB7BA transparent transparent;
  }
  
  .ng-tooltip-show {
    opacity: 1;
  }`]
})
class TestTooltipDirectiveComponent {
}

describe('TooltipDirective', () => {
  let component: TestTooltipDirectiveComponent;
  let fixture: ComponentFixture<TestTooltipDirectiveComponent>;
  let inputEl: DebugElement;
  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TestTooltipDirectiveComponent, TooltipDirective]
    });
    fixture = TestBed.createComponent(TestTooltipDirectiveComponent);
    component = fixture.componentInstance;
    inputEl = fixture.debugElement.query(By.css('button'));
  });
  describe('TooltipDirective', () => {
    it('should create an instance', () => {
      // const directive = new TooltipDirective();
      // expect(directive).toBeTruthy();
    });
    it('should create', () => {
      expect(component).toBeTruthy();
    });
    it('hovering over button tooltip should be visible', () => {
      inputEl.triggerEventHandler('mouseenter', null);
      fixture.detectChanges();
      const compiled = fixture.debugElement.nativeElement;
      if (compiled.querySelector('.span')) {
        expect(compiled.querySelector('.span')).toBe(true);
      }
    });
    it('hovering over button tooltip should shown', () => {
      inputEl.triggerEventHandler('mouseleave', null);
      fixture.detectChanges();
      const compiled = fixture.debugElement.nativeElement;
      if (compiled.querySelector('.span')) {
        expect(compiled.querySelector('.span')).toBe(false);
      }
    });
  });
});