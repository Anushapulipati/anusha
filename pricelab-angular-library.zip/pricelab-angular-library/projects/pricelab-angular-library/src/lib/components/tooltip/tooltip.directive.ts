import { Directive, OnDestroy, Input, HostListener, ElementRef, OnInit, ComponentRef, Renderer2 } from '@angular/core';
import { TooltipSize } from '../../models/tooltip-size.enum';


@Directive({
  selector: '[plTooltip]'
})
export class TooltipDirective implements OnInit {
  @Input('plTooltip') tooltipTitle: string;
  @Input() placement?: string;
  @Input() width?: string;
  @Input() labelInput?: any;
  @Input() price?: any;
  tooltip: HTMLElement;
  labelin: HTMLLabelElement;
  priceElement: HTMLElement;
  offset = 10;

  constructor(
    private el: ElementRef, 
    private renderer: Renderer2
  ) { }

  @HostListener('mouseenter') onMouseEnter() {
    if (!this.tooltip) { this.show(); }
  }

  @HostListener('mouseleave') onMouseLeave() {
    if (this.tooltip) { this.hide(); }
  }

  ngOnInit(): void {
    if(this.price)
    {
      this.tooltipTitle += ":";
    }
  }

  show() {
    if (!this.placement) {
      this.placement = "top";
    }
    this.create();
    
    if (!this.width) {
      this.renderer.setStyle(this.tooltip, 'max-width', TooltipSize.DEFAULT + 'px');
    } else {
      switch (this.width) {
        case 'SMALL':
          this.renderer.setStyle(this.tooltip, 'max-width', TooltipSize.SMALL + 'px');
          break;
        case 'MEDIUM':
          this.renderer.setStyle(this.tooltip, 'max-width', TooltipSize.MEDIUM + 'px');
          break;
        case 'LARGE':
          this.renderer.setStyle(this.tooltip, 'max-width', TooltipSize.LARGE + 'px');
          break;
        default:
          this.renderer.setStyle(this.tooltip, 'max-width', TooltipSize.DEFAULT + 'px');
          break;
      }
    }
    this.setPosition();
    this.renderer.addClass(this.tooltip, 'ng-tooltip-show');
  }

  hide() {
    this.renderer.removeClass(this.tooltip, 'ng-tooltip-show');
    this.renderer.removeChild(document.body, this.tooltip);
    this.tooltip = null;
  }

  create() {
    this.tooltip = this.renderer.createElement('div');
    this.labelin = this.renderer.createElement('h6');
    this.priceElement = this.renderer.createElement('span');
    if (this.labelInput) {
      this.renderer.appendChild(this.labelin, this.renderer.createText(this.labelInput));
    }

    this.renderer.appendChild(
      this.tooltip,
      this.labelin
    );

    this.renderer.appendChild(
      this.tooltip,
      this.renderer.createText(this.tooltipTitle)
    );

    if(this.price) {
      this.renderer.appendChild(this.priceElement, this.renderer.createText(this.price));
      this.renderer.appendChild(this.tooltip,this.priceElement);
    }

    this.renderer.appendChild(document.body, this.tooltip);
    this.renderer.addClass(this.labelin, 'ng-lbl');
    this.renderer.addClass(this.priceElement, 'ng-price');
    this.renderer.addClass(this.tooltip, 'ng-tooltip');
    this.renderer.addClass(this.tooltip, `ng-tooltip-${this.placement}`);
  }

  setPosition() {
    const hostPos = this.el.nativeElement.getBoundingClientRect();
    const tooltipPos = this.tooltip.getBoundingClientRect();
    const scrollPos = window.pageYOffset || document.documentElement.scrollTop || document.body.scrollTop || 0;

    let top, left;

    if (this.placement === 'top') {
      top = hostPos.top - tooltipPos.height - this.offset;
      left = hostPos.left + (hostPos.width - tooltipPos.width) / 2;
    }

    if (this.placement === 'bottom') {
      top = hostPos.bottom + this.offset;
      left = hostPos.left + (hostPos.width - tooltipPos.width) / 2;
    }

    if (this.placement === 'left') {
      top = hostPos.top + (hostPos.height - tooltipPos.height) / 2;
      left = hostPos.left - tooltipPos.width - this.offset;
    }

    if (this.placement === 'right') {
      top = hostPos.top + (hostPos.height - tooltipPos.height) / 2;
      left = hostPos.right + this.offset;
    }

    this.renderer.setStyle(this.tooltip, 'top', `${top + scrollPos}px`);
    this.renderer.setStyle(this.tooltip, 'left', `${left}px`);
  }
}
