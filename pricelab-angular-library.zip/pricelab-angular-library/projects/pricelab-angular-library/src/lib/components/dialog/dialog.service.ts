import { Injectable, ComponentFactoryResolver, ApplicationRef, Injector, Type, EmbeddedViewRef, ComponentRef } from '@angular/core';
import { DialogComponent } from './dialog.component';
import { DialogInjector } from './dialog-injector';
import { DialogModel } from './dialog-model';
import { DialogRef } from './dialog-ref';

@Injectable({
  providedIn: 'root'
})
export class DialogService {
  dialogComponentRef: ComponentRef<DialogComponent>;
  listOfOpenDialog: ComponentRef<DialogComponent>[] = [];
  constructor(
    private componentFactoryResolver: ComponentFactoryResolver, 
    private appRef: ApplicationRef, 
    private injector: Injector
  ) { }

  public open(componentType: Type<any>, config: DialogModel) {
    const dialogRef = this.appendDialogComponentToBody(config);
    this.dialogComponentRef.instance.childComponentType = componentType;
    return dialogRef;
  }

  private appendDialogComponentToBody(config: DialogModel) {
    const map = new WeakMap();
    map.set(DialogModel, config);

    const dialogRef = new DialogRef();
    map.set(DialogRef, dialogRef);

    const sub = dialogRef.afterClosed.subscribe(() => {
      this.removeDialogComponentFromBody();
      sub.unsubscribe();
    });

    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(DialogComponent);
    const componentRef = componentFactory.create(new DialogInjector(this.injector, map));
    this.appRef.attachView(componentRef.hostView);
    const domElem = (componentRef.hostView as EmbeddedViewRef<any>).rootNodes[0] as HTMLElement;
    document.body.appendChild(domElem);
    this.dialogComponentRef = componentRef;

    this.listOfOpenDialog.push(this.dialogComponentRef);
    this.dialogComponentRef.instance.onClose.subscribe(() => {
      this.removeDialogComponentFromBody();
    });
    return dialogRef;
  }

  private removeDialogComponentFromBody() {
    const dialogRefToRemove = this.listOfOpenDialog.slice(-1, this.listOfOpenDialog.length);
    this.dialogComponentRef = dialogRefToRemove[0];
    this.appRef.detachView(this.dialogComponentRef.hostView);
    this.listOfOpenDialog.pop();
    this.dialogComponentRef.destroy();
  }
}
