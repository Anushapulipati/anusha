import {
  Component, Type, ComponentFactoryResolver, ViewChild, OnDestroy,
  ComponentRef, AfterViewInit, ChangeDetectorRef, ElementRef
} from '@angular/core';
import { InsertionDirective } from './insertion.directive';
import { Subject } from 'rxjs';
import { DialogRef } from './dialog-ref';
import { DialogModel } from './dialog-model';


@Component({
  selector: 'pl-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.css']
})
export class DialogComponent implements AfterViewInit, OnDestroy {
  @ViewChild(InsertionDirective) insertionPoint: InsertionDirective;
  componentRef: ComponentRef<any>;
  element: any;
  showIt: boolean;
  id: string;
  title: string;
  large: boolean;
  small: boolean;
  medium: boolean;
  isShowCloseButton: boolean;
  externalHeaderClass: any = {};
  private readonly _onClose = new Subject<any>();
  public onClose = this._onClose.asObservable();
  childComponentType: Type<any>;

  constructor(
    private componentFactoryResolver: ComponentFactoryResolver, 
    private cd: ChangeDetectorRef, 
    private dialogRef: DialogRef,
    public elRef: ElementRef, 
    private config: DialogModel
  ) {
      this.element = elRef.nativeElement;
      this.title = config.title;
      this.id = config.id;
      if (config.noCloseButton) {
        this.isShowCloseButton = config.noCloseButton;
      }
      if (config.size === 'large') {
        this.large = true;
      } else if (config.size === 'small') {
        this.small = true;
      } else {
        this.medium = true;
      }
      this.externalHeaderClass = this.config.externalHeaderClass ? this.config.externalHeaderClass : {} ;
      this.externalHeaderClass['modal-sm'] = this.small;
      this.externalHeaderClass['modal-lg'] = this.large;
      this.externalHeaderClass['modal-md'] = this.medium;
      console.log(this.externalHeaderClass);
  }

  ngAfterViewInit() {
    this.loadChildComponent(this.childComponentType);
    const closetParent = this.element.querySelectorAll('div.modal');
    closetParent[0].style.display = 'block';
    this.showIt = true;
    this.cd.detectChanges();
  }

  onOverlayClicked(evt: MouseEvent) {
    this.dialogRef.close();
  }

  onDialogClicked(evt: MouseEvent) {
    evt.stopPropagation();
  }

  loadChildComponent(componentType: Type<any>) {
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(componentType);
    const viewContainerRef = this.insertionPoint.viewContainerRef;
    viewContainerRef.clear();
    this.componentRef = viewContainerRef.createComponent(componentFactory);
  }

  ngOnDestroy() {
    this.showIt = false;
    if (this.componentRef) {
      this.componentRef.destroy();
    }
  }

}
