

import { TestBed, ComponentFixture, inject } from '@angular/core/testing';
import { DialogService } from './dialog.service';
describe('DialogService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DialogService]
    });
  });

  it('should be created', inject([DialogService], (service: DialogService) => {
    expect(service).toBeTruthy();
  }));
  it('should have list of listOfOpenDialog', inject([DialogService], (service: DialogService) => {
    expect(service.listOfOpenDialog.length).toBe(0);
  }));
});
