import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[balDialogInsertion]'
})
export class InsertionDirective {
  constructor(public viewContainerRef: ViewContainerRef) { }
}
