import { Component, ComponentFactoryResolver } from '@angular/core';
import { TestBed, ComponentFixture } from '@angular/core/testing';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { DialogComponent } from './dialog.component';
import { DialogRef } from './dialog-ref';
import { DialogModel } from './dialog-model';
import { By } from '@angular/platform-browser';
@Component({
	selector: 'bal-hosted',
	template: 'templ'
})
class HostedComponent {
	content: string;
}

describe('DialogComponent', () => {
	let fixture: ComponentFixture<DialogComponent>;
	let component: DialogComponent;
	beforeEach(() => {
		TestBed.configureTestingModule({
			providers: [ComponentFactoryResolver, DialogRef, DialogModel],
			declarations: [HostedComponent, DialogComponent]
		});
		TestBed.overrideModule(BrowserDynamicTestingModule, {
			set: {
				entryComponents: [HostedComponent]
			}
		});
		TestBed.compileComponents();
	});
	beforeEach(() => {
		fixture = TestBed.createComponent(DialogComponent);
		component = fixture.componentInstance;
	});
	it('should create', () => {
		expect(fixture).toBeTruthy();
	});

	it('should have title as given that is My Popup', () => {
		spyOn(component, 'loadChildComponent');
		component.title = 'My Popup';
		fixture.detectChanges();
		const compiled = fixture.debugElement.nativeElement;
		if (compiled.querySelector('.h2')) {
			expect(compiled.querySelector('.h2')).toBe(true);
			expect(compiled.querySelector('.h2').textContent).toBe('My Popup');
		}
	});

	it('should have showIt value of dialog false', () => {
		spyOn(component, 'loadChildComponent');
		fixture.detectChanges();
		expect(component.showIt).toBe(true);
	});

	it('should be small dialog class applied', () => {
		component.small = true;
		spyOn(component, 'loadChildComponent');
		fixture.detectChanges();
		expect(fixture.debugElement.query(By.css('.modal-sm')).nativeElement).toBeTruthy();
	});

	it('should be large dialog class applied', () => {
		component.large = true;
		spyOn(component, 'loadChildComponent');
		fixture.detectChanges();
		expect(fixture.debugElement.query(By.css('.modal-lg')).nativeElement).toBeTruthy();
	});
});
