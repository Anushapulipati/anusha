export class DialogModel<D = any> {
  data?: D;
  title?: string;
  id?: string;
  size?: 'large' | 'small' | 'medium';
  noCloseButton?: boolean;
  externalHeaderClass?: {};
}
