import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { SelectComponent } from './select.component';
import { EventsModel } from '../../models/event-model';
import { By } from '@angular/platform-browser';
import { Component } from '@angular/core';

describe('SelectComponent', () => {
  let component: SelectComponent;
  let fixture: ComponentFixture<SelectComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [SelectComponent],
      imports: [
        CommonModule,
        FormsModule
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectComponent);
    component = fixture.componentInstance;
    const selectEvent: EventsModel[] = [
      { eventName: 'click', eventCallBack: clickedOnSelect.bind(this) },
      { eventName: 'change', eventCallBack: changedSelect.bind(this) }
    ];
    component.id = 'elements';

    component._selectData = [
      {
        value: 'primary',
        description: 'primo elemento'
      },
      {
        value: 'secondary',
        description: 'secondo elemento'
      }
    ];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('if should be checked for if checked is true', () => {
    const cityDropdown = fixture.debugElement.query(By.css('select')).nativeElement;
    component.dataModel = 'primary';
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(cityDropdown.value).toBe('primary');

    });
  });

  it('it should check options description', () => {
    const cityDropdown = fixture.debugElement.query(By.css('select')).nativeElement;
    fixture.whenStable().then(() => {
      fixture.detectChanges();
      expect(cityDropdown.options[1].value).toBe('secondary');
    });
  });

  it('on modelChange', () => {
    const cityDropdown = fixture.debugElement.query(By.css('select')).nativeElement;
    spyOn(component, 'modelChange').and.callThrough();
    fixture.whenStable().then(() => {
      cityDropdown.dispatchEvent(new Event('change'));
      expect(component.modelChange).toHaveBeenCalled();
    });
  });

  it('should correctly render the passed @Input name', () => {
    const cityDropdown = fixture.debugElement.query(By.css('select')).nativeElement;
    component.name = 'test input';
    fixture.detectChanges();
    expect(cityDropdown.id).toBe('test input');
  });

  it('should correctly render the passed @Input title', () => {
    const cityDropdown = fixture.debugElement.query(By.css('select')).nativeElement;
    component.title = 'test title';
    fixture.detectChanges();
    expect(cityDropdown.title).toBe('test title');
  });

});


export function clickedOnSelect() {
  console.log('select clicked');
}

export function changedSelect() {
  console.log('change on select');
}
