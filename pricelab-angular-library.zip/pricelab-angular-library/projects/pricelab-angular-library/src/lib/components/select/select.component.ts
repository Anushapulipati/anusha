import {
  Component, Input, ElementRef, Renderer2, ViewChild, AfterViewInit, Output,
  EventEmitter,
  AfterContentChecked,
  ChangeDetectorRef
} from '@angular/core';
import { NgModel, ControlValueAccessor, NG_VALUE_ACCESSOR, Validator, NG_VALIDATORS } from '@angular/forms';
import { EventsModel } from '../../models/event-model';
import { SelectOptionModel } from '../../models/select-option-model';

@Component({
  selector: 'pl-select',
  templateUrl: './select.component.html',
  styleUrls: ['./select.component.scss'],
  providers: [
    { provide: NG_VALUE_ACCESSOR, useExisting: SelectComponent, multi: true },
    { provide: NG_VALIDATORS, useExisting: SelectComponent, multi: true }
  ]
})
export class SelectComponent implements AfterViewInit, AfterContentChecked, ControlValueAccessor, Validator {
  @Input() name: string;
  @Input() id: string;
  @Input() title: string;
  @Input() placeholder: string;
  @Input() label: string;
  @Input() emptyOption: true | false;
  @Input() required: true | false;
  @Input() disabled: true | false;
  @Input() events: EventsModel[];
  dataModel: string;
  @Input() errorMessage: string;
  @Input() showErrorMessages: true | false = false;
  @Input() showErrorOnLoad: true | false = false;
  @ViewChild('templateRef') templateRef: NgModel;
  onChange: (value: string) => void;
  onTouched: () => void;
  @Output() errorChange: EventEmitter<any> = new EventEmitter<any>();
  _selectData: SelectOptionModel[];
  dataData: SelectOptionModel;
  @Input() customValidation: boolean;
  @Input() referance: NgModel;
  @Input() isReactForm: boolean;
  errorArray: any[];

  @Input()
  set selectData(selectData: any) {
    this._selectData = [];
    if (selectData) {
      selectData.forEach(data => {
        if (typeof data === 'string') {
          this.dataData = {
            description: data
          };
          this._selectData.push(this.dataData);
        } else {
          if (data.value !== null) {
            this._selectData.push(data);
          }
        }
      });
    }
  }

  constructor(
    public elRef: ElementRef,
    private renderer: Renderer2,
    private cdr: ChangeDetectorRef) {
  }

  ngAfterViewInit() {
    if (this.events !== undefined && this.events != null && this.events.length > 0) {
      this.events.forEach(event => {
        this.renderer.listen(this.elRef.nativeElement.querySelector('select'), event.eventName, (evt) => {
          event.eventCallBack(this.elRef.nativeElement, evt);
        });
      });
    }
    this.cdr.detectChanges();
  }

  ngAfterContentChecked() {
    this.populateErrorsArray();
    this.validate();
    if (this.isReactForm) {
      if (!this.customValidation) {
        this.templateRef.control.setErrors(null);
        this.templateRef.control.markAsTouched({ onlySelf: true });
      } else {
        this.templateRef.control.setErrors({ error: true });
        this.templateRef.control.markAsTouched({ onlySelf: true });
      }
    }
  }
  modelChange(event) {
    if (this.onChange !== undefined && this.onChange != null) {
      this.onChange(this.dataModel);
    }
  }
  writeValue(value: string) {
    this.dataModel = value;
  }

  populateErrorsArray() {
    this.errorArray = [];
    for (const key in this.templateRef.control.errors) {
      if (this.templateRef.control.errors.hasOwnProperty(key)) {
        this.errorArray.push(key);
      }
    }
  }
  registerOnTouched(onTouched: () => void) {
    this.onTouched = onTouched;
  }

  registerOnChange(onChange: any) {
    this.onChange = onChange;
  }
  validate() {
    if (this.referance) {
      if (this.customValidation === true) {
        const error = this.customValidation;
        this.referance.control.setErrors({ error: this.customValidation });
        this.referance.control.markAsTouched({ onlySelf: true });
        this.templateRef.control.setErrors({ error: this.customValidation });
        this.templateRef.control.markAsTouched({ onlySelf: true });
      } else {
        if (this.referance.control.hasError('error') && this.templateRef.control.hasError('error')) {
          this.referance.control.setErrors(null);
          this.referance.control.markAsTouched({ onlySelf: true });
          this.templateRef.control.setErrors(null);
          this.templateRef.control.markAsTouched({ onlySelf: true });
        }
      }
    }
    if (this.errorArray !== undefined && this.errorArray !== null) {
      if (this.errorArray.length > 0) {
        this.errorChange.emit(this.errorArray);
        return this.templateRef.control.errors;
      } else {
        this.errorChange.emit(this.errorArray);
      }
    }
    return null;
  }
}

