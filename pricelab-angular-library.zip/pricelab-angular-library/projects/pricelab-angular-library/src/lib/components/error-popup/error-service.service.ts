import { Injectable } from '@angular/core';
import { ErrorMessageModel } from '../../models/error-message-model';
import { DialogService } from '../dialog/dialog.service';
import { ErrorPopupComponent } from './error-popup.component';

@Injectable({
  providedIn: 'root'
})
export class ErrorServiceService {

  constructor(private dialogs: DialogService) { }

  openErrorPopup(Error: ErrorMessageModel) {
    const ref = this.dialogs.open(ErrorPopupComponent, {
      data: { error: Error }
    });
  }
}
