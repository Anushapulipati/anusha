import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { DialogModel } from './../dialog/dialog-model';
import { DialogRef } from './../dialog/dialog-ref';
import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { DialogComponent } from './../dialog/dialog.component';

import { ErrorPopupComponent } from './error-popup.component';
import { ErrorServiceService } from './error-service.service';
import { AccordionComponent } from '../accordion/accordion.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'bal-hosted',
  template: 'templ'
})
class HostedComponent {
  constructor(private npvErrorServiceService: ErrorServiceService) { }

  openErrorPopup() {
    const Error = {
      'message': 'Error Occured ',
      'details': [{ 'code': '99', 'message': 'Fault occurred while processing.', 'service': '', 'forzabile': false }]
    };
    this.npvErrorServiceService.openErrorPopup(Error);
  }
}

describe('ErrorPopupComponent', () => {
  let fixture: ComponentFixture<HostedComponent>;
  let fixture1: ComponentFixture<ErrorPopupComponent>
  let component: HostedComponent;
  let component1:ErrorPopupComponent;
  let Error1;
  let Error2;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [DialogRef, DialogModel, ErrorServiceService],
      schemas: [NO_ERRORS_SCHEMA]
    });
    TestBed.overrideModule(BrowserDynamicTestingModule, {
      set: {
        imports: [CommonModule, NgbModule],
        declarations: [DialogComponent, HostedComponent, ErrorPopupComponent, AccordionComponent],
        entryComponents: [DialogComponent, ErrorPopupComponent],
        schemas: [NO_ERRORS_SCHEMA]
      }
    });
    TestBed.compileComponents();
  });
  beforeEach(() => {
    Error1 = {
      'message': 'Error Occured ',
      'details': [{ 'code': '99', 'message': 'Fault occurred while processing.', 'service': '', 'forzabile': false }]
    };
     Error2= {
      'message': 'Error Occured ',
      'details': [{ 'code': '99', 'message': '', 'service': '', 'forzabile': false }]
    };
    fixture = TestBed.createComponent(HostedComponent);
    fixture1=TestBed.createComponent(ErrorPopupComponent);
    component = fixture.componentInstance;
    component1= fixture1.componentInstance;
    component.openErrorPopup();
  });
  
  it('should open popup', () => {
    expect(fixture).toBeTruthy();
  });

  it('Should render the CODICE',()=>{
   fixture.whenStable().then(() => {
      component1.errorModel=Error1;
		component1._textMessage();
    fixture.detectChanges();
   expect(component1.errorModel.details[0].code).toContain('99');
    });
  });

  it('Should render the SERVIZIO',()=>{
    fixture.whenStable().then(() => {
    component1.errorModel=Error1;
		component1._textMessage();
    fixture.detectChanges();
    expect(component1.errorModel.message).toContain('Error Occured');
    });
  });
 
  it('should have detailMessages  to be  true', () => {
    component1.errorModel=Error1;
		component1._textMessage();
		fixture.detectChanges();
		expect(component1.detailMessages).toBe(true);
	});

  it(' errorMessageBody should contain message of error ', () => {
    component1.errorModel=Error1;
    component1._textMessage();
    component1.detailMessages=true;
    fixture.detectChanges();
    expect(component1.errorMessageBody).toContain('Error Occured');
  });
  
   it(' errorMessage should contain the text Errore Generico', () => {
    const Error= {
      'message': 'Error Occured ',
      'details': []
    };
    component1.errorModel=Error;
    component1._textMessage();
    fixture.detectChanges();
    expect(component1.errorMessage).toContain('Errore Generico');
  });
  
  it('should have detailMessages  to be  false', () => {
    component1.errorModel=Error2;
    component1._textMessage();
    fixture.detectChanges();
    expect(component1.detailMessages).toBe(false);
  });
  
  it(' errorDescription should contain error Description ', () => {
    component1.errorModel=Error2;
    component1._textMessage();
    component1.detailMessages=false;
    fixture.detectChanges();
    expect(component1.errorDescription).toContain('Error Occured');
  });
});

