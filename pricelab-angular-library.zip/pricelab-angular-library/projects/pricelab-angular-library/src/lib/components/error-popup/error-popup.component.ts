import { Component, OnInit } from '@angular/core';
import { DialogRef } from '../dialog/dialog-ref';
import { DialogModel } from '../dialog/dialog-model';
import { ErrorMessageModel } from '../../models/error-message-model';

@Component({
  selector: 'pl-error-popup',
  templateUrl: './error-popup.component.html',
  styleUrls: ['./error-popup.component.css']
})
export class ErrorPopupComponent implements OnInit {
  errorModel: ErrorMessageModel;
  isValid: boolean;
  errorMessageBody: string;
  errorMessage: string;
  errorDescription: string;
  detailMessages: boolean;

  constructor(
    public config: DialogModel, 
    public dialog: DialogRef
  ) { }

  ngOnInit() {
    this.errorModel = this.config.data.error;
    this._textMessage();
  }

  onCloseMain() {
    this.dialog.close();
  }

  toggleAccordion($event) {
  
  }
  
  onClose() {
    this.dialog.close();
  }
  
  _textMessage() {
    if (this.errorModel) {
      if (this.errorModel.details && this.errorModel.details.length > 0) {
        this.detailMessages = false;
        for (let i = 0; i < this.errorModel.details.length; i++) {
          if (this.errorModel.details[i].message) {
            this.detailMessages = true;
            this.isValid = true;
            break;
          }
        }
        if (this.detailMessages) {
          this.errorMessageBody = this.errorModel.message;
        } else {
          this.errorDescription = this.errorModel.message;
        }
      } else {
        this.errorMessage = 'Errore Generico';
        this.isValid = true;
        this.errorMessageBody = this.errorModel.message;

      }
    }
  }
}
