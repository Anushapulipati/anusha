import { TestBed } from '@angular/core/testing';
import { ErrorMessageModel } from './../../models/error-message-model';
import { CommonModule } from '@angular/common';
import { BrowserDynamicTestingModule } from '@angular/platform-browser-dynamic/testing';
import { DialogComponent } from './../dialog/dialog.component';
import { ErrorServiceService } from './error-service.service';
import { ErrorPopupComponent } from './error-popup.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AccordionComponent } from '../accordion/accordion.component';
import { NO_ERRORS_SCHEMA } from '@angular/core';

describe('ErrorServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
    });
    TestBed.overrideModule(BrowserDynamicTestingModule, {
      set: {
        imports: [CommonModule, NgbModule],
        declarations: [DialogComponent, ErrorPopupComponent, AccordionComponent],
        entryComponents: [DialogComponent, ErrorPopupComponent],
        schemas: [NO_ERRORS_SCHEMA]
      }
    });
    TestBed.compileComponents();
  });

  it('should be created', () => {
    const service: ErrorServiceService = TestBed.get(ErrorServiceService);
    expect(service).toBeTruthy();
  });
  it('should  have openErrorPopup method', () => {
    let obj: ErrorMessageModel;
    const service: ErrorServiceService = TestBed.get(ErrorServiceService);
    service.openErrorPopup(obj);
    expect(true).toBeDefined();
  });
});
