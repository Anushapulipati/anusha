export interface SelectOptionModel {
    description: string;
    value?: string;
    disabled?: true | false;
    checked?: true | false;
}
