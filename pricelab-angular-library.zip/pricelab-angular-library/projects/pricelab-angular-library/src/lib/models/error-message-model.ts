export interface ErrorMessageModel {
  message: string;
  details: any[];
}
