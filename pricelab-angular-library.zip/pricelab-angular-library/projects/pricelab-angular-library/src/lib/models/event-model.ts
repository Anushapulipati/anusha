export interface EventsModel {
    eventName: string;
    eventCallBack: (input?: any, event?: any) => any;
}
