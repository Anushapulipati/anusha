import { Attributo } from './attributo';

export class Occorrenza {
  constructor(private _valori: Array<Attributo>, private _numeroOccorrenza: number) {
  }

  public get valori(): Array<Attributo> {
    return this._valori;
  }
  public set valori(value: Array<Attributo>) {
    this._valori = value;
  }
  public get numeroOccorrenza(): number {
    return this._numeroOccorrenza;
  }
  public set numeroOccorrenza(value: number) {
    this._numeroOccorrenza = value;
  }
}
