import { TipoFormatoAttributo } from './tipo-formato-attributo.enum';

export class Attributo {
  constructor(private _valore: string, private _tipoFormatoAttributo: TipoFormatoAttributo, private _elencoValori: Array<any>,
    private _codiceAttributo: string, private _descrizioneAttributo: string) {
  }

  public get elencoValori(): Array<any> {
    return this._elencoValori;
  }
  public set elencoValori(value: Array<any>) {
    this._elencoValori = value;
  }
  public get tipoFormatoAttributo(): TipoFormatoAttributo {
    return this._tipoFormatoAttributo;
  }
  public set tipoFormatoAttributo(value: TipoFormatoAttributo) {
    this._tipoFormatoAttributo = value;
  }
  public get valore(): string {
    return this._valore;
  }
  public set valore(value: string) {
    this._valore = value;
  }
  public get descrizioneAttributo(): string {
    return this._descrizioneAttributo;
  }
  public set descrizioneAttributo(value: string) {
    this._descrizioneAttributo = value;
  }
  public get codiceAttributo(): string {
    return this._codiceAttributo;
  }
  public set codiceAttributo(value: string) {
    this._codiceAttributo = value;
  }
}
