import { ElencoCondizioni } from './elenco-condizioni';

export class Decorrenza {
  constructor(private _elencoCondizioni: ElencoCondizioni) {
  }

  public get elencoCondizioni(): ElencoCondizioni {
    return this._elencoCondizioni;
  }
  public set elencoCondizioni(value: ElencoCondizioni) {
    this._elencoCondizioni = value;
  }
}
