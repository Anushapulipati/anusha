import { ElencoOccorrenze } from './elenco-occorrenze';
import { TipoGestioneCondizione } from './tipo-gestione-condizione.enum';

export class Condizione {
  constructor(private _elencoOccorrenze: ElencoOccorrenze, private _tipoGestioneCondizione: TipoGestioneCondizione, private _codiceCondizione: string, private _descrizioneCondizione: string) {
  }

  public get tipoGestioneCondizione(): TipoGestioneCondizione {
    return this._tipoGestioneCondizione;
  }
  public set tipoGestioneCondizione(value: TipoGestioneCondizione) {
    this._tipoGestioneCondizione = value;
  }
  public get elencoOccorrenze(): ElencoOccorrenze {
    return this._elencoOccorrenze;
  }
  public set elencoOccorrenze(value: ElencoOccorrenze) {
    this._elencoOccorrenze = value;
  }
  public get codiceCondizione(): string {
    return this._codiceCondizione;
  }
  public set codiceCondizione(value: string) {
    this._codiceCondizione = value;
  }
  public get descrizioneCondizione(): string {
    return this._descrizioneCondizione;
  }
  public set descrizioneCondizione(value: string) {
    this._descrizioneCondizione = value;
  }
}
