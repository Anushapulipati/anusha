export enum TipoGestioneCondizione {
  F = "LISTA_FISSA",
  S = "LISTA_SEMPLICE",
  V = "LISTA_VARIABILE",
  I = "LISTA_INCREMENTALE"
}
