export enum TipoFormatoAttributo {
  A = "ALFANUMERICO",
  N = "NUMERICO",
  T = "TASSO",
  S = "SEGNATO",
  I = "IMPORTO",
  P = "PROGRESSIVO",
  C = "CODIFICATO",
  L = "LISTINO",
  F = "FILTRO",
  D = "DATA"
}
