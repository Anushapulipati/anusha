import { Condizione } from './condizione';

export class ElencoCondizioni {
  constructor(private _condizioni: Array<Condizione>) {
  }

  public get condizioni(): Array<Condizione> {
    return this._condizioni;
  }
  public set condizioni(value: Array<Condizione>) {
    this._condizioni = value;
  }
}
