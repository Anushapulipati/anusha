import { Occorrenza } from './occorrenza';

export class ElencoOccorrenze {
  constructor(private _occorrenze: Array<Occorrenza>) {
  }

  public get occorrenze(): Array<Occorrenza> {
    return this._occorrenze;
  }
  public set occorrenze(value: Array<Occorrenza>) {
    this._occorrenze = value;
  }
}
