export enum TooltipSize {
    DEFAULT = 150,
    SMALL = 150,
    MEDIUM = 250,
    LARGE = 500
}
