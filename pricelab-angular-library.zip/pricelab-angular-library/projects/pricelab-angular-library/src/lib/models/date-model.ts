export class DateModel {
    year: number;
    month: number;
    day: number;
}
