import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { AccordionComponent } from './components/accordion/accordion.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LoaderComponent } from './components/loader/loader.component';
import { TooltipDirective } from './components/tooltip/tooltip.directive';
import { TypeaheadComponent } from './components/typeahead/typeahead.component';
import { SelectComponent } from './components/select/select.component';
import { DialogComponent } from './components/dialog/dialog.component';
import { InsertionDirective } from './components/dialog/insertion.directive';
import { DatepickerComponent } from './components/datepicker/datepicker.component';
import { ImportoInputBoxComponent } from './components/input-type/input-type.component';
import { FileUploaderComponent } from './components/file-uploader/file-uploader.component';
import { ErrorPopupComponent } from './components/error-popup/error-popup.component';
import { ListaFissaComponent } from './components/lista-fissa/lista-fissa.component';
import { ListaSempliceComponent } from './components/lista-semplice/lista-semplice.component';
import { ListaVariabileComponent } from './components/lista-variabile/lista-variabile.component';

@NgModule({
  declarations: [
    AccordionComponent,
    LoaderComponent,
    TooltipDirective,
    TypeaheadComponent,
    SelectComponent,
    DialogComponent,
    InsertionDirective,
    DatepickerComponent,
    ImportoInputBoxComponent,
    FileUploaderComponent,
    ErrorPopupComponent,
    ListaFissaComponent,
    ListaSempliceComponent,
    ListaVariabileComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    RouterModule,

  ],
  exports: [
    AccordionComponent,
    NgbModule,
    LoaderComponent,
    TooltipDirective,
    TypeaheadComponent,
    SelectComponent,
    DialogComponent,
    DatepickerComponent,
    ImportoInputBoxComponent,
    FileUploaderComponent,
    ErrorPopupComponent,
    ListaFissaComponent,
    ListaSempliceComponent,
    ListaVariabileComponent
  ],
  entryComponents: [
    DialogComponent,
    ErrorPopupComponent
  ]
})

export class PricelabAngularLibraryModule { }
