import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';

import { ErrorPopupComponent } from './error-popup.component';
import { CommonModule } from '@angular/common';

import { DialogComponent } from './../dialog/dialog.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AccordionComponent } from 'projects/pricelab-angular-library/src/lib/components/accordion/accordion.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ErrorServiceService } from 'projects/pricelab-angular-library/src/lib/components/error-popup/error-service.service';
import { of } from 'rxjs';

describe('ErrorPopupComponent', () => {
  let component: ErrorPopupComponent;
  let fixture: ComponentFixture<ErrorPopupComponent>;
  let Error1;
  let mockService;

  beforeEach(async(() => {

    mockService = jasmine.createSpyObj(['openErrorPopup']);

    Error1 = {
      'message': 'Error Occured ',
      'details': [{ 'code': '99', 'message': 'Fault occurred while processing.', 'service': '', 'forzabile': false }]
    };
    TestBed.configureTestingModule({
      imports: [CommonModule,NgbModule],
      declarations: [DialogComponent, ErrorPopupComponent,AccordionComponent],
      providers:[{provide: ErrorServiceService,useValue:mockService}],
      schemas:[CUSTOM_ELEMENTS_SCHEMA]
    
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ErrorPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should render title in a h2 tag', () => {
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h2').textContent).toContain('Error Popup Component');
  });

  it('should verify the call to open error popup method', async(()=> {
    spyOn(component,'openErrorPopup');
    component.openErrorPopup();
    expect(component.openErrorPopup).toHaveBeenCalled();
  }));
  
  it('should render the open error popup button', fakeAsync(()=> {
  fixture.detectChanges();
    spyOn(component, 'openErrorPopup');
    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.click();
    tick();
    fixture.whenStable().then(() => {
      expect(component.openErrorPopup).toHaveBeenCalled();
    });
  }))
 
it('should call service openerrorpopup method', () => {
  mockService.openErrorPopup;
  fixture.detectChanges();
  expect(fixture.componentInstance).toBeTruthy();
});
});
