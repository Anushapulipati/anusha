import { Component, OnInit } from '@angular/core';
import { ErrorServiceService } from 'projects/pricelab-angular-library/src/lib/components/error-popup/error-service.service';


@Component({
  selector: 'demo-error-popup',
  templateUrl: './error-popup.component.html',
  styleUrls: ['./error-popup.component.scss']
})
export class ErrorPopupComponent implements OnInit {

  constructor(
    private errorServiceService: ErrorServiceService
  ) { }

  ngOnInit() {
  }

  openErrorPopup() {
    const Error = {
      'message' : 'Error Occured',
      'details': [
        {'code': '99', 'message': 'Fault occurred while processing.', 'service': '', 'forzabile': false}
      ]
    };
    this.errorServiceService.openErrorPopup(Error);
  }
}
