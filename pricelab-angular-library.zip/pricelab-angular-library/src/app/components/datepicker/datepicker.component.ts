import { Component, OnInit } from '@angular/core';
import { DateModel } from 'projects/pricelab-angular-library/src/lib/models/date-model';

@Component({
  selector: 'demo-datepicker',
  templateUrl: './datepicker.component.html',
  styleUrls: ['./datepicker.component.scss']
})
export class DatepickerComponent {
  demoVariable: DateModel;
  customValidation = false;
  message = 'Resolve the errors';

  changeCallBack(event) {
    console.log(event);
    console.log(this.customValidation);
  }

  toggle() {
    this.customValidation = !this.customValidation;
    if (this.customValidation) {
      this.message = 'custom validation message';
    } else {
      this.message = 'Resolve the errors';
    }
  }
}




