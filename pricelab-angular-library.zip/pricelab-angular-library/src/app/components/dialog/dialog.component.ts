import { Component } from '@angular/core';
import { DialogOverviewComponent } from './dialog-overview/dialog-overview.component';
import { DialogService } from 'projects/pricelab-angular-library/src/lib/components/dialog/dialog.service';

@Component({
  selector: 'demo-dialog',
  templateUrl: './dialog.component.html',
  styleUrls: ['./dialog.component.scss']
})
export class DialogComponent {
  selectedDate: any;
  constructor(
    public dialog: DialogService
  ) {}

  openModal() {
    const ref = this.dialog.open(DialogOverviewComponent, {
      size: 'medium',
      title: 'Modal Header',
      noCloseButton: false,
      externalHeaderClass: {
        'bg-primary': true,
        'text-light': true
      },
      data:{ message: 'this is data transfer to pop up' }
    });
    ref.afterClosed.subscribe(result => {
      if(result) {
        this.selectedDate = `${result.day}/${result.month}/${result.year}`;
      }
    });
  }
}
