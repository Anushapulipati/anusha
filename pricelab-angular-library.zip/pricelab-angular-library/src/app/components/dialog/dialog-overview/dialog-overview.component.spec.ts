import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DialogOverviewComponent } from './dialog-overview.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule } from '@angular/forms';
import { DialogRef, DialogModel } from 'projects/pricelab-angular-library/src/public_api';

describe('DialogOverviewComponent', () => {
  let component: DialogOverviewComponent;
  let fixture: ComponentFixture<DialogOverviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DialogOverviewComponent ],
      imports:[NgbModule,FormsModule],
      schemas:[CUSTOM_ELEMENTS_SCHEMA],
      providers:[DialogRef,DialogModel]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DialogOverviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
