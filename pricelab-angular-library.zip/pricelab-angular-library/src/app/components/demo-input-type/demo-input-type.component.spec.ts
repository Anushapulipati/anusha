import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { DemoInputTypeComponent } from './demo-input-type.component';



describe('DemoInputTypeComponent', () => {
  let component: DemoInputTypeComponent;
  let fixture: ComponentFixture<DemoInputTypeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DemoInputTypeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DemoInputTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
