import { Component, OnInit, ChangeDetectorRef, ElementRef, ViewChild } from '@angular/core';
import { EventsModel } from 'src/app/models/event-model';
import { FormControl, Validators } from '@angular/forms';
//import { EventsModel } from 'projects/bstore-angular-library/src/lib/models/event-model';

@Component({
  selector: 'pl-demo-input-type',
  templateUrl: './demo-input-type.component.html',
  styleUrls: ['./demo-input-type.component.scss']
})
export class DemoInputTypeComponent implements OnInit {
  anotherDemoVariable: string;
  demoVariable: string;
  demoEvents: EventsModel[] = [];
  anotherDemoEvents: EventsModel[] = [];
  myErrorMessage: string;
  errorMessage:string;
  minImporto: string;
  maxImporto: string;
  error: boolean;
  amount: number;
  isDecimal: boolean;
 // rateControl:number;
  @ViewChild('demo1') demo1: ElementRef;
  @ViewChild('demo2') demo2: ElementRef;

  constructor(private changeDetector: ChangeDetectorRef) { }

  ngOnInit() {
    this.minImporto = '10.0';
    this.maxImporto = '1000.00';
    this.isDecimal = true;
    this.myErrorMessage = 'Resolve the errors';
    //this.errorMessage="Please enter valid input";
    //this.rateControl = new FormControl("", [Validators.max(100), Validators.min(0)]);

    this.demoEvents = [
      { eventName: 'blur', eventCallBack: this.blurCallBack.bind(this) },
      { eventName: 'change', eventCallBack: this.changeCallBack.bind(this) },
      { eventName: 'focus', eventCallBack: this.focusCallBack.bind(this) },
      { eventName: 'click', eventCallBack: this.clickCallBack.bind(this) }
    ];

    this.anotherDemoEvents = [
      { eventName: 'blur', eventCallBack: this.blurCallBack.bind(this) },
      { eventName: 'change', eventCallBack: this.changeCallBack.bind(this) },
      { eventName: 'focus', eventCallBack: this.focusCallBack.bind(this) },
      { eventName: 'click', eventCallBack: this.clickCallBack.bind(this) }
    ];
    this.demoVariable = '';
    this.anotherDemoVariable = '';
  }

  toggleAccordion(event) {
     //alert(event)
  }

  ngAfterViewInit() {
    this.changeDetector.detectChanges();
  }

  blurCallBack(input, event) {
    console.log('blur callback called');
  }

  changeCallBack(input, event) {
    console.log('change callback called');
  }

  focusCallBack(input, event) {
    console.log('focus call back called');
  }

  clickCallBack(input, event) {
    console.log('click call back called');
  }

  setNewError(errors) {
    if (errors.length === 0) {
      this.error = false;
      this.errorMessage="";
    } else {
      this.error = true;
      this.errorMessage="Enter a valid currency";
    }
  }
}
