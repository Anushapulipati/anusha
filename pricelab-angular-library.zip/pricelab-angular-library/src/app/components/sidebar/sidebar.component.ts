import { Component, OnInit } from '@angular/core';
@Component({
  selector: 'demo-sidebar',
  templateUrl: './sidebar.component.html',
  styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
  _opened = true;
  mode = 'push'
  position = 'left';
  constructor() { }
  
  ngOnInit() {

  }
  
  toggleSidePanel() {
    this._opened = !this._opened;
    this.mode ='push';
  }

  togglePosition() {
    (this.position == 'left') ? this.position = 'top' : this.position = 'left';
  }

  toggleAccordion(event) {
    console.log(event);
  }
}
