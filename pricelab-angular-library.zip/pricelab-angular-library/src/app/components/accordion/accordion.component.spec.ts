import { async, ComponentFixture, TestBed, fakeAsync, tick, } from '@angular/core/testing';

import { AccordionComponent } from './accordion.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';


describe('AccordionComponent', () => {
  let component: AccordionComponent;
  let fixture: ComponentFixture<AccordionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccordionComponent ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccordionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call toggle button', fakeAsync( () => {
    fixture.detectChanges();
    spyOn(component, 'toggle');
    let button = fixture.debugElement.nativeElement.querySelector('button');
    button.click();
    tick();
    fixture.whenStable().then(() => {
      expect(component.toggle).toHaveBeenCalled();
    });
  }));

  it('should call toggle method', () => {
    const toggleMock = spyOn(component, 'toggle');
    fixture.debugElement.query(By.css('button')).triggerEventHandler('click', null);
    expect(toggleMock).toHaveBeenCalled();
    component.toggle();
  });

});