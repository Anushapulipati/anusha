import { Component } from '@angular/core';

@Component({
  selector: 'demo-accordion',
  templateUrl: './accordion.component.html',
  styleUrls: ['./accordion.component.scss']
})
export class AccordionComponent {
  isOpened: boolean;

  toggleAccordion(event) {
    console.log(event);
  }

  toggle() {
    this.isOpened = !this.isOpened;
  }
}
