import { Component, OnInit } from '@angular/core';
import { Attributo } from 'projects/pricelab-angular-library/src/lib/models/classes/attributo';
import { TipoFormatoAttributo } from 'projects/pricelab-angular-library/src/lib/models/classes/tipo-formato-attributo.enum';
import { Occorrenza } from 'projects/pricelab-angular-library/src/lib/models/classes/occorrenza';
import { ElencoOccorrenze } from 'projects/pricelab-angular-library/src/lib/models/classes/elenco-occorrenze';
import { Condizione } from 'projects/pricelab-angular-library/src/lib/models/classes/condizione';
import { TipoGestioneCondizione } from 'projects/pricelab-angular-library/src/lib/models/classes/tipo-gestione-condizione.enum';
import { ElencoCondizioni } from 'projects/pricelab-angular-library/src/lib/models/classes/elenco-condizioni';
import { Decorrenza } from 'projects/pricelab-angular-library/src/lib/models/classes/decorrenza';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'demo-decorrenza',
  templateUrl: './decorrenza.component.html',
  styleUrls: ['./decorrenza.component.scss']
})
export class DecorrenzaComponent {
  attr1: Attributo = new Attributo("Nostri Sportelli", TipoFormatoAttributo.A, [], "", "Canale");
  attr2: Attributo = new Attributo("1.250", TipoFormatoAttributo.N, [], "", "Permillare");
  attr3: Attributo = new Attributo("asd", TipoFormatoAttributo.N, [], "", "Importo massimo");
  attr4: Attributo = new Attributo("27.000", TipoFormatoAttributo.N, [], "", "Importo minimo");
  occorrenza1: Occorrenza = new Occorrenza([this.attr1, this.attr2, this.attr3, this.attr4], 1);

  attr5: Attributo = new Attributo("Altri Sportelli", TipoFormatoAttributo.A, [], "", "Canale");
  attr6: Attributo = new Attributo("1.500", TipoFormatoAttributo.N, [], "", "Permillare");
  attr7: Attributo = new Attributo("5.200", TipoFormatoAttributo.N, [], "", "Importo massimo");
  attr8: Attributo = new Attributo("27.050", TipoFormatoAttributo.N, [], "", "Importo minimo");
  occorrenza2: Occorrenza = new Occorrenza([this.attr5, this.attr6, this.attr7, this.attr8], 2);

  occorrenze1: Array<Occorrenza> = [this.occorrenza1, this.occorrenza2];
  elencoOccorrenze1: ElencoOccorrenze = new ElencoOccorrenze(this.occorrenze1);
  condizione1: Condizione = new Condizione(this.elencoOccorrenze1, TipoGestioneCondizione.F, "Condizione 1", "la condizione 1");



  attr9: Attributo = new Attributo("27.050", TipoFormatoAttributo.N, [], "", "Recupero Spese per Invio Comunicazioni Periodiche (€)");
  occorrenza3: Occorrenza = new Occorrenza([this.attr9], 1);

  occorrenze2: Array<Occorrenza> = [this.occorrenza3];
  elencoOccorrenze2: ElencoOccorrenze = new ElencoOccorrenze(this.occorrenze2);
  condizione2: Condizione = new Condizione(this.elencoOccorrenze2, TipoGestioneCondizione.S, "Condizione 2", "la condizione 2");



  attr10: Attributo = new Attributo("Occorrenza", TipoFormatoAttributo.A, [], "", "Attributo 1");
  attr11: Attributo = new Attributo("11.500", TipoFormatoAttributo.N, [], "", "Attributo 2");
  attr12: Attributo = new Attributo("55.200", TipoFormatoAttributo.N, [], "", "Attributo 3");
  attr13: Attributo = new Attributo("2,277.050", TipoFormatoAttributo.N, [], "", "Attributo 4");
  occorrenza4: Occorrenza = new Occorrenza([this.attr10, this.attr11, this.attr12, this.attr13], 1);

  occorrenze3: Array<Occorrenza> = [this.occorrenza4];
  elencoOccorrenze3: ElencoOccorrenze = new ElencoOccorrenze(this.occorrenze3);
  condizione3: Condizione = new Condizione(this.elencoOccorrenze3, TipoGestioneCondizione.V, "Condizione 3", "la condizione 3");



  condizioni: Array<Condizione> = [this.condizione1, this.condizione2, this.condizione3];
  elencoCondizioni: ElencoCondizioni = new ElencoCondizioni(this.condizioni);
  decorrenza: Decorrenza = new Decorrenza(this.elencoCondizioni);

  input: String = 'Iniziale';
  tipoGestioneCondizione = TipoGestioneCondizione;

  onSubmit(form: NgForm) {
    console.log("FORM COMPLETO");
    console.log(form.valid);
    console.log(form);
    // console.log(this.condizione);
  }
}
