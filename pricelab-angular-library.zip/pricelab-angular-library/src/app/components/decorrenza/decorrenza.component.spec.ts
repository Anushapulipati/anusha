import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DecorrenzaComponent } from './decorrenza.component';

describe('DecorrenzaComponent', () => {
  let component: DecorrenzaComponent;
  let fixture: ComponentFixture<DecorrenzaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DecorrenzaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DecorrenzaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
