import { async, ComponentFixture, TestBed, tick } from '@angular/core/testing';

import { FileUploadComponent } from './file-upload.component';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { By } from '@angular/platform-browser';
import { FileUploaderComponent } from 'projects/pricelab-angular-library/src/lib/components/file-uploader/file-uploader.component';

fdescribe('FileUploadComponent', () => {
  let component: FileUploadComponent;
  let fixture: ComponentFixture<FileUploadComponent>;
  let params;

  let childComponent: FileUploaderComponent;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [FileUploadComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FileUploadComponent);
    component = fixture.componentInstance;
    params ={
      event:{
      }
    }
    fixture.detectChanges();
  });

  fit('should create', () => {
    expect(component).toBeTruthy();
  });


  fit('should render title in a h2 tag', () => {
    // const fixture = TestBed.createComponent(FileUploadComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h2').textContent).toContain(
      'File uploader component');
  });

  fit('should select the file', () => {
    const fileList = { 0: { name: 'foo', size: 500001 } };
    component.fileName = fileList[0].name;
    fixture.detectChanges();
    expect(component.fileName).toEqual("foo");
  });

  fit('should recive the event from child',()=>{

    const debugElement = fixture.debugElement.query(By.css('pl-file-uploader'));
    debugElement.triggerEventHandler('selectedFile',params.event);
    expect(debugElement).toBeTruthy();
  });


});
