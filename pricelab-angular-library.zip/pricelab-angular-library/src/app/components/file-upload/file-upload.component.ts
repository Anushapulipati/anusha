import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'demo-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent implements OnInit { 
  fileName:string;

  constructor() { }

  getFileName(event:any) {
    this.fileName = event.target.files[0].name;
  }
 
  ngOnInit() {
  }
}
