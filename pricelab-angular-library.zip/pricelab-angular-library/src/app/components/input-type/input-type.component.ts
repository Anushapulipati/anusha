import { Component, OnInit, ChangeDetectorRef, ElementRef, ViewChild } from '@angular/core';
import { FormControl, Validators, FormGroup, FormBuilder } from '@angular/forms';
import { EventsModel } from 'projects/pricelab-angular-library/src/lib/models/event-model';


@Component({
  selector: 'pl-demo-input-type',
  templateUrl: './input-type.component.html',
  styleUrls: ['./input-type.component.scss']
})
export class DemoInputTypeComponent implements OnInit {

  anotherDemoVariable: string;
  demoVariable: string;
  demoEvents: EventsModel[] = [];
  anotherDemoEvents: EventsModel[] = [];
  myErrorMessage: string;
  errorMessage:string;
  minImporto: string;
  maxImporto: string;
  error: boolean;
  amount: number;
  isDecimal: boolean;
  registerForm: FormGroup;
    submitted = false;
    isValidFormSubmitted = false;
 // rateControl:number;
  @ViewChild('demo1') demo1: ElementRef;
  @ViewChild('demo2') demo2: ElementRef;

  constructor(private changeDetector: ChangeDetectorRef,private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.minImporto = '50.0';
    this.maxImporto = '100.00';
    this.isDecimal = true;
    this.myErrorMessage = 'Please enter valid input';
    //this.errorMessage="Please enter valid input";
    //this.rateControl = new FormControl("", [Validators.max(100), Validators.min(0)]);
    this.registerForm = this.formBuilder.group({

    email: ['', [Validators.required, Validators.email,Validators.pattern('^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$')]],
  });

    this.demoEvents = [
      { eventName: 'blur', eventCallBack: this.blurCallBack.bind(this) },
      { eventName: 'change', eventCallBack: this.changeCallBack.bind(this) },
      { eventName: 'focus', eventCallBack: this.focusCallBack.bind(this) },
      { eventName: 'click', eventCallBack: this.clickCallBack.bind(this) }
    ];

    this.anotherDemoEvents = [
      { eventName: 'blur', eventCallBack: this.blurCallBack.bind(this) },
      { eventName: 'change', eventCallBack: this.changeCallBack.bind(this) },
      { eventName: 'focus', eventCallBack: this.focusCallBack.bind(this) },
      { eventName: 'click', eventCallBack: this.clickCallBack.bind(this) }
    ];
    

    this.demoVariable = '';
    this.anotherDemoVariable = '';
    
  }
  

  toggleAccordion(event) {
     //alert(event)
  }

  ngAfterViewInit() {
    this.changeDetector.detectChanges();
  }

  blurCallBack(input, event) {
    console.log('blur callback called');
  }

  changeCallBack(input, event) {
    console.log('change callback called');
  }

  focusCallBack(input, event) {
    console.log('focus call back called');
  }

  clickCallBack(input, event) {
    console.log('click call back called');
  }

  setNewError(errors) {
    if (errors.length === 0) {
      this.error = false; 
    } else {
      this.error = true;
    }
  }

  get f() { return this.registerForm.controls; }
  onSubmit() {
    this.submitted = true;

    // stop here if form is invalid
    if (this.registerForm.invalid) {
        return;
    }

    alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.registerForm.value))
}
  
}
