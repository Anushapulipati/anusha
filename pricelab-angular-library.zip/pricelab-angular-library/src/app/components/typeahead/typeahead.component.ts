import {Component, OnInit} from '@angular/core';
import { TypeaheadService } from './typeahead.service';

@Component({
  selector: 'demo-typeahead-input',
  templateUrl: './typeahead.component.html',
  styles: ['./typeahead.component.scss']
})
export class TypeaheadComponent implements OnInit{
  demoSelectedValue = {};
  listData: any;

  constructor(private typeaheadService: TypeaheadService) { }

  ngOnInit() {
    this.loadTypeaheadData();
  }

  loadTypeaheadData() {
    return this.typeaheadService.getTypeaheadList().subscribe(typeaheadList => {
       this.listData = typeaheadList;   
     });
  }

  selected(eventSelectedValue:String) {
    console.log('Received value '+eventSelectedValue)
    this.demoSelectedValue = eventSelectedValue;
  }
}
