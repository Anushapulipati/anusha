import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TypeaheadService {

  constructor(
    private httpClient: HttpClient
  ) { }

  getTypeaheadList() {
    return this.httpClient.get('assets/links.json');
  }
}
