import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InputBrokenExampleComponent } from './input-broken-example.component';

describe('InputBrokenExampleComponent', () => {
  let component: InputBrokenExampleComponent;
  let fixture: ComponentFixture<InputBrokenExampleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InputBrokenExampleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InputBrokenExampleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
