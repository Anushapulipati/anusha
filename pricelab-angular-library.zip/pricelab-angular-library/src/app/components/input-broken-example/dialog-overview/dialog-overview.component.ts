import { Component } from '@angular/core';
import { DialogRef, DialogModel } from 'projects/pricelab-angular-library/src/public_api';

@Component({
  selector: 'demo-dialog-overview',
  templateUrl: './dialog-overview.component.html',
  styleUrls: ['./dialog-overview.component.scss']
})
export class DialogErrorOverviewComponent {
  demoVariable: string;

  constructor(
    public dialog: DialogRef,
    public config: DialogModel
  ) {
  }

  onCloseMain(data) {
    this.dialog.close(data);
  }

  changeCallBack(event) {
    console.log(event);
  }
}
