import { Component } from '@angular/core';
import { DialogErrorOverviewComponent } from './dialog-overview/dialog-overview.component';
import { DialogService } from 'projects/pricelab-angular-library/src/lib/components/dialog/dialog.service';

@Component({
  selector: 'demo-input-broken-example',
  templateUrl: './input-broken-example.component.html',
  styleUrls: ['./input-broken-example.component.scss']
})
export class InputBrokenExampleComponent {
  constructor(
    public dialog: DialogService
  ) { }

  openModal() {
    const ref = this.dialog.open(DialogErrorOverviewComponent, {
      size: 'medium',
      title: 'Modal Header',
      noCloseButton: false,
      externalHeaderClass: {
        'bg-primary': true,
        'text-light': true
      },
      data: { message: 'this is data transfer to pop up' }
    });
    ref.afterClosed.subscribe();
  }
}
