import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'demo-example-ngb-tooltip',
  templateUrl: './example-ngb-tooltip.component.html',
  styleUrls: ['./example-ngb-tooltip.component.scss']
})
export class ExampleNgbTooltipComponent implements OnInit {

  input: String = 'Iniziale';

  constructor() { }

  ngOnInit() {
  }

  toggleAccordion(event) {
  }
}
