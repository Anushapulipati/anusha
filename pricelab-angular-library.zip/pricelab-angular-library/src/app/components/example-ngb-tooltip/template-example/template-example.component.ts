import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'demo-template-example',
  templateUrl: './template-example.component.html',
  styleUrls: ['./template-example.component.scss']
})
export class TemplateExampleComponent implements OnInit {

  @Input() input: string;

  constructor() { }

  ngOnInit() {
  }

}
