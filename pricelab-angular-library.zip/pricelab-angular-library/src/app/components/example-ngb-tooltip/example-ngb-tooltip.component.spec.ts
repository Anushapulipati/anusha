import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExampleNgbTooltipComponent } from './example-ngb-tooltip.component';

describe('ExampleNgbTooltipComponent', () => {
  let component: ExampleNgbTooltipComponent;
  let fixture: ComponentFixture<ExampleNgbTooltipComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExampleNgbTooltipComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExampleNgbTooltipComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
