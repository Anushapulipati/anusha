import { Component, OnInit } from '@angular/core';
import { LoaderService } from 'projects/pricelab-angular-library/src/public_api';

@Component({
  selector: 'demo-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit {
  showLoader = false;
  constructor(
    private loaderService: LoaderService
  ) { }

  ngOnInit() {
  }

  getLoader() {
    // this.showLoader = true;
    this.loaderService.show();
    setTimeout(() => {
      // this.showLoader = false;
      this.loaderService.hide();
    }, 3000);
  }

  
  toggleAccordion(event) {
    // alert(event)
  }
}
