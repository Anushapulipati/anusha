import { Component, OnInit } from '@angular/core';
import { EventsModel } from 'projects/pricelab-angular-library/src/lib/models/event-model';
import { SelectOptionModel } from 'projects/pricelab-angular-library/src/lib/models/select-option-model';

@Component({
  selector: 'demo-search-select',
  templateUrl: './search-select.component.html',
  styleUrls: ['./search-select.component.scss']
})
export class SearchSelectComponent implements OnInit {
  selectedValue = 'primary';
  secondSelect: string;
  demoEvents: EventsModel[] = [];

  private states: SelectOptionModel[] = [
    {
      value: 'Alabama',
      description: 'Alabama'
    },
    {
      value: 'Alaska',
      description: 'Alaska',
      checked: true
    },
    {
      value: 'Delaware',
      description: 'Delaware'
    },
    {
      value: 'Maryland',
      description: 'Maryland'
    }];

  constructor() {
  }

  ngOnInit() {
    this.demoEvents = [
      { eventName: 'blur', eventCallBack: this.blurCallBack.bind(this) },
      { eventName: 'change', eventCallBack: this.changeCallBack.bind(this) },
      { eventName: 'focus', eventCallBack: this.focusCallBack.bind(this) },
      { eventName: 'click', eventCallBack: this.clickCallBack.bind(this) }
    ];
  }

  blurCallBack(input, event) {
    console.log('blur callback called');
  }

  changeCallBack(input, event) {
    console.log('click callback called');
  }

  focusCallBack(input, event) {
    console.log('focus call back called');
  }

  clickCallBack(input, event) {
    console.log('click call back called');
  }
}
