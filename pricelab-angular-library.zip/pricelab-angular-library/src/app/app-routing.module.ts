import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { AccordionComponent } from './components/accordion/accordion.component';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { LoaderComponent } from './components/loader/loader.component';
import { TooltipComponent } from './components/tooltip/tooltip.component';
import { TypeaheadComponent } from './components/typeahead/typeahead.component';
import { SearchSelectComponent } from './components/search-select/search-select.component';
import { DialogComponent } from './components/dialog/dialog.component';
import { DatepickerComponent } from './components/datepicker/datepicker.component';
import { ErrorPopupComponent } from './components/error-popup/error-popup.component';
import { DemoInputTypeComponent } from './components/input-type/input-type.component';
import { ExampleNgbTooltipComponent } from './components/example-ngb-tooltip/example-ngb-tooltip.component';
import { DecorrenzaComponent } from './components/decorrenza/decorrenza.component';
import { InputBrokenExampleComponent } from './components/input-broken-example/input-broken-example.component';

const routes: Routes = [
  {
    path: '',
    redirectTo: 'loader',
    pathMatch: 'full'
  },
  {
    path: 'sidebar',
    component: SidebarComponent
  },
  {
    path: 'accordion',
    component: AccordionComponent
  },
  {
    path: 'file-upload',
    component: FileUploadComponent
  },
  {
    path: 'loader',
    component: LoaderComponent
  },
  {
    path: 'tooltip',
    component: TooltipComponent
  },
  {
    path: 'typeahead',
    component: TypeaheadComponent
  },
  {
    path: 'select',
    component: SearchSelectComponent
  },
  {
    path: 'modal',
    component: DialogComponent
  },
  {
    path: 'datepicker',
    component: DatepickerComponent
  },
  {
    path: 'error-popup',
    component: ErrorPopupComponent
  },
  {
    path: 'input-type',
    component: DemoInputTypeComponent
  },
  {
    path: 'example-tooltip',
    component: ExampleNgbTooltipComponent
  },
  {
    path: 'decorrenza',
    component: DecorrenzaComponent
  },
  {
    path: 'input-broken-example',
    component: InputBrokenExampleComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
