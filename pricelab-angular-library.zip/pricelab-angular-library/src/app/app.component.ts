import { Component } from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'Pricelab Library';
  _opened = true;
  mode = 'push'
  toggleSidePanel() {
    this._opened = !this._opened;
    this.mode ='slide';
  }

 
}
