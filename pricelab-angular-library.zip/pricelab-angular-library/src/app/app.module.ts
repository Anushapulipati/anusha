import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PricelabAngularLibraryModule } from 'projects/pricelab-angular-library/src/lib/pricelab-angular-library.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { LinksComponent } from './components/links/links.component';
import { SidebarModule } from 'ng-sidebar';
import { SidebarComponent } from './components/sidebar/sidebar.component';
import { AccordionComponent } from './components/accordion/accordion.component';
import { FileUploadComponent } from './components/file-upload/file-upload.component';
import { LoaderComponent } from './components/loader/loader.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DialogComponent } from './components/dialog/dialog.component';
import { DialogOverviewComponent } from './components/dialog/dialog-overview/dialog-overview.component';
import { DatepickerComponent } from './components/datepicker/datepicker.component';
import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { SearchSelectComponent } from './components/search-select/search-select.component';
import { TypeaheadComponent } from './components/typeahead/typeahead.component';
import { DemoInputTypeComponent } from './components/input-type/input-type.component';
import { TypeaheadService } from './components/typeahead/typeahead.service';
import { HttpClientModule } from '@angular/common/http';
import { ErrorPopupComponent } from './components/error-popup/error-popup.component';
import { TooltipComponent } from './components/tooltip/tooltip.component';
import { ExampleNgbTooltipComponent } from './components/example-ngb-tooltip/example-ngb-tooltip.component';
import { TemplateExampleComponent } from './components/example-ngb-tooltip/template-example/template-example.component';
import { DecorrenzaComponent } from './components/decorrenza/decorrenza.component';
import { InputBrokenExampleComponent } from './components/input-broken-example/input-broken-example.component';
import { DialogErrorOverviewComponent } from './components/input-broken-example/dialog-overview/dialog-overview.component';

@NgModule({
  declarations: [
    AppComponent,
    LinksComponent,
    SidebarComponent,
    AccordionComponent,
    LoaderComponent,
    FileUploadComponent,
    DialogComponent,
    DialogOverviewComponent,
    DatepickerComponent,
    SearchSelectComponent,
    TypeaheadComponent,
    ErrorPopupComponent,
    DemoInputTypeComponent,
    TooltipComponent,
    ExampleNgbTooltipComponent,
    TemplateExampleComponent,
    DecorrenzaComponent,
    InputBrokenExampleComponent,
    DialogErrorOverviewComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AppRoutingModule,
    PricelabAngularLibraryModule,
    FontAwesomeModule,
    NgbModule,
    BrowserAnimationsModule,
    SidebarModule.forRoot(),
    HttpClientModule
  ],
  providers: [
    TypeaheadService
  ],
  bootstrap: [AppComponent],
  entryComponents: [
    DialogOverviewComponent,
    ErrorPopupComponent,
    DialogErrorOverviewComponent
  ]
})

export class AppModule { }
