import {enableProdMode} from '@angular/core';
import {platformBrowserDynamic} from '@angular/platform-browser-dynamic';

import {AppModule} from './app/app.module';
import {environment} from './environments/environment';
import {environmentLoader} from './environments/environmentLoader';

environmentLoader.then(env => {
  if (environment.production) {
    enableProdMode();
  }

  environment.production = env.production;
  environment.apiUrl = env.apiUrl;
  environment.developmentMode = env.developmentMode;

  platformBrowserDynamic().bootstrapModule(AppModule)
    .catch(err => console.error(err));

});
