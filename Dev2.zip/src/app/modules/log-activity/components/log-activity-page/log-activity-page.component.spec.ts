import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LogActivityPageComponent } from './log-activity-page.component';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { MultiselectDropdownComponent } from 'src/app/shared/components/multiselect-dropdown/multiselect-dropdown.component';
import { LogActivityService } from '../../services/log-activity.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ProposteService } from 'src/app/modules/proposte/services/proposte.service';
import { SearchInputService } from 'src/app/shared/services/search-input.service';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('LogActivityPageComponent', () => {
  let component: LogActivityPageComponent;
  let fixture: ComponentFixture<LogActivityPageComponent>;
  let logService;
  let logactivityForm;
  let proposteService;
  let mockResponse;
  let date: any;

  beforeEach(async(() => {
    logService = jasmine.createSpyObj(['getFilteredLogDetails']);
    proposteService = jasmine.createSpyObj(['getUTCDate', 'getDropdownData']);
    // searchInputService = jasmine.createSpyObj(['getSearchResults']);
    TestBed.configureTestingModule({
      declarations: [ LogActivityPageComponent, MultiselectDropdownComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        NgbModule,
        HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: LogActivityService, useValue: logService },
        { provide: ProposteService, useValue: proposteService },
        /* { provide: SearchInputService, useValue: searchInputService }, */


      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
      logactivityForm = new FormGroup({
      fromDate: new FormControl(),
      toDate: new FormControl(),
      matricola: new FormControl([]),
      campo: new FormControl([]),
      orderBy: new FormControl(''),
    });
    date  = {
      day: 12,
      month : 12,
      year : 2020
      };
    // tslint:disable-next-line: max-line-length
    const dropdownData = {'Matricola': [{'itemId': '1', 'tableId': 'Matricola', 'itemName': '810011', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Matricola', 'itemName': '810012', 'subDomainList': null}, {'itemId': '3', 'tableId': 'Matricola', 'itemName': '810013', 'subDomainList': null}, {'itemId': '4', 'tableId': 'Matricola', 'itemName': '810014', 'subDomainList': null}, {'itemId': '5', 'tableId': 'Matricola', 'itemName': '810015', 'subDomainList': null}, {'itemId': '6', 'tableId': 'Matricola', 'itemName': '810016', 'subDomainList': null}], 'Campo': [{'itemId': '1', 'tableId': 'Campo', 'itemName': 'Societa del referente di contratto', 'subDomainList': null}, {'itemId': '10', 'tableId': 'Campo', 'itemName': 'Fornitura ICT non rilevante', 'subDomainList': null}, {'itemId': '11', 'tableId': 'Campo', 'itemName': 'Fornitura ICT con rischio basso medio alto', 'subDomainList': null}, {'itemId': '12', 'tableId': 'Campo', 'itemName': 'Codice Contratto', 'subDomainList': null}, {'itemId': '13', 'tableId': 'Campo', 'itemName': 'Ogetto del contratto', 'subDomainList': null}, {'itemId': '14', 'tableId': 'Campo', 'itemName': 'Descrizione del servizio erogato', 'subDomainList': null}, {'itemId': '15', 'tableId': 'Campo', 'itemName': 'Stato del Contratto', 'subDomainList': null}, {'itemId': '16', 'tableId': 'Campo', 'itemName': 'Data di decorrenza del contratto', 'subDomainList': null}, {'itemId': '17', 'tableId': 'Campo', 'itemName': 'Data di sottoscrizione del contratto', 'subDomainList': null}, {'itemId': '18', 'tableId': 'Campo', 'itemName': 'Tacito rinnovo', 'subDomainList': null}, {'itemId': '19', 'tableId': 'Campo', 'itemName': 'Durata nel rinnovo (mesi)', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Campo', 'itemName': 'SLA Monitorati', 'subDomainList': null}, {'itemId': '20', 'tableId': 'Campo', 'itemName': 'Data cessazioone del contratto', 'subDomainList': null}, {'itemId': '21', 'tableId': 'Campo', 'itemName': 'Data di ultimorinnovo del contratto', 'subDomainList': null}, {'itemId': '22', 'tableId': 'Campo', 'itemName': 'Costo totaledel contratto', 'subDomainList': null}, {'itemId': '23', 'tableId': 'Campo', 'itemName': 'Data di scadenza del contratto', 'subDomainList': null}, {'itemId': '24', 'tableId': 'Campo', 'itemName': 'Termini preavviso - Cliente', 'subDomainList': null}, {'itemId': '25', 'tableId': 'Campo', 'itemName': 'Termini preavviso - Fornitore', 'subDomainList': null}, {'itemId': '26', 'tableId': 'Campo', 'itemName': 'Possibilita di recesso', 'subDomainList': null}, {'itemId': '27', 'tableId': 'Campo', 'itemName': 'Soglia di impatto dell\'interruzione della funzione', 'subDomainList': null}, {'itemId': '28', 'tableId': 'Campo', 'itemName': 'Costo annuo di esercizio del contratto sostenuto nell esercizio precedente - Attività running', 'subDomainList': null}, {'itemId': '29', 'tableId': 'Campo', 'itemName': 'Sostituibilità', 'subDomainList': null}, {'itemId': '3', 'tableId': 'Campo', 'itemName': 'Societa del Referente erogatore servizi IT', 'subDomainList': null}, {'itemId': '30', 'tableId': 'Campo', 'itemName': 'Fornitori alternativi', 'subDomainList': null}, {'itemId': '31', 'tableId': 'Campo', 'itemName': 'Possibilità di reinternalizzazione', 'subDomainList': null}, {'itemId': '32', 'tableId': 'Campo', 'itemName': 'Numero subfornitori', 'subDomainList': null}, {'itemId': '33', 'tableId': 'Campo', 'itemName': 'Costo stimato del contratto per lanno in corso - Attività running', 'subDomainList': null}, {'itemId': '34', 'tableId': 'Campo', 'itemName': 'Stato del Servizio', 'subDomainList': null}, {'itemId': '35', 'tableId': 'Campo', 'itemName': 'Data di decorrenza del servizio', 'subDomainList': null}, {'itemId': '36', 'tableId': 'Campo', 'itemName': 'Data sottoscrizione del servizio', 'subDomainList': null}, {'itemId': '37', 'tableId': 'Campo', 'itemName': 'Data di scadenza del servizio', 'subDomainList': null}, {'itemId': '38', 'tableId': 'Campo', 'itemName': 'Data di cessazione del servizio', 'subDomainList': null}, {'itemId': '4', 'tableId': 'Campo', 'itemName': 'Referente di contratto', 'subDomainList': null}, {'itemId': '5', 'tableId': 'Campo', 'itemName': 'Referente erogatore servizi IT', 'subDomainList': null}, {'itemId': '6', 'tableId': 'Campo', 'itemName': 'Comunicazioni tra le Parti - Cliente interno(Unita Organizzativa)', 'subDomainList': null}, {'itemId': '7', 'tableId': 'Campo', 'itemName': 'Classificazione', 'subDomainList': null}, {'itemId': '8', 'tableId': 'Campo', 'itemName': 'Comunicazioni tra le Parti - Fornitore Infragruppo(Unita Organizzativa)', 'subDomainList': null}, {'itemId': '9', 'tableId': 'Campo', 'itemName': 'Gestore di budget', 'subDomainList': null}], 'Ordina per log activity': [{'itemId': '1', 'tableId': 'Ordina per log activity', 'itemName': 'Più recenti', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Ordina per log activity', 'itemName': 'Meno recenti', 'subDomainList': null}]};
    const searchResponse = {};
    // tslint:disable-next-line: max-line-length
    mockResponse = {'searchResultList': [{'logActivityId': 42, 'dataEOrario': '2020-12-07 15:51:34', 'matricola': 810011, 'idRegistro': 76, 'campo': 'NOTE', 'valorePrecedente': 'Testing note', 'valoreNuovo': 'Pradeep'}, {'logActivityId': 43, 'dataEOrario': '2020-12-07 15:54:45', 'matricola': 810011, 'idRegistro': 76, 'campo': 'NOTE', 'valorePrecedente': 'Pradeep', 'valoreNuovo': 'Pradeep1'}, {'logActivityId': 44, 'dataEOrario': '2020-12-07 15:59:07', 'matricola': 810011, 'idRegistro': 76, 'campo': 'data_di_sottoscrizione', 'valorePrecedente': 'Pradeep1', 'valoreNuovo': 'Pradeep1'}, {'logActivityId': 45, 'dataEOrario': '2020-12-07 16:00:23', 'matricola': 810011, 'idRegistro': 76, 'campo': 'data_di_sottoscrizione', 'valorePrecedente': 'Pradeep1', 'valoreNuovo': 'Pradeep1'}, {'logActivityId': 46, 'dataEOrario': '2020-12-07 16:01:05', 'matricola': 810011, 'idRegistro': 76, 'campo': 'NOTE', 'valorePrecedente': '128', 'valoreNuovo': '128'}, {'logActivityId': 47, 'dataEOrario': '2020-12-08 07:32:57', 'matricola': 810011, 'idRegistro': 76, 'campo': 'NOTE', 'valorePrecedente': '128', 'valoreNuovo': '128'}, {'logActivityId': 48, 'dataEOrario': '2020-12-08 08:31:57', 'matricola': 810011, 'idRegistro': 76, 'campo': 'Data Di Sottoscrizione', 'valorePrecedente': '2020-12-08', 'valoreNuovo': '2020-12-08'}, {'logActivityId': 49, 'dataEOrario': '2020-12-08 13:24:38', 'matricola': 810011, 'idRegistro': 106, 'campo': 'NOTE', 'valorePrecedente': 'Test Note', 'valoreNuovo': 'Test Note'}, {'logActivityId': 50, 'dataEOrario': '2020-12-08 13:24:38', 'matricola': 810011, 'idRegistro': 106, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'First servizio Test1234', 'valoreNuovo': 'First servizio Test1234'}, {'logActivityId': 51, 'dataEOrario': '2020-12-08 15:03:19', 'matricola': 810011, 'idRegistro': 133, 'campo': 'NOTE', 'valorePrecedente': null, 'valoreNuovo': null}, {'logActivityId': 52, 'dataEOrario': '2020-12-08 15:03:19', 'matricola': 810011, 'idRegistro': 133, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'Esternalizzazione FEI', 'valoreNuovo': 'Esternalizzazione FEI'}, {'logActivityId': 53, 'dataEOrario': '2020-12-08 15:06:44', 'matricola': 810011, 'idRegistro': 136, 'campo': 'NOTE', 'valorePrecedente': null, 'valoreNuovo': null}, {'logActivityId': 54, 'dataEOrario': '2020-12-08 15:06:44', 'matricola': 810011, 'idRegistro': 136, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'Esternalizzazione FEI', 'valoreNuovo': 'Esternalizzazione FEI'}, {'logActivityId': 55, 'dataEOrario': '2020-12-08 15:07:52', 'matricola': 810011, 'idRegistro': 136, 'campo': 'NOTE', 'valorePrecedente': null, 'valoreNuovo': null}, {'logActivityId': 56, 'dataEOrario': '2020-12-08 15:07:52', 'matricola': 810011, 'idRegistro': 136, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'Esternalizzazione FEI', 'valoreNuovo': 'Esternalizzazione FEI'}, {'logActivityId': 57, 'dataEOrario': '2020-12-08 17:02:30', 'matricola': 810011, 'idRegistro': 106, 'campo': 'NOTE', 'valorePrecedente': 'Test Note', 'valoreNuovo': 'Test Note'}, {'logActivityId': 58, 'dataEOrario': '2020-12-08 17:02:30', 'matricola': 810011, 'idRegistro': 106, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'First servizio Test1234', 'valoreNuovo': 'First servizio Test1234'}, {'logActivityId': 59, 'dataEOrario': '2020-12-08 17:16:17', 'matricola': 810011, 'idRegistro': 106, 'campo': 'NOTE', 'valorePrecedente': 'Test Note', 'valoreNuovo': 'Test'}, {'logActivityId': 60, 'dataEOrario': '2020-12-08 17:16:17', 'matricola': 810011, 'idRegistro': 106, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'First servizio Test1234', 'valoreNuovo': 'First servizio Test1234'}, {'logActivityId': 61, 'dataEOrario': '2020-12-08 17:21:16', 'matricola': 810011, 'idRegistro': 106, 'campo': 'NOTE', 'valorePrecedente': 'Test', 'valoreNuovo': 'Test Note'}], 'collectionSize': 577};
    proposteService.getUTCDate.and.returnValue(of(new Date()));
    proposteService.getDropdownData.and.returnValue(of(dropdownData));
    logService.getFilteredLogDetails.and.returnValue(of(mockResponse));
    // searchInputService.getSearchResults.and.returnValue(of(searchResponse));
    fixture = TestBed.createComponent(LogActivityPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show label names', () => {
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('label').textContent).toContain('label.logActivity.Periodo');
  });

  it('should check filter keys', () => {
    const filterKeys = ['Campo', 'Matricola', 'Ordina per log activity'];
    fixture.detectChanges();
    expect(component.filterKeys).toEqual(filterKeys);
  });

 it('should call applyFilter and return the said result', () => {
    // tslint:disable-next-line: max-line-length


    const mockParameter = {};
    logService.getFilteredLogDetails.and.returnValue(of(mockResponse));
    component.applyFilter();
    fixture.detectChanges();
    expect(logService.getFilteredLogDetails).toHaveBeenCalled();
    logService.getFilteredLogDetails(logactivityForm).subscribe(result => {
      expect(result).toBe(mockResponse);
    });
  });

  it('should call ngoninit', () => {
    spyOn(component, 'ngOnInit');
    component.ngOnInit();
    expect(component.ngOnInit).toHaveBeenCalled();
  });
  it('should call onPageChange method', () => {
    component.isSearchedResult = false;
    // component.anagraficheForm.controls['ordinaPer'].setValue(anagraficheForm.get('ordinaPer').value);
    // component.anagraficheForm.controls['classificazione'].setValue(anagraficheForm.get('classificazione').value);
    component.onPageChange(1);
    expect(component.page).toBe(1);
    expect(component.isSearchedResult).toBe(false);
  });

  it('should call onCampoChange method', () => {
    spyOn(component, 'onCampoChange');
    component.onCampoChange(logactivityForm.get('campo').value);
    expect(component.onCampoChange).toHaveBeenCalled();
  });
  it('should call onOrdinaperChange method', () => {
    spyOn(component, 'onOrdinaperChange');
    component.onOrdinaperChange(logactivityForm.get('orderBy').value);
    expect(component.onOrdinaperChange).toHaveBeenCalled();
  });

  it('should call onDateSelection method', () => {
    spyOn(component, 'onDateSelection');
    component.onDateSelection(date);
    expect(component.onDateSelection).toHaveBeenCalled();
  });

  it('should call validateInput method', () => {
    spyOn(component, 'validateInput');
    component.validateInput(date, 'date');
    expect(component.validateInput).toHaveBeenCalled();
  });

  it('should call ngOnDestroy', () => {
    spyOn(component, 'ngOnDestroy');
    component.ngOnDestroy();
    expect(component.ngOnDestroy).toHaveBeenCalled();
  });

  it('should call isRange method', () => {
    spyOn(component, 'isRange');
    component.isRange(date);
    expect(component.isRange).toHaveBeenCalled();
  });
  it('should call isInside method', () => {
    spyOn(component, 'isInside');
    component.isInside(date);
    expect(component.isInside).toHaveBeenCalled();
  });
  it('should call isHovered method', () => {
    spyOn(component, 'isHovered');
    component.isHovered(date);
    expect(component.isHovered).toHaveBeenCalled();
  });
});
