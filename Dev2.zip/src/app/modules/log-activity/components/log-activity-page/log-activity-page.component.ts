import { Component, OnInit, Injector, OnDestroy } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { NgbDateCustomParserFormatter } from 'src/app/shared/services/dateFormat';
import { LogActivityService } from '../../services/log-activity.service';
import { ProposteService } from 'src/app/modules/proposte/services/proposte.service';
import { BasePage } from 'src/app/shared/base-page/base-page';
import {NgbDate, NgbCalendar, NgbDateParserFormatter} from '@ng-bootstrap/ng-bootstrap';
import { SearchInputService } from 'src/app/shared/services/search-input.service';
import { DropdownTreeviewI18nService } from 'src/app/shared/services/dropdown-treeview-i18n.service';
import { TreeviewI18n } from 'ngx-treeview';

@Component({
  selector: 'reg-log-activity-page',
  templateUrl: './log-activity-page.component.html',
  styleUrls: ['./log-activity-page.component.scss'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter },
    DropdownTreeviewI18nService,
    { provide: TreeviewI18n, useClass: DropdownTreeviewI18nService }
  ]
})
export class LogActivityPageComponent extends BasePage implements OnInit, OnDestroy {
  calendar: NgbCalendar;
  campo: any;
  collectionSize: any;
  filterKeys = ['Campo', 'Matricola', 'Ordina per log activity'];
  fromDate: NgbDate;
  hoveredDate: NgbDate | null = null;
  isFilterApplied: boolean;
  isSearchedResult = false;
  logactivityForm = new FormGroup({
    fromDate: new FormControl(),
    toDate: new FormControl(),
    matricola: new FormControl([]),
    campo: new FormControl([]),
    orderBy: new FormControl(''),
  });
  logList: any;
  matricola: any;
  ordinaper: any;
  ordinaPer: any;
  page = 1;
  pageSize = 20;
  searchData: any;
  subscription: any;
  toDate: NgbDate | null = null;
  value = 1;
  value1 = 10;
  value2 = 20;
  value3 = 30;

  constructor(
    calendar: NgbCalendar,
    injector: Injector,
    private logActivityService: LogActivityService,
    private proposteService: ProposteService,
    public formatter: NgbDateParserFormatter,
    private searchInputService: SearchInputService
  ) {
    super(injector);
    this.fromDate = calendar.getPrev(calendar.getToday(), 'd', 30);
    this.toDate =  calendar.getToday();
  }

  private checkSearchInput() {
    this.subscription = this.searchInputService.getSearchInput().subscribe((searchInput: any) => {
      if (searchInput && searchInput.inputValue !== '' && searchInput.inputValue !== undefined) {
        this.page = 1;
        this.isSearchedResult = true;
        this.searchData = {
          name : searchInput.page,
          value : searchInput.inputValue,
          startIndex : this.page
        };
        this.getSearchData(this.searchData);
      } else {
        this.isSearchedResult = false;
        this.getDropdownTableKeys();
      }
    });
  }

  private getDropdownTableKeys() {
    this.proposteService.getDropdownData(this.filterKeys).subscribe(async filters => {
      this.campo = await this.getFilterdData(filters[this.filterKeys[0]]);
      this.matricola = await this.getFilterdData(filters[this.filterKeys[1]]);
      this.ordinaper = await this.getFilterdData(filters[this.filterKeys[2]]);
      const logData = {
        matricola: [810011],
        campo: ['Societa del referente di contratto'],
        fromDate: this.proposteService.getUTCDate(this.fromDate),
        toDate: this.proposteService.getUTCDate(this.toDate),
        orderBy: 'Più recenti'
      };
      if (!this.isSearchedResult) {
        this.getFilteredLogDetails(logData);
      }
    });
  }

  private getFilteredLogDetails(logDetails) {
    logDetails['pageNo'] = this.page;
    this.logActivityService.getFilteredLogDetails(logDetails).subscribe(logList => {
      this.collectionSize = logList['collectionSize'];
      this.logList = logList.searchResultList;
    });
  }

  private getSearchData(searchData) {
    this.searchInputService.getSearchResults(searchData).subscribe(searchResult => {
      this.collectionSize = searchResult['count'];
      this.logList = searchResult['logActivity'];
      this.isSearchedResult = true;
    });
  }

  applyFilter() {
    this.page = 1;
    this.isSearchedResult = false;
    this.isFilterApplied = true;
    const logData = {
      ...this.logactivityForm.value,
      fromDate: this.proposteService.getUTCDate(this.fromDate),
      toDate: this.proposteService.getUTCDate(this.toDate),
    };
    this.getFilteredLogDetails(logData);
  }

  isHovered(date: NgbDate) {
    return this.fromDate && !this.toDate && this.hoveredDate && date.after(this.fromDate) && date.before(this.hoveredDate);
  }

  isInside(date: NgbDate) {
    return this.toDate && date.after(this.fromDate) && date.before(this.toDate);
  }

  isRange(date: NgbDate) {
    return date.equals(this.fromDate) || (this.toDate && date.equals(this.toDate)) || this.isInside(date) || this.isHovered(date);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  async ngOnInit() {
    this.searchInputService.setSelectedOption('logActivity');
    await this.getDropdownTableKeys();
    this.checkSearchInput();
    // this.searchInputService.setSearchInput(false);

  }

  onCampoChange(value) {
    this.logactivityForm.get('campo').setValue('Societa del referente di contratto');
  }

  onDateSelection(date: NgbDate) {
    if (!this.fromDate && !this.toDate) {
      this.fromDate = date;
    } else if (this.fromDate && !this.toDate && date && date.after(this.fromDate)) {
      this.toDate = date;
    } else {
      this.toDate = null;
      this.fromDate = date;
    }
  }

  onOrdinaperChange(value) {
    this.logactivityForm.get('orderBy').setValue(value);
  }

  onPageChange(event) {
    this.page = event;
    let logDetails;
    if (this.isFilterApplied) {
      // logDetails = this.logactivityForm.value;
      logDetails = {
        ...this.logactivityForm.value,
        fromDate: this.proposteService.getUTCDate(this.fromDate),
        toDate: this.proposteService.getUTCDate(this.toDate),
      };
    } else {
      logDetails = {
        matricola: [810011],
        campo: ['Societa del referente di contratto'],
        fromDate: this.proposteService.getUTCDate(this.fromDate),
        toDate: this.proposteService.getUTCDate(this.toDate),
        orderBy: 'Più recenti'
      };
    }
    if (this.isSearchedResult) {
      this.searchData['startIndex'] = this.page;
      this.getSearchData(this.searchData);
    } else {
      this.getFilteredLogDetails(logDetails);
    }

  }

  validateInput(currentValue: NgbDate | null, input: string): NgbDate | null {
    const parsed = this.formatter.parse(input);
    return parsed && this.calendar.isValid(NgbDate.from(parsed)) ? NgbDate.from(parsed) : currentValue;
  }
}
