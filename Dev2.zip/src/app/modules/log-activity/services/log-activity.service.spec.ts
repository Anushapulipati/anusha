import { TestBed } from '@angular/core/testing';

import { LogActivityService } from './log-activity.service';
import { UrlProviderService } from 'src/app/shared/services/url-provider.service';
import { HttpClientTestingModule, HttpTestingController, TestRequest } from '@angular/common/http/testing';
import { FormGroup, FormControl } from '@angular/forms';

describe('LogActivityService', () => {
  let logActivityService;
  let httpTestingController;
  let urlProviderService;
  beforeEach(() => {
    TestBed.configureTestingModule({
    providers: [
      LogActivityService,
      UrlProviderService],
      imports: [HttpClientTestingModule],
  });
  logActivityService = TestBed.get(LogActivityService);
  httpTestingController = TestBed.get(HttpTestingController);
  urlProviderService = TestBed.get(UrlProviderService);
});

  it('should be created', () => {
    const service: LogActivityService = TestBed.get(LogActivityService);
    expect(service).toBeTruthy();
  });

  it('should call getFilteredLogDetails with this request method and url', () => {
    const   logactivityForm = new FormGroup({
      fromDate: new FormControl(),
      toDate: new FormControl(),
      matricola: new FormControl([]),
      campo: new FormControl([]),
      orderBy: new FormControl(''),
    });
    // tslint:disable-next-line: max-line-length
    const getResponse = {'searchResultList': [{'logActivityId': 42, 'dataEOrario': '2020-12-07 15:51:34', 'matricola': 810011, 'idRegistro': 76, 'campo': 'NOTE', 'valorePrecedente': 'Testing note', 'valoreNuovo': 'Pradeep'}, {'logActivityId': 43, 'dataEOrario': '2020-12-07 15:54:45', 'matricola': 810011, 'idRegistro': 76, 'campo': 'NOTE', 'valorePrecedente': 'Pradeep', 'valoreNuovo': 'Pradeep1'}, {'logActivityId': 44, 'dataEOrario': '2020-12-07 15:59:07', 'matricola': 810011, 'idRegistro': 76, 'campo': 'data_di_sottoscrizione', 'valorePrecedente': 'Pradeep1', 'valoreNuovo': 'Pradeep1'}, {'logActivityId': 45, 'dataEOrario': '2020-12-07 16:00:23', 'matricola': 810011, 'idRegistro': 76, 'campo': 'data_di_sottoscrizione', 'valorePrecedente': 'Pradeep1', 'valoreNuovo': 'Pradeep1'}, {'logActivityId': 46, 'dataEOrario': '2020-12-07 16:01:05', 'matricola': 810011, 'idRegistro': 76, 'campo': 'NOTE', 'valorePrecedente': '128', 'valoreNuovo': '128'}, {'logActivityId': 47, 'dataEOrario': '2020-12-08 07:32:57', 'matricola': 810011, 'idRegistro': 76, 'campo': 'NOTE', 'valorePrecedente': '128', 'valoreNuovo': '128'}, {'logActivityId': 48, 'dataEOrario': '2020-12-08 08:31:57', 'matricola': 810011, 'idRegistro': 76, 'campo': 'Data Di Sottoscrizione', 'valorePrecedente': '2020-12-08', 'valoreNuovo': '2020-12-08'}, {'logActivityId': 49, 'dataEOrario': '2020-12-08 13:24:38', 'matricola': 810011, 'idRegistro': 106, 'campo': 'NOTE', 'valorePrecedente': 'Test Note', 'valoreNuovo': 'Test Note'}, {'logActivityId': 50, 'dataEOrario': '2020-12-08 13:24:38', 'matricola': 810011, 'idRegistro': 106, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'First servizio Test1234', 'valoreNuovo': 'First servizio Test1234'}, {'logActivityId': 51, 'dataEOrario': '2020-12-08 15:03:19', 'matricola': 810011, 'idRegistro': 133, 'campo': 'NOTE', 'valorePrecedente': null, 'valoreNuovo': null}, {'logActivityId': 52, 'dataEOrario': '2020-12-08 15:03:19', 'matricola': 810011, 'idRegistro': 133, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'Esternalizzazione FEI', 'valoreNuovo': 'Esternalizzazione FEI'}, {'logActivityId': 53, 'dataEOrario': '2020-12-08 15:06:44', 'matricola': 810011, 'idRegistro': 136, 'campo': 'NOTE', 'valorePrecedente': null, 'valoreNuovo': null}, {'logActivityId': 54, 'dataEOrario': '2020-12-08 15:06:44', 'matricola': 810011, 'idRegistro': 136, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'Esternalizzazione FEI', 'valoreNuovo': 'Esternalizzazione FEI'}, {'logActivityId': 55, 'dataEOrario': '2020-12-08 15:07:52', 'matricola': 810011, 'idRegistro': 136, 'campo': 'NOTE', 'valorePrecedente': null, 'valoreNuovo': null}, {'logActivityId': 56, 'dataEOrario': '2020-12-08 15:07:52', 'matricola': 810011, 'idRegistro': 136, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'Esternalizzazione FEI', 'valoreNuovo': 'Esternalizzazione FEI'}, {'logActivityId': 57, 'dataEOrario': '2020-12-08 17:02:30', 'matricola': 810011, 'idRegistro': 106, 'campo': 'NOTE', 'valorePrecedente': 'Test Note', 'valoreNuovo': 'Test Note'}, {'logActivityId': 58, 'dataEOrario': '2020-12-08 17:02:30', 'matricola': 810011, 'idRegistro': 106, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'First servizio Test1234', 'valoreNuovo': 'First servizio Test1234'}, {'logActivityId': 59, 'dataEOrario': '2020-12-08 17:16:17', 'matricola': 810011, 'idRegistro': 106, 'campo': 'NOTE', 'valorePrecedente': 'Test Note', 'valoreNuovo': 'Test'}, {'logActivityId': 60, 'dataEOrario': '2020-12-08 17:16:17', 'matricola': 810011, 'idRegistro': 106, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'First servizio Test1234', 'valoreNuovo': 'First servizio Test1234'}, {'logActivityId': 61, 'dataEOrario': '2020-12-08 17:21:16', 'matricola': 810011, 'idRegistro': 106, 'campo': 'NOTE', 'valorePrecedente': 'Test', 'valoreNuovo': 'Test Note'}], 'collectionSize': 577};

    logActivityService.getFilteredLogDetails(logactivityForm).subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.getFilteredLogDetails);
    expect(req.request.method).toEqual('POST');
    req.flush(getResponse);
  });

  it('should call getLogDetails with this request method and url', () => {
    // tslint:disable-next-line: max-line-length
    const getResponse = {'searchResultList': [{'logActivityId': 42, 'dataEOrario': '2020-12-07 15:51:34', 'matricola': 810011, 'idRegistro': 76, 'campo': 'NOTE', 'valorePrecedente': 'Testing note', 'valoreNuovo': 'Pradeep'}, {'logActivityId': 43, 'dataEOrario': '2020-12-07 15:54:45', 'matricola': 810011, 'idRegistro': 76, 'campo': 'NOTE', 'valorePrecedente': 'Pradeep', 'valoreNuovo': 'Pradeep1'}, {'logActivityId': 44, 'dataEOrario': '2020-12-07 15:59:07', 'matricola': 810011, 'idRegistro': 76, 'campo': 'data_di_sottoscrizione', 'valorePrecedente': 'Pradeep1', 'valoreNuovo': 'Pradeep1'}, {'logActivityId': 45, 'dataEOrario': '2020-12-07 16:00:23', 'matricola': 810011, 'idRegistro': 76, 'campo': 'data_di_sottoscrizione', 'valorePrecedente': 'Pradeep1', 'valoreNuovo': 'Pradeep1'}, {'logActivityId': 46, 'dataEOrario': '2020-12-07 16:01:05', 'matricola': 810011, 'idRegistro': 76, 'campo': 'NOTE', 'valorePrecedente': '128', 'valoreNuovo': '128'}, {'logActivityId': 47, 'dataEOrario': '2020-12-08 07:32:57', 'matricola': 810011, 'idRegistro': 76, 'campo': 'NOTE', 'valorePrecedente': '128', 'valoreNuovo': '128'}, {'logActivityId': 48, 'dataEOrario': '2020-12-08 08:31:57', 'matricola': 810011, 'idRegistro': 76, 'campo': 'Data Di Sottoscrizione', 'valorePrecedente': '2020-12-08', 'valoreNuovo': '2020-12-08'}, {'logActivityId': 49, 'dataEOrario': '2020-12-08 13:24:38', 'matricola': 810011, 'idRegistro': 106, 'campo': 'NOTE', 'valorePrecedente': 'Test Note', 'valoreNuovo': 'Test Note'}, {'logActivityId': 50, 'dataEOrario': '2020-12-08 13:24:38', 'matricola': 810011, 'idRegistro': 106, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'First servizio Test1234', 'valoreNuovo': 'First servizio Test1234'}, {'logActivityId': 51, 'dataEOrario': '2020-12-08 15:03:19', 'matricola': 810011, 'idRegistro': 133, 'campo': 'NOTE', 'valorePrecedente': null, 'valoreNuovo': null}, {'logActivityId': 52, 'dataEOrario': '2020-12-08 15:03:19', 'matricola': 810011, 'idRegistro': 133, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'Esternalizzazione FEI', 'valoreNuovo': 'Esternalizzazione FEI'}, {'logActivityId': 53, 'dataEOrario': '2020-12-08 15:06:44', 'matricola': 810011, 'idRegistro': 136, 'campo': 'NOTE', 'valorePrecedente': null, 'valoreNuovo': null}, {'logActivityId': 54, 'dataEOrario': '2020-12-08 15:06:44', 'matricola': 810011, 'idRegistro': 136, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'Esternalizzazione FEI', 'valoreNuovo': 'Esternalizzazione FEI'}, {'logActivityId': 55, 'dataEOrario': '2020-12-08 15:07:52', 'matricola': 810011, 'idRegistro': 136, 'campo': 'NOTE', 'valorePrecedente': null, 'valoreNuovo': null}, {'logActivityId': 56, 'dataEOrario': '2020-12-08 15:07:52', 'matricola': 810011, 'idRegistro': 136, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'Esternalizzazione FEI', 'valoreNuovo': 'Esternalizzazione FEI'}, {'logActivityId': 57, 'dataEOrario': '2020-12-08 17:02:30', 'matricola': 810011, 'idRegistro': 106, 'campo': 'NOTE', 'valorePrecedente': 'Test Note', 'valoreNuovo': 'Test Note'}, {'logActivityId': 58, 'dataEOrario': '2020-12-08 17:02:30', 'matricola': 810011, 'idRegistro': 106, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'First servizio Test1234', 'valoreNuovo': 'First servizio Test1234'}, {'logActivityId': 59, 'dataEOrario': '2020-12-08 17:16:17', 'matricola': 810011, 'idRegistro': 106, 'campo': 'NOTE', 'valorePrecedente': 'Test Note', 'valoreNuovo': 'Test'}, {'logActivityId': 60, 'dataEOrario': '2020-12-08 17:16:17', 'matricola': 810011, 'idRegistro': 106, 'campo': 'REGISTRO NAME', 'valorePrecedente': 'First servizio Test1234', 'valoreNuovo': 'First servizio Test1234'}, {'logActivityId': 61, 'dataEOrario': '2020-12-08 17:21:16', 'matricola': 810011, 'idRegistro': 106, 'campo': 'NOTE', 'valorePrecedente': 'Test', 'valoreNuovo': 'Test Note'}], 'collectionSize': 577};

    logActivityService.getLogDetails().subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.getLogDetails);
    expect(req.request.method).toEqual('GET');
    req.flush(getResponse);
  });
});
