import { Injectable } from '@angular/core';
import { UrlProviderService } from 'src/app/shared/services/url-provider.service';
import { HttpClient, HttpParams } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LogActivityService {

  constructor(
    private httpClient: HttpClient,
    private urlProviderService: UrlProviderService
  ) { }

  getFilteredLogDetails(logFilters) {
    return this.httpClient.post<any>(this.urlProviderService.getFilteredLogDetails, logFilters);
  }

  getLogDetails() {
    return this.httpClient.get<any>(this.urlProviderService.getLogDetails);
  }
}
