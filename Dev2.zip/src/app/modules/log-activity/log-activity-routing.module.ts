import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LogActivityPageComponent } from './components/log-activity-page/log-activity-page.component';


const routes: Routes = [
  {
    path: '',
    component: LogActivityPageComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LogActivityRoutingModule { }
