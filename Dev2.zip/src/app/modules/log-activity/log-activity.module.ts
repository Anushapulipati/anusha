import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LogActivityPageComponent } from './components/log-activity-page/log-activity-page.component';
import { LogActivityRoutingModule } from './log-activity-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';

@NgModule({
  declarations: [LogActivityPageComponent],
  imports: [
    CommonModule,
    LogActivityRoutingModule,
    SharedModule
  ]
})
export class LogActivityModule { }
