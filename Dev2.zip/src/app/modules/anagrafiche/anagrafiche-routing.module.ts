import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NuovoFornitoreComponent } from './components/nuovo-fornitore/nuovo-fornitore.component';
import { NuovoClienteComponent } from './components/nuovo-cliente/nuovo-cliente.component';
import { AnagrafichePageComponent } from './pages/anagrafiche-page/anagrafiche-page.component';
import { CategoryBankItComponent } from './pages/category-bank-it/category-bank-it.component';
import { CategoryInterneComponent } from './pages/category-interne/category-interne.component';
import { TrattamentoDatiPersonaliComponent } from './pages/trattamento-dati-personali/trattamento-dati-personali.component';


const routes: Routes = [
   {
    path: '',
    component: AnagrafichePageComponent
  },
  // {
  //   path: ':propostaId',
  //   component: AnagrafichePageComponent
  // },
  {
    path: 'nuovo-fornitore',
    component: NuovoFornitoreComponent,
  },
  {
    path: 'nuovo-fornitore/:fornitoreId',
    component: NuovoFornitoreComponent,
  },

  {
    path: 'nuovo-fornitore/:registroId/:propostaId/:fornitoreId',
    component: NuovoFornitoreComponent,
  },
  {
    path: 'nuovo-fornitore/:propostaId/:fornitoreId',
    component: NuovoFornitoreComponent,
  },
  {
    path: 'nuovo-cliente',
    component: NuovoClienteComponent,
  },
  {
    path: 'nuovo-cliente/:clientId',
    component: NuovoClienteComponent
  },
  {
    path: 'category-bank-it',
    component: CategoryBankItComponent,
  },
  {
    path: 'category-interne',
    component: CategoryInterneComponent,
  },
  {
    path: 'trattamento-dati-personali',
    component: TrattamentoDatiPersonaliComponent,
  },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AnagraficheRoutingModule { }
