import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'src/app/shared/shared.module';
import { AnagraficheRoutingModule } from './anagrafiche-routing.module';
import { NuovoFornitoreComponent } from './components/nuovo-fornitore/nuovo-fornitore.component';
import { NuovoClienteComponent } from './components/nuovo-cliente/nuovo-cliente.component';
import { AnagrafichePageComponent } from './pages/anagrafiche-page/anagrafiche-page.component';
import { CategoryBankItComponent } from './pages/category-bank-it/category-bank-it.component';
import { CategoryInterneComponent } from './pages/category-interne/category-interne.component';
import { TrattamentoDatiPersonaliComponent } from './pages/trattamento-dati-personali/trattamento-dati-personali.component';

@NgModule({
  declarations: [
    AnagrafichePageComponent,
    NuovoFornitoreComponent,
     NuovoClienteComponent,
     CategoryBankItComponent,
     CategoryInterneComponent,
     TrattamentoDatiPersonaliComponent
    ],
  imports: [
    CommonModule,
    AnagraficheRoutingModule,
    SharedModule
  ]
})
export class AnagraficheModule { }
