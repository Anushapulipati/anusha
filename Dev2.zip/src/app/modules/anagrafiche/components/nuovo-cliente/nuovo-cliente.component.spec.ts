import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NuovoClienteComponent } from './nuovo-cliente.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { ActivatedRoute, Router } from '@angular/router';
import { AnagraficheService } from '../../services/anagrafiche.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ProposteService } from 'src/app/modules/proposte/services/proposte.service';
import { LoginService } from 'src/app/shared/services/login.service';


const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}


describe('NuovoClienteComponent', () => {
  let component: NuovoClienteComponent;
  let fixture: ComponentFixture<NuovoClienteComponent>;
  let router;
  let anagraficheService;
  let proposteService;
  let cliente;
  let loginService;
  const route = { name: 'tips', params: of({ tipsId: '4' }) };
  beforeEach(async(() => {
    anagraficheService = jasmine.createSpyObj(['updateCliente', 'saveCliente', 'getClienteDetails']);
    proposteService = jasmine.createSpyObj(['getDropdownData', 'getPropostaDetails']);
    loginService = jasmine.createSpyObj(['getOperationModel']);
    TestBed.configureTestingModule({
      declarations: [ NuovoClienteComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: ActivatedRoute, useValue: route },
        { provide: Router, useValue: router },
        { provide: AnagraficheService, useValue: anagraficheService },
        { provide: ProposteService, useValue: proposteService},
        { provide: LoginService, useValue: loginService}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
  // tslint:disable-next-line: max-line-length
  cliente = {'clientiId': 41, 'nomeSocieta': 'Alessandro12334', 'abi': '123', 'classeSocieta': 'Banca', 'partitaIva': '123', 'codiceFiscale': '123'};
    const dropDownResponse = {
      'Classe societa': [
         {
            'itemId': '1',
            'tableId': 'Classe societa',
            'itemName': 'Banca',
            'subDomainList': null
         },
         {
            'itemId': '2',
            'tableId': 'Classe societa',
            'itemName': 'Società Strumentale',
            'subDomainList': null
         }
      ]
   };
   const operationModel =  {
    hasAnagraficheReadOnly: true
   };

    proposteService.getDropdownData.and.returnValue(of(dropDownResponse));
    // proposteService.getPropostaDetails.and.returnValue(of(getResponse));
    anagraficheService.saveCliente.and.returnValue(of(cliente));
    anagraficheService.updateCliente.and.returnValue(of(cliente));
    // anagraficheService.getClienteDetails.and.returnValue(of(cliente));
    loginService.getOperationModel.and.returnValue(of(operationModel));
    fixture = TestBed.createComponent(NuovoClienteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call get cliente method and return the said result', () => {
    const mockParameter = 41;
    // anagraficheService.getClienteDetails.and.returnValue(of(cliente));
    anagraficheService.getClienteDetails.and.returnValue(of(cliente));
    component.getClientDetails(mockParameter);
    // fixture.detectChanges();
    expect(anagraficheService.getClienteDetails).toHaveBeenCalled();
    anagraficheService.getClienteDetails(mockParameter).subscribe(result => {
      expect(result).toBe(cliente);
    });
  });

 it('should call update cliente method and return the said result', () => {
  // tslint:disable-next-line: max-line-length
  const cliente1 = {'clientiId': 54, 'nomeSocieta': 'cliente', 'abi': 'abi', 'classeSocieta': 'Banca', 'codiceFiscale': 23, 'partitaIva': 'partita'};
   const mockParameter = {};
    anagraficheService.updateCliente.and.returnValue(of(cliente1));
    const nuovoClienteForm = new FormGroup({
      clientiId: new FormControl(),
      nomeSocieta: new FormControl('', Validators.required),
      abi: new FormControl(),
      codiceFiscale: new FormControl(),
      classeSocieta: new FormControl('', Validators.required),
      partitaIva: new FormControl(),
    });

    component.saveOrUpadateCliente();
    // fixture.detectChanges();
    // expect(anagraficheService.updateCliente).toHaveBeenCalled();
    anagraficheService.updateCliente(nuovoClienteForm).subscribe(result => {
    expect(result).toBe(cliente1);
    });
  });

  it('should call save cliente method and return the said result', () => {
    // tslint:disable-next-line: max-line-length
    const cliente1 = {'clientiId': 54, 'nomeSocieta': 'cliente', 'abi': 'abi', 'classeSocieta': 'Banca', 'codiceFiscale': 23, 'partitaIva': 'partita'};
     const mockParameter = {};
      anagraficheService.saveCliente.and.returnValue(of(cliente1));
      const nuovoClienteForm = new FormGroup({
        clientiId: new FormControl(),
        nomeSocieta: new FormControl('', Validators.required),
        abi: new FormControl(),
        codiceFiscale: new FormControl(),
        classeSocieta: new FormControl('', Validators.required),
        partitaIva: new FormControl(),
      });
      component.saveOrUpadateCliente();
      // fixture.detectChanges();
      // expect(anagraficheService.updateCliente).toHaveBeenCalled();
      anagraficheService.saveCliente(nuovoClienteForm).subscribe(result => {
      expect(result).toBe(cliente1);
      });
    });
});
