import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AnagraficheService } from '../../services/anagrafiche.service';
import { ActivatedRoute, Router } from '@angular/router';
import { LoginService } from '../../../../shared/services/login.service';
import { ProposteService } from 'src/app/modules/proposte/services/proposte.service';
import { SelectView } from 'src/app/shared/models/selectView';
import { AccessOperationVm } from '../../../../shared/models/operationVm';
const commonDropdown = [
  {
    value: 'Si',
    description: 'Si'
  },
  {
    value: 'No',
    description: 'No',
  }
];

@Component({
  selector: 'reg-nuovo-cliente',
  templateUrl: './nuovo-cliente.component.html',
  styleUrls: ['./nuovo-cliente.component.scss']
})
export class NuovoClienteComponent implements OnInit {
  breadcrumbs = [
    {
      label: 'Anagrafe',
      url: '/anagarfe'
    },
    {
      label: 'Clienti',
      url: '/anagarfe/nuovo-cliente'
    }
  ];
  classeSocieta: SelectView[];
  clienteDetails: any;
  clientId: any;
  dropdownSiNo = commonDropdown;
  hasAnagraficheReadOnly: boolean;
  nuovoClienteForm = new FormGroup({
    clientiId: new FormControl(),
    nomeSocieta: new FormControl('', Validators.required),
    abi: new FormControl(),
    codiceFiscale: new FormControl(),
    classeSocieta: new FormControl('', Validators.required),
    partitaIva: new FormControl(),
  });

  constructor(
    private anagraficheService: AnagraficheService,
    private route: ActivatedRoute,
    private router: Router,
    private loginService: LoginService,
    private proposteService: ProposteService
  ) { }

  private getDropdownData(filters) {
    const items: SelectView[] = [];
    filters.map((filter, index) => {
      const item = new SelectView(filter.itemName, filter.itemName);
      items.push(item);
    });
    return items;
  }

  private getDropdownTableKeys() {
    this.proposteService.getDropdownData(['Classe societa']).subscribe(async filters => {
      this.classeSocieta = await this.getDropdownData(filters['Classe societa']);
    });
  }



  getClientDetails(clientId) {
    this.anagraficheService.getClienteDetails(clientId).subscribe(clienteDetails => {
      this.clienteDetails = clienteDetails;
      this.nuovoClienteForm.patchValue(clienteDetails);
      this.nuovoClienteForm.updateValueAndValidity();
    });
  }

  ngOnInit() {
      let operationModel: any = this.loginService.getOperationModel();
      this.hasAnagraficheReadOnly = operationModel ? operationModel.hasAnagraficheReadOnly : '';

     this.getDropdownTableKeys();
    this.route.params.subscribe(async params => {
      this.clientId = params['clientId'];
      if (this.clientId) {
        this.getClientDetails(this.clientId);
      }
    });
  }

  async resetForm() {
    this.nuovoClienteForm.reset();
    if (this.clienteDetails) {
      this.nuovoClienteForm.patchValue(this.clienteDetails);
      this.nuovoClienteForm.updateValueAndValidity();
    } else {
      Object.keys(this.nuovoClienteForm['controls']).map(control => {
        if (control !== 'clientiId') {
          this.nuovoClienteForm.get(control).setValue('');
        } else {
          this.nuovoClienteForm.get(control).setValue(null);
        }
        this.nuovoClienteForm.updateValueAndValidity();
      });
    }
  }

  saveOrUpadateCliente() {
    if (this.nuovoClienteForm.get('clientiId').value === null) {
      this.anagraficheService.saveCliente(this.nuovoClienteForm.value).subscribe(saveCliente => {});
    } else {
      this.anagraficheService.updateCliente(this.nuovoClienteForm.value).subscribe(updateCliente => {
        this.getClientDetails(this.clientId);
      });
    }
  }
}
