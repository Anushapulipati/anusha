import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NuovoFornitoreComponent } from './nuovo-fornitore.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { AnagraficheService } from '../../services/anagrafiche.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ProposteService } from 'src/app/modules/proposte/services/proposte.service';
import { RegistroService } from 'src/app/registro/services/registro.service';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}


describe('NuovoFornitoreComponent', () => {
  let component: NuovoFornitoreComponent;
  let fixture: ComponentFixture<NuovoFornitoreComponent>;
  let anagraficheService;
  let fornitore;
  let router;
  let proposteService;
  let registroService;
  let registroResponse;
  const route = { name: 'tips', params: of({ tipsId: '4' }) };
  beforeEach(async(() => {
    anagraficheService = jasmine.createSpyObj(['saveFornitoredetails', 'updateFornitoredetails', 'getFornitoredetails']);
    proposteService = jasmine.createSpyObj(['getDropdownData', 'getPropostaDetails', 'getRegistroDetails']);
    // registroService = jasmine.createSpyObj(['getRegistroDetails']);
    TestBed.configureTestingModule({
      declarations: [ NuovoFornitoreComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: ActivatedRoute, useValue: route },
        { provide: Router, useValue: router },
        { provide: AnagraficheService, useValue: anagraficheService },
        { provide: ProposteService, useValue: proposteService},
        { provide: RegistroService, useValue: registroService },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    // tslint:disable-next-line: max-line-length
    registroResponse = {'idRegistro': 171, 'categorieBankIt': 'Servizi di pagamento 123', 'sottoCategorieBankIt': 'Gestione processing carte', 'contractId': 379, 'categoriaEba': 'Acquisizione di beni (e.g. tessere di plastica, lettori di carte, forniture per ufficio, personal computer, mobilio)', 'classificazione': 'Fornitura', 'clienteInterno': null, 'codiceContratto': null, 'codiceContrattoPadre': null, 'costoAnnuoDiEsercizio': 2323, 'costoTotaleDelContratto': null, 'dataCessazioneDelContratto': '12/12/2020', 'dataCessazioneDelServizio': null, 'dataDelProssimoAudit': '25/12/2020', 'dataDelUltimoAudit': '19/12/2020', 'dataDellUltimaValutazione': '12/12/2020', 'dataDiDecorrenza': '12/12/2020', 'dataDiDecorrenzaDelServizio': null, 'dataDiScadenzaDelContratto': '12/12/2020', 'dataDiScadenzaDelServizio': null, 'dataDiSottoscrizione': '12/12/2020', 'dataDiUltimaValutazione': '12/12/2020', 'dataDiUltimoRinnovoDelContratto': '12/12/2020', 'dataSottoscrizioneDelServizio': null, 'durataDelRinnovo': 0, 'fornitoreInfragruppo': null, 'fornituraICTRilevanterischioalto': 'No', 'fornituraNonICTRilevante': 'No', 'gestoreDiBudget': null, 'note': 'This Will work', 'perimetroMonitoraggioICTVendor': 'No', 'possibilitaDiRecesso': '', 'referenteDiContratto': '', 'referenteErogatoreServiziIT': null, 'slaMonitorati': 'No', 'sogliaDiImpattoDellinterruzioneDellaFunzione': 0, 'tacitoRinnovo': '', 'oggettoDelContratto': null, 'descrizioneServizioErogato': '', 'terminiPreavvisoCliente': '', 'terminiPreavvisoFornitore': '', 'legislazioneApplicataNazione': null, 'costoStimatoDelContratto': null, 'sostituibilità': 'Facile', 'fornitoriAlternativi': 'Fornitori ', 'possibilitàDiReinternalizzazione': 'Si', 'numeroSubfornitori': 1, 'subFornitore': [{'fornitoreId': 1, 'nomeSocieta': 'Capgemini Italia'}], 'proposta': {'proposalId': 290, 'numeroProposta': '2020_675', 'segnalante': 'Segnalante', 'societaDelSegnalante': 'SV Banca', 'oggDellaProposta': 'Oggetto della proposta', 'statoProposta': 'Conclusa', 'sotoStatoProposta': 'Conclusa', 'propostaName': 'Proposta ABC', 'canDiSegnalazione': 'Progetto', 'cambioFornitore': 'Si', 'dataDellaProposta': '06/12/2020', 'dataDelCensimento': '12/12/2020', 'praticaOwner': 'Pratica', 'dataFineProposta': '12/12/2020', 'codCanSegnalazione': '', 'gestionePraticaBackup': '', 'completoOrInCompleto': true, 'uosegnalante': 'Segnalante '}, 'contratto': {'contrattoId': 379, 'propostaFornitoreId': null, 'societaClientiId': 1, 'fornitoriAlternativi': 'Fornitori ', 'oggettoDelContratto': 'Oggetto del contratto', 'terminiPreavvisoCliente': '', 'terminiPreavvisoFornitore': '', 'costoAttivita': null, 'numeroSubfornitori': 1, 'societaGruppoCliente': 'SV Banca', 'statoComunicazioneAdv': '', 'autoritaCompetente': '', 'statoCompletoAdv': 'complete', 'dataInvioComunicazioneAdv': null, 'necessariaProceduraSindacale': '', 'statoComunicazione': '', 'dataInvioComunicazione': null, 'periodoAttesaEsito': 0, 'scadenzaRiscontro': null, 'statoCompletoProcedura': 'complete', 'societaClienteDatApprovazione': null, 'societaClienteApprovatoreFinale': '', 'statoCompletoCDA': 'complete', 'fornitoreInfragruppoDataDi': null, 'fornitoreInfragruppoFinale': '', 'pareresuiContrattiComplianceList': [{'parereSuiContrattiComplianceId': 19, 'contrattoId': null, 'dataParere': '03/12/2020', 'areaNormativa': 'Esternalizzazioni', 'livelloRischioNonConformita': 'Basso', 'livelloDiAdeguatezza': 'Adeguato', 'statoCompletoCompliance': '', 'idRegistro': 171, 'nparere': '1231_231'}, {'parereSuiContrattiComplianceId': 20, 'contrattoId': null, 'dataParere': '03/12/2020', 'areaNormativa': 'Esternalizzazioni', 'livelloRischioNonConformita': 'Basso', 'livelloDiAdeguatezza': 'Adeguato', 'statoCompletoCompliance': 'complete', 'idRegistro': 171, 'nparere': '1231_231'}, {'parereSuiContrattiComplianceId': 21, 'contrattoId': null, 'dataParere': '02/12/2020', 'areaNormativa': 'Privacy', 'livelloRischioNonConformita': 'Basso', 'livelloDiAdeguatezza': 'Prevalentemente adeguato', 'statoCompletoCompliance': 'complete', 'idRegistro': 171, 'nparere': '2321_312'}], 'parereSuiContrattiRischiList': [{'parereSuiContrattiRischiId': 20, 'contrattoId': null, 'dataParere': '10/12/2020', 'livelloDiRischiosita': 'Basso', 'statoCompletoRischi': '', 'idRegistro': 171, 'nparereRischio': '2342_342'}, {'parereSuiContrattiRischiId': 21, 'contrattoId': null, 'dataParere': '10/12/2020', 'livelloDiRischiosita': 'Medio Alto', 'statoCompletoRischi': 'complete', 'idRegistro': 171, 'nparereRischio': '2312_321'}, {'parereSuiContrattiRischiId': 22, 'contrattoId': null, 'dataParere': '11/12/2020', 'livelloDiRischiosita': 'Basso', 'statoCompletoRischi': 'complete', 'idRegistro': 171, 'nparereRischio': '2323_213'}], 'servizioList': null, 'servizioContrattoId': null, 'servizioResponseList': null, 'fornitoreResponseList': null, 'subFornitore': null, 'completoOrInCompleto': true, 'codiceContrattoPadre': null, 'commonContrattoId': null}, 'fornitore': {'fornitoreId': 1, 'nomeSocieta': 'Capgemini Italia', 'infraGruppoExtraGruppo': 'Infragruppo', 'codice': 212233412, 'ndg': 1938021, 'partitaIva': '121Par update123465', 'codiceFiscale': 125, 'atecoBankIt': 'ATECO_2007_BANKIT', 'indirizzoFornitore': 'Paese_di_registrazione_fornitor', 'paeseFornitore': 'LEI_Numero_registrazione_fornitore', 'numeroFornitore': 'abcd', 'capoGruppo': 'xysz', 'description': 'INDIA', 'nation': 'Europe', 'ccnl': 'CCNL', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'Si', 'grouppo': 'group new update', 'email': 'abc@gmail.com', 'dataInserimento': '09/12/2020', 'ncommerico': 'N_Iscrizione_camera_commercio'}, 'servizioEntity': {'servizioId': 412, 'propostaFornitoreId': null, 'marcoProcesso': '', 'racConDeiPro': '', 'servizioInfrastrttra': '', 'tipologiaDiCloud': '', 'possibilitaDiRei': 'Si', 'sostituibilita': 'Facile', 'classificazioneOne': 'Esternalizzazione', 'classificazioneTipo': 'Fornitura', 'datiPersonali': '', 'sogliaFunzione': null, 'funzioneEsternalizzata': '', 'funzioneImportante': '', 'ultimaValutazioneData': null, 'sintesideiMotivi': '', 'paeseDiVieneSvolto': '', 'paesediconDati': '', 'cloudpaesediCon': '', 'descrizioneDel': '', 'tipologiaDaDati': null, 'cloudNaturaDaDati': null, 'livelloDiRischiosita': '', 'breveRischiosita': '', 'completoStato': 'complete', 'categoriaBankIt': null, 'sottocategoriaBankIt': null, 'servizioName': 'First', 'categoriaEba': null}, 'nomeSocietaCliente': 'SV Banca', 'clientId': 1, 'statoContratto': 'In attesa sottoscrizione', 'statoServizio': 'In attesa sottoscrizione', 'registroName': 'First', 'pareresuiContrattiComplianceList': [{'parereSuiContrattiComplianceId': 19, 'contrattoId': null, 'dataParere': '03/12/2020', 'areaNormativa': 'Esternalizzazioni', 'livelloRischioNonConformita': 'Basso', 'livelloDiAdeguatezza': 'Adeguato', 'statoCompletoCompliance': '', 'idRegistro': 171, 'nparere': '1231_231'}, {'parereSuiContrattiComplianceId': 20, 'contrattoId': null, 'dataParere': '03/12/2020', 'areaNormativa': 'Esternalizzazioni', 'livelloRischioNonConformita': 'Basso', 'livelloDiAdeguatezza': 'Adeguato', 'statoCompletoCompliance': 'complete', 'idRegistro': 171, 'nparere': '1231_231'}, {'parereSuiContrattiComplianceId': 21, 'contrattoId': null, 'dataParere': '02/12/2020', 'areaNormativa': 'Privacy', 'livelloRischioNonConformita': 'Basso', 'livelloDiAdeguatezza': 'Prevalentemente adeguato', 'statoCompletoCompliance': 'complete', 'idRegistro': 171, 'nparere': '2321_312'}], 'parereSuiContrattiRischiList': [{'parereSuiContrattiRischiId': 20, 'contrattoId': null, 'dataParere': '10/12/2020', 'livelloDiRischiosita': 'Basso', 'statoCompletoRischi': '', 'idRegistro': 171, 'nparereRischio': '2342_342'}, {'parereSuiContrattiRischiId': 21, 'contrattoId': null, 'dataParere': '10/12/2020', 'livelloDiRischiosita': 'Medio Alto', 'statoCompletoRischi': 'complete', 'idRegistro': 171, 'nparereRischio': '2312_321'}, {'parereSuiContrattiRischiId': 22, 'contrattoId': null, 'dataParere': '11/12/2020', 'livelloDiRischiosita': 'Basso', 'statoCompletoRischi': 'complete', 'idRegistro': 171, 'nparereRischio': '2323_213'}], 'breveSintesiDeiMotivi': '', 'breveSintesiSulLivello': '', 'societàDelReferenteErogatoreServiziIT': null, 'propostaFornitoreId': 353, 'commonContrattoId': 25, 'oggDellaProposta': 'Oggetto della proposta', 'datiPersonali': '', 'funzioneEsternalizzata': '', 'paeseDiVieneSvolto': '', 'paesediconDati': '', 'marcoProcesso': '', 'racConDeiPro': '', 'trasferimentoDati': null, 'tipologiaDaDati': ['Transazioni economiche'], 'cloudNaturaDaDati': ['Transazioni economiche'], 'tipologiaDiCloud': '', 'servizioInfrastrttra': '', 'cloudpaesediCon': ''};
    // tslint:disable-next-line: max-line-length
    const propostaDetailsResponse = {'proposalId': 288, 'numeroProposta': '2020_673', 'segnalante': 'Segnalante', 'societaDelSegnalante': 'SV Banca', 'oggDellaProposta': 'Oggetto ', 'statoProposta': 'In corso', 'sotoStatoProposta': 'Descrizione Esigenza', 'propostaName': 'Test ABC', 'canDiSegnalazione': '', 'cambioFornitore': 'No', 'dataDellaProposta': '01/12/2020', 'dataDelCensimento': '12/12/2020', 'praticaOwner': '', 'dataFineProposta': null, 'codCanSegnalazione': '', 'gestionePraticaBackup': '', 'completoOrInCompleto': true, 'uosegnalante': 'U.O.Segnalante'};
    // tslint:disable-next-line: max-line-length
    const dropDownResponse = {'Infragruppo': [{'itemId': '1', 'tableId': 'Infragruppo', 'itemName': 'Infragruppo', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Infragruppo', 'itemName': 'Extragruppo', 'subDomainList': null}]};
    // tslint:disable-next-line: max-line-length
    fornitore = {'fornitoreId': 51, 'nomeSocieta': '13', 'infraGruppoExtraGruppo': 'Infragruppo', 'codice': null, 'ndg': null, 'partitaIva': '1', 'codiceFiscale': 1, 'atecoBankIt': '12', 'indirizzoFornitore': '1', 'paeseFornitore': null, 'numeroFornitore': null, 'capoGruppo': '1', 'description': '1', 'nation': '1', 'ccnl': '1', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'Si', 'grouppo': '1', 'email': '1', 'dataInserimento': '03/12/2020', 'ncommerico': '1'};
    proposteService.getDropdownData.and.returnValue(of(dropDownResponse));
    proposteService.getPropostaDetails.and.returnValue(of(propostaDetailsResponse));
    proposteService.getRegistroDetails.and.returnValue(of(registroResponse));
    fixture = TestBed.createComponent(NuovoFornitoreComponent);
    fixture = TestBed.createComponent(NuovoFornitoreComponent);
    component = fixture.componentInstance;
    component.registroId = 180;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call get fornitore method and return the said result', () => {
    const mockParameter = 41;
    anagraficheService.getFornitoredetails.and.returnValue(of(fornitore));
    component.getFornitoredetails(mockParameter);
    // fixture.detectChanges();
    expect(anagraficheService.getFornitoredetails).toHaveBeenCalled();
    anagraficheService.getFornitoredetails(mockParameter).subscribe(result => {
      expect(result).toBe(fornitore);
    });
  });

  it('should call save fornitore method and return the said result', () => {
    const mockParameter = {};
    anagraficheService.saveFornitoredetails.and.returnValue(of(fornitore));
    const  nuovoFornitoreForm = new FormGroup({
      fornitoreId: new FormControl(),
      nomeSocieta: new FormControl('', Validators.required),
      infraGruppoExtraGruppo: new FormControl('', Validators.required),
      codice: new FormControl(),
      ndg: new FormControl(),
      partitaIva: new FormControl('', Validators.required),
      codiceFiscale: new FormControl('', Validators.required),
      ncommerico: new FormControl('', Validators.required),
      atecoBankIt: new FormControl('', Validators.required),
      indirizzoFornitore: new FormControl('', Validators.required),
      paeseFornitore: new FormControl(),
      numeroFornitore: new FormControl(),
      capoGruppo: new FormControl('', Validators.required),
      description: new FormControl('', Validators.required),
      nation: new FormControl('', Validators.required),
      ccnl: new FormControl('', Validators.required),
      fornitoreCosti: new FormControl('', Validators.required),
      fornitoreConRatingNegativo: new FormControl('', Validators.required),
      grouppo: new FormControl('', Validators.required),
      email: new FormControl('', Validators.required),
    });
    component.saveOrUpadateFornitore();
    // fixture.detectChanges();
    expect(anagraficheService.saveFornitoredetails).toHaveBeenCalled();
    anagraficheService.saveFornitoredetails(nuovoFornitoreForm).subscribe(result => {
      expect(result).toBe(fornitore);
    });
  });
  it('should call update fornitore method and return the said result', () => {
    const mockParameter = {};
    anagraficheService.updateFornitoredetails.and.returnValue(of(fornitore));
    anagraficheService.saveFornitoredetails.and.returnValue(of(fornitore));
    const  nuovoFornitoreForm = new FormGroup({
      fornitoreId: new FormControl(),
      nomeSocieta: new FormControl('', Validators.required),
      infraGruppoExtraGruppo: new FormControl('', Validators.required),
      codice: new FormControl(),
      ndg: new FormControl(),
      partitaIva: new FormControl('', Validators.required),
      codiceFiscale: new FormControl('', Validators.required),
      ncommerico: new FormControl('', Validators.required),
      atecoBankIt: new FormControl('', Validators.required),
      indirizzoFornitore: new FormControl('', Validators.required),
      paeseFornitore: new FormControl(),
      numeroFornitore: new FormControl(),
      capoGruppo: new FormControl('', Validators.required),
      description: new FormControl('', Validators.required),
      nation: new FormControl('', Validators.required),
      ccnl: new FormControl('', Validators.required),
      fornitoreCosti: new FormControl('', Validators.required),
      fornitoreConRatingNegativo: new FormControl('', Validators.required),
      grouppo: new FormControl('', Validators.required),
      email: new FormControl('', Validators.required),
    });
    component.saveOrUpadateFornitore();
    fixture.detectChanges();
    // expect(anagraficheService.updateFornitoredetails).toHaveBeenCalled();
    anagraficheService.updateFornitoredetails(nuovoFornitoreForm).subscribe(result => {
      expect(result).toBe(fornitore);
    });
  });
 

  it('should call getRegistro method  and return the said result', () => {
    component.ngOnInit();
     component.registroId = 180;
    const  mockParameter = 180;
     proposteService.getRegistroDetails.and.returnValue(of(registroResponse));
      // fixture.detectChanges();
      // expect(registroService.getRegistroDetails).toHaveBeenCalled();
      proposteService.getRegistroDetails(mockParameter).subscribe(result => {
        expect(result).toBe(registroResponse);
      });
    });
    
   it('should call getPropostaDetails method  and return the said result', () => {
      // tslint:disable-next-line: max-line-length
      const propostaResponse = {'proposalId': 301, 'numeroProposta': '2020_686', 'segnalante': 'Segnalante', 'societaDelSegnalante': 'SV Banca', 'oggDellaProposta': 'Oggetto ', 'statoProposta': 'In corso', 'sotoStatoProposta': 'Descrizione Esigenza', 'propostaName': 'Test', 'canDiSegnalazione': '', 'cambioFornitore': 'Si', 'dataDellaProposta': '04/12/2020', 'dataDelCensimento': '15/12/2020', 'praticaOwner': 'Gestione ', 'dataFineProposta': null, 'codCanSegnalazione': '', 'gestionePraticaBackup': '', 'completoOrInCompleto': false, 'uosegnalante': 'U.O.Segnalante'};
      component.ngOnInit();
       component.registroId = 180;
      const  mockParameter = 301;
       proposteService.getPropostaDetails.and.returnValue(of(propostaResponse));
        // fixture.detectChanges();
        // expect(registroService.getRegistroDetails).toHaveBeenCalled();
        proposteService.getPropostaDetails(mockParameter).subscribe(result => {
          expect(result).toEqual(propostaResponse);
        });
      });
});
