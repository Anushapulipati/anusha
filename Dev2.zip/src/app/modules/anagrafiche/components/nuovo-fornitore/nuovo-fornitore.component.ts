import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AnagraficheService } from '../../services/anagrafiche.service';
import { ActivatedRoute, Router } from '@angular/router';
import { ProposteService } from 'src/app/modules/proposte/services/proposte.service';
import { SelectView } from 'src/app/shared/models/selectView';
import { LoginService } from '../../../../shared/services/login.service';

const commonDropdown = [
  {
    value: 'Si',
    description: 'Si'
  },
  {
    value: 'No',
    description: 'No',
  }
];

@Component({
  selector: 'reg-nuovo-fornitore',
  templateUrl: './nuovo-fornitore.component.html',
  styleUrls: ['./nuovo-fornitore.component.scss']
})
export class NuovoFornitoreComponent implements OnInit {
  breadcrumbs = [
    {
      label: 'Anagrafe',
      url: '/anagarfe'
    },
    {
      label: 'Fornitori',
      url: '/anagarfe/nuovo-fornitore'
    }
  ];
  dropdownSiNo = commonDropdown;
  fornitoredetails: any;
  fornitoreId: any;
  hasAnagraficheReadOnly: boolean;
  infragruppo: SelectView[];
  isProposalCompleted: boolean;
  nuovoFornitoreForm = new FormGroup({
    fornitoreId: new FormControl(),
    nomeSocieta: new FormControl('', Validators.required),
    infraGruppoExtraGruppo: new FormControl('', Validators.required),
    codice: new FormControl(),
    ndg: new FormControl(),
    partitaIva: new FormControl('', Validators.required),
    codiceFiscale: new FormControl('', Validators.required),
    ncommerico: new FormControl('', Validators.required),
    atecoBankIt: new FormControl('', Validators.required),
    indirizzoFornitore: new FormControl('', Validators.required),
    paeseFornitore: new FormControl(),
    numeroFornitore: new FormControl(),
    capoGruppo: new FormControl('', Validators.required),
    description: new FormControl('', Validators.required),
    nation: new FormControl('', Validators.required),
    ccnl: new FormControl('', Validators.required),
    fornitoreCosti: new FormControl('', Validators.required),
    fornitoreConRatingNegativo: new FormControl('', Validators.required),
    grouppo: new FormControl('', Validators.required),
    email: new FormControl('', Validators.required),
  });
  propostaDetails: any;
  propostaId: number;
  registroId: number;
  statoServizio: any;
  constructor(
    private anagraficheService: AnagraficheService,
    private route: ActivatedRoute,
    private router: Router,
    private proposteService: ProposteService,
    private loginService: LoginService,
  ) { }

  private getDropdownData(filters) {
    const items: SelectView[] = [];
    filters.map((filter, index) => {
      const item = new SelectView(filter.itemName, filter.itemName);
      items.push(item);
    });
    return items;
  }

  private getDropdownTableKeys() {
    this.proposteService.getDropdownData(['Infragruppo']).subscribe(async filters => {
      this.infragruppo = await this.getDropdownData(filters['Infragruppo']);
    });
  }

  private getPropostaDetails(propostaId) {
    return this.proposteService.getPropostaDetails(propostaId).subscribe(propostaDetails => {
      this.propostaDetails = propostaDetails;
      this.isProposalCompleted = (this.propostaDetails.statoProposta === 'Conclusa' || this.propostaDetails.statoProposta === 'Annullata') ? true : false;
      if (this.isProposalCompleted) {
        this.nuovoFornitoreForm.disable();
        this.nuovoFornitoreForm.updateValueAndValidity();
      }
    });
  }
  private getRegistroDetails(registroId) {
    return this.proposteService.getRegistroDetails(registroId).subscribe(async registroDetails => {
      this.statoServizio = (registroDetails.statoServizio === 'Cessato' ) ? true : false;
      if (this.statoServizio) {
        this.nuovoFornitoreForm.disable();
        this.nuovoFornitoreForm.updateValueAndValidity();
      }
    });
  }

  getFornitoredetails(fornitoreId) {
    this.anagraficheService.getFornitoredetails(fornitoreId).subscribe(fornitoredetails => {
      this.fornitoredetails = fornitoredetails;
      this.nuovoFornitoreForm.patchValue(fornitoredetails);
    });
  }

  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasAnagraficheReadOnly = operationModel ? operationModel.hasAnagraficheReadOnly: '';
    this.getDropdownTableKeys();
    this.route.params.subscribe(async params => {
      this.registroId = params['registroId'];
      this.fornitoreId = params['fornitoreId'];
      this.propostaId =  params['propostaId'];
      if (this.registroId) {
        this.getRegistroDetails(this.registroId);
      }
      if (this.propostaId) {
        this.getPropostaDetails(this.propostaId);
      }
      if (this.fornitoreId) {
        this.getFornitoredetails(this.fornitoreId);
      }
    });
  }

  async resetForm() {
    this.nuovoFornitoreForm.reset();
    if (this.fornitoredetails) {
      this.nuovoFornitoreForm.patchValue(this.fornitoredetails);
      this.nuovoFornitoreForm.updateValueAndValidity();
    } else {
      Object.keys(this.nuovoFornitoreForm['controls']).map(control => {
        if (control !== 'fornitoreId') {
          this.nuovoFornitoreForm.get(control).setValue('');
        } else {
          this.nuovoFornitoreForm.get(control).setValue(null);
        }
      });
    }
  }

  saveOrUpadateFornitore() {
    if (this.nuovoFornitoreForm.get('fornitoreId').value === null) {
      this.anagraficheService.saveFornitoredetails(this.nuovoFornitoreForm.value).subscribe(saveSuccess => {
      });
    } else {
      this.anagraficheService.updateFornitoredetails(this.nuovoFornitoreForm.value).subscribe(updateSuccess => {
        this.getFornitoredetails(this.fornitoreId);
      });
    }
  }
}
