import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { EsportaModel } from 'src/app/shared/models/esportaModel';
import { UrlProviderService } from 'src/app/shared/services/url-provider.service';

@Injectable({
  providedIn: 'root'
})
export class AnagraficheService {

  constructor(
    private httpClient: HttpClient,
    private urlProviderService: UrlProviderService
  ) { }

  checkExcelStatus(id: any): any {
    const params = new HttpParams();
    const parameters = params.append('id', id.toString());
    return this.httpClient.get<any>(this.urlProviderService.verifyAnagraficheExcel, { params: parameters });
  }

  exportToAnagraficheExcel(esportaModel: EsportaModel): Observable<any> {
    return this.httpClient.post<any>(this.urlProviderService.exportToAnagraficheExcel, esportaModel);

}

  getCategoriaInterna() {
    return this.httpClient.get<any>(this.urlProviderService.getCategoriaInterna);
  }

  getCategoryBankIt() {
    return this.httpClient.get<any>(this.urlProviderService.getCategoryBankIt);
  }
  getClienteDetails(clienteId) {
    const params = new HttpParams();
    const parameters = params.append('clienteId', clienteId);
    return this.httpClient.get<any>(this.urlProviderService.getClienteDetails, { params: parameters });
  }

  getElencoTrattamentoDatiPersonali() {
    return this.httpClient.get<any>(this.urlProviderService.getElencoTrattamentoDatiPersonali);
  }

  getFornitoreClientDetails() {
    return this.httpClient.get<any>(this.urlProviderService.getFornitoreClientDetails);
  }

  getFornitoreClientDetailsByFilters(filters) {
    return this.httpClient.post<any>(this.urlProviderService.getFornitoreClientDetailsByFilters, filters);
  }

  getFornitoredetails(fornitoreId) {
    const params = new HttpParams();
    const parameters = params.append('fornitoreId', fornitoreId);
    return this.httpClient.get<any>(this.urlProviderService.getFornitoredetails, { params: parameters });
  }

  saveCategoriaInterna(categories) {
    return this.httpClient.post<any>(this.urlProviderService.saveCategoriaInterna, categories);
  }

  saveCategoryBankIt(cagegories) {
    return this.httpClient.post<any>(this.urlProviderService.saveCategoryBankIt, cagegories);
  }

  saveCliente(clienteInput) {
    return this.httpClient.post<any>(this.urlProviderService.saveCliente, clienteInput);
  }

  saveElencoTrattamentoDatiPersonali(categories) {
    return this.httpClient.post<any>(this.urlProviderService.saveElencoTrattamentoDatiPersonali, categories);
  }

  saveFornitoredetails(fornitoreInput) {
    return this.httpClient.post<any>(this.urlProviderService.saveFornitoredetails, fornitoreInput);
  }
  updateCliente(clienteInput) {
    return this.httpClient.post<any>(this.urlProviderService.updateCliente, clienteInput);
  }

  updateFornitoredetails(fornitoreInput) {
    return this.httpClient.post<any>(this.urlProviderService.saveFornitoredetails, fornitoreInput);
  }
}
