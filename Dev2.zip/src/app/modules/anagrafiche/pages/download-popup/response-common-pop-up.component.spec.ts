import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResponseCommonPopUpComponent } from './response-common-pop-up.component';
import { of, Observable, config } from 'rxjs';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { DialogModel, DialogRef } from 'fe-dghub-component-library';
import { AppModule } from 'src/app/app.module';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('ResponseCommonPopUpComponent', () => {
  let component: ResponseCommonPopUpComponent;
  let fixture: ComponentFixture<ResponseCommonPopUpComponent>;
  let dialog;
  let dialogModel;
  let config;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [  ],
      imports: [
        AppModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: DialogModel, useValue: dialogModel},
        { provide: DialogRef, useValue: dialog}
      ]
     
    })
    .compileComponents();
  }));

  beforeEach(() => {
   config = {
      data : {
        message: 'message'
      }
    };
    fixture = TestBed.createComponent(ResponseCommonPopUpComponent);
    component = fixture.componentInstance;
    component.config = config;
    fixture.detectChanges();
  });

 it('should create', () => {
    expect(component).toBeTruthy();
    component.ngOnInit();

  });
});
