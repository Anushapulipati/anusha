import { Component, OnInit, HostListener } from '@angular/core';
import { DialogModel, DialogRef } from 'fe-dghub-component-library';

@Component({
  selector: 'reg-response-common-pop-up',
  templateUrl: './response-common-pop-up.component.html',
  styleUrls: ['./response-common-pop-up.component.css']
})
export class ResponseCommonPopUpComponent implements OnInit {
  message: any;

  constructor(
    public config: DialogModel,
    public dialog: DialogRef
  ) { }

  ngOnInit() {
    this.message = this.config.data.message;
  }

  onClose(data) {
    this.dialog.close(data);
  }
}
