import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoryInterneComponent } from './category-interne.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { AnagraficheService } from '../../services/anagrafiche.service';
import { LoginService } from 'src/app/shared/services/login.service';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('CategoryInterneComponent', () => {
  let component: CategoryInterneComponent;
  let fixture: ComponentFixture<CategoryInterneComponent>;
  let anagraficheService;
  let loginService;
  beforeEach(async(() => {
    anagraficheService = jasmine.createSpyObj(['saveCategoriaInterna', 'getCategoriaInterna']);
    loginService = jasmine.createSpyObj(['getOperationModel']);
    TestBed.configureTestingModule({
      declarations: [ CategoryInterneComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: AnagraficheService, useValue: anagraficheService },
        { provide: LoginService, useValue: loginService}
      ]
		})
    .compileComponents();
  }));

  beforeEach(() => {
    const getResponse = [
      {
         'idCategiriaInterna': 1,
         'categoriaEba': 'Infrastruttura globale di messaggistica finanziaria soggetta alla vigilanza delle pertinenti autorità'
      },
      {
         'idCategiriaInterna': 2,
         'categoriaEba': 'Acquisizione di beni (e.g. tessere di plastica, lettori di carte, forniture per ufficio, personal computer, mobilio)'
      },
    ]
    anagraficheService.getCategoriaInterna.and.returnValue(of(getResponse));
   anagraficheService.saveCategoriaInterna.and.returnValue(of(getResponse));
    fixture = TestBed.createComponent(CategoryInterneComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show title', () => {
    const compiled = fixture.debugElement.nativeElement;
    // expect(compiled.queryAll(By.css('div'))[4].textContent).toContain('label.anagrafichePage.ElencoCategorieBankIT');
    expect(compiled.querySelector('div').textContent).toContain('label.anagrafichePage.ElencoCategorieInterne');
    // expect(fixture.debugElement.queryAll(By.css('div'))[4].nativeElement.textContent).toBe('label.anagrafichePage.ElencoCategorieBankIT');
  });

   it('should call ngoninit', () => {
    spyOn(component, 'ngOnInit');
    component.ngOnInit();
    expect(component.ngOnInit).toHaveBeenCalled();
  });


  it('should call saveCategory', () => {
    spyOn(component, 'saveCategory');
    component.saveCategory();
    expect(component.saveCategory).toHaveBeenCalled();
  });


  it('should call service method ', () => {
    // tslint:disable-next-line: max-line-length
    const mockResponse = [{'idCategiriaInterna': 1, 'categoriaEba': 'Infrastruttura globale di messaggistica finanziaria soggetta alla vigilanza delle pertinenti autorità'}, {'idCategiriaInterna': 2, 'categoriaEba': 'Acquisizione di beni (e.g. tessere di plastica, lettori di carte, forniture per ufficio, personal computer, mobilio)'}, {'idCategiriaInterna': 3, 'categoriaEba': 'Acquisizione di servizi di pubblica utilità (e.g. forniture di elettricità, gas, acqua, telefonia)'}, {'idCategiriaInterna': 4, 'categoriaEba': 'Acquisizione di servizi di pulizia e igiene, sanificazione, disinfezione, disinfestazione e derattizzazione ambientale '}, {'idCategiriaInterna': 5, 'categoriaEba': 'Acquisto di licenze d\'uso di software per cui sia la proprietà sia il diritto di effettuare attività di manutenzione o di personalizzazione rimangono in capo al fornitore'}, {'idCategiriaInterna': 6, 'categoriaEba': 'Consulenza di servizi professionali (e.g. consulenza legale, strategica, organizzativa, tecnica) aventi ad oggetto esclusivamente attività limitate nel tempo (progetti), non reiterate ed eseguite sotto il controllo di referenti, precisamente identificati, della Legal Entity Cliente ed i cui risultati siano sottoposti a verifica ed approvazione della Legal Entity Cliente'}, {'idCategiriaInterna': 7, 'categoriaEba': 'Consulenza di servizi professionali (e.g. consulenza di un architetto) per progettazione ed esecuzione di opere di riqualificazione e adeguamento normativo degli immobili, progettazione ed installazione di dispositivi per il risparmio energetico e la riduzione di emissione di agenti inquinanti in atmosfera'}, {'idCategiriaInterna': 8, 'categoriaEba': 'Funzione che a norma di legge deve essere svolta da un fornitore di servizi (e.g. la revisione legale dei conti)'}, {'idCategiriaInterna': 9, 'categoriaEba': 'Sistema informativo o sue componenti critiche, incluso Supporto e Application Maintenance (AM) su software/applicativi di proprietà della Banca/Società del Gruppo e di cui la Banca/Società ha a disposizione i sorgenti'}, {'idCategiriaInterna': 10, 'categoriaEba': 'Supporto e Application Maintenance (AM) su software/applicativi di Terze parti di cui la Banca/Società non dispone dei sorgenti'}, {'idCategiriaInterna': 11, 'categoriaEba': 'Infrastruttura di rete globale (e.g. Visa, MasterCard)'}, {'idCategiriaInterna': 12, 'categoriaEba': 'Accordo di compensazione e regolamento tra organismi di compensazione, controparti centrali e istituti di regolamento e loro membri'}, {'idCategiriaInterna': 13, 'categoriaEba': 'Supporto specialistico - Qualora l\'oggetto del contratto preveda attività limitate (rispetto al processo di cui fanno parte) e lo svolgimento di tali attività (anche in loco) all’interno dei processi della Legal Entity Cliente, sulla base di istruzioni e sotto la diretta supervisione della stessa'}, {'idCategiriaInterna': 14, 'categoriaEba': 'Manutenzione dei locali della legal entity cliente (e.g. acquisizione di servizi di gestione, conduzione e manutenzione di impianti idrici, termici, di climatizzazione e condizionamento, antincendio, porte tagliafuoco ed uscite di emergenza, impianti di allarme, impianti elevatori, serrature elettroniche)'}, {'idCategiriaInterna': 15, 'categoriaEba': 'Manutenzione delle aree verdi'}, {'idCategiriaInterna': 16, 'categoriaEba': 'Manutenzione di automobili aziendali'}, {'idCategiriaInterna': 17, 'categoriaEba': 'Manutenzione di componenti standard di hardware nell\'ambito di soluzioni di mercato'}, {'idCategiriaInterna': 18, 'categoriaEba': 'Noleggio di hardware e di licenze software per cui sia la proprietà sia il diritto di effettuare attività di manutenzione o di personalizzazione rimangono in capo al fornitore (rientrano in questo caso anche i servizi di hosting infrastrutturale delle apparecchiature con riferimento ai pacchetti software di mercato)'}, {'idCategiriaInterna': 19, 'categoriaEba': 'Servizi amministrativi (e.g. servizi di economato)'}, {'idCategiriaInterna': 20, 'categoriaEba': 'Servizi bancari di corrispondenza'}, {'idCategiriaInterna': 21, 'categoriaEba': 'Servizi di business travel (e.g. prenotazione hotel)'}, {'idCategiriaInterna': 22, 'categoriaEba': 'Servizi di distribuzione automatica'}, {'idCategiriaInterna': 23, 'categoriaEba': 'Servizi di informazione sui mercati (e.g. la fornitura di dati da parte di Bloomberg, Moody’s, Standard & Poor’s, Fitch) o sui clienti (e.g. CRIF)'}, {'idCategiriaInterna': 24, 'categoriaEba': 'Servizi di portierato, receptionist, segreteria e centralino update'}, {'idCategiriaInterna': 25, 'categoriaEba': 'Servizi di ristorazione (e.g. erogazione pasti, catering, fornitura buoni pasto)'}, {'idCategiriaInterna': 26, 'categoriaEba': 'Servizi di vigilanza e sorveglianza armata'}, {'idCategiriaInterna': 27, 'categoriaEba': 'Servizi medici'}, {'idCategiriaInterna': 28, 'categoriaEba': 'Servizi postali'}, {'idCategiriaInterna': 29, 'categoriaEba': 'Funzione aziendale di controllo (i.e. Revisione Interna, Compliance, Controllo dei Rischi, Convalida, Antiriciclaggio)'}, {'idCategiriaInterna': 30, 'categoriaEba': 'Recupero crediti'}, {'idCategiriaInterna': 31, 'categoriaEba': 'Segnalazioni di Vigilanza'}, {'idCategiriaInterna': 32, 'categoriaEba': 'Servizi e attività di investimento'}, {'idCategiriaInterna': 33, 'categoriaEba': 'Servizio/attività di back office'}, {'idCategiriaInterna': 34, 'categoriaEba': 'Servizio archiviazione digitale o cartacea'}, {'idCategiriaInterna': 35, 'categoriaEba': 'Sistema informativo o sue componenti critiche'}, {'idCategiriaInterna': 36, 'categoriaEba': 'Trasporto valori'}, {'idCategiriaInterna': 37, 'categoriaEba': 'Trattamento del contante'}, {'idCategiriaInterna': 41, 'categoriaEba': 'Trasporto valori1'}, {'idCategiriaInterna': 42, 'categoriaEba': 'Trasporto valori2'}, {'idCategiriaInterna': 43, 'categoriaEba': 'Trasporto valori3'}, {'idCategiriaInterna': 44, 'categoriaEba': 'Le tagliatelle di nonna Pina'}, {'idCategiriaInterna': 45, 'categoriaEba': 'Ambrogio Fogar'}, {'idCategiriaInterna': 46, 'categoriaEba': 'Prova1234'}, {'idCategiriaInterna': 47, 'categoriaEba': 'Testa categoria interna'}, {'idCategiriaInterna': 48, 'categoriaEba': 'Test categoria interna'}, {'idCategiriaInterna': 49, 'categoriaEba': 'Test categoria interna 2'}, {'idCategiriaInterna': 50, 'categoriaEba': 'Testing#01'}];
      const categories = {};

    const mockParameter = {};
    anagraficheService.saveCategoriaInterna.and.returnValue(of(mockResponse));

    component.saveCategory();

    expect(anagraficheService.saveCategoriaInterna).toHaveBeenCalled();
    anagraficheService.saveCategoriaInterna(categories).subscribe(result => {
      expect(result).toBe(mockResponse);
    });
  });
  it('should call addCategory', () => {
    const formArray = [];
    spyOn(component, 'addCategory');
    component.addCategory();
    expect(component.addCategory).toHaveBeenCalled();
  });

  it('should call editSubcategory', () => {
    spyOn(component, 'editSubcategory');
    component.editSubcategory(121);
    expect(component.editSubcategory).toHaveBeenCalled();
  });
});
