import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddServizioPopUpComponent } from 'src/app/modules/proposte/components/add-servizio-pop-up/add-servizio-pop-up.component';
import { AnagraficheService } from '../../services/anagrafiche.service';
import { LoginService } from '../../../../shared/services/login.service';

@Component({
  selector: 'reg-category-interne',
  templateUrl: './category-interne.component.html',
  styleUrls: ['./category-interne.component.scss']
})
export class CategoryInterneComponent implements OnInit {
  breadcrumbs = [
    {
      label: 'Anagrafe',
      url: '/anagarfe'
    },
    {
      label: 'Elenco Categorie Interne',
      url: '/anagarfe/category-interne'
    }
  ];
  categories = [];
  categoryInterneForm: FormArray;
  editMode = [];
  hasAnagraficheReadOnly: boolean;
  constructor(
    private anagraficheService: AnagraficheService,
    private _modalService: NgbModal,
    private loginService: LoginService
  ) { }

  private createFromGroup(categories) {
    const formArray = categories.map(category => {
      return new FormGroup({
        categoriaEba: new FormControl(category.categoriaEba),
        idCategiriaInterna: new FormControl(category.idCategiriaInterna),
      });
    });
    this.categoryInterneForm = new FormArray(formArray);
  }

  private getCategories() {
    this.anagraficheService.getCategoriaInterna().subscribe(categories => {
      this.categories = categories;
      this.createFromGroup(categories);
    });
  }

  addCategory() {
    const serviceModalRef = this._modalService.open(AddServizioPopUpComponent, {
      backdrop: 'static'
    });
    serviceModalRef.componentInstance.modalName = 'interne';
    serviceModalRef.result.then((categoryName) => {
      if (categoryName) {
        this.categoryInterneForm.push(
          new FormGroup({
            categoriaEba: new FormControl(categoryName),
            idCategiriaInterna: new FormControl(),
          })
        );
      }
    });
  }

  editSubcategory(index) {
    this.editMode[index] = !this.editMode[index];
  }

  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
      this.hasAnagraficheReadOnly = operationModel ? operationModel.hasAnagraficheReadOnly : '';
    this.getCategories();
  }

  async resetForm() {
    this.createFromGroup(this.categories);
  }

  saveCategory() {
    this.anagraficheService.saveCategoriaInterna(this.categoryInterneForm.value).subscribe(categories => {
      this.categories = categories;
      this.createFromGroup(this.categories);
    });
  }

}
