import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TrattamentoDatiPersonaliComponent } from './trattamento-dati-personali.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { AnagraficheService } from '../../services/anagrafiche.service';
import { LoginService } from 'src/app/shared/services/login.service';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('TrattamentoDatiPersonaliComponent', () => {
  let component: TrattamentoDatiPersonaliComponent;
  let fixture: ComponentFixture<TrattamentoDatiPersonaliComponent>;
  let anagraficheService;
  let loginService;

  beforeEach(async(() => {
    anagraficheService = jasmine.createSpyObj(['saveElencoTrattamentoDatiPersonali', 'getElencoTrattamentoDatiPersonali']);
    loginService = jasmine.createSpyObj(['getOperationModel']);
    TestBed.configureTestingModule({
      declarations: [ TrattamentoDatiPersonaliComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: AnagraficheService, useValue: anagraficheService },
        { provide: LoginService, useValue: loginService}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const getResponse = [
      {
         'idCategiriaInterna': 1,
         'categoriaEba': 'Infrastruttura globale di messaggistica finanziaria soggetta alla vigilanza delle pertinenti autorità'
      },
      {
         'idCategiriaInterna': 2,
         // tslint:disable-next-line: max-line-length
         'categoriaEba': 'Acquisizione di beni (e.g. tessere di plastica, lettori di carte, forniture per ufficio, personal computer, mobilio)'
      },
    ]
    anagraficheService.getElencoTrattamentoDatiPersonali.and.returnValue(of(getResponse));
    anagraficheService.saveElencoTrattamentoDatiPersonali.and.returnValue(of(getResponse));
    fixture = TestBed.createComponent(TrattamentoDatiPersonaliComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show title', () => {
    const compiled = fixture.debugElement.nativeElement;
    // expect(compiled.queryAll(By.css('div'))[4].textContent).toContain('label.anagrafichePage.ElencoCategorieBankIT');
    expect(compiled.querySelector('div').textContent).toContain('label.anagrafichePage.ElencoTrattamentoDatiPersonali');
    // tslint:disable-next-line: max-line-length
    // expect(fixture.debugElement.queryAll(By.css('div'))[4].nativeElement.textContent).toBe('label.anagrafichePage.ElencoCategorieBankIT');
  });

   it('should call ngoninit', () => {
    spyOn(component, 'ngOnInit');
    component.ngOnInit();
    expect(component.ngOnInit).toHaveBeenCalled();
  });


  it('should call saveCategory', () => {
    spyOn(component, 'saveCategory');
    component.saveCategory();
    expect(component.saveCategory).toHaveBeenCalled();
  });


  it('should call service method ', () => {
    // tslint:disable-next-line: max-line-length
    const mockResponse = [{'trattamentotId': 1, 'orderId': 1, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Transazioni economiche update'}, {'trattamentotId': 2, 'orderId': 2, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': ' Affidabilità bancaria (Informazioni sulla affidabilità bancaria del soggetto)'}, {'trattamentotId': 3, 'orderId': 3, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Autenticazione (Informazioni utili per l\'autenticazione individuale)'}, {'trattamentotId': 4, 'orderId': 4, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Autenticazione (Informazioni utili per l\'autenticazione individuale)'}, {'trattamentotId': 5, 'orderId': 5, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Comunicazioni (Informazioni sulle comunicazioni operate o ricevute dal soggetto:  es. registrazioni telefoniche, email, PEC, registrazioni vocali)'}, {'trattamentotId': 6, 'orderId': 6, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Contatti (Informazioni che consentono di entrare in contatto con il soggetto)'}, {'trattamentotId': 7, 'orderId': 7, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Funzione che a norma di legge deve essere svolta da un fornitore di servizi (e.g. la revisione legale dei conti)'}, {'trattamentotId': 8, 'orderId': 1, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Credo religioso e convinzioni (Informazioni sul credo religioso e sulle convinzioni culturali)'}, {'trattamentotId': 9, 'orderId': 2, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Demografici Economici Geografici (Informazioni relative a caratteristiche del soggetto  che siano condivise con una classe : demografica, economica, geografica, altro)'}, {'trattamentotId': 10, 'orderId': 3, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Dispositivi elettronici ( Informazioni relative ai dispositivi elettronici per uso personale attribuiti al soggetto con uso part-time o altro)'}, {'trattamentotId': 11, 'orderId': 4, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Geolocalizzazione (Informazioni relative alla geolocalizzazione del soggetto)'}, {'trattamentotId': 12, 'orderId': 5, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Identificativi personali (Informazioni che possono identificare in maniera assoluta o parziale un individuo)'}, {'trattamentotId': 13, 'orderId': 6, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Immagini e dati biometrici (Immagini e dati biometrici che possono individuare in maniera parziale un individuo)'}, {'trattamentotId': 14, 'orderId': 1, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Transazioni economiche'}, {'trattamentotId': 15, 'orderId': 2, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': ' Affidabilità bancaria (Informazioni sulla affidabilità bancaria del soggetto)'}, {'trattamentotId': 16, 'orderId': 3, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Autenticazione (Informazioni utili per l\'autenticazione individuale)'}, {'trattamentotId': 17, 'orderId': 4, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Autenticazione (Informazioni utili per l\'autenticazione individuale)'}, {'trattamentotId': 18, 'orderId': 5, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Comunicazioni (Informazioni sulle comunicazioni operate o ricevute dal soggetto:  es. registrazioni telefoniche, email, PEC, registrazioni vocali)'}, {'trattamentotId': 19, 'orderId': 6, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Contatti (Informazioni che consentono di entrare in contatto con il soggetto)'}, {'trattamentotId': 20, 'orderId': 7, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Funzione che a norma di legge deve essere svolta da un fornitore di servizi (e.g. la revisione legale dei conti)'}, {'trattamentotId': 21, 'orderId': 1, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Credo religioso e convinzioni (Informazioni sul credo religioso e sulle convinzioni culturali)'}, {'trattamentotId': 22, 'orderId': 2, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Demografici Economici Geografici (Informazioni relative a caratteristiche del soggetto  che siano condivise con una classe : demografica, economica, geografica, altro)'}, {'trattamentotId': 23, 'orderId': 3, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Dispositivi elettronici ( Informazioni relative ai dispositivi elettronici per uso personale attribuiti al soggetto con uso part-time o altro)'}, {'trattamentotId': 24, 'orderId': 4, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Geolocalizzazione (Informazioni relative alla geolocalizzazione del soggetto)'}, {'trattamentotId': 25, 'orderId': 5, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Identificativi personali (Informazioni che possono identificare in maniera assoluta o parziale un individuo)'}, {'trattamentotId': 26, 'orderId': 6, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Immagini e dati biometrici (Immagini e dati biometrici che possono individuare in maniera parziale un individuo)'}, {'trattamentotId': 28, 'orderId': 0, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Identificativi personali1'}, {'trattamentotId': 33, 'orderId': 0, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Identificativi personali2'}, {'trattamentotId': 34, 'orderId': 0, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Identificativi personali3'}, {'trattamentotId': 35, 'orderId': 0, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'jj'}, {'trattamentotId': 36, 'orderId': 0, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Prova12345'}, {'trattamentotId': 37, 'orderId': 0, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'Test dati personali'}, {'trattamentotId': 38, 'orderId': 0, 'tableId': 'Elenco Trattamento Dati', 'elencoTrattamentoDati': 'tt123'}];
      const categories = {};

    const mockParameter = {};
    anagraficheService.saveElencoTrattamentoDatiPersonali.and.returnValue(of(mockResponse));

    component.saveCategory();

    expect(anagraficheService.saveElencoTrattamentoDatiPersonali).toHaveBeenCalled();
    anagraficheService.saveElencoTrattamentoDatiPersonali(categories).subscribe(result => {
      expect(result).toBe(mockResponse);
    });
  });

  it('should call addCategory', () => {
   spyOn(component, 'addCategory');
    component.addCategory();
    expect(component.addCategory).toHaveBeenCalled();
  });

  it('should call editSubcategory', () => {
    spyOn(component, 'editSubcategory');
    component.editSubcategory(121);
    expect(component.editSubcategory).toHaveBeenCalled();
  });
});
