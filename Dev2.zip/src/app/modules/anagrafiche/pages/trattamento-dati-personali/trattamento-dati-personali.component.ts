import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddServizioPopUpComponent } from 'src/app/modules/proposte/components/add-servizio-pop-up/add-servizio-pop-up.component';
import { AnagraficheService } from '../../services/anagrafiche.service';
import { LoginService } from '../../../../shared/services/login.service';

@Component({
  selector: 'reg-trattamento-dati-personali',
  templateUrl: './trattamento-dati-personali.component.html',
  styleUrls: ['./trattamento-dati-personali.component.scss']
})
export class TrattamentoDatiPersonaliComponent implements OnInit {
  breadcrumbs = [
    {
      label: 'Anagrafe',
      url: '/anagarfe'
    },
    {
      label: 'Elenco Trattamento dati personali',
      url: '/anagarfe/trattamento-dati-personali'
    }
  ];
  categories = [];
  trattamentoForm: FormArray;
  hasAnagraficheReadOnly: boolean;
  editMode = [];
  constructor(
    private anagraficheService: AnagraficheService,
    private _modalService: NgbModal,
    private loginService: LoginService
  ) { }


  private createFromGroup(categories) {
    const formArray = categories.map(category => {
      return new FormGroup({
        elencoTrattamentoDati:  new FormControl(category.elencoTrattamentoDati),
        orderId: new FormControl(category.orderId),
        tableId: new FormControl(category.tableId),
        trattamentotId: new FormControl(category.trattamentotId)
      });
    });
    this.trattamentoForm = new FormArray(formArray);
  }

  private getCategories() {
    this.anagraficheService.getElencoTrattamentoDatiPersonali().subscribe(categories => {
      this.categories = categories;
      this.createFromGroup(categories);
    });
  }

  addCategory() {
    const serviceModalRef = this._modalService.open(AddServizioPopUpComponent, {
      backdrop: 'static'
    });
    serviceModalRef.componentInstance.modalName = 'trattomento';
    serviceModalRef.result.then((categoryName) => {
      if (categoryName) {
        this.trattamentoForm.push(
          new FormGroup({
            elencoTrattamentoDati:  new FormControl(categoryName),
            orderId: new FormControl(),
            tableId: new FormControl('Elenco Trattamento Dati'),
            trattamentotId: new FormControl()
          })
        );
      }
    });
  }

  editSubcategory(index) {
    this.editMode[index] = !this.editMode[index];
  }

  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasAnagraficheReadOnly = operationModel ? operationModel.hasAnagraficheReadOnly : '';
    this.getCategories();
  }

  async resetForm() {
    this.createFromGroup(this.categories);
  }

  saveCategory() {
    this.anagraficheService.saveElencoTrattamentoDatiPersonali(this.trattamentoForm.value).subscribe(categories => {
      this.categories = categories;
      this.createFromGroup(this.categories);
    });
  }
}
