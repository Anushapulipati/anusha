import { Component, Injector, OnDestroy, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ProposteService } from 'src/app/modules/proposte/services/proposte.service';
import { BasePage } from 'src/app/shared/base-page/base-page';
import { AnagraficheService } from '../../services/anagrafiche.service';
import { TreeviewItem } from 'ngx-treeview';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginService } from '../../../../shared/services/login.service';
import { EsportaModel } from 'src/app/shared/models/esportaModel';
import { UrlProviderService } from 'src/app/shared/services/url-provider.service';
import { ResponseCommonPopUpComponent } from '../download-popup/response-common-pop-up.component';
import { DialogService } from 'fe-dghub-component-library';
import { SearchInputService } from 'src/app/shared/services/search-input.service';

@Component({
  selector: 'reg-anagrafiche-page',
  templateUrl: './anagrafiche-page.component.html',
  styleUrls: ['./anagrafiche-page.component.scss']
})
export class AnagrafichePageComponent extends BasePage implements OnInit, OnDestroy {
  anagraficheForm: FormGroup;
  anagraficheList: any;
  clienteList: any;
  collectionSize: any;
  dialogRef: any;
  esportaModel: EsportaModel;
  fornitore = false;
  fornitoreList: any;
  hasNewClienteAccess: boolean;
  hasNewFornitoreAccess: boolean;
  idOfExcel: number[] = [];
  isfornitoreList = true;
  isSearchedResult = false;
  isShowclienteList = true;
  isShowfornitoreList = true;
  ordinaPer: TreeviewItem[];
  page = 1;
  pageSize = 20;
  searchData: any;
  subscription: any;
  value: any;
  constructor(
    private proposteService: ProposteService,
    private anagraficheService: AnagraficheService,
    injector: Injector,
    private loginService: LoginService,
    private router: Router,
    private route: ActivatedRoute,
    private urlProviderService: UrlProviderService,
    private dialog: DialogService,
    private searchInputService: SearchInputService
  ) {
    super(injector);
  }

  private checkSearchInput() {
    this.subscription = this.searchInputService.getSearchInput().subscribe((searchInput: any) => {
      // if (searchInput && searchInput.inputValue !== ' ' && searchInput.inputValue !== undefined) {
      if (searchInput && searchInput.inputValue !== '' && searchInput.inputValue !== undefined) {
        this.isSearchedResult = true;
        this.page = 1;
        this.searchData = {
          name : searchInput.page,
          value : searchInput.inputValue,
          startIndex : this.page
        };
        this.getSearchData(this.searchData);
      } else {
        this.isSearchedResult = false;
        this.setFormGroup();
        this.onPageChange(this.page);
        this.getFornitoreClientList();
      }
    });
  }

  private getSearchData(searchData) {
    this.searchInputService.getSearchResults(searchData).subscribe(searchResult => {
      this.collectionSize = searchResult['count'];
      const fornitoreClientData = searchResult['anagrafe'] ? searchResult['anagrafe'] : [];
      this.anagraficheList = fornitoreClientData;
      this.isSearchedResult = true;
    });
  }

  private getData(filters) {
    this.anagraficheService.getFornitoreClientDetailsByFilters(filters)
      .subscribe(async fornitoreClientList => {
        this.collectionSize = fornitoreClientList['total'];
        const fornitoreClientData = fornitoreClientList['data'] ? fornitoreClientList['data'] : [];
        this.anagraficheList = fornitoreClientData;
      });
  }

  private getFornitoreClientList() {
    this.proposteService.getDropdownData(['Ordina per Anagrafica']).subscribe(async filters => {
      this.ordinaPer = await this.getFilterdData(filters['Ordina per Anagrafica']);
    });
  }

  private setFormGroup() {
    this.anagraficheForm = new FormGroup({
      ordinaPer: new FormControl([]),
      classificazione: new FormControl('FORNITORE'),
    });
  }

  applyFilter() {
    this.page = 1;
    this.isSearchedResult = false;
    const sortBy = this.anagraficheForm.get('ordinaPer').value[0] ? this.anagraficheForm.get('ordinaPer').value[0] : false;
    const filterBy = this.anagraficheForm.get('classificazione').value ? this.anagraficheForm.get('classificazione').value : 'FORNITORE';
    const filters = {
      'filterBy': filterBy,
      'pageNo': this.page,
      'sortBy': sortBy ? sortBy : 'A-Z Nome fornitore/Società cliente',
    };
    this.getData(filters);

  }

  getDetails(id, isFornitoreOrCliente) {
    if (isFornitoreOrCliente === 'F') {
      this.router.navigate(['anagarfe/nuovo-fornitore', id]);
      } else {
      this.router.navigate(['anagarfe/nuovo-cliente', id]);
      }
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  async ngOnInit() {
    this.searchInputService.setSelectedOption('Anagrafe');
    // this.searchInputService.setSearchInput(false);
    this.checkSearchInput();
    const operationModel: any = this.loginService.getOperationModel();
    this.hasNewClienteAccess = operationModel.hasNewClienteAccess;
    this.hasNewFornitoreAccess = operationModel.hasNewFornitoreAccess;
    this.setFormGroup();
    this.onPageChange(this.page);
    await this.getFornitoreClientList();
  }

  onPageChange(value) {
    this.page = value;
    const sortBy = this.anagraficheForm.get('ordinaPer').value[0] ? this.anagraficheForm.get('ordinaPer').value[0] : false;
    const filterBy = this.anagraficheForm.get('classificazione').value ? this.anagraficheForm.get('classificazione').value : 'FORNITORE';
    const filters = {
      'filterBy': filterBy,
      'pageNo': this.page,
      'sortBy': sortBy ? sortBy : 'A-Z Nome fornitore/Società cliente',
    };
    // this.getData(filters);
    if (this.isSearchedResult) {
      this.searchData['startIndex'] = this.page;
      this.getSearchData(this.searchData);
    } else {
      this.getData(filters);
    }
  }

  onValueChange(value) {
    this.anagraficheForm.get('ordinaPer').setValue([value]);
  }

  // tslint:disable-next-line: member-ordering
  esporta() {
    this.showDownloadPopUp();
    this.anagraficheService.exportToAnagraficheExcel(this.esportaModel).subscribe(data => {
      this.idOfExcel.push(data.id);
      this.verifyStatus(data.id);
      // localStorage.setItem("idsToExport", this.idOfExcel);
    });
  }

  verifyStatus(id: any) {
    this.anagraficheService.checkExcelStatus(id).subscribe(
      result => {
        if (result.status === 'Completed') {
          this.downloadFile(result.id, result.glossariType);
        } else {
          // tslint:disable-next-line:no-non-null-assertion
          if (result.status! = 'Failed') {
            setTimeout(() => {
              this.verifyStatus(result.id);
            }, 10000);
          }
        }
      }
    );
  }

  // tslint:disable-next-line: member-ordering
  downloadFile(data: any, fileName: any) {
    console.log('inside download');
    const element = document.createElement('a');
    window.open(this.urlProviderService.downloadAnagraficheExcel + '?id=' + data);
    this.dialogRef.close();
  }

  // tslint:disable-next-line: member-ordering
  showDownloadPopUp() {
    const message = {
      title: 'message',
      body: '',
      details: '',
      stackTrace: ''
    };
    message.details = 'downloading..';
    this.dialogRef = this.dialog.open(ResponseCommonPopUpComponent, {
      size: 'small',
      noCloseButton: true,
      data: { message }
    });
    this.dialogRef.afterClosed.subscribe(result => {
      if (result) {

      }
    });
  }
}
