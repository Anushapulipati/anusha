import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnagrafichePageComponent } from './anagrafiche-page.component';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { HttpClientModule } from '@angular/common/http';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

import { TreeviewItem, TreeviewConfig } from 'ngx-treeview';
import { Router, ActivatedRoute } from '@angular/router';
import { ProposteService } from 'src/app/modules/proposte/services/proposte.service';
import { AnagraficheService } from '../../services/anagrafiche.service';
import { SearchInputService } from 'src/app/shared/services/search-input.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LoginService } from 'src/app/shared/services/login.service';
import { RouterTestingModule } from '@angular/router/testing';
import { NuovoFornitoreComponent } from '../../components/nuovo-fornitore/nuovo-fornitore.component';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('AnagrafichePageComponent', () => {
  let component: AnagrafichePageComponent;
  let fixture: ComponentFixture<AnagrafichePageComponent>;
  let treeViewItem: TreeviewItem;
  let treeViewConfig: TreeviewConfig;
  let anagraficheService;
  let route;
  let mockResponse;
  let anagraficheForm;
  let searchInputService;
  let loginService;
  let searchInput;
  let loginResponse;

  beforeEach(async(() => {
    loginService =  jasmine.createSpyObj(['login', 'logout', 'setOperationalModel', 'getOperationModel']);
    anagraficheService = jasmine.createSpyObj(['getFornitoreClientDetailsByFilters']);
    // tslint:disable-next-line: max-line-length
    searchInputService = jasmine.createSpyObj(['setSearchInput', 'setSelectedOption', 'getSearchResults', 'getSelectedOption', 'getSearchInput']);

    TestBed.configureTestingModule({
      declarations: [ AnagrafichePageComponent, NuovoFornitoreComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        FeDghubComponentLibraryModule,
        HttpClientTestingModule,
        RouterTestingModule.withRoutes([
          { path: 'anagarfe/nuovo-fornitore/:propostaId/:fornitoreId', component: NuovoFornitoreComponent },
          { path: 'anagarfe/nuovo-fornitore/:fornitoreId', component: NuovoFornitoreComponent }
      ]),
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TreeviewItem, useValue: treeViewItem },
        { provide: TreeviewConfig, useValue: treeViewConfig },
       /*  { provide: Router, useValue: router }, */
        { provide: AnagraficheService, useValue: anagraficheService },
        { provide: ActivatedRoute, useValue: route },
        {provide: SearchInputService, useValue: searchInputService},
        { provide: LoginService, useValue: loginService},
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    searchInput = {
      name : 'registro',
      startIndex : '1',
      value : '177'
    };
    const logoutResponse = {};
    // tslint:disable-next-line: max-line-length
    const searchResponse = {'suppliers': null, 'registro': [{'registroId': 177, 'societaDelGruppoCliente': 'SV Banca', 'fornitore': 'Capgemini Italia update', 'fornitoreInfraExtraGruppo': 'Infragruppo', 'classificazione': 'Fornitura', 'perimetroMonitoraggioICTVendor': 'No', 'statoDelServizio': 'In attesa sottoscrizione', 'ogettoDelContratto': 'Oggetto ', 'descrizioneDelServizioErogato': 'description', 'contrattoId': null, 'fornitoreId': null}], 'anagrafe': null, 'logActivity': null, 'count': 1};
    // tslint:disable-next-line: max-line-length
    loginResponse = {'name': 'Mario', 'surname': 'Rasso', 'matricola': '23456', 'office': null, 'id': null, 'profile': {'code': 'Amministratore', 'description': null}, 'operationVm': {'hasExportAllAccess': true, 'hasAllTabAccess': true, 'hasRegistroReadOnly': false, 'hasNewPropostaAccess': true, 'hasNewContrattoAccess': true, 'hasNewFornitoreAccess': true, 'hasNewClienteAccess': true, 'hasPropostaReadOnly': false, 'hasAnagraficheReadOnly': false, 'hasLogActivityReadOnly': false, 'hasExportBySystemDate': false, 'hasRegistroStatoFilter': false, 'hasRegistroFornitoreDisabled': false}};
    loginService.login.and.returnValue(of(loginResponse));
    loginService.setOperationalModel(loginResponse.operationVm);
    loginService.logout.and.returnValue(of(logoutResponse));
    // tslint:disable-next-line: max-line-length
    const operationVm = {'hasExportAllAccess': true, 'hasAllTabAccess': true, 'hasRegistroReadOnly': false, 'hasNewPropostaAccess': true, 'hasNewContrattoAccess': true, 'hasNewFornitoreAccess': true, 'hasNewClienteAccess': true, 'hasPropostaReadOnly': false, 'hasAnagraficheReadOnly': false, 'hasLogActivityReadOnly': false, 'hasExportBySystemDate': false, 'hasRegistroStatoFilter': false, 'hasRegistroFornitoreDisabled': false}
    loginService.getOperationModel.and.returnValue(of(operationVm));
    const inputValue = 'registro';
    searchInputService.getSearchInput.and.returnValue(of(inputValue));
    searchInputService.getSearchResults.and.returnValue(of(searchResponse));
    // tslint:disable-next-line: max-line-length
    mockResponse = {'total': 25, 'pageSize': 2, 'societaCliente': null, 'fornitoreDetail': null, 'data': [{'clientiId': 47, 'abi': '123', 'classeSocieta': 'Società Strumentale', 'codiceFiscale': 123, 'partitaIva': '123', 'fornitoreId': null, 'nomeSocieta': 'Alessandro LiV93', 'infraGruppoExtraGruppo': null, 'codice': 123, 'ndg': null, 'atecoBankIt': null, 'indirizzoFornitore': null, 'paeseFornitore': null, 'numeroFornitore': null, 'capoGruppo': null, 'description': null, 'nation': null, 'ccnl': null, 'fornitoreCosti': null, 'fornitoreConRatingNegativo': null, 'grouppo': null, 'email': null, 'dataInserimento': null, 'type': null, 'ncommerico': null}, {'clientiId': 41, 'abi': '123', 'classeSocieta': 'Banca', 'codiceFiscale': 123, 'partitaIva': '123', 'fornitoreId': null, 'nomeSocieta': 'Alessandro12334', 'infraGruppoExtraGruppo': null, 'codice': 123, 'ndg': null, 'atecoBankIt': null, 'indirizzoFornitore': null, 'paeseFornitore': null, 'numeroFornitore': null, 'capoGruppo': null, 'description': null, 'nation': null, 'ccnl': null, 'fornitoreCosti': null, 'fornitoreConRatingNegativo': null, 'grouppo': null, 'email': null, 'dataInserimento': null, 'type': null, 'ncommerico': null},]};
    fixture = TestBed.createComponent(AnagrafichePageComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
    anagraficheForm = new FormGroup({
      ordinaPer: new FormControl(['ordinaPer']),
      classificazione: new FormControl(),
    });
    component.anagraficheForm = anagraficheForm;
    anagraficheService.getFornitoreClientDetailsByFilters.and.returnValue(of())
    });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show label names', () => {
    const compiled = fixture.debugElement.nativeElement;
    // expect(compiled.querySelector('label').textContent).toContain('label.anagrafichePage.ordinaper');
  });

  it('should call ngoninit', () => {
    component.ngOnInit();
    /* component.hasNewClienteAccess = loginResponse.operationVm?.hasNewClienteAccess;
    component.hasNewFornitoreAccess = loginResponse.operationVm?.hasNewFornitoreAccess;
    expect(component.hasNewClienteAccess).toBe(true);
    expect(component.hasNewFornitoreAccess).toBe(true); */
  });



it('should call applyFilter and return the said result', () => {
    const anagraficheForm: FormGroup = new FormGroup({
        ordinaPer: new FormControl([]),
        classificazione: new FormControl('FORNITORE'),
      });
      component.anagraficheForm = anagraficheForm;
    const mockParameter = {};
    anagraficheService.getFornitoreClientDetailsByFilters.and.returnValue(of(mockResponse));
    component.page = 1;
    component.applyFilter();
    // fixture.detectChanges();
    expect(anagraficheService.getFornitoreClientDetailsByFilters).toHaveBeenCalled();
    anagraficheService.getFornitoreClientDetailsByFilters(anagraficheForm).subscribe(result => {
      expect(result).toBe(mockResponse);
    });
  });
  it('should call onPageChange method', () => {
    component.searchData = searchInput;
    component.isSearchedResult = true;
    component.anagraficheForm.controls['ordinaPer'].setValue(anagraficheForm.get('ordinaPer').value);
    component.anagraficheForm.controls['classificazione'].setValue(anagraficheForm.get('classificazione').value);
    component.onPageChange(1);
    expect(component.page).toBe(1);
    expect(component.isSearchedResult).toBe(true);
  });

  it('should call onValueChange method', () => {
    // spyOn(component, 'onValueChange');
    component.onValueChange(anagraficheForm.get('ordinaPer').value);
    // expect(component.onValueChange).toHaveBeenCalled();
    expect(component.anagraficheForm.get('ordinaPer').value).toEqual([ [ 'ordinaPer' ] ]);

  });
  it('should call getDetails method', () => {
    // spyOn(component, 'onValueChange');
    component.getDetails(55, 'F');
    // expect(component.onValueChange).toHaveBeenCalled();

  });
});
