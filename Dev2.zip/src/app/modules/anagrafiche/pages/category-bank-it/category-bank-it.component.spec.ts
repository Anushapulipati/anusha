import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoryBankItComponent } from './category-bank-it.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { AnagraficheService } from '../../services/anagrafiche.service';
import { By } from '@angular/platform-browser';
import { LoginService } from 'src/app/shared/services/login.service';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('CategoryBankItComponent', () => {
  let component: CategoryBankItComponent;
  let fixture: ComponentFixture<CategoryBankItComponent>;
  let anagraficheService;
  let loginService;

  beforeEach(async(() => {
    anagraficheService = jasmine.createSpyObj(['saveCategoryBankIt', 'getCategoryBankIt']);
    loginService = jasmine.createSpyObj(['getOperationModel']);
    TestBed.configureTestingModule({
      declarations: [ CategoryBankItComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })

      ],
      providers: [
        { provide: AnagraficheService, useValue: anagraficheService },
        { provide: LoginService, useValue: loginService}
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const getResponse = [
      {
         'idCategorieBankit': 1,
         'categoriBankIt': 'Credito / cartolarizzazioni',
         'code': 'C09',
         'childCategoriaBankit': [
            {
               'idCategorieBankit': 128,
               'categoriBankIt': 'Fasi o specifiche attivitÃ  del processo di istruttoria',
               'parentCategoriaBankit': 1,
               'code': null
            },

            {
               'idCategorieBankit': 200,
               'categoriBankIt': 'Se si "Altro o dettagli" specificare qui',
               'parentCategoriaBankit': 1,
               'code': null
            }
         ]
      },
      {
         'idCategorieBankit': 3,
         'categoriBankIt': 'Gestione collettiva',
         'code': 'C11',
         'childCategoriaBankit': [
            {
               'idCategorieBankit': 140,
               'categoriBankIt': 'Gestione del portafoglio dei fondi',
               'parentCategoriaBankit': 3,
               'code': null
            },

            {
               'idCategorieBankit': 146,
               'categoriBankIt': 'Se si "Altro o dettagli" specificare qui:',
               'parentCategoriaBankit': 3,
               'code': null
            }
         ]
      },

   ];
   const saveResponse = [
    {
       'parentCategorieBankIt': {
          'idCategorieBankit': 1,
          'categoriBankIt': 'Credito / cartolarizzazioni',
          'parentCategoriaBankit': null,
          'code': 'C09'
       },
       'childCategoriesIt': [
          {
             'idCategorieBankit': 128,
             'categoriBankIt': 'Fasi o specifiche attivitÃ  del processo di istruttoria',
             'parentCategoriaBankit': 1,
             'code': null
          },
          {
             'idCategorieBankit': 129,
             'categoriBankIt': 'Fasi o specifiche attivitÃ  del processo di monitoraggio',
             'parentCategoriaBankit': 1,
             'code': null
          },

       ]
    },

 ];
   anagraficheService.getCategoryBankIt.and.returnValue(of(getResponse));
   anagraficheService.saveCategoryBankIt.and.returnValue(of(saveResponse));
    fixture = TestBed.createComponent(CategoryBankItComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

   it('should show title', () => {
    const compiled = fixture.debugElement.nativeElement;
    // expect(compiled.queryAll(By.css('div'))[4].textContent).toContain('label.anagrafichePage.ElencoCategorieBankIT');
    expect(compiled.querySelector('div').textContent).toContain('label.anagrafichePage.ElencoCategorieBankIT');
    // tslint:disable-next-line: max-line-length
    // expect(fixture.debugElement.queryAll(By.css('div'))[4].nativeElement.textContent).toBe('label.anagrafichePage.ElencoCategorieBankIT');
  });

   it('should call ngoninit', () => {
    spyOn(component, 'ngOnInit');
    component.ngOnInit();
    expect(component.ngOnInit).toHaveBeenCalled();
  });


  it('should call saveAnagrafe', () => {
    spyOn(component, 'saveAnagrafe');
    component.saveAnagrafe();
    expect(component.saveAnagrafe).toHaveBeenCalled();
  });


  it('should call saveAnagrafe method ', () => {
    // tslint:disable-next-line: max-line-length
    const mockResponse = [{'parentCategorieBankIt': {'idCategorieBankit': 1, 'categoriBankIt': 'Credito / cartolarizzazioni', 'parentCategoriaBankit': null, 'code': 'C09'}, 'childCategoriesIt': [{'idCategorieBankit': 128, 'categoriBankIt': 'Fasi o specifiche attivitÃ  del processo di istruttoria', 'parentCategoriaBankit': 1, 'code': null}, ]}];
      const categories = {};

    const mockParameter = {};
    anagraficheService.saveCategoryBankIt.and.returnValue(of(mockResponse));

    component.saveAnagrafe();

    expect(anagraficheService.saveCategoryBankIt).toHaveBeenCalled();
    anagraficheService.saveCategoryBankIt(categories).subscribe(result => {
      expect(result).toBe(mockResponse);
    });
  });


  it('should call addSubCategory', () => {
    const formArray = [];
    spyOn(component, 'addSubCategory');
    component.addSubCategory(formArray, 121);
    expect(component.addSubCategory).toHaveBeenCalled();
  });

  it('should call editSubcategory', () => {
    spyOn(component, 'editSubcategory');
    component.editSubcategory(121);
    expect(component.editSubcategory).toHaveBeenCalled();
  });
});
