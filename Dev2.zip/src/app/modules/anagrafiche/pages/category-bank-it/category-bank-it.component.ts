import { Component, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, FormGroupName, Validators } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddServizioPopUpComponent } from 'src/app/modules/proposte/components/add-servizio-pop-up/add-servizio-pop-up.component';
import { AnagraficheService } from '../../services/anagrafiche.service';
import { LoginService } from '../../../../shared/services/login.service';

@Component({
  selector: 'reg-category-bank-it',
  templateUrl: './category-bank-it.component.html',
  styleUrls: ['./category-bank-it.component.scss']
})
export class CategoryBankItComponent implements OnInit {
  breadcrumbs = [
    {
      label: 'Anagrafe',
      url: '/anagarfe'
    },
    {
      label: 'Elenco Categorie BankIT',
      url: '/anagarfe/category-bank-it'
    }
  ];
  categories: any;
  categoryBankItForm: FormArray;
  hasAnagraficheReadOnly: boolean;
  opened: boolean;
  editMode = [];
  constructor(
    private anagraficheService: AnagraficheService,
    private _modalService: NgbModal,
    private loginService: LoginService
  ) { }

  private createFromGroup(categories) {
    const objToFormGroup = (obj) => {
      return new FormGroup({
        categoriBankIt: new FormControl(obj.categoriBankIt),
        // code: new FormControl(obj.code),
        idCategorieBankit: new FormControl(obj.idCategorieBankit),
        parentCategoriaBankit: new FormControl(obj.parentCategoriaBankit),
      });
    };
    const formArray = categories.map(category => {
      return new FormGroup({
        categoriBankIt: new FormControl(category.categoriBankIt),
        code: new FormControl(category.code),
        idCategorieBankit: new FormControl(category.idCategorieBankit),
        value: new FormArray(category['childCategoriaBankit'].map(objToFormGroup))
      });
    });
    this.categoryBankItForm = new FormArray(formArray);
  }

  private getCategories() {
    this.anagraficheService.getCategoryBankIt().subscribe(categories => {
      this.categories = categories;
      this.createFromGroup(categories);
    });
  }

  addCategory() {
    const serviceModalRef = this._modalService.open(AddServizioPopUpComponent, {
      backdrop: 'static'
    });
    serviceModalRef.componentInstance.modalName = 'bankIt';
    serviceModalRef.result.then((categoryName) => {
      if (categoryName) {
        this.categoryBankItForm.push(
          new FormGroup({
            categoriBankIt: new FormControl(categoryName),
            code: new FormControl(),
            idCategorieBankit: new FormControl(),
            value: new FormArray([])
          })
        );
      }
    });
  }

  addSubCategory(formArray, idCategorieBankit) {
    const serviceModalRef = this._modalService.open(AddServizioPopUpComponent, {
      backdrop: 'static'
    });
    serviceModalRef.componentInstance.modalName = 'subbankIt';
    serviceModalRef.result.then((subCategoryName) => {
      if (subCategoryName) {
        const subCategory = new FormGroup({
          categoriBankIt: new FormControl(subCategoryName),
          idCategorieBankit: new FormControl(),
          parentCategoriaBankit: new FormControl(idCategorieBankit),
        });
        formArray.push(subCategory);
      }
    });
  }

  editSubcategory(index) {
    this.editMode[index] = !this.editMode[index];
  }

  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasAnagraficheReadOnly = operationModel ? operationModel.hasAnagraficheReadOnly : '';
    this.getCategories();
  }

  async resetForm() {
    this.createFromGroup(this.categories);
  }

  saveAnagrafe() {
    const categories = this.categoryBankItForm.value.map(group => {
      return {
        'parentCategorieBankIt': {
          'categoriBankIt': group.categoriBankIt,
          'code': group.code,
          'idCategorieBankit': group.idCategorieBankit,
          'parentCategoriaBankit': 0
        },
        'childCategoriesIt': group.value
      };
    });
    this.anagraficheService.saveCategoryBankIt(categories).subscribe(savedCategories => {
      // this.categories = savedCategories;
      // this.createFromGroup(this.categories);
    });
  }
}
