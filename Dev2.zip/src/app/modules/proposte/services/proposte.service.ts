import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UrlProviderService } from 'src/app/shared/services/url-provider.service';
import { HttpClient, HttpParams } from '@angular/common/http';
import { EsportaModel } from 'src/app/shared/models/esportaModel';

@Injectable({
  providedIn: 'root'
})
export class ProposteService {
  constructor(
    private httpClient: HttpClient,
    private urlProviderService: UrlProviderService
  ) { }
  checkExcelStatus(id: any): any {
    const params = new HttpParams();
    const parameters = params.append('id', id.toString());
    return this.httpClient.get<any>(this.urlProviderService.verifyPropostaExport, { params: parameters });
  }
  exportToFilterPropostaExcel(esportaModel: EsportaModel): Observable<any> {
    return this.httpClient.post<any>(this.urlProviderService.exportToExcel, esportaModel);
   }

  exportToPropostaExcel(esportaModel: EsportaModel): Observable<any> {
    return this.httpClient.post<any>(this.urlProviderService.exportToExcel, esportaModel);

}

   getAllClientiDetails() {
    return this.httpClient.get<any>(this.urlProviderService.getAllClientiDetails);
  }

  getContrattoDetails(propostaFornitoreId) {
    const params = new HttpParams();
    const parameters = params.append('contrattoId', propostaFornitoreId);
    return this.httpClient.get(this.urlProviderService.getContrattoDetails, { params: parameters });
  }

  getContrattoServizioDetails(serviceIds) {
    return this.httpClient.post<any>(this.urlProviderService.getContrattoServizioDetails, serviceIds);
  }

  getDate(d) {
    if (d) {
      return {
        day: d.getDate(),
        month: d.getMonth(),
        year: d.getFullYear()
      };
    } else {
      return null;
    }
  }

  getDateObject(date) {
    if (date) {
      const dateArry = date.split('/');
      return { day: parseInt(dateArry[0], 0), month: parseInt(dateArry[1], 0), year: parseInt(dateArry[2], 0) };
    } else {
      return null;
    }
  }

  getDropdownData(keys) {
    const params = new HttpParams();
    const parameters = params
      .append('domaintablekeys', keys[0])
      .append('domaintablekeys', keys[1])
      .append('domaintablekeys', keys[2])
      .append('domaintablekeys', keys[3])
      .append('domaintablekeys', keys[4])
      .append('domaintablekeys', keys[5])
      .append('domaintablekeys', keys[6])
      .append('domaintablekeys', keys[7])
      .append('domaintablekeys', keys[8]);
    return this.httpClient.get(this.urlProviderService.getDomainTableData, { params: parameters });
  }

  getDropdownKeys(): Observable<any> {
    return this.httpClient.get(this.urlProviderService.getDomainTableKeys);
  }

  getFornitoredetailsWithFornitoreId(propostaFornitoreId) {
    const params = new HttpParams();
    const parameters = params.append('fornitoreId', propostaFornitoreId);
    return this.httpClient.get<any>(this.urlProviderService.getFornitoredetailsWithFornitoreId, { params: parameters });
  }

  getFornitourDropdownDetails(): Observable<any>  {
    return this.httpClient.get<any>(this.urlProviderService.getFornitourDropdownDetails);
  }

  getProposals(proposalFilters): Observable<any> {
    return this.httpClient.post<any>(this.urlProviderService.getProposals, proposalFilters);
  }

  getPropostaDetails(propostaId) {
    const params = new HttpParams();
    const parameters = params.append('propostaId', propostaId);
    return this.httpClient.get(this.urlProviderService.getPropostaDetails, { params: parameters });
  }

  getPropostadetailswithSuppliers(propostaId) {
    const params = new HttpParams();
    const parameters = params.append('propostaId', propostaId);
    return this.httpClient.get(this.urlProviderService.getPropostadetailswithSuppliers, { params: parameters });
  }

  getRegistroDetails(registroId) {
    const params = new HttpParams();
    const parameters = params.append('registroId', registroId);
    return this.httpClient.get<any>(this.urlProviderService.getRegistroDetails, { params: parameters });
  }

  getServizioList(propostaFornitoreId) {
    const params = new HttpParams();
    const parameters = params.append('propostaFornitoreId', propostaFornitoreId);
    return this.httpClient.get<any>(this.urlProviderService.getServizioList, { params: parameters });
  }

  getSupplierDetails(propostaInput): Observable<any> {
    return this.httpClient.post<any>(this.urlProviderService.getSupplierDetails, propostaInput);
  }

  getUTCDate(dateString) {
    if (dateString) {
      return new Date(dateString.year, dateString.month - 1 , dateString.day);
    } else {
      return dateString;
    }
  }

  saveContratto(contratto) {
    return this.httpClient.post<any>(this.urlProviderService.saveContratto, contratto);
  }

  saveServizio(servizio) {
    return this.httpClient.post<any>(this.urlProviderService.getsaveServizio, servizio);
  }

  saveServizioListInServizioPage(proposalFilters): Observable<any> {
    return this.httpClient.post<any>(this.urlProviderService.saveServizioListInServizioPage, proposalFilters);
  }

  updateContratto(contratto) {
    return this.httpClient.post<any>(this.urlProviderService.updateContratto, contratto);
  }

  updateSupplierDetails(propostaInput): Observable<any> {
    return this.httpClient.post<any>(this.urlProviderService.updateSupplierDetails, propostaInput);
  }

}
