import { TestBed } from '@angular/core/testing';

import { ProposteService } from './proposte.service';
import { HttpClientTestingModule, HttpTestingController, TestRequest } from '@angular/common/http/testing';
import { UrlProviderService } from 'src/app/shared/services/url-provider.service';

describe('ProposteService', () => {
  let proposteService: ProposteService;
  let httpTestingController;
  let urlProviderService: UrlProviderService;
  const propostaInput = getPropostaInputVm();
  const supplierDetails = getSupplierDetails();
  beforeEach(() => {
    // urlProviderService = jasmine.createSpyObj(['getSupplierDetails', 'getFornitourDropdownDetails', 'getDropdownKeys',
    // 'getDropdownData', 'updateSupplierDetails']);
    TestBed.configureTestingModule({
      providers: [
        ProposteService,
        UrlProviderService],
      imports: [HttpClientTestingModule],

    });
    proposteService = TestBed.get(ProposteService);
    httpTestingController = TestBed.get(HttpTestingController);
    urlProviderService = TestBed.get(UrlProviderService);
  });

  afterEach(() => {
    // After every test, assert that there are no more pending requests.
    // httpTestingController.verify();
  });
  it('should be created', () => {
    const service: ProposteService = TestBed.get(ProposteService);
    expect(service).toBeTruthy();
  });
  it('should call getDropdownKeys with this request method and url', () => {
    const tableKeys = [
      'Categorie BankIT',
      'Stato Proposta',
      'Categorie EBA',
      'Canale di segnalazione',
      'Sottostato Proposta',
      'Società del Segnalante'
    ];
    proposteService.getDropdownKeys().subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.getDomainTableKeys);
    expect(req.request.method).toEqual('GET');
    req.flush(tableKeys);
  });

  it('should call getDropdownData with this request method and url', () => {
    const tableKeys = [
      'Categorie',
      // 'Stato Proposta',
      // 'Categorie EBA',
      // 'Canale di segnalazione',
      // 'Sottostato Proposta',
      // 'Società del Segnalante'
    ];
    const mockResponse = [
      {
        CategorieBankIT: [
          { value: 1, description: 'categoria1' }
        ],
      },
      {
        StatoProposta: [
          { value: 1, description: 'statoProposta' }
        ],
      },

    ];
    proposteService.getDropdownData(tableKeys).subscribe();
    /* const req: TestRequest = httpTestingController.expectOne(urlProviderService.getDomainTableData + '?domaintablekeys=Categorie');
    expect(req.request.method).toEqual('GET');
    req.flush(mockResponse); */
  });

  it('should call getFornitourDropdownDetails with this request method and url', () => {
    const fornitore = [
      {
        'fornitoreId': 1,
        'nomeSocieta': '2020_060'
      },
      {
        'fornitoreId': 2,
        'nomeSocieta': '2020_060'
      },
      {
        'fornitoreId': 3,
        'nomeSocieta': '2020_060'
      }
    ];
    proposteService.getFornitourDropdownDetails().subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.getFornitourDropdownDetails);
    expect(req.request.method).toEqual('GET');
    req.flush(fornitore);
  });

  it('should call getSupplierDetails with this request method and url', () => {
    proposteService.getSupplierDetails(propostaInput).subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.getSupplierDetails);
    expect(req.request.method).toEqual('POST');
    req.flush(supplierDetails);
  });

  it('should call updateSupplierDetails with this request method and url', () => {
    proposteService.updateSupplierDetails(propostaInput).subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.updateSupplierDetails);
    expect(req.request.method).toEqual('POST');
    req.flush(supplierDetails);
  });

  it('should call getAllClientiDetails with this request method and url', () => {
    // tslint:disable-next-line: max-line-length
    const getClientDetails = [{'clientiId': 1, 'nomeSocieta': 'SV Banca', 'abi': 'CLIENT1', 'classeSocieta': 'banca', 'partitaIva': '1', 'codiceFiscale': '1'}, {'clientiId': 25, 'nomeSocieta': 'BPER Banca', 'abi': '5387', 'classeSocieta': 'Società Strumentale', 'partitaIva': 'Partita IVA bper!', 'codiceFiscale': '6666'}, {'clientiId': 26, 'nomeSocieta': 'BPER Banca', 'abi': '5387', 'classeSocieta': 'Società Strumentale', 'partitaIva': 'Partita IVA bper!', 'codiceFiscale': '6666'}, {'clientiId': 27, 'nomeSocieta': 'Test', 'abi': 'Test', 'classeSocieta': 'Si', 'partitaIva': 'Partita ', 'codiceFiscale': '334'}, {'clientiId': 28, 'nomeSocieta': 'Test Nome Società*', 'abi': 'Test ABI', 'classeSocieta': 'Banca', 'partitaIva': 'Test Partita IVA', 'codiceFiscale': '3'}, {'clientiId': 31, 'nomeSocieta': 'Test Cliente', 'abi': 'ABI', 'classeSocieta': 'BancaSocietà Strumentale', 'partitaIva': '11', 'codiceFiscale': '22'}, {'clientiId': 33, 'nomeSocieta': 'efaew', 'abi': 'ABI', 'classeSocieta': 'BancaSocietà Strumentale', 'partitaIva': 'Partita IVA', 'codiceFiscale': '2'}, {'clientiId': 34, 'nomeSocieta': 'Nome Società', 'abi': 'ABI', 'classeSocieta': 'BancaSocietà Strumentale', 'partitaIva': 'Partita IVA', 'codiceFiscale': '11'}, {'clientiId': 37, 'nomeSocieta': 'Società emanuele', 'abi': '55555', 'classeSocieta': 'BancaSocietà Strumentale', 'partitaIva': 'hhh88888', 'codiceFiscale': '9999'}, {'clientiId': 39, 'nomeSocieta': 'my cliente', 'abi': 'ABI', 'classeSocieta': 'Banca', 'partitaIva': 'Partita ', 'codiceFiscale': '6'}, {'clientiId': 41, 'nomeSocieta': 'Alessandro12334', 'abi': '123', 'classeSocieta': 'Banca', 'partitaIva': '123', 'codiceFiscale': '123'}, {'clientiId': 42, 'nomeSocieta': 'Nome Società', 'abi': null, 'classeSocieta': 'Banca', 'partitaIva': null, 'codiceFiscale': null}, {'clientiId': 43, 'nomeSocieta': 'Nome Società', 'abi': null, 'classeSocieta': 'Banca', 'partitaIva': null, 'codiceFiscale': null}, {'clientiId': 44, 'nomeSocieta': 'Test abcx', 'abi': 'ABI', 'classeSocieta': 'Banca', 'partitaIva': 'Partita IVA', 'codiceFiscale': '12'}, {'clientiId': 45, 'nomeSocieta': 'Società', 'abi': null, 'classeSocieta': 'Banca', 'partitaIva': null, 'codiceFiscale': null}, {'clientiId': 46, 'nomeSocieta': 'Società mine', 'abi': null, 'classeSocieta': 'Banca', 'partitaIva': null, 'codiceFiscale': null}, {'clientiId': 47, 'nomeSocieta': 'Alessandro LiV93', 'abi': '123', 'classeSocieta': 'Società Strumentale', 'partitaIva': '123', 'codiceFiscale': '123'}, {'clientiId': 48, 'nomeSocieta': 'Prova n.1', 'abi': null, 'classeSocieta': 'Banca', 'partitaIva': null, 'codiceFiscale': null}, {'clientiId': 49, 'nomeSocieta': 'Nome Società1', 'abi': null, 'classeSocieta': 'Banca', 'partitaIva': null, 'codiceFiscale': null}, {'clientiId': 50, 'nomeSocieta': 'Nome Società2', 'abi': null, 'classeSocieta': 'Banca', 'partitaIva': null, 'codiceFiscale': null}, {'clientiId': 51, 'nomeSocieta': 'Nome Società3', 'abi': null, 'classeSocieta': 'Società Strumentale', 'partitaIva': null, 'codiceFiscale': null}, {'clientiId': 52, 'nomeSocieta': 'Test altro Cliente', 'abi': '4444', 'classeSocieta': 'Società Strumentale', 'partitaIva': null, 'codiceFiscale': '444'}, {'clientiId': 53, 'nomeSocieta': 'Test 1122', 'abi': null, 'classeSocieta': 'Banca', 'partitaIva': null, 'codiceFiscale': null}, {'clientiId': 54, 'nomeSocieta': 'cliente', 'abi': null, 'classeSocieta': 'Banca', 'partitaIva': null, 'codiceFiscale': null}, {'clientiId': 55, 'nomeSocieta': 'new client', 'abi': null, 'classeSocieta': 'Banca', 'partitaIva': null, 'codiceFiscale': null}];
    proposteService.getAllClientiDetails().subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.getAllClientiDetails);
    expect(req.request.method).toEqual('GET');
    req.flush(getClientDetails);
  });

  it('should call getContrattoDetails with this request method and url', () => {
    const contrattoId = 97;
    // tslint:disable-next-line: max-line-length
    const contrattoDetails = {'contrattoId': 389, 'propostaFornitoreId': 361, 'societaClientiId': 1, 'fornitoriAlternativi': 'Fornitori ', 'oggettoDelContratto': 'Oggetto del contratto', 'terminiPreavvisoCliente': '', 'terminiPreavvisoFornitore': '', 'costoAttivita': 76576, 'numeroSubfornitori': 1, 'societaGruppoCliente': 'SV Banca', 'statoComunicazioneAdv': '', 'autoritaCompetente': '', 'statoCompletoAdv': 'complete', 'dataInvioComunicazioneAdv': null, 'necessariaProceduraSindacale': '', 'statoComunicazione': '', 'dataInvioComunicazione': null, 'periodoAttesaEsito': 0, 'scadenzaRiscontro': null, 'statoCompletoProcedura': 'complete', 'societaClienteDatApprovazione': null, 'societaClienteApprovatoreFinale': '', 'statoCompletoCDA': 'complete', 'fornitoreInfragruppoDataDi': null, 'fornitoreInfragruppoFinale': '', 'pareresuiContrattiComplianceList': null, 'parereSuiContrattiRischiList': null, 'servizioList': null, 'servizioContrattoId': null, 'servizioResponseList': [{'servizioId': 421, 'propostaFornitoreId': null, 'marcoProcesso': '13Raccordo con albero dei Processi(Macroprocesso)*', 'racConDeiPro': '13Raccordo con albero dei Processi(Processo)*', 'servizioInfrastrttra': 'Si', 'tipologiaDiCloud': 'Cloud Pubblico', 'possibilitaDiRei': 'Si', 'sostituibilita': 'Difficile', 'classificazioneOne': 'Fornitura', 'classificazioneTipo': 'Esternalizzazione', 'datiPersonali': 'Si', 'sogliaFunzione': 44, 'funzioneEsternalizzata': 'Si', 'funzioneImportante': 'Si', 'ultimaValutazioneData': '01/12/2020', 'sintesideiMotivi': '13Breve sintesi dei motivi per cui la funzione è essenziale o importante', 'paeseDiVieneSvolto': '13Paese in cui il servizio viene svolto*', 'paesediconDati': '13Paese di conservazione dei dati*', 'cloudpaesediCon': '13Cloud - Paese di conservazione dati*', 'descrizioneDel': '13Descrizione del servizio erogato*', 'tipologiaDaDati': null, 'cloudNaturaDaDati': null, 'livelloDiRischiosita': 'Rischio Medio', 'breveRischiosita': '13Breve sintesi sul livello di rischiosità*', 'completoStato': 'complete', 'categoriaBankIt': null, 'sottocategoriaBankIt': null, 'servizioName': '13 - fornitura - fornitore x', 'categoriaEba': 'Supporto e Application Maintenance (AM) su software/applicativi di Terze parti di cui la Banca/Società non dispone dei sorgenti'}], 'fornitoreResponseList': [{'fornitoreId': 38, 'nomeSocieta': 'Fornitore x', 'infraGruppoExtraGruppo': 'Extragruppo', 'codice': 1111, 'ndg': 2222, 'partitaIva': 'AAAAA333', 'codiceFiscale': 44444, 'atecoBankIt': 'CCCC6666', 'indirizzoFornitore': 'via del faggiolo, 56 50012 italia', 'paeseFornitore': 'Italia', 'numeroFornitore': 'DDD777', 'capoGruppo': 'BPER BANCA SPA.', 'description': 'servizi informatici em', 'nation': 'Italiana', 'ccnl': 'Metalmeccanico1', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'No', 'grouppo': 'perché obbligatorio?', 'email': 'aaa@ffttt444.it', 'dataInserimento': '11/12/2020', 'ncommerico': 'BBBB5555'}], 'subFornitore': [{'fornitoreId': 1, 'nomeSocieta': 'Capgemini Italia update'}], 'completoOrInCompleto': false, 'codiceContrattoPadre': null, 'commonContrattoId': 33};
    proposteService.getContrattoDetails(contrattoId).subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.getContrattoDetails + '?contrattoId=' + contrattoId);
    expect(req.request.method).toEqual('GET');
    req.flush(contrattoDetails);
  });

 it('should call getContrattoServizioDetails with this request method and url', () => {
  const servizioIds = [421];

  // tslint:disable-next-line: max-line-length
  const contrattoDetails = [{'contrattoId': 389, 'sevrizioLista': [{'servizioId': 421, 'servizioName': '13 - fornitura - fornitore x'}], 'societaGruppoCliente': 'SV Banca', 'commonContrattoId': 33}];
  proposteService.getContrattoServizioDetails(servizioIds).subscribe();
  const req: TestRequest = httpTestingController.expectOne(urlProviderService.getContrattoServizioDetails);
  expect(req.request.method).toEqual('POST');
  req.flush(contrattoDetails);
});


it('should call getFornitoredetailsWithFornitoreId with this request method and url', () => {
  const servizioIds = [421];
 const fornitoreId = 120;
  // tslint:disable-next-line: max-line-length
  const contrattoDetails = {'fornitoreId': 38, 'nomeSocieta': 'Fornitore x', 'infraGruppoExtraGruppo': 'Extragruppo', 'codice': 1111, 'ndg': 2222, 'partitaIva': 'AAAAA333', 'codiceFiscale': 44444, 'atecoBankIt': 'CCCC6666', 'indirizzoFornitore': 'via del faggiolo, 56 50012 italia', 'paeseFornitore': 'Italia', 'numeroFornitore': 'DDD777', 'capoGruppo': 'BPER BANCA SPA.', 'description': 'servizi informatici em', 'nation': 'Italiana', 'ccnl': 'Metalmeccanico1', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'No', 'grouppo': 'perché obbligatorio?', 'email': 'aaa@ffttt444.it', 'dataInserimento': '11/12/2020', 'ncommerico': 'BBBB5555'};
  proposteService.getFornitoredetailsWithFornitoreId(fornitoreId).subscribe();
  // tslint:disable-next-line: max-line-length
  const req: TestRequest = httpTestingController.expectOne(urlProviderService.getFornitoredetailsWithFornitoreId + '?fornitoreId=' + fornitoreId);
  expect(req.request.method).toEqual('GET');
  req.flush(contrattoDetails);
});

it('should call getProposals with this request method and url', () => {
 const  filterForm = {
    statoProposta: 'statoProposta',
    categorieInterne: 'categorieInterne',
    categorieBankIT: 'categorieBankIT',
    ordinaPer: 'ordinaPer'
  };

  // tslint:disable-next-line: max-line-length
  const contrattoDetails = {'fornitoreId': 38, 'nomeSocieta': 'Fornitore x', 'infraGruppoExtraGruppo': 'Extragruppo', 'codice': 1111, 'ndg': 2222, 'partitaIva': 'AAAAA333', 'codiceFiscale': 44444, 'atecoBankIt': 'CCCC6666', 'indirizzoFornitore': 'via del faggiolo, 56 50012 italia', 'paeseFornitore': 'Italia', 'numeroFornitore': 'DDD777', 'capoGruppo': 'BPER BANCA SPA.', 'description': 'servizi informatici em', 'nation': 'Italiana', 'ccnl': 'Metalmeccanico1', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'No', 'grouppo': 'perché obbligatorio?', 'email': 'aaa@ffttt444.it', 'dataInserimento': '11/12/2020', 'ncommerico': 'BBBB5555'};
  proposteService.getProposals(filterForm).subscribe();
  // tslint:disable-next-line: max-line-length
  const req: TestRequest = httpTestingController.expectOne(urlProviderService.getProposals);
  expect(req.request.method).toEqual('POST');
  req.flush(contrattoDetails);
});

it('should call getPropostaDetails with this request method and url', () => {
 const fornitoreId = 120;
  // tslint:disable-next-line: max-line-length
  const contrattoDetails = {'fornitoreId': 38, 'nomeSocieta': 'Fornitore x', 'infraGruppoExtraGruppo': 'Extragruppo', 'codice': 1111, 'ndg': 2222, 'partitaIva': 'AAAAA333', 'codiceFiscale': 44444, 'atecoBankIt': 'CCCC6666', 'indirizzoFornitore': 'via del faggiolo, 56 50012 italia', 'paeseFornitore': 'Italia', 'numeroFornitore': 'DDD777', 'capoGruppo': 'BPER BANCA SPA.', 'description': 'servizi informatici em', 'nation': 'Italiana', 'ccnl': 'Metalmeccanico1', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'No', 'grouppo': 'perché obbligatorio?', 'email': 'aaa@ffttt444.it', 'dataInserimento': '11/12/2020', 'ncommerico': 'BBBB5555'};
  proposteService.getPropostaDetails(fornitoreId).subscribe();
  // tslint:disable-next-line: max-line-length
  const req: TestRequest = httpTestingController.expectOne(urlProviderService.getPropostaDetails + '?propostaId=' + fornitoreId);
  expect(req.request.method).toEqual('GET');
  req.flush(contrattoDetails);
});

it('should call getPropostadetailswithSuppliers with this request method and url', () => {
  const fornitoreId = 120;
   // tslint:disable-next-line: max-line-length
   const contrattoDetails = {'fornitoreId': 38, 'nomeSocieta': 'Fornitore x', 'infraGruppoExtraGruppo': 'Extragruppo', 'codice': 1111, 'ndg': 2222, 'partitaIva': 'AAAAA333', 'codiceFiscale': 44444, 'atecoBankIt': 'CCCC6666', 'indirizzoFornitore': 'via del faggiolo, 56 50012 italia', 'paeseFornitore': 'Italia', 'numeroFornitore': 'DDD777', 'capoGruppo': 'BPER BANCA SPA.', 'description': 'servizi informatici em', 'nation': 'Italiana', 'ccnl': 'Metalmeccanico1', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'No', 'grouppo': 'perché obbligatorio?', 'email': 'aaa@ffttt444.it', 'dataInserimento': '11/12/2020', 'ncommerico': 'BBBB5555'};
   proposteService.getPropostadetailswithSuppliers(fornitoreId).subscribe();
   // tslint:disable-next-line: max-line-length
   const req: TestRequest = httpTestingController.expectOne(urlProviderService.getPropostadetailswithSuppliers + '?propostaId=' + fornitoreId);
   expect(req.request.method).toEqual('GET');
   req.flush(contrattoDetails);
 });
 
 it('should call getRegistroDetails with this request method and url', () => {
  const fornitoreId = 120;
   // tslint:disable-next-line: max-line-length
   const contrattoDetails = {'fornitoreId': 38, 'nomeSocieta': 'Fornitore x', 'infraGruppoExtraGruppo': 'Extragruppo', 'codice': 1111, 'ndg': 2222, 'partitaIva': 'AAAAA333', 'codiceFiscale': 44444, 'atecoBankIt': 'CCCC6666', 'indirizzoFornitore': 'via del faggiolo, 56 50012 italia', 'paeseFornitore': 'Italia', 'numeroFornitore': 'DDD777', 'capoGruppo': 'BPER BANCA SPA.', 'description': 'servizi informatici em', 'nation': 'Italiana', 'ccnl': 'Metalmeccanico1', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'No', 'grouppo': 'perché obbligatorio?', 'email': 'aaa@ffttt444.it', 'dataInserimento': '11/12/2020', 'ncommerico': 'BBBB5555'};
   proposteService.getRegistroDetails(fornitoreId).subscribe();
   // tslint:disable-next-line: max-line-length
   const req: TestRequest = httpTestingController.expectOne(urlProviderService.getRegistroDetails + '?registroId=' + fornitoreId);
   expect(req.request.method).toEqual('GET');
   req.flush(contrattoDetails);
 });

 

 it('should call getServizioList with this request method and url', () => {
  const fornitoreId = 120;
   // tslint:disable-next-line: max-line-length
   const contrattoDetails = {'fornitoreId': 38, 'nomeSocieta': 'Fornitore x', 'infraGruppoExtraGruppo': 'Extragruppo', 'codice': 1111, 'ndg': 2222, 'partitaIva': 'AAAAA333', 'codiceFiscale': 44444, 'atecoBankIt': 'CCCC6666', 'indirizzoFornitore': 'via del faggiolo, 56 50012 italia', 'paeseFornitore': 'Italia', 'numeroFornitore': 'DDD777', 'capoGruppo': 'BPER BANCA SPA.', 'description': 'servizi informatici em', 'nation': 'Italiana', 'ccnl': 'Metalmeccanico1', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'No', 'grouppo': 'perché obbligatorio?', 'email': 'aaa@ffttt444.it', 'dataInserimento': '11/12/2020', 'ncommerico': 'BBBB5555'};
   proposteService.getServizioList(fornitoreId).subscribe();
   // tslint:disable-next-line: max-line-length
   const req: TestRequest = httpTestingController.expectOne(urlProviderService.getServizioList + '?propostaFornitoreId=' + fornitoreId);
   expect(req.request.method).toEqual('GET');
   req.flush(contrattoDetails);
 });

 
 it('should call saveContratto with this request method and url', () => {
  const fornitoreId = 120;
   // tslint:disable-next-line: max-line-length
  const contrattoDetails = {'contrattoId': 389, 'propostaFornitoreId': 361, 'societaClientiId': 1, 'fornitoriAlternativi': 'Fornitori ', 'oggettoDelContratto': 'Oggetto del contratto', 'terminiPreavvisoCliente': '', 'terminiPreavvisoFornitore': '', 'costoAttivita': 76576, 'numeroSubfornitori': 1, 'societaGruppoCliente': 'SV Banca', 'statoComunicazioneAdv': '', 'autoritaCompetente': '', 'statoCompletoAdv': 'complete', 'dataInvioComunicazioneAdv': null, 'necessariaProceduraSindacale': '', 'statoComunicazione': '', 'dataInvioComunicazione': null, 'periodoAttesaEsito': 0, 'scadenzaRiscontro': null, 'statoCompletoProcedura': 'complete', 'societaClienteDatApprovazione': null, 'societaClienteApprovatoreFinale': '', 'statoCompletoCDA': 'complete', 'fornitoreInfragruppoDataDi': null, 'fornitoreInfragruppoFinale': '', 'pareresuiContrattiComplianceList': null, 'parereSuiContrattiRischiList': null, 'servizioList': null, 'servizioContrattoId': null, 'servizioResponseList': [{'servizioId': 421, 'propostaFornitoreId': null, 'marcoProcesso': '13Raccordo con albero dei Processi(Macroprocesso)*', 'racConDeiPro': '13Raccordo con albero dei Processi(Processo)*', 'servizioInfrastrttra': 'Si', 'tipologiaDiCloud': 'Cloud Pubblico', 'possibilitaDiRei': 'Si', 'sostituibilita': 'Difficile', 'classificazioneOne': 'Fornitura', 'classificazioneTipo': 'Esternalizzazione', 'datiPersonali': 'Si', 'sogliaFunzione': 44, 'funzioneEsternalizzata': 'Si', 'funzioneImportante': 'Si', 'ultimaValutazioneData': '01/12/2020', 'sintesideiMotivi': '13Breve sintesi dei motivi per cui la funzione è essenziale o importante', 'paeseDiVieneSvolto': '13Paese in cui il servizio viene svolto*', 'paesediconDati': '13Paese di conservazione dei dati*', 'cloudpaesediCon': '13Cloud - Paese di conservazione dati*', 'descrizioneDel': '13Descrizione del servizio erogato*', 'tipologiaDaDati': null, 'cloudNaturaDaDati': null, 'livelloDiRischiosita': 'Rischio Medio', 'breveRischiosita': '13Breve sintesi sul livello di rischiosità*', 'completoStato': 'complete', 'categoriaBankIt': null, 'sottocategoriaBankIt': null, 'servizioName': '13 - fornitura - fornitore x', 'categoriaEba': 'Supporto e Application Maintenance (AM) su software/applicativi di Terze parti di cui la Banca/Società non dispone dei sorgenti'}], 'fornitoreResponseList': [{'fornitoreId': 38, 'nomeSocieta': 'Fornitore x', 'infraGruppoExtraGruppo': 'Extragruppo', 'codice': 1111, 'ndg': 2222, 'partitaIva': 'AAAAA333', 'codiceFiscale': 44444, 'atecoBankIt': 'CCCC6666', 'indirizzoFornitore': 'via del faggiolo, 56 50012 italia', 'paeseFornitore': 'Italia', 'numeroFornitore': 'DDD777', 'capoGruppo': 'BPER BANCA SPA.', 'description': 'servizi informatici em', 'nation': 'Italiana', 'ccnl': 'Metalmeccanico1', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'No', 'grouppo': 'perché obbligatorio?', 'email': 'aaa@ffttt444.it', 'dataInserimento': '11/12/2020', 'ncommerico': 'BBBB5555'}], 'subFornitore': [{'fornitoreId': 1, 'nomeSocieta': 'Capgemini Italia update'}], 'completoOrInCompleto': false, 'codiceContrattoPadre': null, 'commonContrattoId': 33};
   proposteService.saveContratto(contrattoDetails).subscribe();
   // tslint:disable-next-line: max-line-length
   const req: TestRequest = httpTestingController.expectOne(urlProviderService.saveContratto);
   expect(req.request.method).toEqual('POST');
   req.flush(contrattoDetails);
 });

 
 it('should call saveServizio with this request method and url', () => {
  const fornitoreId = 120;
   // tslint:disable-next-line: max-line-length
  const contrattoDetails = {'contrattoId': 389, 'propostaFornitoreId': 361, 'societaClientiId': 1, 'fornitoriAlternativi': 'Fornitori ', 'oggettoDelContratto': 'Oggetto del contratto', 'terminiPreavvisoCliente': '', 'terminiPreavvisoFornitore': '', 'costoAttivita': 76576, 'numeroSubfornitori': 1, 'societaGruppoCliente': 'SV Banca', 'statoComunicazioneAdv': '', 'autoritaCompetente': '', 'statoCompletoAdv': 'complete', 'dataInvioComunicazioneAdv': null, 'necessariaProceduraSindacale': '', 'statoComunicazione': '', 'dataInvioComunicazione': null, 'periodoAttesaEsito': 0, 'scadenzaRiscontro': null, 'statoCompletoProcedura': 'complete', 'societaClienteDatApprovazione': null, 'societaClienteApprovatoreFinale': '', 'statoCompletoCDA': 'complete', 'fornitoreInfragruppoDataDi': null, 'fornitoreInfragruppoFinale': '', 'pareresuiContrattiComplianceList': null, 'parereSuiContrattiRischiList': null, 'servizioList': null, 'servizioContrattoId': null, 'servizioResponseList': [{'servizioId': 421, 'propostaFornitoreId': null, 'marcoProcesso': '13Raccordo con albero dei Processi(Macroprocesso)*', 'racConDeiPro': '13Raccordo con albero dei Processi(Processo)*', 'servizioInfrastrttra': 'Si', 'tipologiaDiCloud': 'Cloud Pubblico', 'possibilitaDiRei': 'Si', 'sostituibilita': 'Difficile', 'classificazioneOne': 'Fornitura', 'classificazioneTipo': 'Esternalizzazione', 'datiPersonali': 'Si', 'sogliaFunzione': 44, 'funzioneEsternalizzata': 'Si', 'funzioneImportante': 'Si', 'ultimaValutazioneData': '01/12/2020', 'sintesideiMotivi': '13Breve sintesi dei motivi per cui la funzione è essenziale o importante', 'paeseDiVieneSvolto': '13Paese in cui il servizio viene svolto*', 'paesediconDati': '13Paese di conservazione dei dati*', 'cloudpaesediCon': '13Cloud - Paese di conservazione dati*', 'descrizioneDel': '13Descrizione del servizio erogato*', 'tipologiaDaDati': null, 'cloudNaturaDaDati': null, 'livelloDiRischiosita': 'Rischio Medio', 'breveRischiosita': '13Breve sintesi sul livello di rischiosità*', 'completoStato': 'complete', 'categoriaBankIt': null, 'sottocategoriaBankIt': null, 'servizioName': '13 - fornitura - fornitore x', 'categoriaEba': 'Supporto e Application Maintenance (AM) su software/applicativi di Terze parti di cui la Banca/Società non dispone dei sorgenti'}], 'fornitoreResponseList': [{'fornitoreId': 38, 'nomeSocieta': 'Fornitore x', 'infraGruppoExtraGruppo': 'Extragruppo', 'codice': 1111, 'ndg': 2222, 'partitaIva': 'AAAAA333', 'codiceFiscale': 44444, 'atecoBankIt': 'CCCC6666', 'indirizzoFornitore': 'via del faggiolo, 56 50012 italia', 'paeseFornitore': 'Italia', 'numeroFornitore': 'DDD777', 'capoGruppo': 'BPER BANCA SPA.', 'description': 'servizi informatici em', 'nation': 'Italiana', 'ccnl': 'Metalmeccanico1', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'No', 'grouppo': 'perché obbligatorio?', 'email': 'aaa@ffttt444.it', 'dataInserimento': '11/12/2020', 'ncommerico': 'BBBB5555'}], 'subFornitore': [{'fornitoreId': 1, 'nomeSocieta': 'Capgemini Italia update'}], 'completoOrInCompleto': false, 'codiceContrattoPadre': null, 'commonContrattoId': 33};
   proposteService.saveServizio(contrattoDetails).subscribe();
   // tslint:disable-next-line: max-line-length
   const req: TestRequest = httpTestingController.expectOne(urlProviderService.getsaveServizio);
   expect(req.request.method).toEqual('POST');
   req.flush(contrattoDetails);
 });
 
 it('should call saveServizioListInServizioPage with this request method and url', () => {
  const fornitoreId = 120;
   // tslint:disable-next-line: max-line-length
  const contrattoDetails = {'contrattoId': 389, 'propostaFornitoreId': 361, 'societaClientiId': 1, 'fornitoriAlternativi': 'Fornitori ', 'oggettoDelContratto': 'Oggetto del contratto', 'terminiPreavvisoCliente': '', 'terminiPreavvisoFornitore': '', 'costoAttivita': 76576, 'numeroSubfornitori': 1, 'societaGruppoCliente': 'SV Banca', 'statoComunicazioneAdv': '', 'autoritaCompetente': '', 'statoCompletoAdv': 'complete', 'dataInvioComunicazioneAdv': null, 'necessariaProceduraSindacale': '', 'statoComunicazione': '', 'dataInvioComunicazione': null, 'periodoAttesaEsito': 0, 'scadenzaRiscontro': null, 'statoCompletoProcedura': 'complete', 'societaClienteDatApprovazione': null, 'societaClienteApprovatoreFinale': '', 'statoCompletoCDA': 'complete', 'fornitoreInfragruppoDataDi': null, 'fornitoreInfragruppoFinale': '', 'pareresuiContrattiComplianceList': null, 'parereSuiContrattiRischiList': null, 'servizioList': null, 'servizioContrattoId': null, 'servizioResponseList': [{'servizioId': 421, 'propostaFornitoreId': null, 'marcoProcesso': '13Raccordo con albero dei Processi(Macroprocesso)*', 'racConDeiPro': '13Raccordo con albero dei Processi(Processo)*', 'servizioInfrastrttra': 'Si', 'tipologiaDiCloud': 'Cloud Pubblico', 'possibilitaDiRei': 'Si', 'sostituibilita': 'Difficile', 'classificazioneOne': 'Fornitura', 'classificazioneTipo': 'Esternalizzazione', 'datiPersonali': 'Si', 'sogliaFunzione': 44, 'funzioneEsternalizzata': 'Si', 'funzioneImportante': 'Si', 'ultimaValutazioneData': '01/12/2020', 'sintesideiMotivi': '13Breve sintesi dei motivi per cui la funzione è essenziale o importante', 'paeseDiVieneSvolto': '13Paese in cui il servizio viene svolto*', 'paesediconDati': '13Paese di conservazione dei dati*', 'cloudpaesediCon': '13Cloud - Paese di conservazione dati*', 'descrizioneDel': '13Descrizione del servizio erogato*', 'tipologiaDaDati': null, 'cloudNaturaDaDati': null, 'livelloDiRischiosita': 'Rischio Medio', 'breveRischiosita': '13Breve sintesi sul livello di rischiosità*', 'completoStato': 'complete', 'categoriaBankIt': null, 'sottocategoriaBankIt': null, 'servizioName': '13 - fornitura - fornitore x', 'categoriaEba': 'Supporto e Application Maintenance (AM) su software/applicativi di Terze parti di cui la Banca/Società non dispone dei sorgenti'}], 'fornitoreResponseList': [{'fornitoreId': 38, 'nomeSocieta': 'Fornitore x', 'infraGruppoExtraGruppo': 'Extragruppo', 'codice': 1111, 'ndg': 2222, 'partitaIva': 'AAAAA333', 'codiceFiscale': 44444, 'atecoBankIt': 'CCCC6666', 'indirizzoFornitore': 'via del faggiolo, 56 50012 italia', 'paeseFornitore': 'Italia', 'numeroFornitore': 'DDD777', 'capoGruppo': 'BPER BANCA SPA.', 'description': 'servizi informatici em', 'nation': 'Italiana', 'ccnl': 'Metalmeccanico1', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'No', 'grouppo': 'perché obbligatorio?', 'email': 'aaa@ffttt444.it', 'dataInserimento': '11/12/2020', 'ncommerico': 'BBBB5555'}], 'subFornitore': [{'fornitoreId': 1, 'nomeSocieta': 'Capgemini Italia update'}], 'completoOrInCompleto': false, 'codiceContrattoPadre': null, 'commonContrattoId': 33};
   proposteService.saveServizioListInServizioPage(contrattoDetails).subscribe();
   // tslint:disable-next-line: max-line-length
   const req: TestRequest = httpTestingController.expectOne(urlProviderService.saveServizioListInServizioPage);
   expect(req.request.method).toEqual('POST');
   req.flush(contrattoDetails);
 });

 it('should call updateContratto with this request method and url', () => {
  const fornitoreId = 120;
   // tslint:disable-next-line: max-line-length
  const contrattoDetails = {'contrattoId': 389, 'propostaFornitoreId': 361, 'societaClientiId': 1, 'fornitoriAlternativi': 'Fornitori ', 'oggettoDelContratto': 'Oggetto del contratto', 'terminiPreavvisoCliente': '', 'terminiPreavvisoFornitore': '', 'costoAttivita': 76576, 'numeroSubfornitori': 1, 'societaGruppoCliente': 'SV Banca', 'statoComunicazioneAdv': '', 'autoritaCompetente': '', 'statoCompletoAdv': 'complete', 'dataInvioComunicazioneAdv': null, 'necessariaProceduraSindacale': '', 'statoComunicazione': '', 'dataInvioComunicazione': null, 'periodoAttesaEsito': 0, 'scadenzaRiscontro': null, 'statoCompletoProcedura': 'complete', 'societaClienteDatApprovazione': null, 'societaClienteApprovatoreFinale': '', 'statoCompletoCDA': 'complete', 'fornitoreInfragruppoDataDi': null, 'fornitoreInfragruppoFinale': '', 'pareresuiContrattiComplianceList': null, 'parereSuiContrattiRischiList': null, 'servizioList': null, 'servizioContrattoId': null, 'servizioResponseList': [{'servizioId': 421, 'propostaFornitoreId': null, 'marcoProcesso': '13Raccordo con albero dei Processi(Macroprocesso)*', 'racConDeiPro': '13Raccordo con albero dei Processi(Processo)*', 'servizioInfrastrttra': 'Si', 'tipologiaDiCloud': 'Cloud Pubblico', 'possibilitaDiRei': 'Si', 'sostituibilita': 'Difficile', 'classificazioneOne': 'Fornitura', 'classificazioneTipo': 'Esternalizzazione', 'datiPersonali': 'Si', 'sogliaFunzione': 44, 'funzioneEsternalizzata': 'Si', 'funzioneImportante': 'Si', 'ultimaValutazioneData': '01/12/2020', 'sintesideiMotivi': '13Breve sintesi dei motivi per cui la funzione è essenziale o importante', 'paeseDiVieneSvolto': '13Paese in cui il servizio viene svolto*', 'paesediconDati': '13Paese di conservazione dei dati*', 'cloudpaesediCon': '13Cloud - Paese di conservazione dati*', 'descrizioneDel': '13Descrizione del servizio erogato*', 'tipologiaDaDati': null, 'cloudNaturaDaDati': null, 'livelloDiRischiosita': 'Rischio Medio', 'breveRischiosita': '13Breve sintesi sul livello di rischiosità*', 'completoStato': 'complete', 'categoriaBankIt': null, 'sottocategoriaBankIt': null, 'servizioName': '13 - fornitura - fornitore x', 'categoriaEba': 'Supporto e Application Maintenance (AM) su software/applicativi di Terze parti di cui la Banca/Società non dispone dei sorgenti'}], 'fornitoreResponseList': [{'fornitoreId': 38, 'nomeSocieta': 'Fornitore x', 'infraGruppoExtraGruppo': 'Extragruppo', 'codice': 1111, 'ndg': 2222, 'partitaIva': 'AAAAA333', 'codiceFiscale': 44444, 'atecoBankIt': 'CCCC6666', 'indirizzoFornitore': 'via del faggiolo, 56 50012 italia', 'paeseFornitore': 'Italia', 'numeroFornitore': 'DDD777', 'capoGruppo': 'BPER BANCA SPA.', 'description': 'servizi informatici em', 'nation': 'Italiana', 'ccnl': 'Metalmeccanico1', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'No', 'grouppo': 'perché obbligatorio?', 'email': 'aaa@ffttt444.it', 'dataInserimento': '11/12/2020', 'ncommerico': 'BBBB5555'}], 'subFornitore': [{'fornitoreId': 1, 'nomeSocieta': 'Capgemini Italia update'}], 'completoOrInCompleto': false, 'codiceContrattoPadre': null, 'commonContrattoId': 33};
   proposteService.updateContratto(contrattoDetails).subscribe();
   // tslint:disable-next-line: max-line-length
   const req: TestRequest = httpTestingController.expectOne(urlProviderService.updateContratto);
   expect(req.request.method).toEqual('POST');
   req.flush(contrattoDetails);
 });
 
 it('should call checkExcelStatus with this request method and url', () => {
  const excelId = 20;
  const checkExcelResponse = {};
  proposteService.checkExcelStatus(excelId).subscribe();
   const req: TestRequest = httpTestingController.expectOne(urlProviderService.verifyPropostaExport + '?id=' + excelId);
   expect(req.request.method).toEqual('GET');
   req.flush(checkExcelResponse);
 });

 it('should call exportToFilterPropostaExcel with this request method and url', () => {
   const excelId = 20;
   const checkExcelResponse = {};
   const esportaModel : any  = {
    id: 1,
    endTime: Date,
    fileContent: 'fileContent',
    startTime: Date,
    status: 'status',
    error: 'error',
    };
   proposteService.exportToFilterPropostaExcel(esportaModel).subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.exportToExcel);
    expect(req.request.method).toEqual('POST');
    req.flush(checkExcelResponse);
  });

  it('should call exportToProposta with this request method and url', () => {
    const esportaModel : any  = {
    id: 1,
    endTime: Date,
    fileContent: 'fileContent',
    startTime: Date,
    status: 'status',
    error: 'error',
    };
   const excelId = 20;
   const checkExcelResponse = {};
   proposteService.exportToPropostaExcel(esportaModel).subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.exportToExcel);
    expect(req.request.method).toEqual('POST');
    req.flush(checkExcelResponse); 
  });
});



function getPropostaInputVm() {
  return {
    dataDellaProposta: '12/12/2020',
    uosegnalante: 'unita operative',
    cambioFornitore: 'si',
    fornitore: 1,
    canDiSegnalazione: 'test data',
    codCanSegnalazione: 'test data'
  };
}
function getSupplierDetails() {
  return {
    'numeroProposta': '2020_047',
    'fornitoreId': 1,
    'nomeSocieta': 'Capgemini Italia',
    'oggDellaProposta': 'bu',
    'dataDellaProposta': 1603045800000,
    'statoProposta': 'nbh',
    'id': 46
  };
}
