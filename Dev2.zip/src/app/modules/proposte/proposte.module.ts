import { NgModule } from '@angular/core';
import { CommonModule, registerLocaleData } from '@angular/common';
import { ProposteRoutingModule } from './proposte-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { PendingChangesGuardGuard } from 'src/app/shared/services/pending-changes-guard.guard';
import { TranslateService } from '@ngx-translate/core';
import { Language } from 'src/app/shared/enumerations/language';
import { en } from 'src/app/i18n/en';
import { NuovoContrattoComponent } from './pages/nuovo-contratto/nuovo-contratto.component';
import { DettaglioRigaProposteComponent } from './pages/dettaglio-riga-proposte/dettaglio-riga-proposte.component';
import { PropostePageComponent } from './pages/proposte-page/proposte-page.component';
import { NuovoPropostaComponent } from './pages/nuovo-proposta/nuovo-proposta.component';
import { ContrattoPanelComponent } from './components/contratto-panel/contratto-panel.component';
import { NuovoContrattoAccordionComponent } from './pages/nuovo-contratto-accordion/nuovo-contratto-accordion.component';
import { DatePipe } from '@angular/common';
import {
  ParereSuiContrattiComplianceComponent
} from './components/parere-sui-contratti-compliance/parere-sui-contratti-compliance.component';
import {
  ApprovazinoeOrganoDiSupervisioneStrategicaComponent
} from './components/approvazinoe-organo-di-supervisione-strategica/approvazinoe-organo-di-supervisione-strategica.component';
import { ProceduraSindacaleComponent } from './components/procedura-sindacale/procedura-sindacale.component';
import { ContrattoServiceListComponent } from './components/contratto-service-list/contratto-service-list.component';
import { NuovoContrattoBaseComponent } from './components/nuovo-contratto-base/nuovo-contratto-base.component';
import { ParertSuiContrattiRischiComponent } from './components/parert-sui-contratti-rischi/parert-sui-contratti-rischi.component';
import { InvioAdAdvComponent } from './components/invio-ad-adv/invio-ad-adv.component';

@NgModule({
  declarations: [
    PropostePageComponent,
    NuovoPropostaComponent,
    DettaglioRigaProposteComponent,
    NuovoContrattoComponent,
    ContrattoPanelComponent,
    NuovoContrattoAccordionComponent,
    ParertSuiContrattiRischiComponent,
    ParereSuiContrattiComplianceComponent,
    ApprovazinoeOrganoDiSupervisioneStrategicaComponent,
    InvioAdAdvComponent,
    ProceduraSindacaleComponent,
    NuovoContrattoBaseComponent,
    ContrattoServiceListComponent
  ],
  imports: [
    CommonModule,
    ProposteRoutingModule,
    SharedModule
  ],
  providers: [ PendingChangesGuardGuard, DatePipe ]
})
export class ProposteModule {
  constructor(private translate: TranslateService) {
    this.translate.setTranslation(Language.EN, en);
    }
}
