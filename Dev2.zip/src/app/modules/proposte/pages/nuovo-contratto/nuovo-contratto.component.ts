import { Component, HostListener, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormArray, Validators } from '@angular/forms';
// tslint:disable-next-line: max-line-length
import { ProposteService } from '../../services/proposte.service';
import { SelectView } from 'src/app/shared/models/selectView';
import { combineLatest } from 'rxjs';
import { ActivatedRoute } from '@angular/router';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from 'src/app/shared/services/dateFormat';
import { ServizioDetailsVm } from 'src/app/shared/models/servizioDetailsVm';
import { ClientVm } from 'src/app/shared/models/clientVm';
import { FornitoreDetailsVm } from 'src/app/shared/models/fornitoreDetailsVm';
import { BreadcrumbModel } from 'fe-dghub-component-library';
import { ComponentCanDeactivate } from 'src/app/shared/services/pending-changes-guard.guard';
import { LoginService } from 'src/app/shared/services/login.service';

@Component({
  selector: 'reg-nuovo-contratto',
  templateUrl: './nuovo-contratto.component.html',
  styleUrls: ['./nuovo-contratto.component.scss'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})
export class NuovoContrattoComponent implements OnInit, ComponentCanDeactivate {
  allClientDetails: ClientVm[];
  areaNormativa: SelectView[];
  autoriaCompetente: SelectView[];
  // canaledisegnalazione: any;
  // contrattoDetails: any;
  breadcrumbs: BreadcrumbModel[] = [];
  contratto: any;
  contrattoForm: FormGroup;
  contrattoID: number;
  dropdownSettings: any;
  filterKeys = [
    'Livello di Rischiosità',
    'Sostituibilita',
    'Area normativa',
    'Livello di rischio di non conformità',
    'Livello di adeguatezza Stato comunicazione',
    'Stato Comunicazione AdV',
    'Necessaria procedura sindacale',
    'Autorità Competente',
    'Stato comunicazione Procedura sindacale'
  ];
  fornitoreDetails: FornitoreDetailsVm;
  fornitoreID:  number;
  hasPropostaReadOnly: boolean;
  isInfragruppo: boolean;
  isInvioAdAdvMandatory: boolean;
  isNecessariaProceduraSindacaleCheck = true;
  isProposalCompleted: boolean;
  isSavedForm = true;
  linkedServizioList: ServizioDetailsVm[];
  livello: SelectView[];
  livelloDiAdeguatezzaStatoComunicazione: SelectView[];
  livelloDiRischioDiNonConformita: SelectView[];
  necessariaProceduraSindacale: SelectView[];
  nomeSocieta: string;
  opened: boolean;
  propostaDetails: any;
  propostaFornitoreId: number;
  propostaId: number;
  registroId: number;
  scadenzaRiscontro: Date;
  servizioList: ServizioDetailsVm[];
  societaGruppoCliente: any;
  sostituibilita: SelectView[];
  statoComunicazioneAdV: SelectView[];
  statoComunicazioneProceduraSindacale: SelectView[];
  subFornitore: FornitoreDetailsVm;
  constructor(
    private proposteService: ProposteService,
    private route: ActivatedRoute,
    private loginService: LoginService
  ) { }

  private checkMandatoryPanelConditions(linkedServizioList) {
    const invioAdadvMandatory = linkedServizioList.some(service => (service.funzioneImportante === 'Si'));
    if (invioAdadvMandatory) {
      this.contrattoForm.get('autoritaCompetente').setValidators([Validators.required]);
      this.contrattoForm.get('statoComunicazioneAdv').setValidators([Validators.required]);
      this.contrattoForm.get('dataInvioComunicazioneAdv').setValidators([Validators.required]);
      this.contrattoForm.get('autoritaCompetente').updateValueAndValidity();
      this.contrattoForm.get('statoComunicazioneAdv').updateValueAndValidity();
      this.contrattoForm.get('dataInvioComunicazioneAdv').updateValueAndValidity();
    } else {
      this.contrattoForm.get('autoritaCompetente').setValidators(null);
      this.contrattoForm.get('statoComunicazioneAdv').setValidators(null);
      this.contrattoForm.get('dataInvioComunicazioneAdv').setValidators(null);
      this.contrattoForm.get('autoritaCompetente').updateValueAndValidity();
      this.contrattoForm.get('statoComunicazioneAdv').updateValueAndValidity();
      this.contrattoForm.get('dataInvioComunicazioneAdv').updateValueAndValidity();
    }
    const isclassificazioneOneNull = linkedServizioList.some(service => (service.classificazioneOne === ''));
    const isclassificazioneTwoEst = linkedServizioList.some(service => (service.classificazioneTipo === 'Esternalizzazione'));
    const isclassificazioneOneTwo =
    linkedServizioList.some(service => (service.classificazioneOne === 'Esternalizzazione' && service.classificazioneTipo === ''));
    // const isNotMandatoryPanels = linkedServizioList.every(service => service.pilot);
    if (isclassificazioneOneNull || isclassificazioneTwoEst || isclassificazioneOneTwo) {
      this.contrattoForm.get('parereSuiContrattiRischiList')['controls'].forEach((group, index) => {
        Object.keys(group['controls']).map(field => {
          if (field === 'dataParere' || field === 'livelloDiRischiosita') {
            group['controls'][field].setValidators([Validators.required]);
            group['controls'][field].updateValueAndValidity();
          }
        });
      });
      this.contrattoForm.get('pareresuiContrattiComplianceList')['controls'].forEach((group, index) => {
        Object.keys(group['controls']).map(field => {
          // tslint:disable-next-line: max-line-length
          if (field === 'dataParere' || field === 'areaNormativa' || field === 'livelloRischioNonConformita' || field === 'livelloDiAdeguatezza' || field === 'nparere') {
            group['controls'][field].setValidators([Validators.required]);
            group['controls'][field].updateValueAndValidity();
          }
        });
      });
      // necessariaProceduraSindacale
      this.isNecessariaProceduraSindacaleCheck = true;
      this.contrattoForm.get('necessariaProceduraSindacale').setValidators([Validators.required]);
      this.contrattoForm.get('necessariaProceduraSindacale').updateValueAndValidity();
    } else {
      this.contrattoForm.get('parereSuiContrattiRischiList')['controls'].forEach((group, index) => {
        Object.keys(group['controls']).map(field => {
          if (field === 'dataParere' || field === 'livelloDiRischiosita') {
            group['controls'][field].setValidators(null);
            group['controls'][field].updateValueAndValidity();
          }
        });
      });
      this.contrattoForm.get('pareresuiContrattiComplianceList')['controls'].forEach((group, index) => {
        Object.keys(group['controls']).map(field => {
          // tslint:disable-next-line: max-line-length
          if (field === 'dataParere' || field === 'areaNormativa' || field === 'livelloRischioNonConformita' || field === 'livelloDiAdeguatezza' || field === 'nparere') {
            group['controls'][field].setValidators(null);
            group['controls'][field].updateValueAndValidity();
          }
        });
      });
      // necessariaProceduraSindacale
      this.isNecessariaProceduraSindacaleCheck = false;
      this.contrattoForm.get('necessariaProceduraSindacale').setValidators(null);
      this.contrattoForm.get('necessariaProceduraSindacale').updateValueAndValidity();
    }
  }

  private detectFormChanges() {
    this.contrattoForm.valueChanges.subscribe(changes => {
      if (changes) {
        this.isSavedForm = false;
      }
    });
    this.contrattoForm.get('servizioList').valueChanges.subscribe(changes => {
      if (changes) {
        const linkedServices = changes;
        const linkedServizioList = linkedServices.map(linkedService => {
          return this.servizioList.filter(service => service.servizioId === linkedService)[0];
        });
        this.checkMandatoryPanelConditions(linkedServizioList);
      }
    });
  }

  private getContrattoDetails(contrattoID) {
    if (this.hasPropostaReadOnly) {
      this.contrattoForm.disable();
    } else {
      this.contrattoForm.enable();
    }
    this.proposteService.getContrattoDetails(contrattoID).subscribe((contratto: any) => {
      let parereSuiContrattiRischiList = [];
      let pareresuiContrattiComplianceList = [];
      this.contratto = contratto;
      if (contratto['parereSuiContrattiRischiList']) {
        parereSuiContrattiRischiList = contratto['parereSuiContrattiRischiList'].map(rischi => {
          return {
            ...rischi,
            dataParere: this.proposteService.getDateObject(rischi.dataParere)
          };
        });
      } else {
        parereSuiContrattiRischiList = [{
          parereSuiContrattiRischiId: '',
          contrattoId: '',
          dataParere: null,
          livelloDiRischiosita: '',
          statoCompletoRischi: '',
          nparereRischio: '',
        }];
      }
      if (contratto['pareresuiContrattiComplianceList']) {
        pareresuiContrattiComplianceList = contratto['pareresuiContrattiComplianceList'].map(compliance => {
          return {
            ...compliance,
            dataParere: this.proposteService.getDateObject(compliance.dataParere)
          };
        });
      } else {
        pareresuiContrattiComplianceList = [{
          parereSuiContrattiComplianceId: '',
          contrattoId: '',
          dataParere: null,
          areaNormativa: '',
          livelloRischioNonConformita: '',
          livelloDiAdeguatezza: '',
          statoCompletoCompliance: '',
          nparere: ''
        }];
      }
      contratto['contrattoId'] = contrattoID;
      contratto['pareresuiContrattiComplianceList'] = pareresuiContrattiComplianceList;
      contratto['parereSuiContrattiRischiList'] = parereSuiContrattiRischiList;
      contratto['fornitoreInfragruppoDataDi'] = contratto['fornitoreInfragruppoDataDi']
      ? this.proposteService.getDateObject(contratto.fornitoreInfragruppoDataDi)
      : contratto['fornitoreInfragruppoDataDi'];
      contratto['societaClienteDatApprovazione'] = contratto['societaClienteDatApprovazione']
        ? this.proposteService.getDateObject(contratto.societaClienteDatApprovazione)
        : contratto['societaClienteDatApprovazione'];
      contratto['dataInvioComunicazioneAdv'] = contratto['dataInvioComunicazioneAdv']
        ? this.proposteService.getDateObject(contratto.dataInvioComunicazioneAdv)
        : contratto['dataInvioComunicazioneAdv'];
      contratto['dataInvioComunicazione'] = contratto['dataInvioComunicazione']
        ? this.proposteService.getDateObject(contratto.dataInvioComunicazione)
        : contratto['dataInvioComunicazione'];
      const societaGruppoCliente = this.allClientDetails.filter(client => client.clientiId === contratto['societaClientiId']);
      this.societaGruppoCliente = societaGruppoCliente[0].nomeSocieta;
      contratto['societaGruppoCliente'] = societaGruppoCliente;
      // contratto['subFornitore'] = this.fornitoreDetails;
      this.linkedServizioList = contratto['servizioResponseList'];
      this.scadenzaRiscontro =  contratto['scadenzaRiscontro'];
      if (contratto['pareresuiContrattiComplianceList']) {
        const complianceListFormArray = new FormArray(contratto.pareresuiContrattiComplianceList.map(group => new FormGroup({
          parereSuiContrattiComplianceId: new FormControl(group.parereSuiContrattiComplianceId),
          contrattoId: new FormControl(group.contrattoId),
          idRegistro: new FormControl(group.idRegistro),
          dataParere: new FormControl(group.dataParere, [Validators.required]),
          areaNormativa: new FormControl(group.areaNormativa, [Validators.required]),
          livelloRischioNonConformita: new FormControl(group.livelloRischioNonConformita, [Validators.required]),
          livelloDiAdeguatezza: new FormControl(group.livelloDiAdeguatezza, [Validators.required]),
          statoCompletoCompliance: new FormControl(group.statoCompletoCompliance),
          // nparere: new FormControl(group.nparere, [Validators.required, Validators.pattern('[0-9]{4}_[0-9]{3}')])
          nparere: new FormControl(group.nparere, [Validators.required, Validators.minLength(5), Validators.maxLength(8)])
        })));
        this.contrattoForm.setControl('pareresuiContrattiComplianceList', complianceListFormArray);
      } else {
        contratto['pareresuiContrattiComplianceList'] = [];
      }
      if (contratto['parereSuiContrattiRischiList']) {
        const rischiListFormArray = new FormArray(contratto.parereSuiContrattiRischiList.map(group => new FormGroup({
          parereSuiContrattiRischiId: new FormControl(group.parereSuiContrattiRischiId),
          contrattoId: new FormControl(group.contrattoId),
          idRegistro: new FormControl(group.idRegistro),
          dataParere: new FormControl(group.dataParere, [Validators.required]),
          livelloDiRischiosita: new FormControl(group.livelloDiRischiosita, [Validators.required]),
          statoCompletoRischi: new FormControl(group.statoCompletoRischi),
          // nparereRischio: new FormControl(group.nparereRischio,  Validators.pattern('[0-9]{4}_[0-9]{3}')),
          // nparereRischio: new FormControl(group.nparereRischio),
          nparereRischio: new FormControl(group.nparereRischio, [Validators.minLength(5), Validators.maxLength(8)]),
        })));
        this.contrattoForm.setControl('parereSuiContrattiRischiList', rischiListFormArray);
      } else {
        contratto['parereSuiContrattiRischiList'] = [];
      }
      this.contrattoForm.patchValue(contratto);
      this.contrattoForm.updateValueAndValidity();
      this.checkMandatoryPanelConditions(this.linkedServizioList);
      setTimeout(async () => {
        this.detectFormChanges();
      }, 2000);
      if (this.isProposalCompleted) {
        this.contrattoForm.disable();
      }

    });
  }

  private getDropdownData(filters = []) {
    const items: SelectView[] = [];
    filters.map((filter, index) => {
      const item = new SelectView(filter.itemName, filter.itemName);
      items.push({
        description: filter.itemName,
        value: filter.itemName
      });
    });
    return items;
  }

  private getDropdownTableKeys() {
    combineLatest(
      this.proposteService.getFornitoredetailsWithFornitoreId(this.fornitoreID),
      this.proposteService.getFornitourDropdownDetails(),
      this.proposteService.getServizioList(this.propostaFornitoreId),
      this.proposteService.getPropostaDetails(this.propostaId),
      this.proposteService.getAllClientiDetails(),
      this.proposteService.getDropdownData(this.filterKeys))
      .subscribe(async ([
        fornitoreDetails,
        subFornitore,
        servizioList,
        propostaDetails,
        allClientDetails,
        filters
      ]) => {
        this.setBreadCrumb(propostaDetails['numeroProposta'], fornitoreDetails['nomeSocieta']);
        this.servizioList = servizioList;
        this.allClientDetails = allClientDetails;
        this.propostaDetails = propostaDetails;
        // this.isProposalCompleted = (this.propostaDetails.statoProposta === 'Conclusa') ? true : false;
        this.isProposalCompleted = (this.propostaDetails.statoProposta !== 'In corso') ? true : false;
        this.livello = await this.getDropdownData(filters[this.filterKeys[0]]);
        this.sostituibilita = await this.getDropdownData(filters[this.filterKeys[1]]);
        this.areaNormativa = await this.getDropdownData(filters[this.filterKeys[2]]);
        this.livelloDiRischioDiNonConformita = await this.getDropdownData(filters[this.filterKeys[3]]);
        this.livelloDiAdeguatezzaStatoComunicazione = await this.getDropdownData(filters[this.filterKeys[4]]);
        this.statoComunicazioneAdV = await this.getDropdownData(filters[this.filterKeys[5]]);
        this.necessariaProceduraSindacale = await this.getDropdownData(filters[this.filterKeys[6]]);
        this.autoriaCompetente = await this.getDropdownData(filters[this.filterKeys[7]]);
        this.statoComunicazioneProceduraSindacale = await this.getDropdownData(filters[this.filterKeys[8]]);
        this.fornitoreDetails = fornitoreDetails;
        this.nomeSocieta = fornitoreDetails.nomeSocieta;
        this.isInfragruppo = (fornitoreDetails.infraGruppoExtraGruppo === 'Infragruppo') ? true : false;
        this.subFornitore = subFornitore;
        this.isInvioAdAdvMandatory = this.servizioList.every(servizio => servizio.funzioneImportante === 'Si');
        if (this.contrattoID) {
          this.getContrattoDetails(this.contrattoID);
        } else {
          setTimeout(async () => {
            this.detectFormChanges();
          }, 2000);
        }
      });
  }

  private setBreadCrumb(numeroProposta, nomeSocieta) {
    let contrattoURL;
    if (this.contrattoID) {
      contrattoURL = `/proposte/nuovo-contratto/${this.propostaId}/${this.propostaFornitoreId}/${this.contrattoID}/${this.fornitoreID}`;
    } else {
      contrattoURL = `/proposte/nuovo-contratto/${this.propostaId}/${this.propostaFornitoreId}/${this.fornitoreID}`;
    }
    this.breadcrumbs = [
      {
        label: `Proposta ${numeroProposta}`,
        url: `/proposte/nuovo-proposta/${this.propostaId}`
      },
      {
        label: `Servizi del fornitore ${nomeSocieta}`,
        url: `/proposte/dettaglio-proposte/${this.propostaId}/${this.propostaFornitoreId}/${this.fornitoreID}`
      },
      {
        label: 'Nuovo Contratto',
        url: contrattoURL
      }
    ];
  }

  private setContrattoForm() {
    this.contrattoForm = new FormGroup({
      contrattoId: new FormControl(null),
      commonContrattoId: new FormControl(null),
      codiceContrattoPadre: new FormControl(null),
      propostaFornitoreId: new FormControl(this.propostaFornitoreId),
      oggettoDelContratto: new FormControl('', [Validators.required]),
      terminiPreavvisoFornitore: new FormControl(''),
      terminiPreavvisoCliente: new FormControl(''),
      costoAttivita: new FormControl(''),
      fornitoriAlternativi: new FormControl('', [Validators.required]),
      numeroSubfornitori: new FormControl(0, [Validators.required]),
      subFornitore: new FormControl([]),
      societaGruppoCliente: new FormControl('', [Validators.required]),
      parereSuiContrattiRischiList: new FormArray([
        new FormGroup({
          parereSuiContrattiRischiId: new FormControl(null),
          contrattoId: new FormControl(null),
          dataParere: new FormControl(null, [Validators.required]),
          livelloDiRischiosita: new FormControl('', [Validators.required]),
          statoCompletoRischi: new FormControl('complete'),
          nparereRischio: new FormControl('', [Validators.minLength(5), Validators.maxLength(8)]),
          // nparereRischio: new FormControl('', Validators.pattern('[0-9]{4}_[0-9]{3}')),
          // nparereRischio: new FormControl(''),
        })
      ]),
      pareresuiContrattiComplianceList: new FormArray([
        new FormGroup({
          parereSuiContrattiComplianceId: new FormControl(null),
          contrattoId: new FormControl(null),
          dataParere: new FormControl(null, [Validators.required]),
          areaNormativa: new FormControl('', [Validators.required]),
          livelloRischioNonConformita: new FormControl('', [Validators.required]),
          livelloDiAdeguatezza: new FormControl('', [Validators.required]),
          statoCompletoCompliance: new FormControl('complete'),
          // nparere: new FormControl('', [Validators.required,  Validators.pattern('[0-9]{4}_[0-9]{3}')])
          nparere: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(8)])
        })
      ]),
      societaClienteDatApprovazione: new FormControl(null),
      societaClienteApprovatoreFinale: new FormControl(''),
      fornitoreInfragruppoDataDi: new FormControl(null),
      fornitoreInfragruppoFinale: new FormControl(''),
      autoritaCompetente: new FormControl(''),
      statoComunicazioneAdv: new FormControl(''),
      dataInvioComunicazioneAdv: new FormControl(null),
      statoCompletoAdv: new FormControl('complete'), // Invio Ad ADV
      statoCompletoProcedura: new FormControl('complete'), // Procedura Sindacale
      statoCompletoCDA: new FormControl('complete'), // APPROVAZINOE ORGANO DI SUPERVISIONE STRATEGICA
      necessariaProceduraSindacale: new FormControl('', [Validators.required]),
      statoComunicazione: new FormControl(''),
      dataInvioComunicazione: new FormControl(null),
      periodoAttesaEsito: new FormControl(0),
      scadenzaRiscontro: new FormControl(null),
      servizioList: new FormControl([]),
      completoOrInCompleto: new FormControl(false),
    });
  }

  @HostListener('window:beforeunload')
  canDeactivate(): boolean {
    return this.isSavedForm;
  }

  getSocietaValue(value) {
    this.societaGruppoCliente = value.nomeSocieta;
  }

  async ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasPropostaReadOnly = operationModel ? operationModel.hasPropostaReadOnly : '';

    await this.setContrattoForm();
    this.route.params.subscribe(async params => {
      this.registroId = await params['registroId'];
      // this.registroId = await params['registroId'];
      this.propostaId = await params['propostaId'];
      this.propostaFornitoreId = await params['propostaFornitoreId'];
      this.fornitoreID = await params['fornitoreID'];
      this.contrattoID = await params['contrattoID'];
      this.contrattoForm.get('propostaFornitoreId').setValue(this.propostaFornitoreId);
      await this.getDropdownTableKeys();
      // this.detectFormChanges();
    });
  }

  async resetForm() {
    if (this.contratto) {
      const servizioIds = this.contrattoForm.get('servizioList').value;
      this.contrattoForm.reset();
      // this.linkedServizioList = this.linkedServizioList.map(linkedService => {
      //   return this.servizioList.filter(service => service.servizioId === linkedService.servizioId)[0];
      // });
      // const servizioIds = this.linkedServizioList.map(servizio => servizio.servizioId);
      this.contratto['servizioList'] = servizioIds;
      this.contrattoForm.patchValue(this.contratto);
      this.contrattoForm.updateValueAndValidity();
    } else {
      Object.keys(this.contrattoForm['controls']).map(control => {
        // tslint:disable-next-line: max-line-length
        if (control !== 'parereSuiContrattiRischiList' && control !== 'pareresuiContrattiComplianceList' && control !== 'propostaFornitoreId' && control !== 'servizioList') {
          this.contrattoForm.get(control).setValue('');
        }
        if (control !== 'parereSuiContrattiRischiList') {
          this.contrattoForm.get('parereSuiContrattiRischiList')['controls'].map(group => {
            Object.keys(group['controls']).map(formControl => {
              group.get(formControl).setValue('');
            });
          });
        }
        if (control !== 'pareresuiContrattiComplianceList') {
          this.contrattoForm.get('pareresuiContrattiComplianceList')['controls'].map(group => {
            Object.keys(group['controls']).map(formControl => {
              group.get(formControl).setValue('');
            });
          });
        }
      });
    }
  }

  saveContratto() {
    const parereSuiContrattiRischiList = this.contrattoForm.value['parereSuiContrattiRischiList'].map(rischi => {
      return {
        ...rischi,
        dataParere: rischi.dataParere ? this.proposteService.getUTCDate(rischi.dataParere) : rischi.dataParere
      };
    });
    const pareresuiContrattiComplianceList = this.contrattoForm.value['pareresuiContrattiComplianceList'].map(compliance => {
      return {
        ...compliance,
        dataParere: compliance.dataParere ? this.proposteService.getUTCDate(compliance.dataParere) : compliance.dataParere
      };
    });
    this.contrattoForm.value['parereSuiContrattiRischiList'] = parereSuiContrattiRischiList;
    this.contrattoForm.value['pareresuiContrattiComplianceList'] = pareresuiContrattiComplianceList;
    const contratto = {
      ...this.contrattoForm.value,
      completoOrInCompleto: this.contrattoForm.valid,
      societaGruppoCliente: this.contrattoForm.value['societaGruppoCliente'][0].nomeSocieta,
      societaClientiId: this.contrattoForm.value['societaGruppoCliente'][0].clientiId,
      fornitoreInfragruppoDataDi: this.contrattoForm.value['fornitoreInfragruppoDataDi']
      ? this.proposteService.getUTCDate(this.contrattoForm.value['fornitoreInfragruppoDataDi'])
      : this.contrattoForm.value['fornitoreInfragruppoDataDi'],
      societaClienteDatApprovazione: this.contrattoForm.value['societaClienteDatApprovazione']
        ? this.proposteService.getUTCDate(this.contrattoForm.value['societaClienteDatApprovazione'])
        : this.contrattoForm.value['societaClienteDatApprovazione'],
      dataInvioComunicazioneAdv: this.contrattoForm.value['dataInvioComunicazioneAdv']
        ? this.proposteService.getUTCDate(this.contrattoForm.value['dataInvioComunicazioneAdv'])
        : this.contrattoForm.value['dataInvioComunicazioneAdv'],
      dataInvioComunicazione: this.contrattoForm.value['dataInvioComunicazione']
        ? this.proposteService.getUTCDate(this.contrattoForm.value['dataInvioComunicazione'])
        : this.contrattoForm.value['dataInvioComunicazione'],
      scadenzaRiscontro: this.contrattoForm.getRawValue().scadenzaRiscontro
      ? this.proposteService.getUTCDate(this.proposteService.getDateObject(this.contrattoForm.getRawValue().scadenzaRiscontro))
      : this.contrattoForm.getRawValue().scadenzaRiscontro
    };
    this.saveOrUpdateContratto(contratto).subscribe(contrattoSuccess => {
      this.contrattoID = contrattoSuccess['contrattoId'];
      this.contrattoForm.get('contrattoId').setValue(this.contrattoID);
      this.getContrattoDetails(this.contrattoID);
      this.isSavedForm = true;
    });
  }

  saveOrUpdateContratto(contratto) {
    return !this.contrattoID ?
      this.proposteService.saveContratto(contratto) :
      this.proposteService.updateContratto(contratto);
  }
}
