import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NuovoContrattoComponent } from './nuovo-contratto.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { of, Observable } from 'rxjs';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { HttpClientModule } from '@angular/common/http';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ProposteService } from '../../services/proposte.service';
import { LoginService } from 'src/app/shared/services/login.service';

describe('NuovoContrattoComponent', () => {
  let component: NuovoContrattoComponent;
  let fixture: ComponentFixture<NuovoContrattoComponent>;
  let router;
  let contrattoRequest;
  const route = { name: 'tips', params: of({ tipsId: '4' }) };
  let contrattoForm;
  let proposteService;
  let loginService;
  let operationModel;


  const translation: any = {
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translation);
    }
  }
  beforeEach(async(() => {
    loginService = jasmine.createSpyObj(['getOperationModel']);
    // tslint:disable-next-line: max-line-length
    proposteService = jasmine.createSpyObj(['getDropdownData', 'getAllClientiDetails', 'saveContratto', 'getFornitoredetailsWithFornitoreId', 'getFornitourDropdownDetails', 'getServizioList', 'getPropostaDetails']);
    TestBed.configureTestingModule({
      declarations: [ NuovoContrattoComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        FeDghubComponentLibraryModule,
        HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: ActivatedRoute, useValue: route },
        { provide: Router, useValue: router },
        { provide: ProposteService, useValue: proposteService },
        { provide: LoginService, useValue: loginService }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
     operationModel = {
      hasPropostaReadOnly: true,
    };
    loginService.getOperationModel.and.returnValue(of(operationModel));
    contrattoForm = new FormGroup({
      contrattoId: new FormControl(null),
      commonContrattoId: new FormControl(null),
      codiceContrattoPadre: new FormControl(null),
      propostaFornitoreId: new FormControl(),
      oggettoDelContratto: new FormControl('', [Validators.required]),
      terminiPreavvisoFornitore: new FormControl(''),
      terminiPreavvisoCliente: new FormControl(''),
      costoAttivita: new FormControl(''),
      fornitoriAlternativi: new FormControl('', [Validators.required]),
      numeroSubfornitori: new FormControl(0, [Validators.required]),
      subFornitore: new FormControl([]),
      societaGruppoCliente: new FormControl('', [Validators.required]),
      parereSuiContrattiRischiList: new FormArray([
        new FormGroup({
          parereSuiContrattiRischiId: new FormControl(null),
          contrattoId: new FormControl(null),
          dataParere: new FormControl(null, [Validators.required]),
          livelloDiRischiosita: new FormControl('', [Validators.required]),
          statoCompletoRischi: new FormControl('complete'),
          nparereRischio: new FormControl('', [Validators.minLength(5), Validators.maxLength(8)]),
        })
      ]),
      pareresuiContrattiComplianceList: new FormArray([
        new FormGroup({
          parereSuiContrattiComplianceId: new FormControl(null),
          contrattoId: new FormControl(null),
          dataParere: new FormControl(null, [Validators.required]),
          areaNormativa: new FormControl('', [Validators.required]),
          livelloRischioNonConformita: new FormControl('', [Validators.required]),
          livelloDiAdeguatezza: new FormControl('', [Validators.required]),
          statoCompletoCompliance: new FormControl('complete'),
          nparere: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(8)])
        })
      ]),
      societaClienteDatApprovazione: new FormControl(null),
      societaClienteApprovatoreFinale: new FormControl(''),
      fornitoreInfragruppoDataDi: new FormControl(null),
      fornitoreInfragruppoFinale: new FormControl(''),
      autoritaCompetente: new FormControl(''),
      statoComunicazioneAdv: new FormControl(''),
      dataInvioComunicazioneAdv: new FormControl(null),
      statoCompletoAdv: new FormControl('complete'), // Invio Ad ADV
      statoCompletoProcedura: new FormControl('complete'), // Procedura Sindacale
      statoCompletoCDA: new FormControl('complete'), // APPROVAZINOE ORGANO DI SUPERVISIONE STRATEGICA
      necessariaProceduraSindacale: new FormControl('', [Validators.required]),
      statoComunicazione: new FormControl(''),
      dataInvioComunicazione: new FormControl('23/12/2020'),
      periodoAttesaEsito: new FormControl(1),
      scadenzaRiscontro: new FormControl(null),
      servizioList: new FormControl([]),
      completoOrInCompleto: new FormControl(false),
    });
    // tslint:disable-next-line: max-line-length
    const dropDownResponse = {'Autorità Competente': [{'itemId': '1', 'tableId': 'Autorità Competente', 'itemName': 'BCE', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Autorità Competente', 'itemName': 'Banca d’Italia', 'subDomainList': null}, {'itemId': '3', 'tableId': 'Autorità Competente', 'itemName': 'Consob', 'subDomainList': null}], 'Stato comunicazione Procedura sindacale': [{'itemId': '1', 'tableId': 'Stato comunicazione Procedura sindacale', 'itemName': 'Da inviare', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Stato comunicazione Procedura sindacale', 'itemName': 'Inviata', 'subDomainList': null}, {'itemId': '3', 'tableId': 'Stato comunicazione Procedura sindacale', 'itemName': 'Esito positivo', 'subDomainList': null}, {'itemId': '4', 'tableId': 'Stato comunicazione Procedura sindacale', 'itemName': 'Esito negativo', 'subDomainList': null}], 'Livello di adeguatezza Stato comunicazione': [{'itemId': '1', 'tableId': 'Livello di adeguatezza Stato comunicazione', 'itemName': 'Adeguato', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Livello di adeguatezza Stato comunicazione', 'itemName': 'Prevalentemente adeguato', 'subDomainList': null}, {'itemId': '3', 'tableId': 'Livello di adeguatezza Stato comunicazione', 'itemName': 'Parzialmente adeguato', 'subDomainList': null}, {'itemId': '4', 'tableId': 'Livello di adeguatezza Stato comunicazione', 'itemName': 'Critico', 'subDomainList': null}], 'Necessaria procedura sindacale': [{'itemId': '1', 'tableId': 'Necessaria procedura sindacale', 'itemName': 'Si', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Necessaria procedura sindacale', 'itemName': 'No', 'subDomainList': null}], 'Livello di rischio di non conformità': [{'itemId': '1', 'tableId': 'Livello di rischio di non conformità', 'itemName': 'Basso', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Livello di rischio di non conformità', 'itemName': 'Medio Basso', 'subDomainList': null}, {'itemId': '3', 'tableId': 'Livello di rischio di non conformità', 'itemName': 'Medio Alto', 'subDomainList': null}, {'itemId': '4', 'tableId': 'Livello di rischio di non conformità', 'itemName': 'Alto', 'subDomainList': null}], 'Sostituibilita': [{'itemId': '1', 'tableId': 'Sostituibilita', 'itemName': 'Facile', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Sostituibilita', 'itemName': 'Difficile', 'subDomainList': null}, {'itemId': '3', 'tableId': 'Sostituibilita', 'itemName': 'Impossibile', 'subDomainList': null}], 'Stato Comunicazione AdV': [{'itemId': '1', 'tableId': 'Stato Comunicazione AdV', 'itemName': 'Da inviare', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Stato Comunicazione AdV', 'itemName': 'Inviata', 'subDomainList': null}], 'Area normativa': [{'itemId': '1', 'tableId': 'Area normativa', 'itemName': 'Esternalizzazioni', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Area normativa', 'itemName': 'Privacy', 'subDomainList': null}, {'itemId': '3', 'tableId': 'Area normativa', 'itemName': 'IT e Sistemi Informativi', 'subDomainList': null}, {'itemId': '4', 'tableId': 'Area normativa', 'itemName': 'Trattamento del contante', 'subDomainList': null}, {'itemId': '5', 'tableId': 'Area normativa', 'itemName': 'Trasparenza dei servizi bancari', 'subDomainList': null}, {'itemId': '6', 'tableId': 'Area normativa', 'itemName': 'Disciplina degli intermediari assicurativi', 'subDomainList': null}, {'itemId': '7', 'tableId': 'Area normativa', 'itemName': 'Continuità Operativa', 'subDomainList': null}, {'itemId': '8', 'tableId': 'Area normativa', 'itemName': 'Reclami / Arbitro Bancario Finanziario', 'subDomainList': null}], 'Livello di Rischiosità': [{'itemId': '1', 'tableId': 'Livello di Rischiosità', 'itemName': 'Rischio Basso', 'subDomainList': null}, {'itemId': '2', 'tableId': 'Livello di Rischiosità', 'itemName': 'Rischio Medio', 'subDomainList': null}, {'itemId': '3', 'tableId': 'Livello di Rischiosità', 'itemName': 'Rischio Alto', 'subDomainList': null}]};
    proposteService.getDropdownData.and.returnValue(of(dropDownResponse));
    // tslint:disable-next-line: max-line-length
    const fornitoreResponse = {'fornitoreId': 1, 'nomeSocieta': 'Capgemini Italia update', 'infraGruppoExtraGruppo': 'Infragruppo', 'codice': 212233412, 'ndg': 1938021, 'partitaIva': '121Par update123465', 'codiceFiscale': 125, 'atecoBankIt': 'ATECO_2007_BANKIT', 'indirizzoFornitore': 'Paese_di_registrazione_fornitor', 'paeseFornitore': 'LEI_Numero_registrazione_fornitore', 'numeroFornitore': 'abcd', 'capoGruppo': 'xysz', 'description': 'INDIA', 'nation': 'Europe', 'ccnl': 'CCNL', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'Si', 'grouppo': 'group new update', 'email': 'abc@gmail.com', 'dataInserimento': '14/12/2020', 'ncommerico': 'N_Iscrizione_camera_commercio'};
    proposteService.getFornitoredetailsWithFornitoreId.and.returnValue(of(fornitoreResponse));
    // tslint:disable-next-line: max-line-length
    const servizioResponse = [{'servizioId': 434, 'propostaFornitoreId': 367, 'marcoProcesso': '', 'racConDeiPro': '', 'servizioInfrastrttra': '', 'tipologiaDiCloud': '', 'possibilitaDiRei': '', 'sostituibilita': '', 'classificazioneOne': 'Fornitura', 'classificazioneTipo': 'Fornitura', 'datiPersonali': '', 'sogliaFunzione': null, 'funzioneEsternalizzata': '', 'funzioneImportante': '', 'ultimaValutazioneData': null, 'sintesideiMotivi': '', 'paeseDiVieneSvolto': '', 'paesediconDati': '', 'cloudpaesediCon': '', 'descrizioneDel': '', 'tipologiaDaDati': null, 'cloudNaturaDaDati': null, 'livelloDiRischiosita': '', 'breveRischiosita': '', 'completoStato': 'complete', 'categoriaBankIt': null, 'sottocategoriaBankIt': null, 'servizioName': 'wdwdw', 'categoriaEba': null}];
    proposteService.getServizioList.and.returnValue(of(servizioResponse));
    // tslint:disable-next-line: max-line-length
    const propostaResponse = {'proposalId': 301, 'numeroProposta': '2020_686', 'segnalante': 'Segnalante', 'societaDelSegnalante': 'SV Banca', 'oggDellaProposta': 'Oggetto ', 'statoProposta': 'In corso', 'sotoStatoProposta': 'Descrizione Esigenza', 'propostaName': 'Test', 'canDiSegnalazione': '', 'cambioFornitore': 'Si', 'dataDellaProposta': '04/12/2020', 'dataDelCensimento': '15/12/2020', 'praticaOwner': 'Gestione ', 'dataFineProposta': null, 'codCanSegnalazione': '', 'gestionePraticaBackup': '', 'completoOrInCompleto': false, 'uosegnalante': 'U.O.Segnalante'};
    proposteService.getPropostaDetails.and.returnValue(of(propostaResponse));
    // tslint:disable-next-line: max-line-length
    const clientResponse = [{'clientiId': 1, 'nomeSocieta': 'SV Banca', 'abi': 'CLIENT1', 'classeSocieta': 'banca', 'partitaIva': '1', 'codiceFiscale': '1'}, {'clientiId': 25, 'nomeSocieta': 'BPER Banca', 'abi': '5387', 'classeSocieta': 'Società Strumentale', 'partitaIva': 'Partita IVA bper!', 'codiceFiscale': '6666'}, ];
    proposteService.getAllClientiDetails.and.returnValue(of(clientResponse));
    // tslint:disable-next-line: max-line-length
    contrattoRequest = {'contrattoId': null, 'commonContrattoId': null, 'codiceContrattoPadre': null, 'propostaFornitoreId': '351', 'oggettoDelContratto': 'Oggetto ', 'terminiPreavvisoFornitore': '', 'terminiPreavvisoCliente': '', 'costoAttivita': '', 'fornitoriAlternativi': 'Fornitori ', 'numeroSubfornitori': 0, 'subFornitore': [], 'societaGruppoCliente': 'BPER Banca', 'parereSuiContrattiRischiList': [{'parereSuiContrattiRischiId': null, 'contrattoId': null, 'dataParere': null, 'livelloDiRischiosita': '', 'statoCompletoRischi': 'complete', 'nparereRischio': ''}], 'pareresuiContrattiComplianceList': [{'parereSuiContrattiComplianceId': null, 'contrattoId': null, 'dataParere': null, 'areaNormativa': '', 'livelloRischioNonConformita': '', 'livelloDiAdeguatezza': '', 'statoCompletoCompliance': 'complete', 'nparere': ''}], 'societaClienteDatApprovazione': null, 'societaClienteApprovatoreFinale': '', 'fornitoreInfragruppoDataDi': null, 'fornitoreInfragruppoFinale': '', 'autoritaCompetente': '', 'statoComunicazioneAdv': '', 'dataInvioComunicazioneAdv': null, 'statoCompletoAdv': 'complete', 'statoCompletoProcedura': 'complete', 'statoCompletoCDA': 'complete', 'necessariaProceduraSindacale': '', 'statoComunicazione': '', 'dataInvioComunicazione': null, 'periodoAttesaEsito': 0, 'scadenzaRiscontro': null, 'servizioList': [415], 'completoOrInCompleto': true, 'societaClientiId': 25};
    const input = {
      nomeSocieta: 'nomeSocieta'
    };
    fixture = TestBed.createComponent(NuovoContrattoComponent);
    component = fixture.componentInstance;
    component.contrattoForm = contrattoForm;
    component.allClientDetails = clientResponse;
    component.societaGruppoCliente = clientResponse;
    fixture.detectChanges();

  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });


  it('should call getSocietaValue', () => {
    const input = {
      nomeSocieta: 'nomeSocieta'
    };
    component.getSocietaValue(input);
    component.saveOrUpdateContratto(contrattoRequest);
    component.ngOnInit();
    expect(component.societaGruppoCliente).toBeDefined();
  });

  it('should call resetForm', () => {

    component.resetForm();
    expect(contrattoForm.get('servizioList').value).toBeDefined();
  });

});
