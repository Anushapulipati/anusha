import { Component, Injector, OnDestroy, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { TreeviewItem, TreeviewConfig, TreeviewI18n } from 'ngx-treeview';
import { ProposteService } from '../../services/proposte.service';
import { concatMap, distinctUntilChanged, pairwise, switchMap } from 'rxjs/operators';
import { DropdownTreeviewI18nService } from 'src/app/shared/services/dropdown-treeview-i18n.service';
import { BasePage } from 'src/app/shared/base-page/base-page';
import { EsportaModel } from 'src/app/shared/models/esportaModel';
import { UrlProviderService } from 'src/app/shared/services/url-provider.service';
import { LoginService } from '../../../../shared/services/login.service';
import { DialogService } from 'fe-dghub-component-library';
import { ResponseCommonPopUpComponent } from 'src/app/modules/anagrafiche/pages/download-popup/response-common-pop-up.component';
import { SearchInputService } from 'src/app/shared/services/search-input.service';

@Component({
  selector: 'reg-proposte-page',
  templateUrl: './proposte-page.component.html',
  styleUrls: ['./proposte-page.component.scss'],
  providers: [
    DropdownTreeviewI18nService,
    { provide: TreeviewI18n, useClass: DropdownTreeviewI18nService }
  ]
})
export class PropostePageComponent extends BasePage implements OnInit, OnDestroy {
  categoriaInterne: TreeviewItem[];
  categorieBankIT: TreeviewItem[];
  collectionSize: number;
  dialogRef: any;
  esportaModel: EsportaModel;
  filterForm = new FormGroup({
    statoProposta: new FormControl([]),
    categoriaInterna: new FormControl([]),
    categoriaBankIt: new FormControl([]),
    ordinaPer: new FormControl([]),
  });
  filterKeys = ['Categorie BankIT', 'Stato Proposta', 'Categorie EBA', 'Ordina per'];
  filters: any;
  hasNewPropostaAccess: boolean;
  idOfExcel: number[] = [];
  isFilterApplied = false;
  isSearchedResult = false;
  items: TreeviewItem[];
  ordinaPer: TreeviewItem[];
  page = 1;
  pageSize = 20;
  proposalsList: any;
  searchData: any;
  selectedOrdinaPerFilters = [];
  statoProposta: any;
  subscription: any;
  url: any;
  value = 11;
  constructor(
    injector: Injector,
    private proposteService: ProposteService,
    private urlProviderService: UrlProviderService,
    private loginService: LoginService,
    private dialog: DialogService,
    private searchInputService: SearchInputService
  ) {
    super(injector);
  }

  private checkSearchInput() {
    this.subscription = this.searchInputService.getSearchInput().subscribe((searchInput: any) => {
      if (searchInput && searchInput.inputValue !== '' && searchInput.inputValue !== undefined) {
        this.isSearchedResult = true;
        this.page = 1;
        this.searchData = {
          name : searchInput.page,
          value : searchInput.inputValue,
          startIndex : this.page
        };
        this.getSearchData(this.searchData);
      } else {
        this.isSearchedResult = false;
        this.getDropdownTableKeys();
      }
    });
  }

  // private esportaFiltri() {
  //   const proposalFilters = this.filterForm.value;
  //   proposalFilters['startIndex'] = this.page;
  //   this.proposteService.exportToFilterRegistroExcel(proposalFilters).subscribe(async response => {
  //     console.log('exportToFilterRegistroExcel response====>>>', response);
  //   });
  // }

  private getDropdownTableKeys() {
    this.proposteService.getDropdownData(this.filterKeys).subscribe(async filters => {
      this.filters = filters;
      this.categorieBankIT = await this.getFilterdData(filters[this.filterKeys[0]]);
      this.statoProposta = await this.getFilterdData(filters[this.filterKeys[1]]);
      this.categoriaInterne = await this.getFilterdData(filters[this.filterKeys[2]]);
      this.ordinaPer = await this.getFilterdData(filters[this.filterKeys[3]]);
      this.onPageChange(this.page);
    });
  }

  private getProposals(proposals) {
    const fornitoreOrderVar = this.selectedOrdinaPerFilters.filter(fil => (fil === 'Fornitore A-Z' || fil === 'Fornitore Z-A'));
    const latestOrderVar =
      this.selectedOrdinaPerFilters.filter(fil => (fil === 'Numero Proposta (decrescente)' || fil === 'Numero Proposta (crescente)'));
    const societaClienteOrderVar =
      this.selectedOrdinaPerFilters.filter(fil => (fil === 'Società del Gruppo Cliente Z-A' || fil === 'Società del Gruppo Cliente A-Z'));
    // 'categoriaBankIt': proposals['categoriaBankIt'] ? proposals['categoriaBankIt'].join('@') : '',
    // 'categoriaInterna': proposals['categoriaInterna'] ? proposals['categoriaInterna'].join('@') : '',
    const proposteFilters = {
      'statoProposta': proposals['statoProposta'] ? proposals['statoProposta'].join('@') : '',
      'categoriaBankIt': '',
      'categoriaInterna': '',
      'fornitoreOrderVar': fornitoreOrderVar[0] ? fornitoreOrderVar[0] : '',
      'latestOrderVar': latestOrderVar[0] ? latestOrderVar[0] : '',
      'societaClienteOrderVar': societaClienteOrderVar[0] ? societaClienteOrderVar[0] : '',
      'startIndex': this.page
    };
    this.proposteService.getProposals(proposteFilters).subscribe(proposalsList => {
      this.collectionSize = proposalsList.count;
      this.proposalsList = proposalsList.supplier ? proposalsList.supplier : [];
    });
  }
  private getEsportaProposals(proposals) {
    const fornitoreOrderVar = this.selectedOrdinaPerFilters.filter(fil => (fil === 'Fornitore A-Z' || fil === 'Fornitore Z-A'));
    const latestOrderVar =
      this.selectedOrdinaPerFilters.filter(fil => (fil === 'Numero Proposta (decrescente)' || fil === 'Numero Proposta (crescente)'));
    const societaClienteOrderVar =
      this.selectedOrdinaPerFilters.filter(fil => (fil === 'Società del Gruppo Cliente Z-A' || fil === 'Società del Gruppo Cliente A-Z'));
    // 'categoriaBankIt': proposals['categoriaBankIt'] ? proposals['categoriaBankIt'].join('@') : '',
    // 'categoriaInterna': proposals['categoriaInterna'] ? proposals['categoriaInterna'].join('@') : '',
    const proposteFilters = {
      'statoProposta': proposals['statoProposta'] ? proposals['statoProposta'].join('@') : '',
      'categoriaBankIt': '',
      'categoriaInterna': '',
      'fornitoreOrderVar': fornitoreOrderVar[0] ? fornitoreOrderVar[0] : '',
      'latestOrderVar': latestOrderVar[0] ? latestOrderVar[0] : '',
      'societaClienteOrderVar': societaClienteOrderVar[0] ? societaClienteOrderVar[0] : ''
    };
    this.proposteService.exportToFilterPropostaExcel(this.esportaModel).subscribe(data => {
      this.showDownloadPopUp();
      this.idOfExcel.push(data.id);
      this.verifyStatus(data.id);
    });
  }

  private getSearchData(searchData) {
    this.searchInputService.getSearchResults(searchData).subscribe(searchResult => {
      this.collectionSize = searchResult['count'];
      this.proposalsList = searchResult['suppliers'];
      this.isSearchedResult = true;
    });
  }

  applyEsportaFilter() {
    const proposals = this.filterForm.value;
    this.getEsportaProposals(proposals);
  }

  applyFilter() {
    this.page = 1;
    this.isSearchedResult = false;
    this.isFilterApplied = true;
    const proposals = this.filterForm.value;
    this.getProposals(proposals);
  }
 
  downloadFile(data: any, fileName: any) {
    console.log('inside download');
    const element = document.createElement('a');
    window.open(this.urlProviderService.downloadProposta + '?id=' + data);
    this.dialogRef.close();
  }

  esportaCompleto() {
    this.showDownloadPopUp();
    this.proposteService.exportToPropostaExcel(this.esportaModel).subscribe(data => {
      this.idOfExcel.push(data.id);
      this.verifyStatus(data.id);
      // localStorage.setItem("idsToExport", this.idOfExcel);
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  async ngOnInit() {
    this.searchInputService.setSelectedOption('proposta');
    // this.searchInputService.setSearchInput(false);
    this.selectedOrdinaPerFilters = ['Numero Proposta (decrescente)'];
    const operationModel: any = this.loginService.getOperationModel();
    this.hasNewPropostaAccess = operationModel ? operationModel.hasNewPropostaAccess : '';
    this.checkSearchInput();
    this.getDropdownTableKeys();
  }

  onPageChange(event) {
    this.page = event;
    let proposals;
    if (this.isFilterApplied) {
      proposals = this.filterForm.value;
    } else {
      const categoriaBankIt = this.categorieBankIT.map(category => {
        let childrens = [];
        if (category.children) {
          childrens = category.children.map(c => c.value);
        }
        return [category.value, ...childrens];
      });
      const merged = [].concat.apply([], categoriaBankIt);
      proposals = {
        statoProposta: [
          'In corso',
          'Descrizione Esigenza',
          'Valutazione Fornitura / Esternalizzazione',
          'Classificazione FEI / NON FEI',
          'Esito Proposta',
          'Esito CDA',
          'Esito istanza AdV / Sindacale'
        ],
        categoriaInterna: this.categoriaInterne.map(category => category.value),
        categoriaBankIt: merged,
        ordinaPer: []
      };
    }
    if (this.isSearchedResult) {
      this.searchData['startIndex'] = this.page;
      this.getSearchData(this.searchData);
    } else {
      this.getProposals(proposals);
    }
  }

  onValueChange(value) {
    this.selectedOrdinaPerFilters = [value];
    // const filteredValue = this.selectedOrdinaPerFilters.filter(fil => (fil === 'Fornitore A-Z' || fil === 'Fornitore Z-A'));
  }

  // selectedValue(selectedValue) {
  //   if (selectedValue === 'filtri') {
  //     this.esportaFiltri();
  //   } else {
  //     this.esportaCompleto();
  //   }
  // }

  verifyStatus(id: any) {
    console.log("inside verify");
    this.proposteService.checkExcelStatus(id).subscribe(result => {
      if (result.status === 'Completed') {
        this.downloadFile(result.id, result.glossariType);
      } else {
        // tslint:disable-next-line:no-non-null-assertion
        if (result.status! = 'Failed') {
          setTimeout(() => {
            this.verifyStatus(result.id);
          }, 10000);
        }
      }
    });
  }
    showDownloadPopUp() {
      const message = {
        title: 'message',
        body: '',
        details: '',
        stackTrace: ''
      };
      message.details = 'downloading..';
      this.dialogRef = this.dialog.open(ResponseCommonPopUpComponent, {
        size: 'small',
        noCloseButton: true,
        data: { message }
      });
      this.dialogRef.afterClosed.subscribe(result => {
        if (result) {
        }
      });
    }
}
