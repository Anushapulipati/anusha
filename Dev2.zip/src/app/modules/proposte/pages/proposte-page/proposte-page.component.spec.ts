import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { PropostePageComponent } from './proposte-page.component';
import { TreeviewItem, TreeviewConfig } from 'ngx-treeview';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { HttpClientModule } from '@angular/common/http';
import { MultiselectDropdownComponent } from 'src/app/shared/components/multiselect-dropdown/multiselect-dropdown.component';
import { Router } from '@angular/router';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ProposteService } from '../../services/proposte.service';
import { of, Observable } from 'rxjs';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('PropostePageComponent', () => {
  let component: PropostePageComponent;
  let fixture: ComponentFixture<PropostePageComponent>;
  let treeViewItem: TreeviewItem;
  let treeViewConfig: TreeviewConfig;
  let router: Router;
  let filterKeys: any;
  let proposteService;
  let tableKeys;
  let filterForm;
  let mockResponse;

  beforeEach(async(() => {
    proposteService = jasmine.createSpyObj(['getDropdownKeys', 'getDropdownData', 'getProposals']);
    TestBed.configureTestingModule({
      declarations: [PropostePageComponent, MultiselectDropdownComponent],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        FeDghubComponentLibraryModule,
        HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TreeviewItem, useValue: treeViewItem },
        { provide: TreeviewConfig, useValue: treeViewConfig },
        { provide: Router, useValue: router },
        { provide: ProposteService, useValue: proposteService }
      ]
    })
      .compileComponents();
  }));
  beforeEach(() => {
      filterKeys = ['Categorie BankIT', 'Stato Proposta', 'Categorie EBA', 'Ordina per'];
      tableKeys = [
      'Categorie BankIT',
      'Stato Proposta',
      'Categorie EBA',
      'Canale di segnalazione',
      'Sottostato Proposta',
      'Società del Segnalante'
    ],
      filterForm = {
        statoProposta: 'statoProposta',
        categorieInterne: 'categorieInterne',
        categorieBankIT: 'categorieBankIT',
        ordinaPer: 'ordinaPer'
      };
      mockResponse = {
        'Categorie BankIT': [
          {
            'orderId': '1',
            'tableId': 'Categorie BankIT',
            'itemName': 'Credito / cartolarizzazioni',
            'subDomainList': [
              {
                'orderId': '2',
                'tableId': 'Categorie BankIT',
                'itemName': 'Fasi o specifiche attività del processo di monitoraggio',
                'subDomainList': null
              },
              {
                'orderId': '3',
                'tableId': 'Categorie BankIT',
                'itemName': 'Fasi o specifiche attività del processo di valutazione',
                'subDomainList': null
              },
              {
                'orderId': '6',
                'tableId': 'Categorie BankIT',
                'itemName': 'Altro (non presente nelle subcategorie) o dettagli (relativi alla subcategoria scelta)',
                'subDomainList': null
              }
            ]
          }
        ],
        'Stato Proposta': [
          {
            'orderId': '1',
            'tableId': 'Stato Proposta',
            'itemName': 'In corso',
            'subDomainList': [
              {
                'orderId': '1',
                'tableId': 'Stato Proposta',
                'itemName': 'Descrizione Esigenza',
                'subDomainList': null
              },
              {
                'orderId': '2',
                'tableId': 'Stato Proposta',
                'itemName': 'Valutazione Fornitura / Esternalizzazione',
                'subDomainList': null
              },
              {
                'orderId': '3',
                'tableId': 'Stato Proposta',
                'itemName': 'Classificazione FEI / NON FEI',
                'subDomainList': null
              },
              {
                'orderId': '4',
                'tableId': 'Stato Proposta',
                'itemName': 'Esito Proposta',
                'subDomainList': null
              },
              {
                'orderId': '5',
                'tableId': 'Stato Proposta',
                'itemName': 'Esito CDA',
                'subDomainList': null
              },
              {
                'orderId': '6',
                'tableId': 'Stato Proposta',
                'itemName': 'Esito istanza AdV / Sindacale',
                'subDomainList': null
              }
            ]
          },
          {
            'orderId': '2',
            'tableId': 'Stato Proposta',
            'itemName': 'conclusa',
            'subDomainList': null
          },
          {
            'orderId': '3',
            'tableId': 'Stato Proposta',
            'itemName': 'annullata',
            'subDomainList': null
          },
          {
            'orderId': '4',
            'tableId': 'Stato Proposta',
            'itemName': 'sospesa',
            'subDomainList': null
          }
        ],
        'Categorie EBA': [
          {
            'orderId': '3',
            'tableId': 'Categorie EBA',
            'itemName': 'Acquisizione di servizi di pubblica utilità (e.g. forniture di elettricità, gas, acqua, telefonia)',
            'subDomainList': null
          },
          {
            'orderId': '8',
            'tableId': 'Categorie EBA',
            'itemName': 'Funzione che a norma di legge deve essere svolta da un fornitore di servizi (e.g. la revisione legale dei conti)',
            'subDomainList': null
          },
         {
            'orderId': '11',
            'tableId': 'Categorie EBA',
            'itemName': 'Infrastruttura di rete globale (e.g. Visa, MasterCard)',
            'subDomainList': null
          },
          {
            'orderId': '12',
            'tableId': 'Categorie EBA',
            'itemName': 'Infrastruttura globale di messaggistica finanziaria soggetta alla vigilanza delle pertinenti autorità',
            'subDomainList': null
          },
          {
            'orderId': '15',
            'tableId': 'Categorie EBA',
            'itemName': 'Manutenzione delle aree verdi',
            'subDomainList': null
          },
          {
            'orderId': '16',
            'tableId': 'Categorie EBA',
            'itemName': 'Manutenzione di automobili aziendali',
            'subDomainList': null
          },
          {
            'orderId': '17',
            'tableId': 'Categorie EBA',
            'itemName': 'Manutenzione di componenti standard di hardware nellambito di soluzioni di mercato',
            'subDomainList': null
          },
          {
            'orderId': '19',
            'tableId': 'Categorie EBA',
            'itemName': 'Servizi amministrativi (e.g. servizi di economato)',
            'subDomainList': null
          },
          {
            'orderId': '20',
            'tableId': 'Categorie EBA',
            'itemName': 'Servizi bancari di corrispondenza',
            'subDomainList': null
          },
          {
            'orderId': '21',
            'tableId': 'Categorie EBA',
            'itemName': 'Servizi di business travel (e.g. prenotazione hotel)',
            'subDomainList': null
          },
          {
            'orderId': '22',
            'tableId': 'Categorie EBA',
            'itemName': 'Servizi di distribuzione automatica',
            'subDomainList': null
          },
          {
            'orderId': '24',
            'tableId': 'Categorie EBA',
            'itemName': 'Servizi di portierato, receptionist, segreteria e centralino',
            'subDomainList': null
          },
          {
            'orderId': '25',
            'tableId': 'Categorie EBA',
            'itemName': 'Servizi di ristorazione (e.g. erogazione pasti, catering, fornitura buoni pasto)',
            'subDomainList': null
          },
          {
            'orderId': '26',
            'tableId': 'Categorie EBA',
            'itemName': 'Servizi di vigilanza e sorveglianza armata',
            'subDomainList': null
          },
          {
            'orderId': '27',
            'tableId': 'Categorie EBA',
            'itemName': 'Servizi medici',
            'subDomainList': null
          },
          {
            'orderId': '28',
            'tableId': 'Categorie EBA',
            'itemName': 'Servizi postali',
            'subDomainList': null
          },
          {
            'orderId': '30',
            'tableId': 'Categorie EBA',
            'itemName': 'Recupero crediti',
            'subDomainList': null
          },
          {
            'orderId': '31',
            'tableId': 'Categorie EBA',
            'itemName': 'Segnalazioni di Vigilanza',
            'subDomainList': null
          },
          {
            'orderId': '32',
            'tableId': 'Categorie EBA',
            'itemName': 'Servizi e attività di investimento',
            'subDomainList': null
          },
          {
            'orderId': '33',
            'tableId': 'Categorie EBA',
            'itemName': 'Servizio/attività di back office',
            'subDomainList': null
          },
          {
            'orderId': '34',
            'tableId': 'Categorie EBA',
            'itemName': 'Servizio archiviazione digitale o cartacea',
            'subDomainList': null
          },
          {
            'orderId': '35',
            'tableId': 'Categorie EBA',
            'itemName': 'Sistema informativo o sue componenti critiche',
            'subDomainList': null
          },
          {
            'orderId': '36',
            'tableId': 'Categorie EBA',
            'itemName': 'Trasporto valori',
            'subDomainList': null
          },
          {
            'orderId': '37',
            'tableId': 'Categorie EBA',
            'itemName': 'Trattamento del contante',
            'subDomainList': null
          }
        ],
        'Ordina per': [
          {
            'orderId': '1',
            'tableId': 'Ordina per',
            'itemName': 'Fornitore A-Z',
            'subDomainList': null
          },
          {
            'orderId': '2',
            'tableId': 'Ordina per',
            'itemName': 'Fornitore Z-A',
            'subDomainList': null
          },
          {
            'orderId': '3',
            'tableId': 'Ordina per',
            'itemName': 'Società del Gruppo Cliente A-Z',
            'subDomainList': null
          },
          {
            'orderId': '4',
            'tableId': 'Ordina per',
            'itemName': 'Società del Gruppo Cliente Z-A',
            'subDomainList': null
          },
          {
            'orderId': '5',
            'tableId': 'Ordina per',
            'itemName': 'Numero Proposta (crescente)',
            'subDomainList': null
          },
          {
            'orderId': '6',
            'tableId': 'Ordina per',
            'itemName': 'Numero Proposta (decrescente)',
            'subDomainList': null
          }
        ]
      };


  });


  beforeEach(() => {
    proposteService.getDropdownKeys.and.returnValue(of(filterKeys));
    proposteService.getDropdownData.and.returnValue(of(mockResponse));
    proposteService.getProposals.and.returnValue(of(mockResponse));
    fixture = TestBed.createComponent(PropostePageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show label names', () => {
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('label').textContent).toContain('label.proposte.statoProposta');
  });

  it('should check filter keys', () => {
    fixture.detectChanges();
    expect(component.filterKeys).toEqual(filterKeys);
  });

it('should call applyFilter and return the said result', () => {
    const mockResponse1 = [
        {
          'numeroProposta': '2020_047',
          'fornitoreId': 1,
          'nomeSocieta': 'Capgemini Italia',
          'oggDellaProposta': 'bu',
          'dataDellaProposta': 1603045800000,
          'statoProposta': 'nbh',
          'id': 46
        },
        {
          'numeroProposta': '2020_047',
          'fornitoreId': 2,
          'nomeSocieta': 'Capgemini Italia',
          'oggDellaProposta': 'bu',
          'dataDellaProposta': 1603045800000,
          'statoProposta': 'nbh',
          'id': 46
        }
      ];
    const mockParameter = {};
    proposteService.getProposals.and.returnValue(of(mockResponse1));
    component.applyFilter();
    fixture.detectChanges();
    expect(proposteService.getProposals).toHaveBeenCalled();
    proposteService.getProposals(filterForm).subscribe(result => {
      expect(result).toBe(mockResponse1);
    });
  });
});
