/* import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NuovoContrattoAccordionComponent } from './nuovo-contratto-accordion.component';

describe('NuovoContrattoAccordionComponent', () => {
  let component: NuovoContrattoAccordionComponent;
  let fixture: ComponentFixture<NuovoContrattoAccordionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NuovoContrattoAccordionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NuovoContrattoAccordionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
 */