import { SelectView } from 'src/app/shared/models/selectView';
import { FormArray, FormGroup, FormControl } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from 'src/app/shared/services/dateFormat';
import { ProposteService } from '../../services/proposte.service';
import { concatMap } from 'rxjs/operators';

const commonDropdown = [
  {
    value: 'Si',
    description: 'Si'
  },
  {
    value: 'No',
    description: 'No',
  }
];

@Component({
  selector: 'reg-nuovo-contratto-accordion',
  templateUrl: './nuovo-contratto-accordion.component.html',
  styleUrls: ['./nuovo-contratto-accordion.component.scss'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})
export class NuovoContrattoAccordionComponent implements OnInit {

  contrattoAccordionForm = new FormGroup({
    parere: new FormControl('2020_120')
  });

  contrattoForm = new FormArray([]);
  datainviocomunicazione: SelectView[];
  datainviocomunicazioneValidation: boolean;
  date: Date = new Date();
  datIdelparereValidation: boolean;
  dropdownSiNo = commonDropdown;
  filterKeys = ['Livello di Rischiosità', 'Sostituibilita'];
  livello: SelectView[];
  opened = false;
  periododiattesa: SelectView[];
  statocomunicazione: SelectView[];

  constructor(
    private proposteService: ProposteService
  ) { }

  private getDropdownData(filters) {
    const items: SelectView[] = [];
    filters.map((filter, index) => {
      const item = new SelectView(filter.itemName, filter.itemName);
      items.push({
        description: filter.itemName,
        value: filter.itemName
      });
    });
    return items;
  }

  private getDropdownTableKeys() {
    this.proposteService.getDropdownKeys().pipe(
      concatMap(tableKeys => {
        return this.proposteService.getDropdownData(this.filterKeys);
      })).subscribe(async filters => {
        this.livello = await this.getDropdownData(filters[this.filterKeys[0]]);
      });
  }

  changeCallBack(date) {
  }

  ngOnInit() {
    this.getDropdownTableKeys();
  }
}
