import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { NuovoPropostaComponent } from './nuovo-proposta.component';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl, Validators } from '@angular/forms';
import { FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { HttpClientModule } from '@angular/common/http';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { By } from '@angular/platform-browser';
import { ProposteService } from '../../services/proposte.service';
import { of, Observable } from 'rxjs';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe } from '@angular/common';
import { AppModule } from 'src/app/app.module';

describe('NuovoPropostaComponent', () => {
  let component: NuovoPropostaComponent;
  let fixture: ComponentFixture<NuovoPropostaComponent>;
  const route = { name: 'tips', params: of({ tipsId: '4' }) };
  const router = {
    navigate: jasmine.createSpy('navigate'),
    myMethod: () => {}
  };
  let proposteService;
  let nuovoPropostaForm;

  const translation: any = {
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translation);
    }
  }

  beforeEach(async(() => {
    proposteService = jasmine.createSpyObj(['getSupplierDetails', 'getFornitourDropdownDetails', 'getDropdownKeys',
      'getDropdownData', 'updateSupplierDetails', 'getAllClientiDetails']);
    TestBed.configureTestingModule({
      declarations: [NuovoPropostaComponent],
      imports: [
        AppModule,
        NgbModule,
        FormsModule,
        ReactiveFormsModule,
        FeDghubComponentLibraryModule,
        HttpClientModule,

        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        DatePipe,
        { provide: ActivatedRoute, useValue: route },
        { provide: Router, useValue: router },
        { provide: ProposteService, useValue: proposteService }
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    nuovoPropostaForm = new FormGroup({
      dataDellaProposta: new FormControl(null),
      uosegnalante: new FormControl(''),
      cambioFornitore: new FormControl(''),
      fornitore: new FormControl('', [Validators.required]),
      canDiSegnalazione: new FormControl(''),
      codCanSegnalazione: new FormControl(''),
      statoProposta: new FormControl('In corso', Validators.required),
      dataFineProposta: new FormControl(''),
      segnalante: new FormControl('', Validators.required),
      societaDelSegnalante: new FormControl('', Validators.required),
      oggDellaProposta: new FormControl('', Validators.required),
      praticaOwner: new FormControl(''),
      gestionePraticaBackup: new FormControl(''),
      sotoStatoProposta: new FormControl('Descrizione Esigenza', Validators.required),
      completoOrInCompleto: new FormControl(false)
    });
    const fornitore = [
      {
        'fornitoreId': 1,
        'nomeSocieta': '2020_060'
      },
      {
        'fornitoreId': 2,
        'nomeSocieta': '2020_060'
      },
      {
        'fornitoreId': 3,
        'nomeSocieta': '2020_060'
      }
    ];
    const tableKeys = [
      'Categorie BankIT',
      'Stato Proposta',
      'Categorie EBA',
      'Canale di segnalazione',
      'Sottostato Proposta',
      'Società del Segnalante'
    ];
    const mockResponse = {
      'Stato Proposta': [
        {
          'orderId': '1',
          'tableId': 'Stato Proposta',
          'itemName': 'In corso',
          'subDomainList': [
            {
              'orderId': '1',
              'tableId': 'Stato Proposta',
              'itemName': 'Descrizione Esigenza',
              'subDomainList': null
            },
            {
              'orderId': '2',
              'tableId': 'Stato Proposta',
              'itemName': 'Valutazione Fornitura / Esternalizzazione',
              'subDomainList': null
            },
            {
              'orderId': '3',
              'tableId': 'Stato Proposta',
              'itemName': 'Classificazione FEI / NON FEI',
              'subDomainList': null
            },
            {
              'orderId': '4',
              'tableId': 'Stato Proposta',
              'itemName': 'Esito Proposta',
              'subDomainList': null
            },
            {
              'orderId': '5',
              'tableId': 'Stato Proposta',
              'itemName': 'Esito CDA',
              'subDomainList': null
            },
            {
              'orderId': '6',
              'tableId': 'Stato Proposta',
              'itemName': 'Esito istanza AdV / Sindacale',
              'subDomainList': null
            }
          ]
        },
        {
          'orderId': '2',
          'tableId': 'Stato Proposta',
          'itemName': 'conclusa',
          'subDomainList': null
        },
        {
          'orderId': '3',
          'tableId': 'Stato Proposta',
          'itemName': 'annullata',
          'subDomainList': null
        },
        {
          'orderId': '4',
          'tableId': 'Stato Proposta',
          'itemName': 'sospesa',
          'subDomainList': null
        }
      ],
      'Canale di segnalazione': [
        {
          'orderId': '1',
          'tableId': 'Canale di segnalazione',
          'itemName': 'Progetto',
          'subDomainList': null
        },
        {
          'orderId': '2',
          'tableId': 'Canale di segnalazione',
          'itemName': 'Evolutiva',
          'subDomainList': null
        },
        {
          'orderId': '3',
          'tableId': 'Canale di segnalazione',
          'itemName': 'Richiesta di Acquisto (RDA)',
          'subDomainList': null
        }
      ]
    };
    const clientResponse = [
      {
        'clientiId': 1,
        'nomeSocieta': 'SV Banca',
        'abi': 'CLIENT1',
        'classeSocieta': 'banca',
        'partitaIva': '1',
        'codiceFiscale': '1'
      },
      {
        'clientiId': 25,
        'nomeSocieta': 'BPER Banca',
        'abi': '5387',
        'classeSocieta': 'Società Strumentale',
        'partitaIva': 'Partita IVA bper!',
        'codiceFiscale': '6666'
      },
      {
        'clientiId': 26,
        'nomeSocieta': 'BPER Banca',
        'abi': '5387',
        'classeSocieta': 'Società Strumentale',
        'partitaIva': 'Partita IVA bper!',
        'codiceFiscale': '6666'
      },
      {
        'clientiId': 27,
        'nomeSocieta': 'Test',
        'abi': 'Test',
        'classeSocieta': 'Si',
        'partitaIva': 'Partita ',
        'codiceFiscale': '334'
      },

    ];
    proposteService.getFornitourDropdownDetails.and.returnValue(of(fornitore));
    proposteService.getDropdownKeys.and.returnValue(of(tableKeys));
    proposteService.getDropdownData.and.returnValue(of(mockResponse));
    proposteService.getAllClientiDetails.and.returnValue(of(clientResponse));
    fixture = TestBed.createComponent(NuovoPropostaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    // component.nuovoPropostaForm = nuovoPropostaForm;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show label names', () => {
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('label').textContent).toContain('Data della segnalazione della proposta');
  });

  it('should call censisci button', () => {
    const mockResponse = [
      {
        'numeroProposta': '2020_047',
        'fornitoreId': 1,
        'nomeSocieta': 'Capgemini Italia',
        'oggDellaProposta': 'bu',
        'dataDellaProposta': 1603045800000,
        'statoProposta': 'nbh',
        'id': 46
      },
      {
        'numeroProposta': '2020_047',
        'fornitoreId': 2,
        'nomeSocieta': 'Capgemini Italia',
        'oggDellaProposta': 'bu',
        'dataDellaProposta': 1603045800000,
        'statoProposta': 'nbh',
        'id': 46
      }
    ];
    fixture.detectChanges();
    spyOn(component, 'getSupplierDetails');
    proposteService.getSupplierDetails.and.returnValue(of(mockResponse));
    component.getSupplierDetails();
    fixture.detectChanges();
    expect(component.getSupplierDetails).toHaveBeenCalled();

  });

  it('should render lable as label.nuovaProposte.AggiungiNuovoFornitore', () => {
    fixture.detectChanges();
     expect(fixture.debugElement.nativeElement.querySelector('a').textContent).toBe(' Aggiungi nuovo fornitore ');
  });

  it('should call aggrigona righe button', () => {
    const mockResponse = [
      {
        'numeroProposta': '2020_047',
        'fornitoreId': 1,
        'nomeSocieta': 'Capgemini Italia',
        'oggDellaProposta': 'bu',
        'dataDellaProposta': 1603045800000,
        'statoProposta': 'nbh',
        'id': 46
      },
      {
        'numeroProposta': '2020_047',
        'fornitoreId': 2,
        'nomeSocieta': 'Capgemini Italia',
        'oggDellaProposta': 'bu',
        'dataDellaProposta': 1603045800000,
        'statoProposta': 'nbh',
        'id': 46
      }
    ];
    fixture.detectChanges();
    spyOn(component, 'updateSupplierDetails');
    component.updateSupplierDetails();
    proposteService.updateSupplierDetails.and.returnValue(of(mockResponse));
    expect(component.updateSupplierDetails).toHaveBeenCalled();

  });

  it('should have title as Nuova Proposta', () => {
    fixture.detectChanges();
    const proposteServiceSpy = spyOn(component, 'getSupplierDetails');
    fixture.detectChanges();
    expect(component.title).toBe('Nuova Proposta');
  });
  it('should call getSupplierDetails and return the said result', () => {
    const mockResponse = [
      {
        'numeroProposta': '2020_047',
        'fornitoreId': 1,
        'nomeSocieta': 'Capgemini Italia',
        'oggDellaProposta': 'bu',
        'dataDellaProposta': 1603045800000,
        'statoProposta': 'nbh',
        'id': 46
      },
      {
        'numeroProposta': '2020_047',
        'fornitoreId': 2,
        'nomeSocieta': 'Capgemini Italia',
        'oggDellaProposta': 'bu',
        'dataDellaProposta': 1603045800000,
        'statoProposta': 'nbh',
        'id': 46
      }
    ];
    const mockParameter = {};
    proposteService.getSupplierDetails.and.returnValue(of(mockResponse));
    spyOn(component,'getSupplierDetails').and.callThrough();
    component.getSupplierDetails();
    fixture.detectChanges();
    // expect(proposteService.getSupplierDetails).toHaveBeenCalled();
    proposteService.getSupplierDetails().subscribe(result => {
      expect(result).toBe(mockResponse);
    });
  });

  it('should call setProposal method', () => {
    component.setProposalStatus('In corso');
    expect(component.isDisbledField).toBe(false);
    expect(component.isStatoDisbled ).toBe(false);
  })
  it('should call setProposal method', () => {
    component.setProposalStatus('Sospesa');
    expect(component.isDisbledField).toBe(true);
    expect(component.isStatoDisbled ).toBe(false);
  });
  
  it('should call setProposal method', () => {
    component.setProposalStatus('Conclusa');
    expect(component.isDisbledField).toBe(true);
    expect(component.isStatoDisbled ).toBe(true);
    expect(component.isDataFineProposta).toBe(false);
  });
  it('should call setSotoStatoProposta method', () => {
    component.setSotoStatoProposta('Conclusa');
    expect(component.isDataFineProposta).toBe(true);
  });
  it('should call updateSupplierDetails and return the said result', () => {
    const mockResponse = [
      {
        'numeroProposta': '2020_047',
        'fornitoreId': 1,
        'nomeSocieta': 'Capgemini Italia',
        'oggDellaProposta': 'bu',
        'dataDellaProposta': 1603045800000,
        'statoProposta': 'nbh',
        'id': 46
      },
      {
        'numeroProposta': '2020_047',
        'fornitoreId': 2,
        'nomeSocieta': 'Capgemini Italia',
        'oggDellaProposta': 'bu',
        'dataDellaProposta': 1603045800000,
        'statoProposta': 'nbh',
        'id': 46
      }
    ];
    const mockParameter = {};
    proposteService.updateSupplierDetails.and.returnValue(of(mockResponse));
    // spyOn(component,'updateSupplierDetails').and.callThrough();
    // component.updateSupplierDetails();
    fixture.detectChanges();
    // expect(proposteService.updateSupplierDetails).toHaveBeenCalled();
    proposteService.updateSupplierDetails().subscribe(result => {
      expect(result).toBe(mockResponse);
    });
  });
});
