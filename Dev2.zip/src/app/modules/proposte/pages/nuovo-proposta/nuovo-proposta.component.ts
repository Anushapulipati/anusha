import { Component, HostListener, OnDestroy, OnInit } from '@angular/core';
import { FormGroup, Validators, FormControl } from '@angular/forms';
import { ProposteService } from '../../services/proposte.service';
import { SelectView } from 'src/app/shared/models/selectView';
import { ActivatedRoute, Router } from '@angular/router';
import { SelectOptionModel } from 'fe-dghub-component-library/lib/models/select-option-model';
import { FornitoreVm } from 'src/app/shared/models/fornitoreVm';
import { SupplierVm } from 'src/app/shared/models/supplierVm';
import { NuovoResponse } from 'src/app/shared/models/nuovo-response';
import { ComponentCanDeactivate } from 'src/app/shared/services/pending-changes-guard.guard';
import { TreeviewConfig, TreeviewItem } from 'ngx-treeview';
import { DatePipe } from '@angular/common';
import { NgbDateParserFormatter, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from 'src/app/shared/services/dateFormat';
import { ConfirmationComponentComponent } from 'src/app/shared/components/confirmation-component/confirmation-component.component';
import { LoginService } from 'src/app/shared/services/login.service';

const cambioFornitourDetails = [
  {
    value: 'Si',
    description: 'Si'
  },
  {
    value: 'No',
    description: 'No',
  }
];

@Component({
  selector: 'reg-nuovo-proposta',
  templateUrl: './nuovo-proposta.component.html',
  styleUrls: ['./nuovo-proposta.component.scss'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})
export class NuovoPropostaComponent implements OnInit, ComponentCanDeactivate {
  allClientiDetails: any;
  cambioFornitourDetails = cambioFornitourDetails;
  canaledisegnalazione: SelectView[];
  clientDetails: any;
  dataDellaPropostaValidation: boolean;
  date: Date = new Date();
  dropdownList: FornitoreVm[];
  dropdownSettings = {
    singleSelection: false,
    idField: 'fornitoreId',
    textField: 'nomeSocieta',
    // selectAllText: 'Select All',
    // unSelectAllText: 'UnSelect All',
    itemsShowLimit: 3,
    allowSearchFilter: true
  };
  editMode: boolean;
  filterKeys = ['Stato Proposta', 'Canale di segnalazione'];
  filters: any;
  hasPropostaReadOnly: boolean;
  isCompleto: boolean;
  isDataFineProposta = true;
  isDisbledField: boolean;
  isRequired: boolean;
  isSavedForm = true;
  isStatoDisbled: boolean;
  numeroPropostaValue: number;
  nuovoProposta = false;
  nuovoPropostaForm = new FormGroup({
    dataDellaProposta: new FormControl(null),
    uosegnalante: new FormControl(''),
    cambioFornitore: new FormControl(''),
    fornitore: new FormControl('', [Validators.required]),
    canDiSegnalazione: new FormControl(''),
    codCanSegnalazione: new FormControl(''),
    statoProposta: new FormControl('In corso', Validators.required),
    dataFineProposta: new FormControl(''),
    segnalante: new FormControl('', Validators.required),
    societaDelSegnalante: new FormControl('', Validators.required),
    oggDellaProposta: new FormControl('', Validators.required),
    praticaOwner: new FormControl(''),
    gestionePraticaBackup: new FormControl(''),
    sotoStatoProposta: new FormControl('Descrizione Esigenza', Validators.required),
    completoOrInCompleto: new FormControl(false)
  });
  propostaFornitoreId: number;
  propostaId: number;
  statoProposta: SelectView[];
  subStateDetails: SelectView[];
  suppliers: SupplierVm[];
  title = 'Nuova Proposta';
  constructor(
    private proposteService: ProposteService,
    private route: ActivatedRoute,
    private router: Router,
    private datePipe: DatePipe,
    private _modalService: NgbModal,
    private loginService: LoginService
  ) { }

  private detectFormChanges() {
    this.nuovoPropostaForm.valueChanges.subscribe(changes => {
      if (changes) {
        this.isSavedForm = false;
      }
    });
  }

  private getDropdownData(filters) {
    const items: SelectView[] = [];
    filters.map((filter, index) => {
      const item = new SelectView(filter.itemName, filter.itemName);
      items.push(item);
    });
    return items;
  }

  private async getDropdownTableKeys() {
    await this.getFornitourDropdownDetails();
    this.proposteService.getDropdownData(this.filterKeys).subscribe(async filters => {
      this.filters = await filters;
      this.canaledisegnalazione = await this.getDropdownData(filters[this.filterKeys[1]]);
      this.statoProposta = await this.getDropdownData(filters[this.filterKeys[0]]);
      this.route.params.subscribe(async params => {
        this.propostaId = params['propostaId'];
        if (this.propostaId) {
          this.getPropostaDetails(this.propostaId);
        } else {
          this.subStateDetails = await this.getDropdownData(filters[this.filterKeys[0]][0].subDomainList);
          setTimeout(async () => {
            this.detectFormChanges();
          }, 2000);
        }
      });
    });
  }

  private getFornitourDropdownDetails() {
    this.proposteService.getFornitourDropdownDetails().subscribe(async result => {
      this.dropdownList = result;
    });
  }

  private getPropostaDetails(propostaId) {
    this.isRequired = true;
    const mandatoryFieldsAfterProposalCreation
    = ['dataDellaProposta', 'uosegnalante', 'cambioFornitore', 'fornitore', 'canDiSegnalazione', 'praticaOwner'];
    mandatoryFieldsAfterProposalCreation.map(field => {
      this.nuovoPropostaForm.get(field).setValidators([Validators.required]);
      this.nuovoPropostaForm.get(field).updateValueAndValidity();
    });

    return this.proposteService.getPropostadetailswithSuppliers(propostaId).subscribe(async propostaDetails => {
      const suppliers = propostaDetails['suppliers'];
      const proposta = propostaDetails['proposta'];
      this.suppliers = suppliers;
      if (proposta['dataDellaProposta']) {
      const dateArry = proposta['dataDellaProposta'].split('/');
      proposta['dataDellaProposta'] = { day: parseInt(dateArry[0], 0), month: parseInt(dateArry[1], 0), year: parseInt(dateArry[2], 0) };
      }
      this.title = proposta['propostaName'];
      this.numeroPropostaValue = proposta['numeroProposta'];
      let fornitore = [];
      if (this.suppliers) {
        this.suppliers.map(supplier => {
          fornitore = [...fornitore, ...this.dropdownList.filter(element => element.fornitoreId === supplier.fornitoreId)];
        });
      }
      proposta['fornitore'] = fornitore;
      this.isCompleto = proposta['completoOrInCompleto'];
      const sotoStato = this.filters[this.filterKeys[0]].filter(filter => (filter.itemName === proposta['statoProposta']));
      this.subStateDetails = await this.getDropdownData(sotoStato[0]['subDomainList']);
      await this.nuovoPropostaForm.patchValue(proposta);
      // await this.setSotoStatoProposta(proposta['statoProposta']);
      await this.setProposalStatus(proposta['statoProposta']);
      this.nuovoProposta = true;
      this.isSavedForm = true;
    });
  }

  @HostListener('window:beforeunload')
  canDeactivate(): boolean {
    return this.isSavedForm;
  }

  changeCallBack(date) {
    if (date instanceof Object) {
      if (date.year && date.year.toString().length === 4) {
        const selectedDate = this.nuovoPropostaForm.get('dataDellaProposta').value;
        const currentDate = new Date();
        const selectedModifiedDate = new Date(selectedDate.year, selectedDate.month - 1, selectedDate.day);
        if (currentDate > selectedModifiedDate) {
          this.dataDellaPropostaValidation = false;
        } else {
          this.dataDellaPropostaValidation = true;
        }
      }
    }
  }

  async ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasPropostaReadOnly = operationModel ? operationModel.hasPropostaReadOnly : '';
    await this.getDropdownTableKeys();
    // this.detectFormChanges();
    this.proposteService.getAllClientiDetails().subscribe(async clientDetails => {
      this.clientDetails = clientDetails;
      const items: SelectView[] = [];
      this.clientDetails.map((value) => {
        const item = new SelectView(value.nomeSocieta, value.nomeSocieta);
        items.push({
          description: value.nomeSocieta,
          value: value.nomeSocieta
        });
      });
      this.allClientiDetails = items;
    });
  }

  // tslint:disable-next-line: member-ordering
  async getSupplierDetails() {
    if (this.nuovoPropostaForm.valid) {
      this.title = 'Proposta ABC';
      let propostaDate;
      if (this.nuovoPropostaForm.value['dataDellaProposta']) {
        propostaDate = this.proposteService.getUTCDate(this.nuovoPropostaForm.value['dataDellaProposta']);
      }
      const proposta = {
        ...this.nuovoPropostaForm.value,
        dataDellaProposta: propostaDate,
        dataDelCensimento: new Date(),
        propostaName: this.title
      };
      this.proposteService.getSupplierDetails(proposta).subscribe(result => {
        this.nuovoProposta = true;
        this.suppliers = result;
        this.isSavedForm = true;
        if (this.suppliers) {
          this.numeroPropostaValue = this.suppliers[0].numeroProposta;
          const proposalID = this.suppliers[0].proposalId;
          this.router.navigate(['/proposte/nuovo-proposta', proposalID]);
        } else {
          this.router.navigate(['/proposte/nuovo-proposta']);
        }
      });
    }
  }

  setProposalStatus(statoProposta) {
    if (this.hasPropostaReadOnly) {
      this.nuovoPropostaForm.disable();
      this.nuovoPropostaForm.updateValueAndValidity();
     } else {
    if (statoProposta === 'Conclusa' || statoProposta === 'Annullata') {
      this.isDataFineProposta = false;
      this.isDisbledField = true;
      this.isStatoDisbled = true;
      this.nuovoPropostaForm.disable();
      this.nuovoPropostaForm.updateValueAndValidity();
    } else {
      if (statoProposta === 'Sospesa') {
        Object.keys(this.nuovoPropostaForm.controls).forEach(key => {
          if (key !== 'statoProposta') {
            this.isDisbledField = true;
            this.isStatoDisbled = false;
            this.nuovoPropostaForm.get(key).disable();
            this.nuovoPropostaForm.get(key).updateValueAndValidity();
          }
        });
      } else if (statoProposta === 'In corso') {
        this.isDisbledField = false;
        this.isStatoDisbled = false;
        this.nuovoPropostaForm.enable();
        this.nuovoPropostaForm.updateValueAndValidity();
      }
    }
  }
    setTimeout(async () => {
      this.isSavedForm = true;
      this.detectFormChanges();
    }, 2000);
  }

  setSotoStatoProposta(statoProposta) {
    const date = new Date();
    const dataFineDate = this.datePipe.transform(date, 'dd/MM/yyyy');
    if (statoProposta === 'Conclusa') {
      if (!this.isCompleto || !this.nuovoPropostaForm.valid) {
        const confirmationModal = this._modalService.open(ConfirmationComponentComponent);
        confirmationModal.componentInstance.isConclusaWarning = true;
        return confirmationModal.result.then((result) => {
          this.nuovoPropostaForm.get('statoProposta').setValue('In corso');
          return;
        });
      }
      this.isDataFineProposta = false;
      this.nuovoPropostaForm.get('dataFineProposta').setValue(dataFineDate);
    } else {
      this.isDataFineProposta = true;
      this.nuovoPropostaForm.get('dataFineProposta').setValue(null);
    }
    this.filters[this.filterKeys[0]].map(filter => {
      if (filter.itemName === statoProposta) {
        this.subStateDetails = (filter.subDomainList)
          ? this.getDropdownData(filter.subDomainList)
          : this.getDropdownData([filter]);
        this.nuovoPropostaForm.get('sotoStatoProposta').setValue(this.subStateDetails[0].value);
      }
    });
  }

  async updateSupplierDetails() {
    let propostaDate = new Date();
    if (this.nuovoPropostaForm.value['dataDellaProposta']) {
      propostaDate = this.proposteService.getUTCDate(this.nuovoPropostaForm.value['dataDellaProposta']);
    }
    const proposta = {
      ...this.nuovoPropostaForm.getRawValue(),
      dataDellaProposta: propostaDate,
      dataDelCensimento: new Date(),
      proposalId: this.propostaId ? this.propostaId : this.suppliers[0].proposalId,
      numeroProposta: this.numeroPropostaValue ? this.numeroPropostaValue : this.suppliers[0].numeroProposta,
      propostaName: this.title
    };
    if (this.nuovoPropostaForm.get('statoProposta').value === 'Conclusa') {
      proposta.dataFineProposta = new Date();
    }
    this.proposteService.updateSupplierDetails(proposta).subscribe(result => {
      this.isSavedForm = true;
      this.suppliers = result;
      this.getPropostaDetails(this.propostaId);
    });
  }
}
