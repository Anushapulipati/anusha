/* import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { TreeviewModule } from 'ngx-treeview';
import { of, Observable } from 'rxjs';
import { AccordionComponent } from 'src/app/shared/components/accordion/accordion.component';
import { MultiselectDropdownComponent } from 'src/app/shared/components/multiselect-dropdown/multiselect-dropdown.component';
import { ProposteService } from '../../services/proposte.service';
import { DettaglioRigaProposteComponent } from './dettaglio-riga-proposte.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { LoginService } from 'src/app/shared/services/login.service';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}


describe('DettaglioRigaProposteComponent', () => {
  let component: DettaglioRigaProposteComponent;
  let fixture: ComponentFixture<DettaglioRigaProposteComponent>;
  const route = { name: 'tips', params: of({ tipsId: '4' }) };
  const router = { events: of({ tipsId: '4' }),
    createUrlTree: (commands, navExtras = {}) => {},
    serializeUrl :() =>{} };
  let proposteService;
  let loginService;

  beforeEach(async(() => {
    proposteService = jasmine.createSpyObj(['getServizioList', 'getDropdownKeys', 'getDropdownData', 'getPropostaDetails']);
    loginService = jasmine.createSpyObj(['getOperationModel']);
    TestBed.configureTestingModule({
      declarations: [DettaglioRigaProposteComponent, MultiselectDropdownComponent, AccordionComponent],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        FeDghubComponentLibraryModule,
        HttpClientTestingModule,
        NgbModule,
        TreeviewModule.forRoot(),
        RouterTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
      
        { provide: ProposteService, useValue: proposteService },
        { provide: LoginService, useValue: loginService},
      ]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    const operationModel = {
      hasPropostaReadOnly: true,
    };
    loginService.getOperationModel.and.returnValue(of(operationModel));
    const fornitore = [
      {
        'fornitoreId': 1,
        'nomeSocieta': '2020_060'
      },
      {
        'fornitoreId': 2,
        'nomeSocieta': '2020_060'
      },
      {
        'fornitoreId': 3,
        'nomeSocieta': '2020_060'
      }
    ];
    const tableKeys = [
      'Categorie BankIT',
      'Stato Proposta',
      'Categorie EBA',
      'Canale di segnalazione',
      'Sottostato Proposta',
      'Società del Segnalante'
    ];
    const mockResponse = {
      'Classificazione - 2': [
        {
          'orderId': '1',
          'tableId': 'Classificazione - 2',
          'itemName': 'Esternalizzazione',
          'subDomainList': null
        },
        {
          'orderId': '2',
          'tableId': 'Classificazione - 2',
          'itemName': 'Fornitura',
          'subDomainList': null
        }
      ],
      'Tipologia Dati da conservare': [
        {
          'orderId': '27',
          'tableId': 'Tipologia Dati da conservare',
          'itemName': 'Tipi fisici',
          'subDomainList': null
        },
        {
          'orderId': '26',
          'tableId': 'Tipologia Dati da conservare',
          'itemName': 'Carriera',
          'subDomainList': null
        },
        {
          'orderId': '28',
          'tableId': 'Tipologia Dati da conservare',
          'itemName': 'Tracking',
          'subDomainList': null
        }
      ],
      'Categorie BankIT': [
        {
          'orderId': '1',
          'tableId': 'Categorie BankIT',
          'itemName': 'Credito / cartolarizzazioni',
          'subDomainList': [
            {
              'orderId': '2',
              'tableId': 'Categorie BankIT',
              'itemName': 'Fasi o specifiche attività del processo di monitoraggio',
              'subDomainList': null
            },
            {
              'orderId': '3',
              'tableId': 'Categorie BankIT',
              'itemName': 'Fasi o specifiche attività del processo di valutazione',
              'subDomainList': null
            },
            {
              'orderId': '6',
              'tableId': 'Categorie BankIT',
              'itemName': 'Altro (non presente nelle subcategorie) o dettagli (relativi alla subcategoria scelta)',
              'subDomainList': null
            }
          ]
        }
      ],
      'Classificazione - 1': [
        {
          'orderId': '1',
          'tableId': 'Classificazione - 1',
          'itemName': 'Esternalizzazione',
          'subDomainList': null
        },
        {
          'orderId': '2',
          'tableId': 'Classificazione - 1',
          'itemName': 'Fornitura',
          'subDomainList': null
        }
      ],
      'Sostituibilita': [
        {
          'orderId': '1',
          'tableId': 'Sostituibilita',
          'itemName': 'Facile',
          'subDomainList': null
        },
        {
          'orderId': '2',
          'tableId': 'Sostituibilita',
          'itemName': 'Difficile',
          'subDomainList': null
        },
        {
          'orderId': '3',
          'tableId': 'Sostituibilita',
          'itemName': 'Impossibile',
          'subDomainList': null
        }
      ],
      'Categorie EBA': [
       {
          'orderId': '3',
          'tableId': 'Categorie EBA',
          'itemName': 'Acquisizione di servizi di pubblica utilità (e.g. forniture di elettricità, gas, acqua, telefonia)',
          'subDomainList': null
        },
        {
          'orderId': '8',
          'tableId': 'Categorie EBA',
          'itemName': 'Funzione che a norma di legge deve essere svolta da un fornitore di servizi (e.g. la revisione legale dei conti)',
          'subDomainList': null
        },
        {
          'orderId': '11',
          'tableId': 'Categorie EBA',
          'itemName': 'Infrastruttura di rete globale (e.g. Visa, MasterCard)',
          'subDomainList': null
        },
        {
          'orderId': '12',
          'tableId': 'Categorie EBA',
          'itemName': 'Infrastruttura globale di messaggistica finanziaria soggetta alla vigilanza delle pertinenti autorità',
          'subDomainList': null
        },
        {
          'orderId': '15',
          'tableId': 'Categorie EBA',
          'itemName': 'Manutenzione delle aree verdi',
          'subDomainList': null
        },
        {
          'orderId': '16',
          'tableId': 'Categorie EBA',
          'itemName': 'Manutenzione di automobili aziendali',
          'subDomainList': null
        },
        {
          'orderId': '17',
          'tableId': 'Categorie EBA',
          'itemName': 'Manutenzione di componenti standard di hardware nellambito di soluzioni di mercato',
          'subDomainList': null
        },
        {
          'orderId': '19',
          'tableId': 'Categorie EBA',
          'itemName': 'Servizi amministrativi (e.g. servizi di economato)',
          'subDomainList': null
        },
        {
          'orderId': '20',
          'tableId': 'Categorie EBA',
          'itemName': 'Servizi bancari di corrispondenza',
          'subDomainList': null
        },
        {
          'orderId': '21',
          'tableId': 'Categorie EBA',
          'itemName': 'Servizi di business travel (e.g. prenotazione hotel)',
          'subDomainList': null
        },
        {
          'orderId': '22',
          'tableId': 'Categorie EBA',
          'itemName': 'Servizi di distribuzione automatica',
          'subDomainList': null
        },
        {
          'orderId': '24',
          'tableId': 'Categorie EBA',
          'itemName': 'Servizi di portierato, receptionist, segreteria e centralino',
          'subDomainList': null
        },
        {
          'orderId': '25',
          'tableId': 'Categorie EBA',
          'itemName': 'Servizi di ristorazione (e.g. erogazione pasti, catering, fornitura buoni pasto)',
          'subDomainList': null
        },
        {
          'orderId': '26',
          'tableId': 'Categorie EBA',
          'itemName': 'Servizi di vigilanza e sorveglianza armata',
          'subDomainList': null
        },
        {
          'orderId': '27',
          'tableId': 'Categorie EBA',
          'itemName': 'Servizi medici',
          'subDomainList': null
        },
        {
          'orderId': '28',
          'tableId': 'Categorie EBA',
          'itemName': 'Servizi postali',
          'subDomainList': null
        },
        {
          'orderId': '30',
          'tableId': 'Categorie EBA',
          'itemName': 'Recupero crediti',
          'subDomainList': null
        },
        {
          'orderId': '31',
          'tableId': 'Categorie EBA',
          'itemName': 'Segnalazioni di Vigilanza',
          'subDomainList': null
        },
        {
          'orderId': '32',
          'tableId': 'Categorie EBA',
          'itemName': 'Servizi e attività di investimento',
          'subDomainList': null
        },
        {
          'orderId': '33',
          'tableId': 'Categorie EBA',
          'itemName': 'Servizio/attività di back office',
          'subDomainList': null
        },
        {
          'orderId': '34',
          'tableId': 'Categorie EBA',
          'itemName': 'Servizio archiviazione digitale o cartacea',
          'subDomainList': null
        },
        {
          'orderId': '35',
          'tableId': 'Categorie EBA',
          'itemName': 'Sistema informativo o sue componenti critiche',
          'subDomainList': null
        },
        {
          'orderId': '36',
          'tableId': 'Categorie EBA',
          'itemName': 'Trasporto valori',
          'subDomainList': null
        },
        {
          'orderId': '37',
          'tableId': 'Categorie EBA',
          'itemName': 'Trattamento del contante',
          'subDomainList': null
        }
      ],
      'Livello di Rischiosità': [
        {
          'orderId': '1',
          'tableId': 'Livello di Rischiosità',
          'itemName': 'Rischio Basso',
          'subDomainList': null
        },
        {
          'orderId': '2',
          'tableId': 'Livello di Rischiosità',
          'itemName': 'Rischio Medio',
          'subDomainList': null
        },
        {
          'orderId': '3',
          'tableId': 'Livello di Rischiosità',
          'itemName': 'Rischio Alto',
          'subDomainList': null
        },
        {
          'orderId': '4',
          'tableId': 'Livello di Rischiosità',
          'itemName': 'Non applicabile',
          'subDomainList': null
        }
      ],
      'Tipologia di Cloud': [
        {
          'orderId': '1',
          'tableId': 'Tipologia di Cloud',
          'itemName': 'Cloud Ibrido',
          'subDomainList': null
        },
        {
          'orderId': '2',
          'tableId': 'Tipologia di Cloud',
          'itemName': 'Cloud Pubblico',
          'subDomainList': null
        },
        {
          'orderId': '3',
          'tableId': 'Tipologia di Cloud',
          'itemName': 'Cloud Privato',
          'subDomainList': null
        },
        {
          'orderId': '4',
          'tableId': 'Tipologia di Cloud',
          'itemName': 'Cloud di Comunità',
          'subDomainList': null
        }
      ]
    };
     proposteService.getServizioList.and.returnValue(of(fornitore));
   
    proposteService.getDropdownKeys.and.returnValue(of(tableKeys));
    proposteService.getDropdownData.and.returnValue(of(mockResponse));
    proposteService.getPropostaDetails.and.returnValue(of(mockResponse));
    fixture = TestBed.createComponent(DettaglioRigaProposteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

   it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should render text as Torna alla proposta', () => {
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('span').textContent).toContain('Torna alla proposta');
  });

  it('should call getServizioList and return the mocked result', () => {
    const supplierResponse = [
      {
        'numeroProposta': '2020_047',
        'fornitoreId': 1,
        'nomeSocieta': 'Capgemini Italia',
        'oggDellaProposta': 'bu',
        'dataDellaProposta': 1603045800000,
        'statoProposta': 'nbh',
        'id': 46
      },
      {
        'numeroProposta': '2020_047',
        'fornitoreId': 2,
        'nomeSocieta': 'Capgemini Italia',
        'oggDellaProposta': 'bu',
        'dataDellaProposta': 1603045800000,
        'statoProposta': 'nbh',
        'id': 46
      }
    ];
    const mockParameter = 12345;
    proposteService.getServizioList.and.returnValue(of(supplierResponse));
  
    fixture.detectChanges();
    expect(proposteService.getServizioList).toHaveBeenCalled();
    proposteService.getServizioList(mockParameter).subscribe(result => {
      expect(result).toBe(supplierResponse);
    });
  }); 
});  */