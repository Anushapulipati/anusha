import { ChangeDetectorRef, Component, OnInit, OnChanges } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { SelectView } from 'src/app/shared/models/selectView';
import { ProposteService } from '../../services/proposte.service';
import { concatMap } from 'rxjs/operators';
import { Location } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { SupplierVm } from 'src/app/shared/models/supplierVm';
import { NgbDateParserFormatter, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AddServizioPopUpComponent } from '../../components/add-servizio-pop-up/add-servizio-pop-up.component';
import { NgbDateCustomParserFormatter } from 'src/app/shared/services/dateFormat';
import { LoginService } from '../../../../shared/services/login.service';

const commonDropdown = [
  {
    value: 'Si',
    description: 'Si'
  },
  {
    value: 'No',
    description: 'No',
  }
];

@Component({
  selector: 'reg-dettaglio-riga-proposte',
  templateUrl: './dettaglio-riga-proposte.component.html',
  styleUrls: ['./dettaglio-riga-proposte.component.scss'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})
export class DettaglioRigaProposteComponent implements OnInit {
  categoriaBankIT: SelectView[];
  categoriaEBA: SelectView[];
  classificazione1: SelectView[];
  classificazione2: SelectView[];
  contrattoList = [];
  dropdownSettings = {
    singleSelection: false,
    idField: 'value',
    textField: 'description',
    itemsShowLimit: 3,
    allowSearchFilter: false
  };
  dropdownSiNo = commonDropdown;
  filterKeys = ['Sostituibilita', 'Classificazione - 1', 'Classificazione - 2', 'Livello di Rischiosità',
      'Tipology Dati Da', 'Tipologia di Cloud', 'Categorie EBA', 'Categorie BankIT'];
  filters: any;
  firstConditionMandatoryFields = [
    'classificazioneOne',
    'classificazioneTipo'
  ];
  fornitoreID: number;
  hasPropostaReadOnly: boolean;
  isProposalCompleted: boolean;
  isRequired = false;
  livello: SelectView[];
  opened = false;
  proposta: SupplierVm;
  propostaDetails: any;
  propostaFornitoreId: number;
  propostaId: number;
  secondConditionMandatoryFields = [
    'sostituibilita',
    'possibilitaDiRei',
    'classificazioneOne',
    'classificazioneTipo',
    'datiPersonali',
    'sogliaFunzione',
    'funzioneEsternalizzata',
    'livelloDiRischiosita',
    'breveRischiosita',
    'funzioneImportante',
    'ultimaValutazioneData',
    'sintesideiMotivi',
    'paesediconDati',
    'paeseDiVieneSvolto',
    'cloudpaesediCon',
    'descrizioneDel',
    'tipologiaDaDati',
    'cloudNaturaDaDati',
    'servizioInfrastrttra',
    'tipologiaDiCloud',
    'racConDeiPro',
    'marcoProcesso',
    'categoriaEba',
    'categoriaBankIt',
    'sottocategoriaBankIt'
  ];
  servizioForm = new FormArray([]);
  servizioIds = [];
  servizioList = [];
  sostituibilita: SelectView[];
  subCategoriaBankIT: SelectView[];
  tipologia: SelectView[];
  tipologiaCloud: SelectView[];
  constructor(
    private _location: Location,
    private route: ActivatedRoute,
    private proposteService: ProposteService,
    private _modalService: NgbModal,
    private router: Router,
    private cdRef: ChangeDetectorRef,
    private loginService: LoginService
  ) { }

  private addServizioFormGroups(servizioName, servizioId?) {
    const formGroup = new FormGroup({
      servizioName: new FormControl(servizioName),
      // propostaId: new FormControl(this.propostaId),
      propostaFornitoreId: new FormControl(this.propostaFornitoreId),
      servizioId: new FormControl(servizioId),
      sostituibilita: new FormControl(''),
      possibilitaDiRei: new FormControl(''),
      classificazioneOne: new FormControl('', Validators.required),
      classificazioneTipo: new FormControl(''),
      datiPersonali: new FormControl(''),
      sogliaFunzione: new FormControl(''),
      funzioneEsternalizzata: new FormControl(''),
      livelloDiRischiosita: new FormControl(''),
      breveRischiosita: new FormControl(''),
      funzioneImportante: new FormControl(''),
      ultimaValutazioneData: new FormControl(null),
      paeseDiVieneSvolto: new FormControl(''),
      paesediconDati: new FormControl(''),
      cloudpaesediCon: new FormControl(''),
      descrizioneDel: new FormControl(''),
      tipologiaDaDati: new FormControl([]),
      cloudNaturaDaDati: new FormControl([]),
      tipologiaDiCloud: new FormControl(''),
      servizioInfrastrttra: new FormControl(''),
      racConDeiPro: new FormControl(''),
      marcoProcesso: new FormControl(''),
      categoriaEba: new FormControl(''),
      categoriaBankIt: new FormControl(''),
      sottocategoriaBankIt: new FormControl(''),
      sintesideiMotivi: new FormControl(''),
      trasferimentoDati: new FormControl(''),
      completoStato: new FormControl('')
    });
    this.servizioForm.push(formGroup);
  }

  private getDropdownData(filters) {
    const items: SelectView[] = [];
    filters.map((filter, index) => {
      const item = new SelectView(filter.itemName, filter.itemName);
      items.push({
        description: filter.itemName,
        value: filter.itemName
      });
    });
    return items;
  }

  private getDropdownTableKeys(propostaId, propostaFornitoreId) {
    this.proposteService.getDropdownData(this.filterKeys).subscribe(async filters => {
      this.filters = filters;
      this.sostituibilita = await this.getDropdownData(filters[this.filterKeys[0]]);
      this.classificazione1 = await this.getDropdownData(filters[this.filterKeys[1]]);
      this.classificazione2 = await this.getDropdownData(filters[this.filterKeys[2]]);
      this.livello = await this.getDropdownData(filters[this.filterKeys[3]]);
      this.tipologia = await this.getDropdownData(filters[this.filterKeys[4]]);
      this.tipologiaCloud = await this.getDropdownData(filters[this.filterKeys[5]]);
      this.categoriaEBA = this.getDropdownData(filters[this.filterKeys[6]]);
      this.categoriaBankIT = await this.getDropdownData(filters[this.filterKeys[7]]);
      this.subCategoriaBankIT = await this.getDropdownData(filters[this.filterKeys[7]][0]['subDomainList']);
      this.getServizioList(propostaId, propostaFornitoreId);
    });
  }

  private getPropostaDetails(propostaId) {
    return this.proposteService.getPropostaDetails(propostaId).subscribe(propostaDetails => {
      this.propostaDetails = propostaDetails;
      this.isProposalCompleted = (this.propostaDetails.statoProposta !== 'In corso') ? true : false;
      if (this.isProposalCompleted) {
        this.servizioForm.disable();
        this.servizioForm.updateValueAndValidity();
      }
    });
  }

  private getServizioList(propostaId, propostaFornitoreId) {
    this.servizioForm = new FormArray([]);
    this.proposteService.getServizioList(propostaFornitoreId).subscribe(async servizioList => {
     if (servizioList) {
        servizioList.forEach(async (servizio, index) => {
          if (servizio['ultimaValutazioneData']) {
            servizio['ultimaValutazioneData'] = this.proposteService.getDateObject((servizio['ultimaValutazioneData']));
          } else {
            servizio['ultimaValutazioneData'] = null;
          }
          this.servizioIds.push(servizio.servizioId);
          this.addServizioFormGroups(servizio.servizioName, servizio.servizioId);
          const categoriaBankIT = this.filters[this.filterKeys[7]].filter(filter => (filter.itemName === servizioList[index]['categoriaBankIt']));
          this.subCategoriaBankIT = [...this.subCategoriaBankIT, ...this.getDropdownData(categoriaBankIT[0]['subDomainList'])];
          // this.setCategoriaBankIT(servizioList[index]['categoriaBankIt'], index);
        });
        this.servizioList = servizioList;

        // this.setCategoriaBankIT(selectedBankIT, formControlIndex)
        await this.servizioForm.patchValue(servizioList);
        await this.getPropostaDetails(this.propostaId);
        servizioList.forEach(async (servizio, index) => {
          await this.onClassificazioneChange(index);
        });
        await this.getContrattoServizioDetails();
      } else {
        await this.getPropostaDetails(this.propostaId);
      }
    });
  }

  getContrattoServizioDetails() {
    this.proposteService.getContrattoServizioDetails(this.servizioIds).subscribe(contrattoServices => {
      this.contrattoList = contrattoServices;
    });
  }

  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasPropostaReadOnly = operationModel.hasPropostaReadOnly;
    this.route.params.subscribe(async params => {
      this.propostaId = params['propostaId'];
      this.propostaFornitoreId = params['propostaFornitoreId'];
      this.fornitoreID = params['fornitoreID'];
      await this.getDropdownTableKeys(params['propostaId'], params['propostaFornitoreId']);
      this.cdRef.detectChanges();
    });
  }

  onClassificazioneChange(formControlIndex) {
    this.isRequired = false;
    const classificazioneOne = this.servizioForm.controls[formControlIndex].get('classificazioneOne').value;
    const classificazioneTwo = this.servizioForm.controls[formControlIndex].get('classificazioneTipo').value;
    const funzioneImportante = this.servizioForm.controls[formControlIndex].get('funzioneImportante').value;
    const esternalizzazioneCondition = (classificazioneOne === 'Esternalizzazione' && classificazioneTwo === '');
    const totalIncompleteCondition = (classificazioneOne === '' && classificazioneTwo === '');

    // tslint:disable-next-line: max-line-length
    const firstCondition = (classificazioneOne === 'Fornitura' && classificazioneTwo === 'Fornitura') || (classificazioneOne === 'Esternalizzazione' && classificazioneTwo === 'Fornitura');

    // tslint:disable-next-line: max-line-length
    const secondCondition = (classificazioneOne === 'Fornitura' && classificazioneTwo === 'Esternalizzazione') || (classificazioneOne === 'Esternalizzazione' && classificazioneTwo === 'Esternalizzazione');

    // tslint:disable-next-line: max-line-length
    if (!totalIncompleteCondition) {
      [...this.firstConditionMandatoryFields, ...this.secondConditionMandatoryFields].map(field => {
        this.servizioForm.controls[formControlIndex].get(field).clearValidators();
        this.servizioForm.controls[formControlIndex].get(field).updateValueAndValidity();
      });
    }

    if (esternalizzazioneCondition) {
      this.servizioForm.controls[formControlIndex].get('classificazioneTipo').setValidators([Validators.required]);
      this.servizioForm.controls[formControlIndex].get('classificazioneTipo').updateValueAndValidity();
    }
    if (firstCondition) {
      this.firstConditionMandatoryFields.map(field => {
        if (field !== 'classificazioneTipo') {
          this.servizioForm.controls[formControlIndex].get(field).setValidators([Validators.required]);
          this.servizioForm.controls[formControlIndex].get(field).updateValueAndValidity();
        } else {
          if (classificazioneOne === 'Esternalizzazione') {
            this.servizioForm.controls[formControlIndex].get(field).setValidators([Validators.required]);
            this.servizioForm.controls[formControlIndex].get(field).updateValueAndValidity();
          }
        }
      });
    }
    if (secondCondition) {
      this.secondConditionMandatoryFields.map(field => {
        if (field !== 'classificazioneTipo' && field !== 'datiPersonali' && field !== 'sintesideiMotivi') {
          this.servizioForm.controls[formControlIndex].get(field).setValidators([Validators.required]);
          this.servizioForm.controls[formControlIndex].get(field).updateValueAndValidity();
        } else {
          if (classificazioneOne === 'Esternalizzazione' && funzioneImportante === 'Si') {
           this.isRequired = !this.isRequired;
           this.servizioForm.controls[formControlIndex].get(field).setValidators([Validators.required]);
            this.servizioForm.controls[formControlIndex].get(field).updateValueAndValidity();
          }
        }
      });
    }
  }

  async resetForm() {
    this.servizioForm['controls'].forEach(async (group, index) => {
      if (group.get('servizioId').value !== null) {
        this.servizioForm['controls'][index].reset();
        this.servizioForm['controls'][index].patchValue(this.servizioList[index]);
        this.servizioForm.updateValueAndValidity();
      } else {
        Object.keys(group['controls']).forEach(control => {
          if (control !== 'servizioName' && control !== 'propostaFornitoreId') {
            if (control !== 'ultimaValutazioneData' && control !== 'servizioId') {
              group.get(control).setValue('');
            } else {
              group.get(control).setValue(null);
            }
            group.get(control).updateValueAndValidity();
          }
        });
      }
    });
  }

  saveServizio() {
    this.servizioForm['controls'].map(group => {
      const formStatus = group.valid ? 'complete' : 'incomplete';
      group.get('completoStato').setValue(formStatus);
    });
    console.log('saveServizio', this.servizioForm);
    this.servizioForm.value.forEach(element => {
      if (element.ultimaValutazioneData) {
        const ultimaValutazioneData = this.proposteService.getUTCDate(element.ultimaValutazioneData);
        element.ultimaValutazioneData = ultimaValutazioneData;
      }
    });
    this.proposteService.saveServizio(this.servizioForm.value).subscribe(success => {
      this.getServizioList(this.propostaId, this.propostaFornitoreId);
    });
  }

  // tslint:disable-next-line: member-ordering
  addServizio() {
    if (!this.isProposalCompleted) {
      const serviceModalRef = this._modalService.open(AddServizioPopUpComponent, {
        backdrop: 'static'
      });
      serviceModalRef.componentInstance.modalName = 'servizio';
      serviceModalRef.result.then((servizioName) => {
        if (servizioName) {
          this.addServizioFormGroups(servizioName);
          // this.servizioList = [...this.servizioList, servizioName];
        }
      });
    }
  }

  // tslint:disable-next-line: member-ordering
  addContratto(index, servizioName) {
    const serviceModalRef = this._modalService.open(AddServizioPopUpComponent, {
      backdrop: 'static'
    });
    serviceModalRef.componentInstance.modalName = 'contratto';
    serviceModalRef.result.then((contrattoName) => {
      if (contrattoName) {
        this.contrattoList.push({
          index: index,
          contrattoName: contrattoName,
          serviceList: [
            {
              serviceName: servizioName
            }
          ]
        });
      }
    });
  }

  setCategoriaBankIT(selectedBankIT, formControlIndex) {
    this.filters[this.filterKeys[7]].forEach(async filter => {
      if (filter.itemName === selectedBankIT) {
        if (filter.subDomainList && filter.subDomainList.length > 0) {
          this.subCategoriaBankIT = await this.getDropdownData(filter.subDomainList);
          this.servizioForm.controls[formControlIndex].get('sottocategoriaBankIt').setValue(this.subCategoriaBankIT[0].value);
          this.servizioForm.controls[formControlIndex].get('sottocategoriaBankIt').updateValueAndValidity();
        }
      }
    });
  }

  showContrattiPopUp(formControlIndex) {
    const classificazioneOne = this.servizioForm.controls[formControlIndex].get('classificazioneOne').value;
    if (classificazioneOne === 'Fornitura') {
      const servizioName = this.servizioForm.controls[formControlIndex].get('servizioName').value;
      this.addContratto(formControlIndex, servizioName);
    } else {
      // this.contrattoList.splice(formControlIndex);
      this.contrattoList = this.contrattoList.filter((contratto) => contratto.index !== formControlIndex);
    }
  }

  // tslint:disable-next-line: member-ordering
  addNewContratto() {
    // [routerLink]="['/proposte/nuovo-contratto', propostaId, propostaFornitoreId, fornitoreID]"
    if (this.servizioList.length > 0) {
      this.router.navigate(['/proposte/nuovo-contratto',
        this.propostaId,
        this.propostaFornitoreId,
        this.fornitoreID
      ]);
    }
  }

  /* ngOnChanges() {
    // this.servizioForm.controls[formControlIndex].get('classificazioneOne').value;
    this.servizioForm.get('funzioneImportante').valueChanges.subscribe(changes => {
      console.log('changes',changes, this.servizioForm.get('funzioneImportante').value);
      if (changes === 'Si') {
        this.isRequired = true;
        this.servizioForm.get('sintesideiMotivi').setValidators([Validators.required]);
      }
      else {
        this.isRequired = false;
        this.servizioForm.get('statoComunicazione').setValidators(null);
      }
      });
  } */
}
