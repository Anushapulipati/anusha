import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { ProposteService } from '../../services/proposte.service';
import { SelectView } from 'src/app/shared/models/selectView';
import { LoginService } from 'src/app/shared/services/login.service';

@Component({
  selector: 'reg-procedura-sindacale',
  templateUrl: './procedura-sindacale.component.html',
  styleUrls: ['./procedura-sindacale.component.scss']
})
export class ProceduraSindacaleComponent implements OnChanges, OnInit {
  hasPropostaReadOnly: boolean;
  @Input() isNecessariaProceduraSindacaleCheck: boolean;
  isRequired: boolean;
  @Input() necessariaProceduraSindacale:  SelectView[];
  @Input() proceduraSindacale: FormGroup;
  @Input() scadenzaRiscontro: string;
  @Input() statoComunicazioneProceduraSindacale:  SelectView[];

  constructor(
    private proposteService: ProposteService,
    private loginService: LoginService
  ) { }

  private async addDays(date, days) {
    const result = new Date(date.year, date.month - 1 , date.day);
    result.setDate(result.getDate() + days);
    return result;
  }

  private convert(d) {
    const date = new Date(d);
    return [date.getDate(), date.getMonth() + 1, date.getFullYear()].join('/');
  }

  ngOnChanges() {
    this.proceduraSindacale.get('necessariaProceduraSindacale').valueChanges.subscribe(changes => {
      if (changes === 'Si' && this.isNecessariaProceduraSindacaleCheck) {
        this.isRequired = true;
        this.proceduraSindacale.get('statoComunicazione').setValidators([Validators.required]);
        this.proceduraSindacale.get('dataInvioComunicazione').setValidators([Validators.required]);
        this.proceduraSindacale.get('periodoAttesaEsito').setValidators([Validators.required]);
        this.proceduraSindacale.get('statoComunicazione').updateValueAndValidity();
        this.proceduraSindacale.get('dataInvioComunicazione').updateValueAndValidity();
        this.proceduraSindacale.get('periodoAttesaEsito').updateValueAndValidity();
      } else {
        this.isRequired = false;
        this.proceduraSindacale.get('statoComunicazione').setValidators(null);
        this.proceduraSindacale.get('dataInvioComunicazione').setValidators(null);
        this.proceduraSindacale.get('periodoAttesaEsito').setValidators(null);
        this.proceduraSindacale.get('statoComunicazione').updateValueAndValidity();
        this.proceduraSindacale.get('dataInvioComunicazione').updateValueAndValidity();
        this.proceduraSindacale.get('periodoAttesaEsito').updateValueAndValidity();
      }
    });
  }
  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasPropostaReadOnly = operationModel ? operationModel.hasPropostaReadOnly : '';
  }

  async setScadenzaRiscontro() {
    const date = this.proceduraSindacale.get('dataInvioComunicazione').value;
    const period = this.proceduraSindacale.get('periodoAttesaEsito').value;
    const scadenzaRiscontro = await this.addDays(date, period);
    this.scadenzaRiscontro = await this.convert(scadenzaRiscontro);
    this.proceduraSindacale.get('scadenzaRiscontro').setValue(this.scadenzaRiscontro);
    this.proceduraSindacale.get('scadenzaRiscontro').updateValueAndValidity();
  }
}
