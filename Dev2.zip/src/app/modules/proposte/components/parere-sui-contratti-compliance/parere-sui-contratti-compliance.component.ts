import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { SelectView } from 'src/app/shared/models/selectView';
import { LoginService } from 'src/app/shared/services/login.service';

@Component({
  selector: 'reg-parere-sui-contratti-compliance',
  templateUrl: './parere-sui-contratti-compliance.component.html',
  styleUrls: ['./parere-sui-contratti-compliance.component.scss']
})
export class ParereSuiContrattiComplianceComponent implements OnInit {
  @Input() areaNormativa:  SelectView[];
  hasPropostaReadOnly: boolean;
  @Input() isProposalCompleted: boolean;
  @Input() livelloDiAdeguatezzaStatoComunicazione:  SelectView[];
  @Input() livelloDiRischioDiNonConformita:  SelectView[];
  @Input() pareresuiContrattiComplianceList: FormArray;

  constructor(
    private loginService: LoginService
 ) { }

 formatNparere(index, input) {
  input = input.replace(/[\W\s\._\-]+/g, '');
  let split = 4;
  const chunk = [];
  for (let i = 0, len = input.length; i < len; i += split) {
    split = ( i >= 0 && i <= 4 ) ? 4 : 100;
    chunk.push( input.substr( i, split ) );
  }
  this.pareresuiContrattiComplianceList.controls[index].get('nparere').setValue(chunk.join('_'));
}

inserisciNuovoParere() {
    if (!this.isProposalCompleted) {
      const pareresuiContrattiComplianceFormGroup = new FormGroup({
        parereSuiContrattiComplianceId: new FormControl(null),
        contrattoId: new FormControl(null),
        dataParere: new FormControl(null, [Validators.required]),
        areaNormativa: new FormControl('', [Validators.required]),
        livelloRischioNonConformita: new FormControl('', [Validators.required]),
        livelloDiAdeguatezza: new FormControl('', [Validators.required]),
        statoCompletoCompliance: new FormControl('complete'),
        // nparere: new FormControl('', [Validators.required, Validators.pattern('[0-9]{4}_[0-9]{3}')])
        nparere: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(8)]),
      });
      this.pareresuiContrattiComplianceList.push(pareresuiContrattiComplianceFormGroup);
    }
  }

  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasPropostaReadOnly = operationModel ? operationModel.hasPropostaReadOnly : '';
    // console.log('this.pareresuiContrattiComplianceList.controls==>>', this.pareresuiContrattiComplianceList.controls);
    // if (!this.pareresuiContrattiComplianceList.controls) {
    //   this.inserisciNuovoParere();
    // }
  }


}
