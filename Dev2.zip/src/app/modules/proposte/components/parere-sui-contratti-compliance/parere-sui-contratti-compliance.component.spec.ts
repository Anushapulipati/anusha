import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ParereSuiContrattiComplianceComponent } from './parere-sui-contratti-compliance.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';

describe('ParereSuiContrattiComplianceComponent', () => {
  let component: ParereSuiContrattiComplianceComponent;
  let fixture: ComponentFixture<ParereSuiContrattiComplianceComponent>;
  let pareresuiContrattiComplianceForm;
  let contrattoForm;

  const translation: any = {
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translation);
    }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ParereSuiContrattiComplianceComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        NgbModule,
        HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    contrattoForm = new FormGroup({
      contrattoId: new FormControl(null),
      commonContrattoId: new FormControl(null),
      codiceContrattoPadre: new FormControl(null),
      propostaFornitoreId: new FormControl(),
      oggettoDelContratto: new FormControl('', [Validators.required]),
      terminiPreavvisoFornitore: new FormControl(''),
      terminiPreavvisoCliente: new FormControl(''),
      costoAttivita: new FormControl(''),
      fornitoriAlternativi: new FormControl('', [Validators.required]),
      numeroSubfornitori: new FormControl(0, [Validators.required]),
      subFornitore: new FormControl([]),
      societaGruppoCliente: new FormControl('', [Validators.required]),
      parereSuiContrattiRischiList: new FormArray([
        new FormGroup({
          parereSuiContrattiRischiId: new FormControl(null),
          contrattoId: new FormControl(null),
          dataParere: new FormControl(null, [Validators.required]),
          livelloDiRischiosita: new FormControl('', [Validators.required]),
          statoCompletoRischi: new FormControl('complete'),
          nparereRischio: new FormControl('', [Validators.minLength(5), Validators.maxLength(8)]),
        })
      ]),
      pareresuiContrattiComplianceList: new FormArray([
        new FormGroup({
          parereSuiContrattiComplianceId: new FormControl(null),
          contrattoId: new FormControl(null),
          dataParere: new FormControl(null, [Validators.required]),
          areaNormativa: new FormControl('', [Validators.required]),
          livelloRischioNonConformita: new FormControl('', [Validators.required]),
          livelloDiAdeguatezza: new FormControl('', [Validators.required]),
          statoCompletoCompliance: new FormControl('complete'),
          nparere: new FormControl('nparere', [Validators.required, Validators.minLength(5), Validators.maxLength(8)])
        })
      ]),
      societaClienteDatApprovazione: new FormControl(null),
      societaClienteApprovatoreFinale: new FormControl(''),
      fornitoreInfragruppoDataDi: new FormControl(null),
      fornitoreInfragruppoFinale: new FormControl(''),
      autoritaCompetente: new FormControl(''),
      statoComunicazioneAdv: new FormControl('stato'),
      dataInvioComunicazioneAdv: new FormControl('23/12/2020'),
      statoCompletoAdv: new FormControl('complete'), // Invio Ad ADV
      statoCompletoProcedura: new FormControl('complete'), // Procedura Sindacale
      statoCompletoCDA: new FormControl('complete'), // APPROVAZINOE ORGANO DI SUPERVISIONE STRATEGICA
      necessariaProceduraSindacale: new FormControl('', [Validators.required]),
      statoComunicazione: new FormControl(''),
      dataInvioComunicazione: new FormControl('23/12/2020'),
      periodoAttesaEsito: new FormControl(1),
      scadenzaRiscontro: new FormControl(null),
      servizioList: new FormControl([]),
      completoOrInCompleto: new FormControl(false),
    });
   
    fixture = TestBed.createComponent(ParereSuiContrattiComplianceComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
    component.isProposalCompleted = false;
    component.pareresuiContrattiComplianceList = contrattoForm.get('pareresuiContrattiComplianceList').value;
  });

 it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call ngOnInit', () => {
    // spyOn(component, 'ngOnInit');
    component.ngOnInit();
    // expect(component.ngOnInit).toHaveBeenCalled();
    // expect(component.servizioListData).toBeDefined();
  });
  it('should call inserisciNuovoParere', () => {
    // spyOn(component, 'inserisciNuovoParere');
    console.log('controls', component.pareresuiContrattiComplianceList.controls);
    component.inserisciNuovoParere();
    // component.formatNparere(0, 'nparere');
    // expect(component.inserisciNuovoParere).toHaveBeenCalled();
    expect(component.isProposalCompleted).toBeDefined();
    expect(component.isProposalCompleted).toBe(false);
  });
});
