import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvioAdAdvComponent } from './invio-ad-adv.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';

import { FormsModule, ReactiveFormsModule, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientTestingModule } from '@angular/common/http/testing';


describe('InvioAdAdvComponent', () => {
  let component: InvioAdAdvComponent;
  let fixture: ComponentFixture<InvioAdAdvComponent>;
  let contrattoForm;

  const translation: any = {
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translation);
    }
  }


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvioAdAdvComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        FeDghubComponentLibraryModule,
        HttpClientTestingModule ,
        NgbModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    contrattoForm = new FormGroup({
      contrattoId: new FormControl(null),
      commonContrattoId: new FormControl(null),
      codiceContrattoPadre: new FormControl(null),
      propostaFornitoreId: new FormControl(),
      oggettoDelContratto: new FormControl('', [Validators.required]),
      terminiPreavvisoFornitore: new FormControl(''),
      terminiPreavvisoCliente: new FormControl(''),
      costoAttivita: new FormControl(''),
      fornitoriAlternativi: new FormControl('', [Validators.required]),
      numeroSubfornitori: new FormControl(0, [Validators.required]),
      subFornitore: new FormControl([]),
      societaGruppoCliente: new FormControl('', [Validators.required]),
      parereSuiContrattiRischiList: new FormArray([
        new FormGroup({
          parereSuiContrattiRischiId: new FormControl(null),
          contrattoId: new FormControl(null),
          dataParere: new FormControl(null, [Validators.required]),
          livelloDiRischiosita: new FormControl('', [Validators.required]),
          statoCompletoRischi: new FormControl('complete'),
          nparereRischio: new FormControl('', [Validators.minLength(5), Validators.maxLength(8)]),
        })
      ]),
      pareresuiContrattiComplianceList: new FormArray([
        new FormGroup({
          parereSuiContrattiComplianceId: new FormControl(null),
          contrattoId: new FormControl(null),
          dataParere: new FormControl(null, [Validators.required]),
          areaNormativa: new FormControl('', [Validators.required]),
          livelloRischioNonConformita: new FormControl('', [Validators.required]),
          livelloDiAdeguatezza: new FormControl('', [Validators.required]),
          statoCompletoCompliance: new FormControl('complete'),
          nparere: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(8)])
        })
      ]),
      societaClienteDatApprovazione: new FormControl(null),
      societaClienteApprovatoreFinale: new FormControl(''),
      fornitoreInfragruppoDataDi: new FormControl(null),
      fornitoreInfragruppoFinale: new FormControl(''),
      autoritaCompetente: new FormControl(''),
      statoComunicazioneAdv: new FormControl('stato'),
      dataInvioComunicazioneAdv: new FormControl('23/12/2020'),
      statoCompletoAdv: new FormControl('complete'), // Invio Ad ADV
      statoCompletoProcedura: new FormControl('complete'), // Procedura Sindacale
      statoCompletoCDA: new FormControl('complete'), // APPROVAZINOE ORGANO DI SUPERVISIONE STRATEGICA
      necessariaProceduraSindacale: new FormControl('', [Validators.required]),
      statoComunicazione: new FormControl(''),
      dataInvioComunicazione: new FormControl('23/12/2020'),
      periodoAttesaEsito: new FormControl(1),
      scadenzaRiscontro: new FormControl(null),
      servizioList: new FormControl([]),
      completoOrInCompleto: new FormControl(false),
    });
    fixture = TestBed.createComponent(InvioAdAdvComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
    component.isInvioAdAdvMandatory = true;
    component.invioAdAdv = contrattoForm;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should check is required value', () => {
    spyOn(component, 'ngOnInit');
    component.ngOnInit();
   component.isInvioAdAdvMandatory = true;
   expect(component.isInvioAdAdvMandatory).toEqual(true);
  });

  it('should show label names', () => {
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('label').textContent).toContain(' ');
  });
  it('should call ngOnInit', () => {
    spyOn(component, 'ngOnInit');
    component.ngOnInit();
    expect(component.ngOnInit).toHaveBeenCalled();
  });

  it('should check form fields', () => {
    fixture.detectChanges();
    component.invioAdAdv.controls['statoComunicazioneAdv'].setValue(contrattoForm.get('statoComunicazioneAdv').value);
    expect(component.invioAdAdv.controls['statoComunicazioneAdv'].value).toBe('stato');
    component.invioAdAdv.controls['dataInvioComunicazioneAdv'].setValue(contrattoForm.get('dataInvioComunicazioneAdv').value);
    expect(component.invioAdAdv.controls['dataInvioComunicazioneAdv'].value).toBe('23/12/2020');
    component.invioAdAdv.controls['statoComunicazioneAdv'].updateValueAndValidity();
    component.invioAdAdv.controls['dataInvioComunicazioneAdv'].updateValueAndValidity();
  })
});
