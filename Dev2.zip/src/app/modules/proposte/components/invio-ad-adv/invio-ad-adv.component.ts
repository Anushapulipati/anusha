import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { SelectView } from 'src/app/shared/models/selectView';
import { LoginService } from 'src/app/shared/services/login.service';

@Component({
  selector: 'reg-invio-ad-adv',
  templateUrl: './invio-ad-adv.component.html',
  styleUrls: ['./invio-ad-adv.component.scss']
})
export class InvioAdAdvComponent implements OnInit {
  @Input() autoriaCompetente:  SelectView[];
  hasPropostaReadOnly: boolean;
  @Input() invioAdAdv: FormGroup;
  @Input() isInvioAdAdvMandatory: boolean;
  isRequired: boolean;
  @Input() statoComunicazioneProceduraSindacale:  SelectView[];
  constructor(
    private loginService: LoginService
  ) { }

  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasPropostaReadOnly = operationModel ? operationModel.hasPropostaReadOnly : '';
    if (this.isInvioAdAdvMandatory) {
      this.isRequired = true;
      this.invioAdAdv.get('statoComunicazioneAdv').setValidators([Validators.required]);
      this.invioAdAdv.get('statoComunicazioneAdv').setValidators([Validators.required]);
      this.invioAdAdv.get('dataInvioComunicazioneAdv').setValidators([Validators.required]);
      this.invioAdAdv.get('statoComunicazioneAdv').updateValueAndValidity();
      this.invioAdAdv.get('statoComunicazioneAdv').updateValueAndValidity();
      this.invioAdAdv.get('dataInvioComunicazioneAdv').updateValueAndValidity();
    }
  }
}
