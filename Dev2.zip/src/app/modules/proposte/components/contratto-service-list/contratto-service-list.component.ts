import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
// tslint:disable-next-line: max-line-length
import { LinkContrattoServizioPopUpComponent } from '../../components/link-contratto-servizio-pop-up/link-contratto-servizio-pop-up.component';
import { ServizioDetailsVm } from 'src/app/shared/models/servizioDetailsVm';
import { LoginService } from 'src/app/shared/services/login.service';

@Component({
  selector: 'reg-contratto-service-list',
  templateUrl: './contratto-service-list.component.html',
  styleUrls: ['./contratto-service-list.component.scss']
})
export class ContrattoServiceListComponent implements OnChanges, OnInit {
  hasPropostaReadOnly: boolean;
  @Input() isProposalCompleted: boolean;
  @Input() linkedServizioList: ServizioDetailsVm[];
  @Input() parentForm: FormGroup;
  @Input() servizioList: ServizioDetailsVm[];

  constructor(
    private _modalService: NgbModal,
    private loginService: LoginService
  ) { }

  linkContrattoServices() {
    if (!this.isProposalCompleted) {
      const serviceModalRef = this._modalService.open(LinkContrattoServizioPopUpComponent, {
        backdrop: 'static'
      });
      serviceModalRef.componentInstance.servizioList = this.servizioList;
      serviceModalRef.componentInstance.linkedServizioList = this.linkedServizioList;
      serviceModalRef.result.then((linkedServices) => {
        if (linkedServices) {
          this.linkedServizioList = linkedServices.map(linkedService => {
            return this.servizioList.filter(service => service.servizioId === linkedService)[0];
          });
          this.parentForm.get('servizioList').setValue(linkedServices);
        }
      });
    }
  }

  ngOnChanges() {
    if (this.linkedServizioList) {
      this.linkedServizioList = this.linkedServizioList.map(linkedService => {
        return this.servizioList.filter(service => service.servizioId === linkedService.servizioId)[0];
      });
      const servizioIds = this.linkedServizioList.map(servizio => servizio.servizioId);
      this.parentForm.get('servizioList').setValue(servizioIds);
      this.parentForm.get('servizioList').updateValueAndValidity();
    }
  }

  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasPropostaReadOnly = operationModel ? operationModel.hasPropostaReadOnly : '';
  }
}
