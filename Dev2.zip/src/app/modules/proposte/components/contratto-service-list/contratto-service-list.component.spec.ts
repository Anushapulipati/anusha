import { async, ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';

import { ContrattoServiceListComponent } from './contratto-service-list.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { HttpClientModule } from '@angular/common/http';
import { LinkContrattoServizioPopUpComponent } from '../link-contratto-servizio-pop-up/link-contratto-servizio-pop-up.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AppModule } from 'src/app/app.module';

describe('ContrattoServiceListComponent', () => {
  let component: ContrattoServiceListComponent;
  let fixture: ComponentFixture<ContrattoServiceListComponent>;
  let contrattoForm;
  let servizioList;
  let linkedServizioList;
  const translation: any = {
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translation);
    }
  }


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContrattoServiceListComponent],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        AppModule,
        FormsModule,
        ReactiveFormsModule,
        FeDghubComponentLibraryModule,
        HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    contrattoForm = new FormGroup({
      contrattoId: new FormControl(null),
      commonContrattoId: new FormControl(null),
      codiceContrattoPadre: new FormControl(null),
      propostaFornitoreId: new FormControl(),
      oggettoDelContratto: new FormControl('', [Validators.required]),
      terminiPreavvisoFornitore: new FormControl(''),
      terminiPreavvisoCliente: new FormControl(''),
      costoAttivita: new FormControl(''),
      fornitoriAlternativi: new FormControl('', [Validators.required]),
      numeroSubfornitori: new FormControl(0, [Validators.required]),
      subFornitore: new FormControl([]),
      societaGruppoCliente: new FormControl('', [Validators.required]),
      parereSuiContrattiRischiList: new FormArray([
        new FormGroup({
          parereSuiContrattiRischiId: new FormControl(null),
          contrattoId: new FormControl(null),
          dataParere: new FormControl(null, [Validators.required]),
          livelloDiRischiosita: new FormControl('', [Validators.required]),
          statoCompletoRischi: new FormControl('complete'),
          nparereRischio: new FormControl('', [Validators.minLength(5), Validators.maxLength(8)]),
        })
      ]),
      pareresuiContrattiComplianceList: new FormArray([
        new FormGroup({
          parereSuiContrattiComplianceId: new FormControl(null),
          contrattoId: new FormControl(null),
          dataParere: new FormControl(null, [Validators.required]),
          areaNormativa: new FormControl('', [Validators.required]),
          livelloRischioNonConformita: new FormControl('', [Validators.required]),
          livelloDiAdeguatezza: new FormControl('', [Validators.required]),
          statoCompletoCompliance: new FormControl('complete'),
          nparere: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(8)])
        })
      ]),
      societaClienteDatApprovazione: new FormControl(null),
      societaClienteApprovatoreFinale: new FormControl(''),
      fornitoreInfragruppoDataDi: new FormControl(null),
      fornitoreInfragruppoFinale: new FormControl(''),
      autoritaCompetente: new FormControl(''),
      statoComunicazioneAdv: new FormControl(''),
      dataInvioComunicazioneAdv: new FormControl(null),
      statoCompletoAdv: new FormControl('complete'), // Invio Ad ADV
      statoCompletoProcedura: new FormControl('complete'), // Procedura Sindacale
      statoCompletoCDA: new FormControl('complete'), // APPROVAZINOE ORGANO DI SUPERVISIONE STRATEGICA
      necessariaProceduraSindacale: new FormControl('', [Validators.required]),
      statoComunicazione: new FormControl(''),
      dataInvioComunicazione: new FormControl('23/12/2020'),
      periodoAttesaEsito: new FormControl(1),
      scadenzaRiscontro: new FormControl(null),
      servizioList: new FormControl([]),
      completoOrInCompleto: new FormControl(false),
    });
    // tslint:disable-next-line: max-line-length
    servizioList = [{'servizioId': 434, 'propostaFornitoreId': 367, 'marcoProcesso': '', 'racConDeiPro': '', 'servizioInfrastrttra': '', 'tipologiaDiCloud': '', 'possibilitaDiRei': '', 'sostituibilita': '', 'classificazioneOne': 'Fornitura', 'classificazioneTipo': 'Fornitura', 'datiPersonali': '', 'sogliaFunzione': null, 'funzioneEsternalizzata': '', 'funzioneImportante': '', 'ultimaValutazioneData': null, 'sintesideiMotivi': '', 'paeseDiVieneSvolto': '', 'paesediconDati': '', 'cloudpaesediCon': '', 'descrizioneDel': '', 'tipologiaDaDati': null, 'cloudNaturaDaDati': null, 'livelloDiRischiosita': '', 'breveRischiosita': '', 'completoStato': 'complete', 'categoriaBankIt': null, 'sottocategoriaBankIt': null, 'servizioName': 'wdwdw', 'categoriaEba': null}];
    // tslint:disable-next-line: max-line-length
    linkedServizioList = [{'servizioId': 425, 'propostaFornitoreId': 364, 'marcoProcesso': '', 'racConDeiPro': '', 'servizioInfrastrttra': '', 'tipologiaDiCloud': '', 'possibilitaDiRei': '', 'sostituibilita': '', 'classificazioneOne': 'Esternalizzazione', 'classificazioneTipo': 'Fornitura', 'datiPersonali': '', 'sogliaFunzione': null, 'funzioneEsternalizzata': '', 'funzioneImportante': 'No', 'ultimaValutazioneData': null, 'sintesideiMotivi': '', 'paeseDiVieneSvolto': '', 'paesediconDati': '', 'cloudpaesediCon': '', 'descrizioneDel': '', 'tipologiaDaDati': null, 'cloudNaturaDaDati': null, 'livelloDiRischiosita': '', 'breveRischiosita': '', 'completoStato': 'complete', 'categoriaBankIt': 'Categoria dell attività esternalizzata: sistema informativo', 'sottocategoriaBankIt': 'Centro dati operativo2', 'servizioName': 'fornitura - 1 spa', 'categoriaEba': null}, {'servizioId': 426, 'propostaFornitoreId': 364, 'marcoProcesso': 'Raccordo con albero dei Processi(Macroprocesso)*', 'racConDeiPro': 'Raccordo con albero dei Processi(Processo)*', 'servizioInfrastrttra': 'Si', 'tipologiaDiCloud': 'Cloud Ibrido', 'possibilitaDiRei': 'Si', 'sostituibilita': 'Difficile', 'classificazioneOne': 'Esternalizzazione', 'classificazioneTipo': 'Esternalizzazione', 'datiPersonali': 'Si', 'sogliaFunzione': 4, 'funzioneEsternalizzata': 'Si', 'funzioneImportante': 'Si', 'ultimaValutazioneData': '02/12/2020', 'sintesideiMotivi': 'Breve sintesi dei motivi per cui la funzione è essenziale o importante *', 'paeseDiVieneSvolto': 'Paese in cui il servizio viene svolto*', 'paesediconDati': 'Paese di conservazione dei dati*', 'cloudpaesediCon': 'Cloud - Paese di conservazione dati*', 'descrizioneDel': 'Descrizione del servizio erogato*', 'tipologiaDaDati': ['Transazioni economiche update', ' Affidabilità bancaria (Informazioni sulla affidabilità bancaria del soggetto)'], 'cloudNaturaDaDati': ['Transazioni economiche update', 'Autenticazione (Informazioni utili per l\'autenticazione individuale)'], 'livelloDiRischiosita': 'Rischio Basso', 'breveRischiosita': 'Breve sintesi sul livello di rischiosità*', 'completoStato': 'complete', 'categoriaBankIt': 'rapporti con la clientela update', 'sottocategoriaBankIt': 'Supporto alla clientela (call centre)', 'servizioName': 'FEI - 1 SPA', 'categoriaEba': 'Manutenzione delle aree verdi'}];
    fixture = TestBed.createComponent(ContrattoServiceListComponent);
    component = fixture.componentInstance;
    component.servizioList = servizioList;
    component.linkedServizioList = linkedServizioList;
    component.parentForm = contrattoForm;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngoninit', () => {
    fixture.detectChanges();
    // spyOn(component, 'ngOnInit');
    component.ngOnInit();
    // expect(component.ngOnInit).toHaveBeenCalled();
  });

 /*  it('should call link services method', fakeAsync( () => {
    fixture.detectChanges();
    spyOn(component, 'linkContrattoServices');
    const button = fixture.debugElement.nativeElement.querySelector('li');
    button.click();
    tick();
    fixture.whenStable().then(() => {
      expect(component.linkContrattoServices).toHaveBeenCalled();
    });
  })); */

  it('should check servizio list value', () => {
    const servizioList: any = [
      {
    breveRischiosita: 'breveRischiosita',
    categoriaBankIt: 'categoriaBankIt',
    categoriaEba: 'categoriaEba',
    classificazioneOne: 'classificazioneOne',
    classificazioneTipo: 'classificazioneTipo',
    cloudNaturaDati: 'cloudNaturaDati',
    cloudpaesediCon: 'cloudpaesediCon',
    completoStato: 'completoStato',
    datiPersonali: 'datiPersonali',
    descrizioneDel: 'descrizioneDel',
    funzioneEsternalizzata: 'funzioneEsternalizzata',
    funzioneImportante: 'funzioneImportante',
    livelloDiRischiosita: 'livelloDiRischiosita',
    marcoProcesso: 'marcoProcesso',
    paesediconDati: 'paesediconDati',
    paeseDiVieneSvolto: 'paeseDiVieneSvolto',
    possibilitaDiRei: 'possibilitaDiRei',
    propostaFornitoreId: 12,
    racConDeiPro: 'racConDeiPro',
    servizioId: 2,
    servizioInfrastrttra: 'servizioInfrastrttra',
    servizioName: 'servizioName',
    sintesideiMotivi: 'sintesideiMotivi',
    sogliaFunzione: 4,
    sostituibilita: 'sostituibilita',
    sottocategoriaBankIt: 'sottocategoriaBankIt',
    tipologiaDatiDa: 'tipologiaDatiDa',
    tipologiaDiCloud: 'tipologiaDiCloud',
    ultimaValutazioneData: '20/12/2020'
      }
    ];
    // fixture.detectChanges();
    component.isProposalCompleted = true;
    component.servizioList = servizioList;
    expect(component.servizioList).toBeDefined();

  });
  it('should call linkContrattoServices', () => {
    // spyOn(component, 'linkContrattoServices');
    component.linkContrattoServices();
    // expect(component.linkContrattoServices).toHaveBeenCalled();
  });
  it('should call ngOnChanges', () => {
    // tslint:disable-next-line: max-line-length
    const servizioList: any  = [{'contrattoId': 389, 'sevrizioLista': [{'servizioId': 421, 'servizioName': '13 - fornitura - fornitore x'}], 'societaGruppoCliente': 'SV Banca', 'commonContrattoId': 33}];
 
   
    // component.linkedServizioList = {};
    // spyOn(component, 'ngOnChanges');
    //component.ngOnChanges();
    // expect(component.ngOnChanges).toHaveBeenCalled();
    // expect(component.parentForm.get('servizioList').value).toEqual([]);
  });
});
