import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { ClientVm } from 'src/app/shared/models/clientVm';
import { FornitoreDetailsVm } from 'src/app/shared/models/fornitoreDetailsVm';
import { LoginService } from 'src/app/shared/services/login.service';
import { Router } from '@angular/router';
@Component({
  selector: 'reg-nuovo-contratto-base',
  templateUrl: './nuovo-contratto-base.component.html',
  styleUrls: ['./nuovo-contratto-base.component.scss']
})
export class NuovoContrattoBaseComponent implements OnInit {
  @Input() clientDetails: ClientVm[];
  dropdownSettings = {
    singleSelection: true,
    idField: 'clientiId',
    textField: 'nomeSocieta',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    itemsShowLimit: 3,
    allowSearchFilter: true
  };
  @Input() fornitoreDetails: FornitoreDetailsVm;
  fornitoreDropdownSettings = {
    singleSelection: false,
    idField: 'fornitoreId',
    textField: 'nomeSocieta',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    itemsShowLimit: 3,
    allowSearchFilter: true
  };
  hasPropostaReadOnly: boolean;
  isRequired: boolean;
  @Input() parentForm: FormGroup;
  @Input() propostaDetails: any;
  @Input() registroId: number;
  selectedValue: any;
  @Output() societaSelectedValue = new EventEmitter();
  @Input() subFornitore: FornitoreDetailsVm;
  constructor(
    private loginService: LoginService,
    private router: Router
  ) { }

  ngOnInit() {
   const operationModel: any = this.loginService.getOperationModel();
    this.hasPropostaReadOnly = operationModel ? operationModel.hasPropostaReadOnly : '';
    this.parentForm.get('numeroSubfornitori').valueChanges.subscribe(changes => {
      if (changes > 0) {
        this.isRequired = true;
        this.parentForm.get('subFornitore').setValidators([Validators.required]);
        this.parentForm.get('subFornitore').updateValueAndValidity();
      } else {
        this.isRequired = false;
        this.parentForm.get('subFornitore').setValidators(null);
        this.parentForm.get('subFornitore').updateValueAndValidity();
      }
    });
  }

  onSelect(selectedValue) {
    this.selectedValue = selectedValue;
    this.societaSelectedValue.emit(this.selectedValue);
    this.parentForm.get('societaGruppoCliente').patchValue([selectedValue]);
    this.parentForm.get('societaGruppoCliente').updateValueAndValidity();
  }

  getFornitorePage(propostaId, fornitoreId) {
    if (this.registroId) {
      this.router.navigate(['/anagarfe/nuovo-fornitore', this.registroId, propostaId, fornitoreId]);
    } else {
      this.router.navigate(['/anagarfe/nuovo-fornitore', propostaId, fornitoreId]);
    }

  }
 }
