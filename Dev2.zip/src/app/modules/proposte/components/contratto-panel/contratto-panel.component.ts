import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ProposteService } from '../../services/proposte.service';
import { LinkContrattoServizioPopUpComponent } from '../link-contratto-servizio-pop-up/link-contratto-servizio-pop-up.component';
import { ServizioDetailsVm } from 'src/app/shared/models/servizioDetailsVm';
import { LoginService } from '../../../../shared/services/login.service';

@Component({
  selector: 'reg-contratto-panel',
  templateUrl: './contratto-panel.component.html',
  styleUrls: ['./contratto-panel.component.scss']
})
export class ContrattoPanelComponent implements OnInit {
  @Input() contratto: any;
  @Input() fornitoreID: number;
  hasPropostaReadOnly: boolean;
  @Input() isProposalCompleted: boolean;
  @Input() linkedServizioList: ServizioDetailsVm[];
  opened = true;
  @Input() propostaFornitoreId: number;
  @Input() propostaId: number;
  @Input() servizioList: ServizioDetailsVm[];
  constructor(
    private _modalService: NgbModal,
    private router: Router,
    private proposteService: ProposteService,
    private loginService: LoginService
  ) { }

  linkContrattoServices() {
    if (!this.isProposalCompleted) {
      const serviceModalRef = this._modalService.open(LinkContrattoServizioPopUpComponent, {
        backdrop: 'static'
      });
      serviceModalRef.componentInstance.servizioList = this.servizioList;
      serviceModalRef.componentInstance.linkedServizioList = this.linkedServizioList;
      serviceModalRef.result.then((linkedServices) => {
        if (linkedServices) {
          this.linkedServizioList = linkedServices.map(linkedService => {
            return this.servizioList.filter(service => service.servizioId === linkedService)[0];
          });
          this.contratto.sevrizioLista = this.linkedServizioList;
          const contratto = {
            contrattoId: this.contratto.contrattoId,
            servizioList: linkedServices,
            propostaFornitoreId: this.propostaFornitoreId
          };
          this.proposteService.saveServizioListInServizioPage(contratto).subscribe(contrattoServices => {
          });
          // this.parentForm.get('servizioList').setValue(linkedServices);
        }
      });
    }
  }

  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasPropostaReadOnly = operationModel ? operationModel.hasPropostaReadOnly : '';
    this.linkedServizioList = this.contratto.sevrizioLista;
  }

  openContrattoPage() {
    this.router.navigate(['/proposte/nuovo-contratto',
      this.propostaId,
      this.propostaFornitoreId,
      this.contratto.contrattoId,
      this.fornitoreID
    ]);
  }
}
