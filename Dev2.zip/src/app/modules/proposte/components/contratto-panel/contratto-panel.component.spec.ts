import { async, ComponentFixture, TestBed, tick, fakeAsync } from '@angular/core/testing';

import { ContrattoPanelComponent } from './contratto-panel.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { HttpClientModule } from '@angular/common/http';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ProposteService } from '../../services/proposte.service';
import { AppModule } from 'src/app/app.module';
import { LoginService } from 'src/app/shared/services/login.service';

describe('ContrattoPanelComponent', () => {
  let component: ContrattoPanelComponent;
  let fixture: ComponentFixture<ContrattoPanelComponent>;
  let proposteService;
  let loginService;
  const router = {
    navigate: jasmine.createSpy('navigate'),
    myMethod: () => {}
  };

  const translation: any = {
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translation);
    }
  }

  beforeEach(async(() => {
    proposteService = jasmine.createSpyObj(['saveServizioListInServizioPage', ]);
    loginService = jasmine.createSpyObj(['getOperationModel']);
    TestBed.configureTestingModule({
      declarations: [ ContrattoPanelComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        AppModule,
        FormsModule,
        ReactiveFormsModule,
        FeDghubComponentLibraryModule,
        HttpClientModule,
        RouterTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [ { provide: Router, useValue: router },
      {provide: ProposteService, useValue: proposteService},
      {provide: LoginService, useValue: loginService}
    ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const operationModel = {
      hasPropostaReadOnly: true,
    };
    loginService.getOperationModel.and.returnValue(of(operationModel));
    const getResponse = [
      {
         'idCategiriaInterna': 1,
         'categoriaEba': 'Infrastruttura globale di messaggistica finanziaria soggetta alla vigilanza delle pertinenti autorità'
      },
      {
         'idCategiriaInterna': 2,
         // tslint:disable-next-line: max-line-length
         'categoriaEba': 'Acquisizione di beni (e.g. tessere di plastica, lettori di carte, forniture per ufficio, personal computer, mobilio)'
      },
    ];
    proposteService.saveServizioListInServizioPage.and.returnValue(of(getResponse));
    fixture = TestBed.createComponent(ContrattoPanelComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
    const contratto: any = {
      sevrizioLista: [
        {
          id: 1,
        },
        {
          id: 2
        }
      ]


    };
    component.contratto = contratto;
    component.linkedServizioList = contratto.sevrizioLista;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call ngoninit', () => {
    spyOn(component, 'ngOnInit');
    component.ngOnInit();
    expect(component.ngOnInit).toHaveBeenCalled();
  });
  it('should call openContrattoPage', () => {
    // spyOn(component, 'openContrattoPage');
    component.openContrattoPage();
    // expect(component.openContrattoPage).toHaveBeenCalled();
  });
  it('should call linkContrattoServices', () => {
    // spyOn(component, 'linkContrattoServices');
    component.linkContrattoServices();
    // expect(component.linkContrattoServices).toHaveBeenCalled();
  });
  it('should call link services method', fakeAsync( () => {
    fixture.detectChanges();
    spyOn(component, 'linkContrattoServices');
    component.linkContrattoServices();
    const button = fixture.debugElement.nativeElement.querySelector('li');
    button.click();
    tick();
    fixture.whenStable().then(() => {
      expect(component.linkContrattoServices).toHaveBeenCalled();
    });
  }));

  it('should check servizio list value', () => {
    const servizioList: any = [
      {
    breveRischiosita: 'breveRischiosita',
    categoriaBankIt: 'categoriaBankIt',
    categoriaEba: 'categoriaEba',
    classificazioneOne: 'classificazioneOne',
    classificazioneTipo: 'classificazioneTipo',
    cloudNaturaDati: 'cloudNaturaDati',
    cloudpaesediCon: 'cloudpaesediCon',
    completoStato: 'completoStato',
    datiPersonali: 'datiPersonali',
    descrizioneDel: 'descrizioneDel',
    funzioneEsternalizzata: 'funzioneEsternalizzata',
    funzioneImportante: 'funzioneImportante',
    livelloDiRischiosita: 'livelloDiRischiosita',
    marcoProcesso: 'marcoProcesso',
    paesediconDati: 'paesediconDati',
    paeseDiVieneSvolto: 'paeseDiVieneSvolto',
    possibilitaDiRei: 'possibilitaDiRei',
    propostaFornitoreId: 12,
    racConDeiPro: 'racConDeiPro',
    servizioId: 2,
    servizioInfrastrttra: 'servizioInfrastrttra',
    servizioName: 'servizioName',
    sintesideiMotivi: 'sintesideiMotivi',
    sogliaFunzione: 4,
    sostituibilita: 'sostituibilita',
    sottocategoriaBankIt: 'sottocategoriaBankIt',
    tipologiaDatiDa: 'tipologiaDatiDa',
    tipologiaDiCloud: 'tipologiaDiCloud',
    ultimaValutazioneData: '20/12/2020'
      }
    ];
    fixture.detectChanges();
    component.isProposalCompleted = true;
    component.servizioList = servizioList;
    expect(component.servizioList).toBeDefined();

  });
});
