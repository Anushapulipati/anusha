import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddServizioPopUpComponent } from './add-servizio-pop-up.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

describe('AddServizioPopUpComponent', () => {
  let component: AddServizioPopUpComponent;
  let fixture: ComponentFixture<AddServizioPopUpComponent>;
  let activeModal: any;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddServizioPopUpComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: NgbActiveModal, useValue: activeModal },
        ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddServizioPopUpComponent);
    component = fixture.componentInstance;
    // component.modalName = 'servizio';
    // fixture.detectChanges();
    component.modalName = 'servizio';
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call ngoninit', () => {
    spyOn(component, 'ngOnInit');
    component.ngOnInit();
    expect(component.ngOnInit).toHaveBeenCalled();
  });

  it('should call submitModal', () => {
    spyOn(component, 'submitModal');
    component.submitModal();
    expect(component.submitModal).toHaveBeenCalled();
  });
  it('should call closeModal', () => {
    spyOn(component, 'closeModal');
    component.closeModal();
    expect(component.closeModal).toHaveBeenCalled();
  });
  it('should check modelname as servizio', () => {
    component.modalName = 'servizio';
    fixture.detectChanges();
    expect(component.modalName).toBe('servizio');
    expect(component.modalHeading).toBe('AGGIUNGI NUOVO SERVIZIO');
    expect(component.modalText).toBe('Vuoi creare un nuovo servizio per questa proposta?');
    expect(component.modalLabel).toBe('Nome del servizio');
    expect(component.btnName).toContain('Crea servizio');
  });
  it('should check modelname  as trattomento ', () => {
    component.modalName = 'trattomento';
    fixture.detectChanges();
    expect(component.modalName).toBe('trattomento');
    expect(component.modalHeading).toBe('Nuova categoria');
    expect(component.modalText).toBe('Inserire il nome da assegnare alla categoria');
    expect(component.modalLabel).toBe('Nome della categoria');
    expect(component.btnName).toContain('Crea Categoria');
  });
  it('should check modelname  as interne ', () => {
    component.modalName = 'interne';
    fixture.detectChanges();
    expect(component.modalName).toBe('interne');
    expect(component.modalHeading).toBe('Nuova categoria');
    expect(component.modalText).toBe('Inserire il nome da assegnare alla categoria');
    expect(component.modalLabel).toBe('Nome della categoria');
    expect(component.btnName).toContain('Crea Categoria');
  });
  it('should check modelname  as bankIt ', () => {
    component.modalName = 'bankIt';
    fixture.detectChanges();
    expect(component.modalName).toBe('bankIt');
    expect(component.modalHeading).toBe('Nuova categoria');
    expect(component.modalText).toBe('Inserire il nome da assegnare alla categoria');
    expect(component.modalLabel).toBe('Nome della categoria');
    expect(component.btnName).toContain('Crea Categoria');
  });
  it('should check modelname  as subbankIt ', () => {
    component.modalName = 'subbankIt';
    fixture.detectChanges();
    expect(component.modalName).toBe('subbankIt');
    expect(component.modalHeading).toBe('Nuova sotto categoria');
    expect(component.modalText).toBe('Inserire il nome da assegnare alla sotto categoria');
    expect(component.modalLabel).toBe('Nome della sotto categoria');
    expect(component.btnName).toContain('Crea Sotto Categoria');
  });
  it('should check modelname value ', () => {
    component.modalName = ' ';
    fixture.detectChanges();
    expect(component.modalHeading).toBe('Servizio non collegato ad alcun contratto');
    expect(component.modalText).toBe('Vuoi creare un nuovo contratto per questa fornitura?');
    expect(component.modalLabel).toBe('Nome del contratto');
    expect(component.btnName).toContain('Crea contratto');
  });
});
