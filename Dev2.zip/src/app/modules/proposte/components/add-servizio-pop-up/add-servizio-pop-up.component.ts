import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'reg-add-servizio-pop-up',
  templateUrl: './add-servizio-pop-up.component.html',
  styleUrls: ['./add-servizio-pop-up.component.scss']
})
export class AddServizioPopUpComponent implements OnInit {
  btnName: string;
  inputValue: string;
  modalHeading: string;
  modalLabel: string;
  @Input() public modalName;
  modalText: string;
  constructor(
    private activeModal: NgbActiveModal
  ) { }

  closeModal() {
    this.activeModal.close(false);
  }

  ngOnInit() {
    if (this.modalName === 'servizio') {
      this.modalHeading = 'AGGIUNGI NUOVO SERVIZIO';
      this.modalText = 'Vuoi creare un nuovo servizio per questa proposta?';
      this.modalLabel = 'Nome del servizio';
      this.btnName = 'Crea servizio';
    } else if (this.modalName === 'trattomento') {
      this.modalHeading = 'Nuova categoria';
      this.modalText = 'Inserire il nome da assegnare alla categoria';
      this.modalLabel = 'Nome della categoria';
      this.btnName = 'Crea Categoria';
    } else if (this.modalName === 'interne') {
      this.modalHeading = 'Nuova categoria';
      this.modalText = 'Inserire il nome da assegnare alla categoria';
      this.modalLabel = 'Nome della categoria';
      this.btnName = 'Crea Categoria';
    } else if (this.modalName === 'bankIt') {
      this.modalHeading = 'Nuova categoria';
      this.modalText = 'Inserire il nome da assegnare alla categoria';
      this.modalLabel = 'Nome della categoria';
      this.btnName = 'Crea Categoria';
    }  else if (this.modalName === 'subbankIt') {
      this.modalHeading = 'Nuova sotto categoria';
      this.modalText = 'Inserire il nome da assegnare alla sotto categoria';
      this.modalLabel = 'Nome della sotto categoria';
      this.btnName = 'Crea Sotto Categoria';
    } else {
      this.modalHeading = 'Servizio non collegato ad alcun contratto';
      this.modalText = 'Vuoi creare un nuovo contratto per questa fornitura?';
      this.modalLabel = 'Nome del contratto';
      this.btnName = 'Crea contratto';
    }
  }

  submitModal() {
    this.activeModal.close(this.inputValue);
  }
}
