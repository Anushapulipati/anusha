import { Component, Input, OnInit } from '@angular/core';
import { FormArray, FormControl, FormGroup, Validators } from '@angular/forms';
import { SelectView } from 'src/app/shared/models/selectView';
import { LoginService } from 'src/app/shared/services/login.service';
@Component({
  selector: 'reg-parert-sui-contratti-rischi',
  templateUrl: './parert-sui-contratti-rischi.component.html',
  styleUrls: ['./parert-sui-contratti-rischi.component.scss']
})
export class ParertSuiContrattiRischiComponent implements OnInit {
  hasPropostaReadOnly: boolean;
  @Input() isProposalCompleted: boolean;
  @Input() livello: SelectView[];
  @Input() parereSuiContrattiRischiList: FormArray;

  constructor(
    private loginService: LoginService
  ) { }

  formatNparere(index, input) {
    input = input.replace(/[\W\s\._\-]+/g, '');
    let split = 4;
    const chunk = [];
    for (let i = 0, len = input.length; i < len; i += split) {
      split = ( i >= 0 && i <= 4 ) ? 4 : 100;
      chunk.push( input.substr( i, split ) );
    }
    this.parereSuiContrattiRischiList.controls[index].get('nparereRischio').setValue(chunk.join('_'));
  }

  inserisciNuovoParere() {
    if (!this.isProposalCompleted) {
      const parereSuiContrattiRischiFormGroup = new FormGroup({
        parereSuiContrattiRischiId: new FormControl(null),
        contrattoId: new FormControl(null),
        dataParere: new FormControl(null, [Validators.required]),
        livelloDiRischiosita: new FormControl('', [Validators.required]),
        statoCompletoRischi: new FormControl('complete'),
        nparereRischio: new FormControl('', [Validators.minLength(5), Validators.maxLength(8)]),
      });
      // Validators.pattern('[0-9]{4}_[0-9]{3}'),
      this.parereSuiContrattiRischiList.push(parereSuiContrattiRischiFormGroup);
    }
  }

  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasPropostaReadOnly = operationModel ? operationModel.hasPropostaReadOnly : '';
  }
}
