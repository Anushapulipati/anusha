import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FooterActionComponent } from './footer-action.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { of, Observable } from 'rxjs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { HttpClientModule } from '@angular/common/http';

describe('FooterActionComponent', () => {
  let component: FooterActionComponent;
  let fixture: ComponentFixture<FooterActionComponent>;
  const translation: any = {
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translation);
    }
  }


  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FooterActionComponent ],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        FeDghubComponentLibraryModule,
        HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FooterActionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call salva', () => {
    fixture.detectChanges();
    
    component.salva();
    component.annulla();
    component.ngOnInit();
    
  });
  
});
