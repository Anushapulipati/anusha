import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';

@Component({
  selector: 'reg-footer-action',
  templateUrl: './footer-action.component.html',
  styleUrls: ['./footer-action.component.scss']
})
export class FooterActionComponent implements OnInit {
  @Output() annullaAction: EventEmitter<any> = new EventEmitter<any>();
  @Input() disabled: boolean;
  @Output() salvaAction: EventEmitter<any> = new EventEmitter<any>();

  constructor() { }

  annulla() {
    this.annullaAction.emit();
  }

  ngOnInit() {
  }

  salva() {
    this.salvaAction.emit();
  }
}
