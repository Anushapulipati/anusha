import { Component, Input, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { ContrattoDetailsVm } from 'src/app/shared/models/contrattoDetailsVm';
import { LoginService } from 'src/app/shared/services/login.service';

@Component({
  selector: 'reg-approvazinoe-organo-di-supervisione-strategica',
  templateUrl: './approvazinoe-organo-di-supervisione-strategica.component.html',
  styleUrls: ['./approvazinoe-organo-di-supervisione-strategica.component.scss']
})
export class ApprovazinoeOrganoDiSupervisioneStrategicaComponent implements OnInit {
  @Input() approvazinoeOrganoDiSupervisioneStrategica: FormGroup;
  @Input() clientDetails: ContrattoDetailsVm;
  dropdownSettings = {
    singleSelection: true,
    idField: 'clientiId',
    textField: 'nomeSocieta',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    itemsShowLimit: 3,
    allowSearchFilter: true
  };
  hasPropostaReadOnly: boolean;
  @Input() isInfragruppo: boolean;
  @Input() societaGruppoCliente: any;
  @Input() nomeSocieta: string;

  constructor(
    private loginService: LoginService
 ) { }



  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasPropostaReadOnly = operationModel ? operationModel.hasPropostaReadOnly : '';

  }

}
