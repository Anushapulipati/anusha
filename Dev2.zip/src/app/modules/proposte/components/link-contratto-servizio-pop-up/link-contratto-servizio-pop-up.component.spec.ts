import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LinkContrattoServizioPopUpComponent } from './link-contratto-servizio-pop-up.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { TreeviewItem, TreeviewConfig } from 'ngx-treeview';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';

describe('LinkContrattoServizioPopUpComponent', () => {
  let component: LinkContrattoServizioPopUpComponent;
  let fixture: ComponentFixture<LinkContrattoServizioPopUpComponent>;
  let treeViewItem;
  let treeViewConfig;
  let activeModal;


  const translation: any = {
  };

  class FakeLoader implements TranslateLoader {
    getTranslation(lang: string): Observable<any> {
      return of(translation);
    }
  }

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LinkContrattoServizioPopUpComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        NgbModule,
        FormsModule,
        ReactiveFormsModule,
        FeDghubComponentLibraryModule,
        HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: NgbActiveModal, useValue: activeModal },
        { provide: TreeviewItem, useValue: treeViewItem },
        { provide: TreeviewConfig, useValue: treeViewConfig },
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    // tslint:disable-next-line: max-line-length
    const servizioList: any  = [{'servizioId': 367, 'propostaFornitoreId': 318, 'marcoProcesso': 'Esternalizzazione - test fornitore - bper', 'racConDeiPro': 'Esternalizzazione - test fornitore - bper', 'servizioInfrastrttra': 'No', 'tipologiaDiCloud': 'Cloud Ibrido', 'possibilitaDiRei': 'Si', 'sostituibilita': 'Facile', 'classificazioneOne': 'Fornitura', 'classificazioneTipo': 'Fornitura', 'datiPersonali': 'Si', 'sogliaFunzione': 44, 'funzioneEsternalizzata': 'No', 'funzioneImportante': 'Si', 'ultimaValutazioneData': '08/12/2020', 'sintesideiMotivi': 'Esternalizzazione - test fornitore - bper', 'paeseDiVieneSvolto': 'Esternalizzazione - test fornitore - bper', 'paesediconDati': 'Esternalizzazione - test fornitore - bper', 'cloudpaesediCon': 'Esternalizzazione - test fornitore - bper', 'descrizioneDel': 'Esternalizzazione - test fornitore - bper', 'tipologiaDaDati': null, 'cloudNaturaDaDati': null, 'livelloDiRischiosita': 'Rischio Basso', 'breveRischiosita': 'Esternalizzazione - test fornitore - bper', 'completoStato': 'incomplete', 'categoriaBankIt': 'Categoria dell attività esternalizzata: sistema informativo', 'sottocategoriaBankIt': 'Se si "Altro o dettagli" specificare qui:', 'servizioName': 'Esternalizzazione - test fornitore - bper', 'categoriaEba': 'Infrastruttura di rete globale (e.g. Visa, MasterCard)'}];
    fixture = TestBed.createComponent(LinkContrattoServizioPopUpComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
    component.servizioList = servizioList;
  });
   it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should call ngOnInit', () => {
    fixture.detectChanges();
    component.ngOnInit();
    // component.closeModal();
    // expect(component.servizioListData).toBeDefined();
  });
  it('should call onSelect', () => {
    fixture.detectChanges();
    // component.submitModal();
    component.onSelect(121);
    expect(component.linkedServices).toBeDefined();
  });

});
