import { Component, Input, OnInit } from '@angular/core';
import { TreeviewItem, TreeviewConfig } from 'ngx-treeview';
import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'reg-link-contratto-servizio-pop-up',
  templateUrl: './link-contratto-servizio-pop-up.component.html',
  styleUrls: ['./link-contratto-servizio-pop-up.component.scss']
})
export class LinkContrattoServizioPopUpComponent implements OnInit {
  config = TreeviewConfig.create({
    hasAllCheckBox: false,
    hasFilter: false,
    hasCollapseExpand: false,
    decoupleChildFromParent: true,
    maxHeight: 400
  });
  linkedServices = [];
  @Input() linkedServizioList: any;
  @Input() servizioList: any;
  servizioListData: any;

  constructor(private activeModal: NgbActiveModal) { }

  private createTreeview(currentNode, treeview) {
    const isChecked = (this.linkedServizioList && this.linkedServizioList.filter(linkedService => linkedService.servizioId === currentNode.servizioId).length === 1)
    ? true : false;
    return {
      text: currentNode.servizioName,
      value: currentNode.servizioId,
      checked: isChecked
    };
  }

  private getFilterdData(filters) {
    if (!filters) {
      return [];
    }
    const items: TreeviewItem[] = [];
    filters.map(async filter => {
      const node = await this.createTreeview(filter, []);
      const item = new TreeviewItem(node);
      item.correctChecked();
      items.push(item);
    });
    return items;
  }

  closeModal() {
    this.activeModal.close(false);
  }

  async ngOnInit() {
    this.servizioListData = await this.getFilterdData(this.servizioList);
  }

  onSelect(likedServices) {
    this.linkedServices = likedServices;
  }

  submitModal() {
    this.activeModal.close(this.linkedServices);
  }
}
