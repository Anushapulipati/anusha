import { NuovoContrattoAccordionComponent } from './pages/nuovo-contratto-accordion/nuovo-contratto-accordion.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PendingChangesGuardGuard } from 'src/app/shared/services/pending-changes-guard.guard';
import { DettaglioRigaProposteComponent } from './pages/dettaglio-riga-proposte/dettaglio-riga-proposte.component';
import { NuovoContrattoComponent } from './pages/nuovo-contratto/nuovo-contratto.component';
import { NuovoPropostaComponent } from './pages/nuovo-proposta/nuovo-proposta.component';
import { PropostePageComponent } from './pages/proposte-page/proposte-page.component';

const routes: Routes = [
  {
    path: '',
    component: PropostePageComponent
  },
  {
    path: 'nuovo-proposta',
    component: NuovoPropostaComponent,
    canDeactivate: [ PendingChangesGuardGuard ]
  },
  {
    path: 'nuovo-proposta/:propostaId',
    component: NuovoPropostaComponent,
    canDeactivate: [ PendingChangesGuardGuard ]
  },
  {
    path: 'dettaglio-proposte',
    component: DettaglioRigaProposteComponent
  },
  {
    path: 'dettaglio-proposte/:propostaId/:propostaFornitoreId/:fornitoreID',
    component: DettaglioRigaProposteComponent
  },
  {
    path: 'nuovo-contratto/:propostaId/:propostaFornitoreId/:fornitoreID',
    component: NuovoContrattoComponent,
    canDeactivate: [ PendingChangesGuardGuard ]
  },
  {
    path: 'nuovo-contratto/:propostaId/:propostaFornitoreId/:contrattoID/:fornitoreID',
    component: NuovoContrattoComponent,
    canDeactivate: [ PendingChangesGuardGuard ]
  },
  {
    path: 'nuovo-contratto/:registroId/:propostaId/:propostaFornitoreId/:contrattoID/:fornitoreID',
    component: NuovoContrattoComponent,
    canDeactivate: [ PendingChangesGuardGuard ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProposteRoutingModule { }
