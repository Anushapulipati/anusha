import { ChangeDetectorRef, Component, OnInit } from '@angular/core';

@Component({
  selector: 'reg-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  showSprinner = false;
  title = 'registro-fe-angular';

  constructor(private cdRef: ChangeDetectorRef) {}

  async ngOnInit() {
    this.cdRef.detectChanges();
  }
}
