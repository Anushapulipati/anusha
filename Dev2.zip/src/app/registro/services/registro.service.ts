import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { UrlProviderService } from 'src/app/shared/services/url-provider.service';
import { RegistroDetailsVm } from 'src/app/shared/models/registroDetailsVm';
import { Observable } from 'rxjs';
import { EsportaModel } from 'src/app/shared/models/esportaModel';

@Injectable({
  providedIn: 'root'
})
export class RegistroService {

  constructor(
    private httpClient: HttpClient,
    private urlProviderService: UrlProviderService
  ) { }
  checkExcelStatus(id: any): any {
    const params = new HttpParams();
    const parameters = params.append('id', id.toString());
    return this.httpClient.get<any>(this.urlProviderService.verifyRegistroExcel, { params: parameters });
  }
  exportToRegistroExcel(esportaModel: EsportaModel): Observable<any> {
    return this.httpClient.post<any>(this.urlProviderService.exportToRegistroExcel, esportaModel);

}
exportToRegistroOggiExcel(esportaModel: EsportaModel): Observable<any> {
  return this.httpClient.post<any>(this.urlProviderService.registroOggiExcel, esportaModel);

}
  filterRegistroData(registroFilters) {
    return this.httpClient.post<any>(this.urlProviderService.filterRegistroData, registroFilters);
  }

  updateRegistro(registroDetails: RegistroDetailsVm) {
    return this.httpClient.post<RegistroDetailsVm>(this.urlProviderService.updateRegistro, registroDetails);
  }


}
