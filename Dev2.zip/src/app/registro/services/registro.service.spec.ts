import { TestBed } from '@angular/core/testing';

import { RegistroService } from './registro.service';
import { UrlProviderService } from 'src/app/shared/services/url-provider.service';
import { HttpClientTestingModule, HttpTestingController, TestRequest } from '@angular/common/http/testing';
import { FormGroup, FormControl, FormArray } from '@angular/forms';

describe('RegistroService', () => {
  let registroservice;
  let httpTestingController;
  let urlProviderService;
  beforeEach(() => {
    TestBed.configureTestingModule({
    providers: [
      RegistroService,
    UrlProviderService],
    imports: [HttpClientTestingModule],

  });
    registroservice  = TestBed.get(RegistroService);
    httpTestingController = TestBed.get(HttpTestingController);
    urlProviderService = TestBed.get(UrlProviderService);
});

  it('should be created', () => {
    const service: RegistroService = TestBed.get(RegistroService);
    expect(service).toBeTruthy();
  });

  it('should call filterRegistroData with this request method and url', () => {
    const registroForm = new FormGroup({
      statoServizio: new FormControl([]),
      categoriaInterna: new FormControl([]),
      categoriaBankIt: new FormControl([]),
      ordinaPer: new FormControl([]),
      classificazione: new FormArray([
        new FormControl(true),
        new FormControl(true),
        new FormControl(true),
        new FormControl(true)
      ])
    });
    const getResponse = {
      'registroFilterResponseList': [
         {
            'registroId': 147,
            'societaDelGruppoCliente': 'SV Banca',
            'fornitore': 'Capgemini Italia',
            'fornitoreInfraExtraGruppo': 'Infragruppo',
            'classificazione': 'Fornitura',
            'perimetroMonitoraggioICTVendor': null,
            'statoDelServizio': 'In attesa sottoscrizione',
            'ogettoDelContratto': null,
            'descrizioneDelServizioErogato': 'Breve ',
            'contrattoId': null,
            'fornitoreId': null
         },
         {
            'registroId': 84,
            'societaDelGruppoCliente': 'SV Banca',
            'fornitore': 'Capgemini Italia',
            'fornitoreInfraExtraGruppo': 'Infragruppo',
            'classificazione': 'Fornitura',
            'perimetroMonitoraggioICTVendor': 'Si',
            'statoDelServizio': 'In vigore',
            'ogettoDelContratto': null,
            'descrizioneDelServizioErogato': null,
            'contrattoId': null,
            'fornitoreId': null
         }
      ],
      'totalNumberOfRecords': 27
   };

    registroservice.filterRegistroData(registroForm).subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.filterRegistroData);
    expect(req.request.method).toEqual('POST');
    req.flush(getResponse);
  });

  it('should call updateRegistro with this request method and url', () => {
    const registroForm = new FormGroup({
      statoServizio: new FormControl([]),
      categoriaInterna: new FormControl([]),
      categoriaBankIt: new FormControl([]),
      ordinaPer: new FormControl([]),
      classificazione: new FormArray([
        new FormControl(true),
        new FormControl(true),
        new FormControl(true),
        new FormControl(true)
      ])
    });
    const getResponse = {
      'registroFilterResponseList': [
         {
            'registroId': 147,
            'societaDelGruppoCliente': 'SV Banca',
            'fornitore': 'Capgemini Italia',
            'fornitoreInfraExtraGruppo': 'Infragruppo',
            'classificazione': 'Fornitura',
            'perimetroMonitoraggioICTVendor': null,
            'statoDelServizio': 'In attesa sottoscrizione',
            'ogettoDelContratto': null,
            'descrizioneDelServizioErogato': 'Breve ',
            'contrattoId': null,
            'fornitoreId': null
         },
         {
            'registroId': 84,
            'societaDelGruppoCliente': 'SV Banca',
            'fornitore': 'Capgemini Italia',
            'fornitoreInfraExtraGruppo': 'Infragruppo',
            'classificazione': 'Fornitura',
            'perimetroMonitoraggioICTVendor': 'Si',
            'statoDelServizio': 'In vigore',
            'ogettoDelContratto': null,
            'descrizioneDelServizioErogato': null,
            'contrattoId': null,
            'fornitoreId': null
         }
      ],
      'totalNumberOfRecords': 27
   };

    registroservice.updateRegistro(registroForm).subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.updateRegistro);
    expect(req.request.method).toEqual('POST');
    req.flush(getResponse);
  });

  it('should call checkExcelStatus with this request method and url', () => {
   const excelId = 20;
   const checkExcelResponse = {};
    registroservice.checkExcelStatus(excelId).subscribe();
    const req: TestRequest = httpTestingController.expectOne(urlProviderService.verifyRegistroExcel + '?id=' + excelId);
    expect(req.request.method).toEqual('GET');
    req.flush(checkExcelResponse);
  });

  it('should call exportToRegistroExcel with this request method and url', () => {
    const excelId = 20;
    const checkExcelResponse = {};
     registroservice.exportToRegistroExcel(excelId).subscribe();
     const req: TestRequest = httpTestingController.expectOne(urlProviderService.exportToRegistroExcel);
     expect(req.request.method).toEqual('POST');
     req.flush(checkExcelResponse);
   });

   it('should call exportToRegistroOggiExcel with this request method and url', () => {
     const esportaModel = {id: 1,
     endTime: Date,
     fileContent: 'fileContent',
     startTime: Date,
     status: 'status',
     error: 'error',
     };
    const excelId = 20;
    const checkExcelResponse = {};
     registroservice.exportToRegistroOggiExcel(esportaModel).subscribe();
    /*  const req: TestRequest = httpTestingController.expectOne(urlProviderService.exportToRegistroOggiExcel);
     expect(req.request.method).toEqual('POST');
     req.flush(checkExcelResponse); */
   });
 

});
