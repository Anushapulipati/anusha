import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DettaglioRigaRegistroComponent } from './dettaglio-riga-registro.component';
import { ActivatedRoute, Router, RouterModule } from '@angular/router';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { FormsModule, ReactiveFormsModule, FormGroup, FormControl, Validators, FormArray, NG_VALUE_ACCESSOR } from '@angular/forms';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA, forwardRef } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LoginService } from 'src/app/shared/services/login.service';
import { MultiselectDropdownComponent, MULTI_SELECT_INPUT_CONTROL_VALUE_ACCESSOR } from 'src/app/shared/components/multiselect-dropdown/multiselect-dropdown.component';
import { ProposteService } from 'src/app/modules/proposte/services/proposte.service';
import { RegistroService } from '../../services/registro.service';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('DettaglioRigaRegistroComponent', () => {
  let component: DettaglioRigaRegistroComponent;
  let fixture: ComponentFixture<DettaglioRigaRegistroComponent>;
  let route;
  let dettaglioRegistroForm;
  let loginService;
  let proposteService;
  let allClientDetailsResponse;
  let allSupplierDetails;
  let drodownResponse;
  let registroService;
  let mockResponse;
  let mockParameter;
  let filterKeys;
  const router = { events: of({ tipsId: '4' }),
    createUrlTree: (commands, navExtras = {}) => {},
    serializeUrl : () => {} };

  beforeEach(async(() => {
    loginService = jasmine.createSpyObj(['getOperationModel']);
    // tslint:disable-next-line: max-line-length
    proposteService = jasmine.createSpyObj(['getAllClientiDetails', 'getFornitourDropdownDetails', 'getUTCDate', 'getRegistroDetails', 'getDateObject']);
    registroService = jasmine.createSpyObj(['filterRegistroData', 'updateRegistro']);
    TestBed.configureTestingModule({
      declarations: [ DettaglioRigaRegistroComponent, MultiselectDropdownComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        RouterTestingModule ,
        HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: LoginService, useValue: loginService},
        { provide: ProposteService, useValue: proposteService},
        { provide: RegistroService, useValue: registroService },
        MULTI_SELECT_INPUT_CONTROL_VALUE_ACCESSOR,
       /*  { provide: ActivatedRoute, useValue: route },
        { provide: Router, useValue: router }, */
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const operationModel = {
      hasRegistroReadOnly: true,
    };
    // tslint:disable-next-line: max-line-length
    allClientDetailsResponse = [{'clientiId': 1, 'nomeSocieta': 'SV Banca', 'abi': 'CLIENT1', 'classeSocieta': 'banca', 'partitaIva': '1', 'codiceFiscale': '1'}, {'clientiId': 25, 'nomeSocieta': 'BPER Banca', 'abi': '5387', 'classeSocieta': 'Società Strumentale', 'partitaIva': 'Partita IVA bper!', 'codiceFiscale': '6666'}, ];
    loginService.getOperationModel.and.returnValue(of(operationModel));
    // tslint:disable-next-line: max-line-length
    allSupplierDetails = [{'fornitoreId': 1, 'nomeSocieta': 'Capgemini Italia update', 'infraGruppoExtraGruppo': 'Infragruppo', 'codice': 212233412, 'ndg': 1938021, 'partitaIva': '121Par update123465', 'codiceFiscale': 125, 'atecoBankIt': 'ATECO_2007_BANKIT', 'indirizzoFornitore': 'Paese_di_registrazione_fornitor', 'paeseFornitore': 'LEI_Numero_registrazione_fornitore', 'numeroFornitore': 'abcd', 'capoGruppo': 'xysz', 'description': 'INDIA', 'nation': 'Europe', 'ccnl': 'CCNL', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'Si', 'grouppo': 'group new update', 'email': 'abc@gmail.com', 'dataInserimento': '14/12/2020', 'ncommerico': 'N_Iscrizione_camera_commercio'}, {'fornitoreId': 2, 'nomeSocieta': 'Capgemini India update mine', 'infraGruppoExtraGruppo': 'Infragruppo', 'codice': null, 'ndg': null, 'partitaIva': '121Par', 'codiceFiscale': 121, 'atecoBankIt': 'ATECO_2007_BANKIT', 'indirizzoFornitore': 'Paese_di_registrazione_fornitor update', 'paeseFornitore': '', 'numeroFornitore': '', 'capoGruppo': 'abcd', 'description': 'INDIA', 'nation': 'Capogruppo-capgemini group', 'ccnl': 'CCNL', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'Si', 'grouppo': 'group', 'email': 'email', 'dataInserimento': '03/12/2020', 'ncommerico': 'N_Iscrizione_camera_commercio'}, ];
    // tslint:disable-next-line: max-line-length
    drodownResponse =  {
      'Categorie BankIT': [
         {
            'itemId': '1',
            'tableId': 'Categorie BankIT',
            'itemName': 'Credito / cartolarizzazioni',
            'subDomainList': [
               {
                  'itemId': '128',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Fasi o specifiche attivitÃ  del processo di istruttoria',
                  'subDomainList': null
               },
               {
                  'itemId': '129',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Fasi o specifiche attivitÃ  del processo di monitoraggio',
                  'subDomainList': null
               },

            ]
         },
         {
            'itemId': '2',
            'tableId': 'Categorie BankIT',
            'itemName': 'Credito / cartolarizzazion',
            'subDomainList': [
               {
                  'itemId': '128',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Fasi o specifiche attivitÃ  del processo di istruttoria',
                  'subDomainList': null
               },
               {
                  'itemId': '129',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Fasi o specifiche attivitÃ  del processo di monitoraggio',
                  'subDomainList': null
               },

            ]
         },
        ],
      'Livello di rischio di non conformità': [
         {
            'itemId': '1',
            'tableId': 'Livello di rischio di non conformità',
            'itemName': 'Basso',
            'subDomainList': null
         },
         {
            'itemId': '2',
            'tableId': 'Livello di rischio di non conformità',
            'itemName': 'Medio Basso',
            'subDomainList': null
         },

      ],
      'STATO_SERVIZIO': [
         {
            'itemId': '1',
            'tableId': 'STATO_SERVIZIO',
            'itemName': 'In attesa sottoscrizione',
            'subDomainList': null
         },
         {
            'itemId': '2',
            'tableId': 'STATO_SERVIZIO',
            'itemName': 'In vigore',
            'subDomainList': null
         },

      ],
      'Sostituibilita': [
         {
            'itemId': '1',
            'tableId': 'Sostituibilita',
            'itemName': 'Facile',
            'subDomainList': null
         },
         {
            'itemId': '2',
            'tableId': 'Sostituibilita',
            'itemName': 'Difficile',
            'subDomainList': null
         },

      ],
      'Area normativa': [
         {
            'itemId': '1',
            'tableId': 'Area normativa',
            'itemName': 'Esternalizzazioni',
            'subDomainList': null
         },
         {
            'itemId': '2',
            'tableId': 'Area normativa',
            'itemName': 'Privacy',
            'subDomainList': null
         },

      ],
      'Categorie EBA': [
         {
            'itemId': '1',
            'tableId': 'Categorie EBA',
            'itemName': 'Infrastruttura globale di messaggistica finanziaria soggetta alla vigilanza delle pertinenti autorità',
            'subDomainList': null
         },
         {
            'itemId': '2',
            'tableId': 'Categorie EBA',
            'itemName': 'Acquisizione di beni (e.g. tessere di plastica, lettori di carte, forniture per ufficio, personal computer, mobilio)',
            'subDomainList': null
         },

      ],
      'Livello di Rischiosità': [
         {
            'itemId': '1',
            'tableId': 'Livello di Rischiosità',
            'itemName': 'Rischio Basso',
            'subDomainList': null
         },
         {
            'itemId': '2',
            'tableId': 'Livello di Rischiosità',
            'itemName': 'Rischio Medio',
            'subDomainList': null
         },

      ],
      'Tipology Dati Da': [
         {
            'itemId': '1',
            'tableId': 'Tipology Dati Da',
            'itemName': 'Transazioni economiche update',
            'subDomainList': null
         },
         {
            'itemId': '2',
            'tableId': 'Tipology Dati Da',
            'itemName': ' Affidabilità bancaria (Informazioni sulla affidabilità bancaria del soggetto)',
            'subDomainList': null
         },

      ],
      'Livello di adeguatezza Stato comunicazione': [
        {
           'itemId': '1',
           'tableId': 'Livello di adeguatezza Stato comunicazione',
           'itemName': 'Adeguato',
           'subDomainList': null
        },
        {
           'itemId': '2',
           'tableId': 'Livello di adeguatezza Stato comunicazione',
           'itemName': 'Prevalentemente adeguato',
           'subDomainList': null
        },
        {
           'itemId': '3',
           'tableId': 'Livello di adeguatezza Stato comunicazione',
           'itemName': 'Parzialmente adeguato',
           'subDomainList': null
        },
        {
           'itemId': '4',
           'tableId': 'Livello di adeguatezza Stato comunicazione',
           'itemName': 'Critico',
           'subDomainList': null
        }
     ],
   };

    // tslint:disable-next-line: max-line-length
    mockResponse = {'idRegistro': 183, 'categorieBankIt': 'null', 'sottoCategorieBankIt': 'Fasi o specifiche attivitÃ  del processo di monitoraggio', 'contractId': 344, 'categoriaEba': 'Servizi postali', 'classificazione': 'Fornitura', 'clienteInterno': null, 'codiceContratto': null, 'codiceContrattoPadre': 1, 'costoAnnuoDiEsercizio': null, 'costoTotaleDelContratto': null, 'dataCessazioneDelContratto': '14/12/2020', 'dataCessazioneDelServizio': null, 'dataDelProssimoAudit': null, 'dataDelUltimoAudit': null, 'dataDellUltimaValutazione': '09/12/2020', 'dataDiDecorrenza': '14/12/2020', 'dataDiDecorrenzaDelServizio': null, 'dataDiScadenzaDelContratto': '14/12/2020', 'dataDiScadenzaDelServizio': null, 'dataDiSottoscrizione': '14/12/2020', 'dataDiUltimaValutazione': '14/12/2020', 'dataDiUltimoRinnovoDelContratto': '14/12/2020', 'dataSottoscrizioneDelServizio': null, 'durataDelRinnovo': 0, 'fornitoreInfragruppo': null, 'fornituraICTRilevanterischioalto': 'No', 'fornituraNonICTRilevante': 'No', 'gestoreDiBudget': null, 'note': 'test1', 'perimetroMonitoraggioICTVendor': 'No', 'possibilitaDiRecesso': '', 'referenteDiContratto': '', 'referenteErogatoreServiziIT': null, 'slaMonitorati': 'No', 'sogliaDiImpattoDellinterruzioneDellaFunzione': 0, 'tacitoRinnovo': '', 'oggettoDelContratto': null, 'descrizioneServizioErogato': 'descrizione serv 2 su SPA', 'terminiPreavvisoCliente': '', 'terminiPreavvisoFornitore': '', 'legislazioneApplicataNazione': null, 'costoStimatoDelContratto': null, 'sostituibilità': 'Facile', 'fornitoriAlternativi': 'Fornitori Alternat', 'possibilitàDiReinternalizzazione': 'Si', 'numeroSubfornitori': 0, 'subFornitore': [{'fornitoreId': 2, 'nomeSocieta': 'Capgemini India update mine'}, {'fornitoreId': 25, 'nomeSocieta': 'Test Nome Società'}], 'proposta': {'proposalId': 257, 'numeroProposta': '2020_642', 'segnalante': '07/12 Segnalante', 'societaDelSegnalante': 'Test altro Cliente', 'oggDellaProposta': '07/12 proposta', 'statoProposta': 'Conclusa', 'sotoStatoProposta': 'Conclusa', 'propostaName': 'Prop test', 'canDiSegnalazione': 'Progetto', 'cambioFornitore': 'No', 'dataDellaProposta': '07/12/2020', 'dataDelCensimento': '14/12/2020', 'praticaOwner': 'ffff', 'dataFineProposta': '14/12/2020', 'codCanSegnalazione': ' Codice Canale di Segnalazione', 'gestionePraticaBackup': 'Gestione Pratica-Backup', 'completoOrInCompleto': true, 'uosegnalante': '07/13 Uo segnalante'}, 'contratto': {'contrattoId': 344, 'propostaFornitoreId': null, 'societaClientiId': 52, 'fornitoriAlternativi': 'Fornitori Alternat', 'oggettoDelContratto': 'contratto SPA - test', 'terminiPreavvisoCliente': '', 'terminiPreavvisoFornitore': '', 'costoAttivita': null, 'numeroSubfornitori': 0, 'societaGruppoCliente': 'Test altro Cliente', 'statoComunicazioneAdv': '', 'autoritaCompetente': '', 'statoCompletoAdv': 'complete', 'dataInvioComunicazioneAdv': null, 'necessariaProceduraSindacale': '', 'statoComunicazione': '', 'dataInvioComunicazione': null, 'periodoAttesaEsito': 0, 'scadenzaRiscontro': null, 'statoCompletoProcedura': 'complete', 'societaClienteDatApprovazione': null, 'societaClienteApprovatoreFinale': '', 'statoCompletoCDA': 'complete', 'fornitoreInfragruppoDataDi': null, 'fornitoreInfragruppoFinale': '', 'pareresuiContrattiComplianceList': null, 'parereSuiContrattiRischiList': null, 'servizioList': null, 'servizioContrattoId': null, 'servizioResponseList': null, 'fornitoreResponseList': null, 'subFornitore': null, 'completoOrInCompleto': true, 'codiceContrattoPadre': 1, 'commonContrattoId': null}, 'fornitore': {'fornitoreId': 24, 'nomeSocieta': '1S.P.A', 'infraGruppoExtraGruppo': 'Extragruppo', 'codice': 1111, 'ndg': 12, 'partitaIva': '10000003', 'codiceFiscale': 14, 'atecoBankIt': '100006SA', 'indirizzoFornitore': '1000008', 'paeseFornitore': '1000009', 'numeroFornitore': '1italiana', 'capoGruppo': '1FilS.P.A', 'description': '1000007', 'nation': '10 italiana', 'ccnl': '10 metalmeccanico', 'fornitoreCosti': 'Si', 'fornitoreConRatingNegativo': 'No', 'grouppo': '10 nessuna', 'email': '11cdd@cc.it', 'dataInserimento': '15/12/2020', 'ncommerico': '1000005'}, 'servizioEntity': {'servizioId': 368, 'propostaFornitoreId': null, 'marcoProcesso': 'bbbb', 'racConDeiPro': 'bbb', 'servizioInfrastrttra': 'Si', 'tipologiaDiCloud': 'Cloud Ibrido', 'possibilitaDiRei': 'Si', 'sostituibilita': 'Facile', 'classificazioneOne': 'Fornitura', 'classificazioneTipo': 'Fornitura', 'datiPersonali': 'No', 'sogliaFunzione': 33, 'funzioneEsternalizzata': 'Si', 'funzioneImportante': 'No', 'ultimaValutazioneData': '09/12/2020', 'sintesideiMotivi': 'serv 2 su SPA funz importante', 'paeseDiVieneSvolto': 'ita', 'paesediconDati': 'ita', 'cloudpaesediCon': 'ita', 'descrizioneDel': 'descrizione serv 2 su SPA', 'tipologiaDaDati': null, 'cloudNaturaDaDati': null, 'livelloDiRischiosita': 'Rischio Medio', 'breveRischiosita': 'serv 2 su SPA breve sintesi sul livello di richiosità', 'completoStato': 'complete', 'categoriaBankIt': 'Credito / cartolarizzazioni', 'sottocategoriaBankIt': null, 'servizioName': 'serv 2 su SPA', 'categoriaEba': 'Servizi postali'}, 'nomeSocietaCliente': 'Test altro Cliente', 'clientId': 52, 'statoContratto': 'In attesa sottoscrizione', 'statoServizio': 'In attesa sottoscrizione', 'registroName': 'serv 2 su SPA.', 'pareresuiContrattiComplianceList': null, 'parereSuiContrattiRischiList': null, 'breveSintesiDeiMotivi': 'serv 2 su SPA funz importante', 'breveSintesiSulLivello': 'serv 2 su SPA breve sintesi sul livello di richiosità', 'societàDelReferenteErogatoreServiziIT': null, 'propostaFornitoreId': 323, 'commonContrattoId': 6, 'oggDellaProposta': '07/12 proposta', 'datiPersonali': 'No', 'funzioneEsternalizzata': 'No', 'paeseDiVieneSvolto': 'ita', 'paesediconDati': 'ita', 'marcoProcesso': 'bbbb', 'racConDeiPro': 'bbb', 'trasferimentoDati': null, 'tipologiaDaDati': null, 'cloudNaturaDaDati': null, 'tipologiaDiCloud': 'Cloud Ibrido', 'servizioInfrastrttra': 'Si', 'cloudpaesediCon': 'ita'};

    dettaglioRegistroForm = new FormGroup({
      idRegistro: new FormControl(''),
      statoServizio: new FormControl('selezionare valore', Validators.required),
      slaMonitorati: new FormControl('', Validators.required),
      referenteDiContratto: new FormControl('', Validators.required),
      nomesocietaCliente: new FormControl(''),
      societàDelReferenteErogatoreServiziIT: new FormControl(''),
      clienteInterno: new FormControl(''),
      fornitoreInfragruppo: new FormControl(''),
      gestoreDiBudget: new FormControl(''),
      fornituraNonICTRilevante: new FormControl('', Validators.required),
      perimetroMonitoraggioICTVendor: new FormControl(''),
      note: new FormControl(''),
      referenteErogatoreServiziIT: new FormControl(''),
      fornituraICTRilevanterischioalto: new FormControl('', Validators.required),
      dataDelUltimoAudit: new FormControl(null),
      dataDelProssimoAudit: new FormControl(null),
      dataDiUltimaValutazione: new FormControl(null, Validators.required),
      dataDiDecorrenza: new FormControl(null, Validators.required),
      dataDiSottoscrizione: new FormControl(null, Validators.required),
      dataCessazioneDelContratto: new FormControl(null, Validators.required),
      dataDiUltimoRinnovoDelContratto: new FormControl(null, Validators.required),
      statoContratto: new FormControl(''),
      classificazione: new FormControl(''),
      codiceContratto: new FormControl(''),
      codiceContrattoPadre: new FormControl(''),
      oggettoDelContratto: new FormControl('', Validators.required),
      // descrizioneServizioErogato: new FormControl('', Validators.required),
      descrizioneServizioErogato:  new FormControl('', Validators.required),
      statodelContratto: new FormControl('', Validators.required),
      durataDelRinnovo: new FormControl('', Validators.required),
      tacitoRinnovo: new FormControl('', Validators.required),
      costoTotaleDelContratto: new FormControl(''),
      terminiPreavvisoCliente: new FormControl('', Validators.required),
      terminiPreavvisoFornitore: new FormControl('', Validators.required),
      possibilitaDiRecesso: new FormControl(''),
      sogliaDiImpattoDellinterruzioneDellaFunzione: new FormControl('', Validators.required),
      costoAnnuoDiEsercizio: new FormControl(''),
      sostituibilità: new FormControl('', Validators.required),
      fornitoriAlternativi: new FormControl('', Validators.required),
      possibilitàDiReinternalizzazione: new FormControl('', Validators.required),
      subFornitore: new FormControl(''),
      numeroSubfornitori: new FormControl('', Validators.required),
      costoStimatoDelContratto: new FormControl('', Validators.required),
      dataDiDecorrenzaDelServizio: new FormControl(''),
      dataSottoscrizioneDelServizio: new FormControl(''),
      dataDiScadenzaDelServizio: new FormControl(''),
      breveSintesiDeiMotivi: new FormControl('', Validators.required),
      // sintesideiMotivi: new FormControl('', Validators.required),
      dataDellUltimaValutazione: new FormControl('23/04/2020', Validators.required),
      dataCessazioneDelServizio: new FormControl(''),
      breveSintesiSulLivello: new FormControl('', Validators.required),
      // breveRischiosita: new FormControl('', Validators.required),
      // NPareredirischio: new FormControl(''),
      // Dataparere: new FormControl(null, Validators.required),
      // livellodiRischiosita: new FormControl('', Validators.required),
      dataDiScadenzaDelContratto: new FormControl('', Validators.required),
      pareresuiContrattiComplianceList: new FormArray([]),
      parereSuiContrattiRischiList: new FormArray([]),
      oggDellaProposta: new FormControl(''),
      datiPersonali: new FormControl(''),
      funzioneEsternalizzata: new FormControl(''),
      paeseDiVieneSvolto: new FormControl(''),
      paesediconDati: new FormControl(''),
      marcoProcesso: new FormControl(''),
      racConDeiPro: new FormControl(''),
      trasferimentoDati: new FormControl(''),
      servizioInfrastrttra:  new FormControl(''),
      tipologiaDiCloud:  new FormControl(''),
      cloudpaesediCon:  new FormControl(''),
      categorieBankIt:  new FormControl(''),
      sottoCategorieBankIt:  new FormControl(''),
      categoriaEba:  new FormControl(''),
      tipologiaDaDati: new FormControl('tipologiaDaDati'),
      cloudNaturaDaDati: new FormControl('')
    });
    fixture = TestBed.createComponent(DettaglioRigaRegistroComponent);
    component = fixture.componentInstance;
    mockParameter = 183;
    // component.registroId = 183;

    console.log('registroId', component.registroId);
    filterKeys =  [
      'Sostituibilita',
      'Livello di Rischiosità',
      'STATO_SERVIZIO',
      'Area normativa',
      'Livello di rischio di non conformità',
      'Livello di adeguatezza Stato comunicazione',
      'Categorie EBA',
      'Categorie BankIT',
      'Tipology Dati Da'
    ];
    // component.filterKeys = filterKeys;
    component.filters= drodownResponse;
    console.log('sub',component.filters);
    console.log('check sub',component.filters['Categorie BankIT'][0].subDomainList);
    component.subCategoriaBankIT = component.filters['Categorie BankIT'][0].subDomainList;
    proposteService.getAllClientiDetails.and.returnValue(of(allClientDetailsResponse));
    proposteService.getFornitourDropdownDetails.and.returnValue(of(allSupplierDetails));
    // proposteService.getDropdownData.and.returnValue(of(drodownResponse));
    proposteService.getRegistroDetails.and.returnValue(of(mockResponse));
    component.dettaglioRegistroForm = dettaglioRegistroForm;
    registroService.updateRegistro.and.returnValue(of(mockResponse));
    component.registroDetails = mockResponse;
    // fixture.detectChanges();
    // component.registroDetails['categorieBankIt'] = null;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });



/*  it('should call getRegistro method  and return the said result', () => {
    component.ngOnInit();
     component.registroId = 183;
     proposteService.getRegistroDetails.and.returnValue(of(mockResponse));
     
      proposteService.getRegistroDetails(mockParameter).subscribe(result => {
        expect(result).toBe(mockResponse);
      });
    });  */
    it('should check filter keys', () => {
      const filterKeys = [
        'Sostituibilita',
        'Livello di Rischiosità',
        'STATO_SERVIZIO',
        'Area normativa',
        'Livello di rischio di non conformità',
        'Livello di adeguatezza Stato comunicazione',
        'Categorie EBA',
        'Categorie BankIT',
        'Tipology Dati Da'
      ];
      // fixture.detectChanges();
      expect(component.filterKeys).toEqual(filterKeys);
     // component.resetForm();
     // component.updateRegistro();
    });

   it('should call update registro', () => {
      const registroRequest = {"idRegistro":182,"statoServizio":"In attesa sottoscrizione","slaMonitorati":"No","referenteDiContratto":"Referente ","nomesocietaCliente":"","societàDelReferenteErogatoreServiziIT":null,"clienteInterno":null,"fornitoreInfragruppo":null,"gestoreDiBudget":null,"fornituraNonICTRilevante":"No","perimetroMonitoraggioICTVendor":"No","note":null,"referenteErogatoreServiziIT":null,"fornituraICTRilevanterischioalto":"No","dataDelUltimoAudit":null,"dataDelProssimoAudit":null,"dataDiUltimaValutazione":"2020-12-13T18:30:00.000Z","dataDiDecorrenza":"2020-12-13T18:30:00.000Z","dataDiSottoscrizione":"2020-12-13T18:30:00.000Z","dataCessazioneDelContratto":"2020-12-13T18:30:00.000Z","dataDiUltimoRinnovoDelContratto":"2020-12-13T18:30:00.000Z","statoContratto":"In attesa sottoscrizione","classificazione":"Fornitura","codiceContratto":null,"codiceContrattoPadre":6,"oggettoDelContratto":"Contratto","descrizioneServizioErogato":"descrizione serv 2 su SPA","statodelContratto":"","durataDelRinnovo":0,"tacitoRinnovo":"Si","costoTotaleDelContratto":null,"terminiPreavvisoCliente":"00","terminiPreavvisoFornitore":"00","possibilitaDiRecesso":"","sogliaDiImpattoDellinterruzioneDellaFunzione":"Soglia","costoAnnuoDiEsercizio":null,"sostituibilità":"Facile","fornitoriAlternativi":"id contratto 6","possibilitàDiReinternalizzazione":"Si","subFornitore":[{"fornitoreId":1,"nomeSocieta":"Capgemini Italia update"}],"numeroSubfornitori":1,"costoStimatoDelContratto":"123455","dataDiDecorrenzaDelServizio":null,"dataSottoscrizioneDelServizio":null,"dataDiScadenzaDelServizio":null,"breveSintesiDeiMotivi":"serv 2 su SPA funz importante","dataDellUltimaValutazione":"2020-12-08T18:30:00.000Z","dataCessazioneDelServizio":null,"breveSintesiSulLivello":"serv 2 su SPA breve sintesi sul livello di richiosità","dataDiScadenzaDelContratto":"2020-12-13T18:30:00.000Z","oggDellaProposta":"07/12 proposta","datiPersonali":"No","funzioneEsternalizzata":"Si","paeseDiVieneSvolto":"ita","paesediconDati":"ita","marcoProcesso":"bbbb","racConDeiPro":"bbb","trasferimentoDati":"Trasferimento ","servizioInfrastrttra":"Si","tipologiaDiCloud":"Cloud Ibrido","cloudpaesediCon":"ita","categorieBankIt":"Credito / cartolarizzazioni","sottoCategorieBankIt":"Fasi o specifiche attivitÃ  del processo di monitoraggio","categoriaEba":"Servizi postali","tipologiaDaDati":["Transazioni economiche update"],"cloudNaturaDaDati":["Transazioni economiche update"],"livelloDiRischiosita":null,"pareresuiContrattiComplianceList":[{"parereSuiContrattiComplianceId":45,"contrattoId":null,"idRegistro":182,"dataParere":"2020-12-05T18:30:00.000Z","areaNormativa":"Privacy","livelloRischioNonConformita":"Medio Basso","livelloDiAdeguatezza":"Prevalentemente adeguato","statoCompletoCompliance":"","nparere":"ffff_555"},{"parereSuiContrattiComplianceId":46,"contrattoId":null,"idRegistro":182,"dataParere":"2020-12-05T18:30:00.000Z","areaNormativa":"Privacy","livelloRischioNonConformita":"Medio Basso","livelloDiAdeguatezza":"Prevalentemente adeguato","statoCompletoCompliance":"","nparere":"ffff_555"}],"parereSuiContrattiRischiList":[{"parereSuiContrattiRischiId":47,"contrattoId":null,"idRegistro":182,"dataParere":"2020-12-05T18:30:00.000Z","livelloDiRischiosita":"Rischio Medio","statoCompletoRischi":"","nparereRischio":"ssss_555"},{"parereSuiContrattiRischiId":48,"contrattoId":null,"idRegistro":182,"dataParere":"2020-12-05T18:30:00.000Z","livelloDiRischiosita":"Rischio Medio","statoCompletoRischi":"","nparereRischio":"ssss_555"}],"matricola":"23456","registroName":"serv 2 su SPA"}
      component.updateRegistro();
       component.registroId = null;
       // proposteService.getRegistroDetails.and.returnValue(of(mockResponse));
        registroService.updateRegistro.and.returnValue(of(mockResponse));
      
         expect(registroService.updateRegistro).toHaveBeenCalled();
        registroService.updateRegistro(registroRequest).subscribe(result => {
          expect(result).toBe(mockResponse);
        });

    });
});
