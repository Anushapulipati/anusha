import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormGroupName, Validators, FormArray } from '@angular/forms';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from 'src/app/shared/services/dateFormat';
import { ProposteService } from 'src/app/modules/proposte/services/proposte.service';
import { SelectView } from 'src/app/shared/models/selectView';
import { concatMap } from 'rxjs/operators';
import { ActivatedRoute, Router } from '@angular/router';
import { RegistroService } from '../../services/registro.service';
import { ClientVm } from 'src/app/shared/models/clientVm';
import { FornitoreDetailsVm } from 'src/app/shared/models/fornitoreDetailsVm';
import { ContrattoDetailsVm } from 'src/app/shared/models/contrattoDetailsVm';
import { RegistroDetailsVm } from 'src/app/shared/models/registroDetailsVm';
import { ServizioDetailsVm } from 'src/app/shared/models/servizioDetailsVm';
import { combineLatest } from 'rxjs';
import { LoginService } from '../../../shared/services/login.service';

const commonDropdown = [
  {
    value: 'Si',
    description: 'Si'
  },
  {
    value: 'No',
    description: 'No',
  }
];

@Component({
  selector: 'reg-dettaglio-riga-registro',
  templateUrl: './dettaglio-riga-registro.component.html',
  styleUrls: ['./dettaglio-riga-registro.component.scss'],
  providers: [
    { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
  ]
})
export class DettaglioRigaRegistroComponent implements OnInit {
  allClientiDetails: SelectView[];
  allSupplierDetails: SelectView[];
  areaNormativa: SelectView[];
  canaledisegnalazione: any;
  categoriaBankIT: SelectView[];
  categoriaEBA: SelectView[];
  clientDetails: ClientVm[];
  contratto: ContrattoDetailsVm;
  contrattoDetails: ContrattoDetailsVm;
  dettaglioRegistroForm: FormGroup;
  dropdownSettings = {
    singleSelection: false,
    idField: 'value',
    textField: 'description',
    itemsShowLimit: 3,
    allowSearchFilter: false
  };
  dropdownSiNo = commonDropdown;
  editMode: boolean;
  filterKeys = [
    'Sostituibilita',
    'Livello di Rischiosità',
    'STATO_SERVIZIO',
    'Area normativa',
    'Livello di rischio di non conformità',
    'Livello di adeguatezza Stato comunicazione',
    'Categorie EBA',
    'Categorie BankIT',
    'Tipology Dati Da'
  ];
  filters: any;
  fornitore: FornitoreDetailsVm;
  fornitoreDetails: FornitoreDetailsVm;
  hasRegistroReadOnly: boolean;
  livello: SelectView[];
  livelloAdeguatezza: SelectView[];
  livellodiRischiosita: SelectView[];
  opened: boolean;
  propostaID: number;
  registroDetails: RegistroDetailsVm;
  registroId: number;
  servizioDetails: ServizioDetailsVm;
  servizioEntity: ServizioDetailsVm;
  sostituibilita: SelectView[];
  statoServizio: SelectView[];
  subCategoriaBankIT: SelectView[];
  supplierDetails: FornitoreDetailsVm[];
  tipologia: SelectView[];
  title = 'Servizio di gestione archivio cartaceo';
  constructor(
    private proposteService: ProposteService,
    private route: ActivatedRoute,
    private router: Router,
    private registroService: RegistroService,
    private loginService: LoginService
  ) { }

  private createForm() {
    this.dettaglioRegistroForm = new FormGroup({
      idRegistro: new FormControl(''),
      statoServizio: new FormControl('selezionare valore', Validators.required),
      slaMonitorati: new FormControl('', Validators.required),
      referenteDiContratto: new FormControl('', Validators.required),
      nomesocietaCliente: new FormControl(''),
      societàDelReferenteErogatoreServiziIT: new FormControl(''),
      clienteInterno: new FormControl(''),
      fornitoreInfragruppo: new FormControl(''),
      gestoreDiBudget: new FormControl(''),
      fornituraNonICTRilevante: new FormControl('', Validators.required),
      perimetroMonitoraggioICTVendor: new FormControl(''),
      note: new FormControl(''),
      referenteErogatoreServiziIT: new FormControl(''),
      fornituraICTRilevanterischioalto: new FormControl('', Validators.required),
      dataDelUltimoAudit: new FormControl(null),
      dataDelProssimoAudit: new FormControl(null),
      dataDiUltimaValutazione: new FormControl(null, Validators.required),
      dataDiDecorrenza: new FormControl(null, Validators.required),
      dataDiSottoscrizione: new FormControl(null, Validators.required),
      dataCessazioneDelContratto: new FormControl(null, Validators.required),
      dataDiUltimoRinnovoDelContratto: new FormControl(null, Validators.required),
      statoContratto: new FormControl(''),
      classificazione: new FormControl(''),
      codiceContratto: new FormControl(''),
      codiceContrattoPadre: new FormControl(''),
      oggettoDelContratto: new FormControl('', Validators.required),
      // descrizioneServizioErogato: new FormControl('', Validators.required),
      descrizioneServizioErogato:  new FormControl('', Validators.required),
      statodelContratto: new FormControl('', Validators.required),
      durataDelRinnovo: new FormControl('', Validators.required),
      tacitoRinnovo: new FormControl('', Validators.required),
      costoTotaleDelContratto: new FormControl(''),
      terminiPreavvisoCliente: new FormControl('', Validators.required),
      terminiPreavvisoFornitore: new FormControl('', Validators.required),
      possibilitaDiRecesso: new FormControl(''),
      sogliaDiImpattoDellinterruzioneDellaFunzione: new FormControl('', Validators.required),
      costoAnnuoDiEsercizio: new FormControl(''),
      sostituibilità: new FormControl('', Validators.required),
      fornitoriAlternativi: new FormControl('', Validators.required),
      possibilitàDiReinternalizzazione: new FormControl('', Validators.required),
      subFornitore: new FormControl(''),
      numeroSubfornitori: new FormControl('', Validators.required),
      costoStimatoDelContratto: new FormControl('', Validators.required),
      dataDiDecorrenzaDelServizio: new FormControl(''),
      dataSottoscrizioneDelServizio: new FormControl(''),
      dataDiScadenzaDelServizio: new FormControl(''),
      breveSintesiDeiMotivi: new FormControl('', Validators.required),
      // sintesideiMotivi: new FormControl('', Validators.required),
      dataDellUltimaValutazione: new FormControl(null, Validators.required),
      dataCessazioneDelServizio: new FormControl(''),
      breveSintesiSulLivello: new FormControl('', Validators.required),
      // breveRischiosita: new FormControl('', Validators.required),
      // NPareredirischio: new FormControl(''),
      // Dataparere: new FormControl(null, Validators.required),
      // livellodiRischiosita: new FormControl('', Validators.required),
      dataDiScadenzaDelContratto: new FormControl('', Validators.required),
      pareresuiContrattiComplianceList: new FormArray([]),
      parereSuiContrattiRischiList: new FormArray([]),
      oggDellaProposta: new FormControl(''),
      datiPersonali: new FormControl(''),
      funzioneEsternalizzata: new FormControl(''),
      paeseDiVieneSvolto: new FormControl(''),
      paesediconDati: new FormControl(''),
      marcoProcesso: new FormControl(''),
      racConDeiPro: new FormControl(''),
      trasferimentoDati: new FormControl(''),
      servizioInfrastrttra:  new FormControl(''),
      tipologiaDiCloud:  new FormControl(''),
      cloudpaesediCon:  new FormControl(''),
      categorieBankIt:  new FormControl(''),
      sottoCategorieBankIt:  new FormControl(''),
      categoriaEba:  new FormControl(''),
      tipologiaDaDati: new FormControl(''),
      cloudNaturaDaDati: new FormControl('')
    });
  }

  private getDropdownData(filters) {
    const items: SelectView[] = [];
    filters.map((filter, index) => {
      const item = new SelectView(filter.itemName, filter.itemName);
      items.push({
        description: filter.itemName,
        value: filter.itemName
      });
    });
    return items;
  }

  private getDropdownTableKeys() {
    this.proposteService.getDropdownData(this.filterKeys)
      .subscribe(async filters => {
        this.filters = filters;
        this.sostituibilita = await this.getDropdownData(filters[this.filterKeys[0]]);
        this.livello = await this.getDropdownData(filters[this.filterKeys[1]]);
        this.statoServizio = await this.getDropdownData(filters[this.filterKeys[2]]);
        this.areaNormativa = await this.getDropdownData(filters[this.filterKeys[3]]);
        this.livellodiRischiosita = await this.getDropdownData(filters[this.filterKeys[4]]);
        this.livelloAdeguatezza = await this.getDropdownData(filters[this.filterKeys[5]]);
        this.categoriaEBA = this.getDropdownData(filters[this.filterKeys[6]]);
        this.categoriaBankIT = await this.getDropdownData(filters[this.filterKeys[7]]);
        this.subCategoriaBankIT = await this.getDropdownData(filters[this.filterKeys[7]][0]['subDomainList']);
        this.tipologia = await this.getDropdownData(filters[this.filterKeys[8]]);
        if (this.registroId) {
          this.getRegistroDetails(this.registroId);
        }
    });
  }

  private getRegistroDetails(registroId) {
    return this.proposteService.getRegistroDetails(registroId).subscribe(async registroDetails => {
      this.registroDetails = registroDetails;
      this.contrattoDetails = registroDetails.contratto;
      this.fornitoreDetails = registroDetails.fornitore;
      this.servizioDetails = registroDetails.servizioEntity;
      // this.title = registroDetails.servizioEntity.servizioName;
      this.propostaID = this.registroDetails['proposta']['proposalId'];
      registroDetails['dataCessazioneDelContratto'] = this.proposteService.getDateObject(registroDetails['dataCessazioneDelContratto']);
      registroDetails['dataCessazioneDelServizio'] = this.proposteService.getDateObject(registroDetails['dataCessazioneDelServizio']);
      registroDetails['dataDelProssimoAudit'] = this.proposteService.getDateObject(registroDetails['dataDelProssimoAudit']);
      registroDetails['dataDelUltimoAudit'] = this.proposteService.getDateObject(registroDetails['dataDelUltimoAudit']);
      registroDetails['dataDiDecorrenza'] = this.proposteService.getDateObject(registroDetails['dataDiDecorrenza']);
      registroDetails['dataDiDecorrenzaDelServizio'] = this.proposteService.getDateObject(registroDetails['dataDiDecorrenzaDelServizio']);
      registroDetails['dataDiScadenzaDelContratto'] = this.proposteService.getDateObject(registroDetails['dataDiScadenzaDelContratto']);
      registroDetails['dataDiScadenzaDelServizio'] = this.proposteService.getDateObject(registroDetails['dataDiScadenzaDelServizio']);
      registroDetails['dataDiSottoscrizione'] = this.proposteService.getDateObject(registroDetails['dataDiSottoscrizione']);
      registroDetails['dataDiUltimaValutazione'] = this.proposteService.getDateObject(registroDetails['dataDiUltimaValutazione']);
      registroDetails['dataDiUltimoRinnovoDelContratto'] =
        this.proposteService.getDateObject(registroDetails['dataDiUltimoRinnovoDelContratto']);
      registroDetails['dataSottoscrizioneDelServizio'] =
        this.proposteService.getDateObject(registroDetails['dataSottoscrizioneDelServizio']);
      registroDetails['dataDellUltimaValutazione'] = this.proposteService.getDateObject(registroDetails['dataDellUltimaValutazione']);
      registroDetails['Dataparere'] = this.proposteService.getDateObject(registroDetails['Dataparere']);
      registroDetails['dataParere'] = this.proposteService.getDateObject(registroDetails['dataParere']);
      if (registroDetails['pareresuiContrattiComplianceList']) {
        registroDetails['pareresuiContrattiComplianceList'] = registroDetails.pareresuiContrattiComplianceList.map(el => {
          return {
            ...el,
            dataParere: this.proposteService.getDateObject(el.dataParere)
          };
        });
        const complianceListFormArray = new FormArray(registroDetails.pareresuiContrattiComplianceList.map(group => new FormGroup({
          parereSuiContrattiComplianceId: new FormControl(group.parereSuiContrattiComplianceId),
          contrattoId: new FormControl(group.contrattoId),
          idRegistro: new FormControl(group.idRegistro),
          dataParere: new FormControl(group.dataParere, [Validators.required]),
          areaNormativa: new FormControl(group.areaNormativa, [Validators.required]),
          livelloRischioNonConformita: new FormControl(group.livelloRischioNonConformita, [Validators.required]),
          livelloDiAdeguatezza: new FormControl(group.livelloDiAdeguatezza, [Validators.required]),
          statoCompletoCompliance: new FormControl(group.statoCompletoCompliance),
          // nparere: new FormControl(group.nparere, [Validators.required])
          nparere: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(8)]),
        })));
        this.dettaglioRegistroForm.setControl('pareresuiContrattiComplianceList', complianceListFormArray);
      } else {
        registroDetails['pareresuiContrattiComplianceList'] = [];
      }
      if (registroDetails['parereSuiContrattiRischiList']) {
        registroDetails['parereSuiContrattiRischiList'] = registroDetails.parereSuiContrattiRischiList.map(el => {
          return {
            ...el,
            dataParere: this.proposteService.getDateObject(el.dataParere)
          };
        });
        const rischiListFormArray = new FormArray(registroDetails.parereSuiContrattiRischiList.map(group => new FormGroup({
          parereSuiContrattiRischiId: new FormControl(group.parereSuiContrattiRischiId),
          contrattoId: new FormControl(group.contrattoId),
          idRegistro: new FormControl(group.idRegistro),
          dataParere: new FormControl(group.dataParere, [Validators.required]),
          livelloDiRischiosita: new FormControl(group.livelloDiRischiosita, [Validators.required]),
          statoCompletoRischi: new FormControl(group.statoCompletoRischi),
          // nparereRischio: new FormControl(group.nparereRischio),
          nparereRischio: new FormControl(group.nparereRischio, [Validators.minLength(5), Validators.maxLength(8)]),
        })));
        this.dettaglioRegistroForm.setControl('parereSuiContrattiRischiList', rischiListFormArray);
      } else {
        registroDetails['parereSuiContrattiRischiList'] = [];
      }
      if (registroDetails['registroName']) {
        this.title = registroDetails['registroName'];
      }
      // tslint:disable-next-line: max-line-length
      if (this.registroDetails['categorieBankIt']) {
        const categoriaBankIT = this.filters[this.filterKeys[7]].filter(filter => (filter.itemName === this.registroDetails['categorieBankIt']));
        this.subCategoriaBankIT = await this.getDropdownData(categoriaBankIT[0]['subDomainList']);
      }
      this.dettaglioRegistroForm.patchValue(registroDetails);
      // this.dettaglioRegistroForm.get('statoServizio').setValue('selezionare valore');
      // this.dettaglioRegistroForm.get('nomesocietaCliente').disable();
      this.dettaglioRegistroForm.updateValueAndValidity();
      // this.dettaglioRegistroForm.get('sostituibilità').setValue(registroDetails.servizioEntity.sostituibilità);
    });
  }


  async ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
      this.hasRegistroReadOnly = operationModel.hasRegistroReadOnly;
    this.getDropdownTableKeys();
    await this.createForm();
    combineLatest(
      this.proposteService.getAllClientiDetails(),
      this.proposteService.getFornitourDropdownDetails()
    ).subscribe(async ([
      clientDetails,
      supplierDetails,
    ]) => {
      this.clientDetails = clientDetails;
      const items: SelectView[] = [];
      this.clientDetails.map((value) => {
        const item = new SelectView(value.nomeSocieta, value.nomeSocieta);
        items.push({
          description: value.nomeSocieta,
          value: value.nomeSocieta
        });
      });
      this.allClientiDetails = items;
      this.allSupplierDetails = supplierDetails;
      // this.supplierDetails = supplierDetails;
      // const supplierItems: SelectView[] = [];
      // this.supplierDetails.map((value) => {
      //   const item = new SelectView(value.nomeSocieta, value.nomeSocieta);
      //   items.push({
      //     description: value.nomeSocieta,
      //     value: value.nomeSocieta
      //   });
      // });
      // this.allSupplierDetails = supplierItems;
      // console.log('this.allSupplierDetails', this.allSupplierDetails);
    });
    this.route.params.subscribe(async params => {
      this.registroId = params['registroId'];
    });
  }

  async resetForm() {
    this.dettaglioRegistroForm.reset();
    this.dettaglioRegistroForm.patchValue(this.registroDetails);
    this.dettaglioRegistroForm.updateValueAndValidity();
  }

  updateRegistro() {
    this.dettaglioRegistroForm.value['pareresuiContrattiComplianceList'] =
      this.dettaglioRegistroForm.value['pareresuiContrattiComplianceList'].map(el => {
        return {
          ...el,
          dataParere: this.proposteService.getUTCDate(el.dataParere)
        };
      });
    this.dettaglioRegistroForm.value['parereSuiContrattiRischiList'] =
      this.dettaglioRegistroForm.value['parereSuiContrattiRischiList'].map(el => {
        return {
          ...el,
          dataParere: this.proposteService.getUTCDate(el.dataParere)
        };
      });
    const dettaglioData = {
      ...this.dettaglioRegistroForm.value,
      dataCessazioneDelContratto: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataCessazioneDelContratto']),
      dataCessazioneDelServizio: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataCessazioneDelServizio']),
      dataDelProssimoAudit: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataDelProssimoAudit']),
      dataDelUltimoAudit: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataDelUltimoAudit']),
      dataDiDecorrenza: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataDiDecorrenza']),
      dataDiDecorrenzaDelServizio: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataDiDecorrenzaDelServizio']),
      dataDiScadenzaDelContratto: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataDiScadenzaDelContratto']),
      dataDiScadenzaDelServizio: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataDiScadenzaDelServizio']),
      dataDiSottoscrizione: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataDiSottoscrizione']),
      dataDiUltimaValutazione: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataDiUltimaValutazione']),
      dataDiUltimoRinnovoDelContratto: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataDiUltimoRinnovoDelContratto']),
      dataSottoscrizioneDelServizio: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataSottoscrizioneDelServizio']),
      dataDellUltimaValutazione: this.proposteService.getUTCDate(this.dettaglioRegistroForm.value['dataDellUltimaValutazione']),
      registroName: this.title
    };
    this.registroService.updateRegistro(dettaglioData).subscribe(updateSuccess => {
      this.getRegistroDetails(this.registroId);
    });
  }
}
