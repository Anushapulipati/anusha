import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistroPageComponent } from './registro-page.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { RegistroService } from '../../services/registro.service';
import { By } from '@angular/platform-browser';
import { FormGroup, FormControl, FormArray, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ProposteService } from 'src/app/modules/proposte/services/proposte.service';
import { LoginService } from 'src/app/shared/services/login.service';
import { SearchInputService } from 'src/app/shared/services/search-input.service';
import { DialogService, FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { DialogComponent } from 'fe-dghub-component-library/lib/components/dialog/dialog.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}


describe('RegistroPageComponent', () => {
  let component: RegistroPageComponent;
  let fixture: ComponentFixture<RegistroPageComponent>;
  let registroService;
  let proposteService;
  let loginService;
  let searchInputService;
  let registroMockResponse;
  let dialogService;
  let registroForm = new FormGroup({
   statoServizio: new FormControl([]),
   categoriaInterna: new FormControl([]),
   categoriaBankIt: new FormControl([]),
   ordinaPer: new FormControl([]),
   classificazione: new FormArray([
     new FormControl(true),
     new FormControl(true),
     new FormControl(true),
     new FormControl(true)
   ])
 }); 
  const router = { events: of({ tipsId: '4' }),
    createUrlTree: (commands, navExtras = {}) => {},
    serializeUrl : () => {} };

  beforeEach(async(() => {
    proposteService = jasmine.createSpyObj(['getDropdownKeys', 'getDropdownData']);
    registroService = jasmine.createSpyObj(['filterRegistroData', 'exportToRegistroOggiExcel']);
    loginService = jasmine.createSpyObj(['getOperationModel']);
    TestBed.configureTestingModule({
      declarations: [ RegistroPageComponent],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
       FormsModule,
       ReactiveFormsModule,
      FeDghubComponentLibraryModule,
        HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: RegistroService, useValue: registroService },
        { provide: ProposteService, useValue: proposteService },
        { provide: LoginService, useValue: loginService},
       /*  { provide: DialogService, useValue: dialogService}, */
        
        /* {provide: SearchInputService, useValue: searchInputService} */
      ],
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const operationModel = {
      hasExportBySystemDate: true,
    };

    const mockResponse = {
      'Categorie BankIT': [
         {
            'itemId': '1',
            'tableId': 'Categorie BankIT',
            'itemName': 'Credito / cartolarizzazioni',
            'subDomainList': [
               {
                  'itemId': '128',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Fasi o specifiche attivitÃ  del processo di istruttoria',
                  'subDomainList': null
               },
               {
                  'itemId': '129',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Fasi o specifiche attivitÃ  del processo di monitoraggio',
                  'subDomainList': null
               },

            ]
         },
         {
            'itemId': '2',
            'tableId': 'Categorie BankIT',
            'itemName': 'Servizi di pagamento 123',
            'subDomainList': [
               {
                  'itemId': '135',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Gestione conti di pagamento',
                  'subDomainList': null
               },
               {
                  'itemId': '136',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Gestione processing carte',
                  'subDomainList': null
               },

            ]
         },
         {
            'itemId': '3',
            'tableId': 'Categorie BankIT',
            'itemName': 'Gestione collettiva',
            'subDomainList': [
               {
                  'itemId': '140',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Gestione del portafoglio dei fondi',
                  'subDomainList': null
               },
               {
                  'itemId': '141',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Funzione di valutazione indipendente dei beni del fondo',
                  'subDomainList': null
               },

            ]
         },
         {
            'itemId': '4',
            'tableId': 'Categorie BankIT',
            'itemName': 'Servizi e attività di investimento',
            'subDomainList': [
               {
                  'itemId': '147',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Gestione del portafoglio dei clienti',
                  'subDomainList': null
               },
               {
                  'itemId': '148',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Anagrafe titoli centralizzata',
                  'subDomainList': null
               },

            ]
         },
         {
            'itemId': '5',
            'tableId': 'Categorie BankIT',
            'itemName': 'Funzioni aziendali di controllo',
            'subDomainList': [
               {
                  'itemId': '154',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Funzione di risk management',
                  'subDomainList': null
               },
               {
                  'itemId': '155',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Funzione di compliance',
                  'subDomainList': null
               },

            ]
         },
         {
            'itemId': '6',
            'tableId': 'Categorie BankIT',
            'itemName': 'Categoria dell attività esternalizzata: sistema informativo',
            'subDomainList': [
               {
                  'itemId': '160',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Full outsourcing1',
                  'subDomainList': null
               },
               {
                  'itemId': '161',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Centro dati operativo2',
                  'subDomainList': null
               },

            ]
         },
         {
            'itemId': '7',
            'tableId': 'Categorie BankIT',
            'itemName': 'servizi amministrativi e adempimenti di vigilanza',
            'subDomainList': [
               {
                  'itemId': '170',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Segnalazioni Centrale dei Rischi e di vigilanza',
                  'subDomainList': null
               },
               {
                  'itemId': '171',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'ContabilitÃ  generale e bilancio',
                  'subDomainList': null
               },

            ]
         },
         {
            'itemId': '8',
            'tableId': 'Categorie BankIT',
            'itemName': 'rapporti con la clientela',
            'subDomainList': [
               {
                  'itemId': '178',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Invio di documentazione di supporto (informativa, resoconti, servizi di postalizzazione, ecc.)',
                  'subDomainList': null
               },
               {
                  'itemId': '179',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Supporto alla clientela (call centre)',
                  'subDomainList': null
               },

            ]
         },
         {
            'itemId': '9',
            'tableId': 'Categorie BankIT',
            'itemName': 'altre attività',
            'subDomainList': [
               {
                  'itemId': '116',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'child one',
                  'subDomainList': null
               },
               {
                  'itemId': '117',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'child two',
                  'subDomainList': null
               },

            ]
         },
         {
            'itemId': '119',
            'tableId': 'Categorie BankIT',
            'itemName': 'Credito / cartolarizzazioni123',
            'subDomainList': null
         },

         {
            'itemId': '196',
            'tableId': 'Categorie BankIT',
            'itemName': 'Test Category01',
            'subDomainList': [
               {
                  'itemId': '197',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Test sub cstegory01',
                  'subDomainList': null
               }
            ]
         },
         {
            'itemId': '198',
            'tableId': 'Categorie BankIT',
            'itemName': 'Test category#02',
            'subDomainList': [
               {
                  'itemId': '199',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Test sub category#01',
                  'subDomainList': null
               }
            ]
         },
         {
            'itemId': '202',
            'tableId': 'Categorie BankIT',
            'itemName': 'Test main category',
            'subDomainList': null
         },
         {
            'itemId': '203',
            'tableId': 'Categorie BankIT',
            'itemName': 'Prova1234444',
            'subDomainList': [
               {
                  'itemId': '204',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Test123',
                  'subDomainList': null
               }
            ]
         },
         {
            'itemId': '205',
            'tableId': 'Categorie BankIT',
            'itemName': 'Test nuova categoria',
            'subDomainList': [
               {
                  'itemId': '206',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'test sottocategoria 1',
                  'subDomainList': null
               },
               {
                  'itemId': '207',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'test sottocategoria 2',
                  'subDomainList': null
               }
            ]
         },
         {
            'itemId': '208',
            'tableId': 'Categorie BankIT',
            'itemName': 'Test Anagrafe#012345',
            'subDomainList': [
               {
                  'itemId': '209',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'Test sub anagrafe Test112233',
                  'subDomainList': null
               }
            ]
         },
         {
            'itemId': '210',
            'tableId': 'Categorie BankIT',
            'itemName': 'Testing',
            'subDomainList': [
               {
                  'itemId': '211',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'First',
                  'subDomainList': null
               }
            ]
         },
         {
            'itemId': '212',
            'tableId': 'Categorie BankIT',
            'itemName': 'Testing 1',
            'subDomainList': [
               {
                  'itemId': '213',
                  'tableId': 'SottoCategorie BankIT',
                  'itemName': 'First',
                  'subDomainList': null
               }
            ]
         }
      ],
      'STATO_SERVIZIO': [
         {
            'itemId': '1',
            'tableId': 'STATO_SERVIZIO',
            'itemName': 'In attesa sottoscrizione',
            'subDomainList': null
         },
         {
            'itemId': '2',
            'tableId': 'STATO_SERVIZIO',
            'itemName': 'In vigore',
            'subDomainList': null
         },

      ],
      'Categorie EBA': [
         {
            'itemId': '1',
            'tableId': 'Categorie EBA',
            'itemName': 'Infrastruttura globale di messaggistica finanziaria soggetta alla vigilanza delle pertinenti autorità',
            'subDomainList': null
         },
         {
            'itemId': '2',
            'tableId': 'Categorie EBA',
            'itemName': 'Acquisizione di beni (e.g. tessere di plastica, lettori di carte, forniture per ufficio, personal computer, mobilio)',
            'subDomainList': null
         },

      ],
      'Ordina per Registro': [
         {
            'itemId': '1',
            'tableId': 'Ordina per Registro',
            'itemName': 'Fornitore A-Z',
            'subDomainList': null
         },
         {
            'itemId': '2',
            'tableId': 'Ordina per Registro',
            'itemName': 'Fornitore Z-A',
            'subDomainList': null
         },

      ]
   };
    registroMockResponse = {
      'registroFilterResponseList': [
         {
            'registroId': 147,
            'societaDelGruppoCliente': 'SV Banca',
            'fornitore': 'Capgemini Italia',
            'fornitoreInfraExtraGruppo': 'Infragruppo',
            'classificazione': 'Fornitura',
            'perimetroMonitoraggioICTVendor': null,
            'statoDelServizio': 'In attesa sottoscrizione',
            'ogettoDelContratto': null,
            'descrizioneDelServizioErogato': 'Breve ',
            'contrattoId': null,
            'fornitoreId': null
         },
         {
            'registroId': 84,
            'societaDelGruppoCliente': 'SV Banca',
            'fornitore': 'Capgemini Italia',
            'fornitoreInfraExtraGruppo': 'Infragruppo',
            'classificazione': 'Fornitura',
            'perimetroMonitoraggioICTVendor': 'Si',
            'statoDelServizio': 'In vigore',
            'ogettoDelContratto': null,
            'descrizioneDelServizioErogato': null,
            'contrattoId': null,
            'fornitoreId': null
         }
      ],
      'totalNumberOfRecords': 27
   };
   registroForm = new FormGroup({
    statoServizio: new FormControl([]),
    categoriaInterna: new FormControl([]),
    categoriaBankIt: new FormControl([]),
    ordinaPer: new FormControl([]),
    classificazione: new FormArray([
      new FormControl(true),
      new FormControl(true),
      new FormControl(true),
      new FormControl(true)
    ])
  });
    const filterKeys = ['Categorie BankIT', 'STATO_SERVIZIO', 'Categorie EBA', 'Ordina per Registro'];
    proposteService.getDropdownKeys.and.returnValue(of(filterKeys));
    proposteService.getDropdownData.and.returnValue(of(mockResponse));
    registroService.filterRegistroData.and.returnValue(of(registroMockResponse));
    loginService.getOperationModel.and.returnValue(of(operationModel));
    // searchInputService.searchInputService.and.returnValue(of(mockResponse))
    fixture = TestBed.createComponent(RegistroPageComponent);
    component = fixture.componentInstance;
    // ixture.detectChanges();
    component.hasExportBySystemDate = true;
  });

  it('should create', () => {
    component.hasExportBySystemDate = true;
    expect(component).toBeTruthy();
  });

  
  it('should check filter keys', () => {
    component.hasExportBySystemDate = true;
   const filterKeys = ['Categorie BankIT', 'STATO_SERVIZIO', 'Categorie EBA', 'Ordina per Registro'];
    fixture.detectChanges();
    expect(component.filterKeys).toEqual(filterKeys);
  });
 it('should call applyFilter and return the said result', () => {
  component.hasExportBySystemDate = true;
  component.hasRegistroFornitoreDisabled = true;
  const registroFormFilters = new FormGroup({
    statoServizio: new FormControl(['statoServizio']),
    categoriaInterna: new FormControl([]),
    categoriaBankIt: new FormControl([]),
    ordinaPer: new FormControl([]),
    classificazione: new FormArray([
      new FormControl(true),
      new FormControl(true),
      new FormControl(true),
      new FormControl(true)
    ])
  });
  component.registroForm = registroFormFilters;
    const mockResponse = {
      'registroFilterResponseList': [
         {
            'registroId': 147,
            'societaDelGruppoCliente': 'SV Banca',
            'fornitore': 'Capgemini Italia',
            'fornitoreInfraExtraGruppo': 'Infragruppo',
            'classificazione': 'Fornitura',
            'perimetroMonitoraggioICTVendor': null,
            'statoDelServizio': 'In attesa sottoscrizione',
            'ogettoDelContratto': null,
            'descrizioneDelServizioErogato': 'Breve ',
            'contrattoId': null,
            'fornitoreId': null
         },
         {
            'registroId': 84,
            'societaDelGruppoCliente': 'SV Banca',
            'fornitore': 'Capgemini Italia',
            'fornitoreInfraExtraGruppo': 'Infragruppo',
            'classificazione': 'Fornitura',
            'perimetroMonitoraggioICTVendor': 'Si',
            'statoDelServizio': 'In vigore',
            'ogettoDelContratto': null,
            'descrizioneDelServizioErogato': null,
            'contrattoId': null,
            'fornitoreId': null
         }
      ],
      'totalNumberOfRecords': 27
   };
     
    const mockParameter = {};
    registroService.filterRegistroData.and.returnValue(of(mockResponse));
    component.applyFilter();
    // fixture.detectChanges();
    // expect(registroService.filterRegistroData).toHaveBeenCalled();
    registroService.filterRegistroData(registroFormFilters).subscribe(result => {
      // expect(result).toBe(mockResponse);
    });
  }); 
  it('should call ngoninit', () => {
   spyOn(component, 'ngOnInit');
   component.ngOnInit();
   expect(component.ngOnInit).toHaveBeenCalled();
 });

 it('should call ngOnDestroy', () => {
   spyOn(component, 'ngOnDestroy');
   component.ngOnDestroy();
   expect(component.ngOnDestroy).toHaveBeenCalled();
 });
 /* it('should call onPageChange method', () => {
   const proposals = registroForm;
   const selectedClassificazione = proposals['classificazione'];
   const selectedOrdinaPerFilters = ['Più recenti'];
   const fornitoreOrderVar = selectedOrdinaPerFilters.filter(fil => (fil === 'Fornitore A-Z' || fil === 'Fornitore Z-A'));
   const latestOrderVar =
    selectedOrdinaPerFilters.filter(fil => (fil === 'Più recenti' || fil === 'Meno recenti'));
    const societaClienteOrderVar =
    selectedOrdinaPerFilters.filter(fil => (fil === 'Società del Gruppo Cliente Z-A' || fil === 'Società del Gruppo Cliente A-Z'));

   const registroFilters = {
      'categoriaBankIt': proposals['categoriaBankIt'] ? proposals['categoriaBankIt'].join('@') : '',
      'categoriaInterna': proposals['categoriaInterna'] ? proposals['categoriaInterna'].join('@') : '',
      'classificazione': selectedClassificazione ? selectedClassificazione.join('@') : '',
      'statoServizio': proposals['statoServizio'] ? proposals['statoServizio'].join('@') : '',
      'fornitoreOrderVar': fornitoreOrderVar[0] ? fornitoreOrderVar[0] : '',
      'latestOrderVar': latestOrderVar[0] ? latestOrderVar[0] : '',
      'societaClienteOrderVar': societaClienteOrderVar[0] ? societaClienteOrderVar[0] : '',
      'startIndex': 1
    };
   component.isSearchedResult = false;
   component.onPageChange(1);
   expect(component.page).toBe(1);
   expect(component.isSearchedResult).toBe(false);
 }); */

 it('should call onValueChange', () => {
    const value = [];
   spyOn(component, 'onValueChange');
   component.onValueChange(value);
   expect(component.onValueChange).toHaveBeenCalled();
   expect(component.selectedOrdinaPerFilters).toBeDefined();
 });
 it('should call esportaOggi', () => {
  spyOn(component, 'esportaOggi');
  component.esportaOggi();
  expect(component.esportaOggi).toHaveBeenCalled();
 });

 /* it('should call service exporto method', () => {
   const mockResponse = {'id': 304, 'endTime': null, 'fileContent': null, 'startTime': null, 'status': 'InProgress', 'error': null};
      const filterForm = {
        statoProposta: 'statoProposta',
        categorieInterne: 'categorieInterne',
        categorieBankIT: 'categorieBankIT',
        ordinaPer: 'ordinaPer'
      };
    const mockParameter = {};
    registroService.exportToRegistroOggiExcel.and.returnValue(of(mockResponse));
    component.esportaOggi();
    fixture.detectChanges();
    expect(registroService.exportToRegistroOggiExcel).toHaveBeenCalled();
    registroService.exportToRegistroOggiExcel(mockResponse).subscribe(result => {
      expect(result).toBe(mockResponse);
    });
 }); */
});
