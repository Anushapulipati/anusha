import { Component, Injector, OnInit, Input, OnDestroy } from '@angular/core';
import { FormArray, FormControl, FormGroup } from '@angular/forms';
import { EventsModel } from 'fe-dghub-component-library/lib/models/event-model';
import { BasePage } from 'src/app/shared/base-page/base-page';
import { ProposteService } from 'src/app/modules/proposte/services/proposte.service';
import { TreeviewConfig, TreeviewI18n, TreeviewItem } from 'ngx-treeview';
import { RegistroService } from '../../services/registro.service';
import { EsportaModel } from 'src/app/shared/models/esportaModel';
import { UrlProviderService } from 'src/app/shared/services/url-provider.service';
import {RegistroHeaderComponent } from 'src/app/header/registro-header.component';
import { LoginService } from '../../../shared/services/login.service';
import { ResponseCommonPopUpComponent } from 'src/app/modules/anagrafiche/pages/download-popup/response-common-pop-up.component';
import { DialogService } from 'fe-dghub-component-library';
import { SearchInputService } from 'src/app/shared/services/search-input.service';
import { subscribeOn } from 'rxjs/operators';
import { DropdownTreeviewI18nService } from 'src/app/shared/services/dropdown-treeview-i18n.service';

@Component({
  selector: 'reg-registro-page',
  templateUrl: './registro-page.component.html',
  styleUrls: ['./registro-page.component.scss'],
  providers: [
    DropdownTreeviewI18nService,
    { provide: TreeviewI18n, useClass: DropdownTreeviewI18nService }
  ]
})
export class RegistroPageComponent extends BasePage implements OnInit, OnDestroy {

  categoriaInterne:  TreeviewItem[];
  categorieBankIT:  TreeviewItem[];
  classificazioneList = ['FORNITURE', 'ESTERNALIZZAZIONI', 'ESTERNALIZZAZIONI FEI', 'EST. RILEVANTI'];
  classificazioneValuesList = ['Fornitura', 'Esternalizzazione', 'Esternalizzazione FEI', 'Esternalizzazione Rilevante'];
  collectionSize: number;
  config: TreeviewConfig = TreeviewConfig.create({
    hasAllCheckBox: false,
    hasFilter: false,
    hasCollapseExpand: false,
    decoupleChildFromParent: true,
    maxHeight: 400
  });
  demoEvents: EventsModel[] = [];
  dialogRef: any;
  esportaModel: EsportaModel;
  filterKeys = ['Categorie BankIT', 'STATO_SERVIZIO', 'Categorie EBA', 'Ordina per Registro'];
  filters: any;
  hasExportBySystemDate: boolean;
  hasRegistroFornitoreDisabled: boolean;
  hasRegistroStatoFilter: boolean;
  idOfExcel: number[] = [];
  isFilterApplied: boolean;
  isSearchedResult = false;
  ordinaPer: TreeviewItem[];
  page = 1;
  pageSize = 20;
  proposalsList = [];
  registroForm: FormGroup;
  searchData: any;
  selectedOrdinaPerFilters = [];
  statoProposta: TreeviewItem[];
  subscription: any;
  value: any;

  constructor(
    injector: Injector,
    private proposteService: ProposteService,
    private registroService: RegistroService,
    private urlProviderService: UrlProviderService,
    private loginService: LoginService,
    private dialog: DialogService,
    private searchInputService: SearchInputService
  ) {
    super(injector);
  }

  private checkSearchInput() {
    this.subscription = this.searchInputService.getSearchInput().subscribe((searchInput: any) => {
      if (searchInput && searchInput.inputValue !== '' && searchInput.inputValue !== undefined) {
        this.isSearchedResult = true;
        this.page = 1;
        this.searchData = {
          name : searchInput.page,
          value : searchInput.inputValue,
          startIndex : this.page
        };
        this.getSearchData(this.searchData);
      } else {
        this.isSearchedResult = false;
        this.getDropdownTableKeys();
      }
    });
  }

  private getDropdownTableKeys() {
    this.proposteService.getDropdownData(this.filterKeys).subscribe(async filters => {
      this.filters = filters;
      this.categorieBankIT = await this.getFilterdData(filters[this.filterKeys[0]], true);
      this.statoProposta = await this.getFilterdData(filters[this.filterKeys[1]]);
      this.categoriaInterne = await this.getFilterdData(filters[this.filterKeys[2]], true);
      this.ordinaPer = await this.getFilterdData(filters[this.filterKeys[3]]);
      this.onPageChange(this.page);
    });
  }

  private getSearchData(searchData) {
    this.searchInputService.getSearchResults(searchData).subscribe(searchResult => {
      this.collectionSize = searchResult['count'];
      this.proposalsList = searchResult['registro'];
      this.isSearchedResult = true;
    });
  }

  applyFilter() {
    this.page = 1;
    this.isSearchedResult = false;
    this.isFilterApplied = true;
    const proposals = this.registroForm.value;
    this.getProposals(this.registroForm.value);
  }

  getProposals(proposals) {
    const fornitoreOrderVar = this.selectedOrdinaPerFilters.filter(fil => (fil === 'Fornitore A-Z' || fil === 'Fornitore Z-A'));
    const latestOrderVar =
    this.selectedOrdinaPerFilters.filter(fil => (fil === 'Più recenti' || fil === 'Meno recenti'));
    const societaClienteOrderVar =
    this.selectedOrdinaPerFilters.filter(fil => (fil === 'Società del Gruppo Cliente Z-A' || fil === 'Società del Gruppo Cliente A-Z'));

    const selectedClassificazione = proposals['classificazione'].map((checked, index) => {
      return (checked) ? this.classificazioneValuesList[index] : '';
    }).filter(el => el !== '');
    const registroFilters = {
      'categoriaBankIt': proposals['categoriaBankIt'] ? proposals['categoriaBankIt'].join('@') : '',
      'categoriaInterna': proposals['categoriaInterna'] ? proposals['categoriaInterna'].join('@') : '',
      'classificazione': selectedClassificazione ? selectedClassificazione.join('@') : '',
      'statoServizio': proposals['statoServizio'] ? proposals['statoServizio'].join('@') : '',
      'fornitoreOrderVar': fornitoreOrderVar[0] ? fornitoreOrderVar[0] : '',
      'latestOrderVar': latestOrderVar[0] ? latestOrderVar[0] : '',
      'societaClienteOrderVar': societaClienteOrderVar[0] ? societaClienteOrderVar[0] : '',
      'startIndex': this.page
    };
    this.registroService.filterRegistroData(registroFilters).subscribe(proposalsResponse => {
      this.collectionSize = proposalsResponse['totalNumberOfRecords'];
      this.proposalsList = proposalsResponse['registroFilterResponseList'];
    });
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  async ngOnInit() {
    this.searchInputService.setSelectedOption('Registro');
    // this.searchInputService.setSearchInput(false);
    this.selectedOrdinaPerFilters = ['Più recenti'];
    const operationModel: any = await this.loginService.getOperationModel();
      this.hasRegistroFornitoreDisabled = operationModel ? operationModel.hasRegistroFornitoreDisabled : '';
      this.hasExportBySystemDate = operationModel ? operationModel.hasExportBySystemDate : '';
      this.hasRegistroStatoFilter = operationModel ? operationModel.hasRegistroStatoFilter : '';
    this.getDropdownTableKeys();
    this.registroForm = new FormGroup({
      statoServizio: new FormControl([]),
      categoriaInterna: new FormControl([]),
      categoriaBankIt: new FormControl([]),
      ordinaPer: new FormControl([]),
      classificazione: new FormArray([
        new FormControl(!this.hasRegistroFornitoreDisabled),
        new FormControl(true),
        new FormControl(true),
        new FormControl(true)
      ])
    });
    this.checkSearchInput();
  }

  onPageChange(event) {
    this.page = event;
    let proposals;
    if (this.isFilterApplied) {
      proposals = this.registroForm.value;
    } else {
      const categoriaBankIt = this.categorieBankIT.map(category => {
        let childrens = [];
        if (category.children) {
          childrens = category.children.map(c => c.value);
        }
        return [category.value, ...childrens];
      });
      const categoriaBankItFlatten = [].concat.apply([], categoriaBankIt);
      proposals = {
        categoriaInterna: this.filters[this.filterKeys[2]].map(categoria => categoria.itemName),
        categoriaBankIt: categoriaBankItFlatten,
        ordinaPer: [],
        statoServizio: ['In attesa sottoscrizione', 'In vigore'],
        classificazione: [true, true, true, true]
      };
    }
    if (this.isSearchedResult) {
      this.searchData['startIndex'] = this.page;
      this.getSearchData(this.searchData);
    } else {
      this.getProposals(proposals);
    }
  }

  onValueChange(value) {
    this.selectedOrdinaPerFilters = [value];
  }

  selectedValue(value) {}
  esportaOggi() {
    this.showDownloadPopUp();
    console.log("oggi");
    this.registroService.exportToRegistroOggiExcel(this.esportaModel).subscribe(data => {
      this.idOfExcel.push(data.id);
      this.verifyStatus(data.id);
     // localStorage.setItem("idsToExport", this.idOfExcel);
    });
  }
    esporta() {
      this.showDownloadPopUp();
      this.registroService.exportToRegistroExcel(this.esportaModel).subscribe(data => {
        this.idOfExcel.push(data.id);
        this.verifyStatus(data.id);
       // localStorage.setItem("idsToExport", this.idOfExcel);
      });
    }
    
    verifyStatus(id: any) {
    this.registroService.checkExcelStatus(id).subscribe(
      result => {
        if (result.status === 'Completed') {
          this.downloadFile(result.id, result.glossariType);
        } else {
            // tslint:disable-next-line:no-non-null-assertion
            if (result.status ! = 'Failed') {
              setTimeout(() => {
                this.verifyStatus(result.id);
              }, 10000);
            }
        }
      }
    );
    }
    downloadFile(data: any, fileName: any) {
      console.log("inside download");
    const element = document.createElement('a');
    window.open(this.urlProviderService.downloadRegistroExcel + '?id=' + data);
    this.dialogRef.close();
    }

    showDownloadPopUp() {
      const message = {
        title: 'message',
        body: '',
        details: '',
        stackTrace: ''
      };
      message.details = 'downloading..';
      this.dialogRef = this.dialog.open(ResponseCommonPopUpComponent, {
        size: 'small',
        noCloseButton: true,
        data: { message }
      });
      this.dialogRef.afterClosed.subscribe(result => {
        if (result) {
  
        }
      });
    }
    }
