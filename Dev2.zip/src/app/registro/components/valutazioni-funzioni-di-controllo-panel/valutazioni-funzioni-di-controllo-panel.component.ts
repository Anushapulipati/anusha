import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { SelectView } from 'src/app/shared/models/selectView';
import { LoginService } from '../../../shared/services/login.service';

@Component({
  selector: 'reg-valutazioni-funzioni-di-controllo-panel',
  templateUrl: './valutazioni-funzioni-di-controllo-panel.component.html',
  styleUrls: ['./valutazioni-funzioni-di-controllo-panel.component.scss']
})
export class ValutazioniFunzioniDiControlloPanelComponent implements OnInit {
  @Input() areaNormativa: SelectView[];
  // canaledisegnalazione: any;
  hasRegistroReadOnly: boolean;
  isValutazioniPanel: boolean;
  livello: SelectView[];
  @Input() livelloAdeguatezza: SelectView[];
  @Input() livellodiRischiosita: SelectView[];
  opened: boolean;
  valutazioniControls = [
    'breveSintesiDeiMotivi',
    'dataDellUltimaValutazione',
    'pareresuiContrattiComplianceList',
    'dataDelUltimoAudit',
    'dataDelProssimoAudit',
    'dataDiUltimaValutazione',
    'breveSintesiSulLivello',
    'parereSuiContrattiRischiList',
  ];
  @Input() valutazioniFunzioniForm: FormGroup;
  constructor(private loginService: LoginService) { }

  private checkValiidation() {
    this.valutazioniFunzioniForm.valueChanges.subscribe(changes => {
      this.isValutazioniPanel = this.valutazioniControls.every(control => {
        return this.valutazioniFunzioniForm.get(control).valid;
      });
    });
  }

  changeValue() {
    this.valutazioniFunzioniForm.get('pareresuiContrattiComplianceList').updateValueAndValidity();
    this.valutazioniFunzioniForm.get('parereSuiContrattiRischiList').updateValueAndValidity();
    this.valutazioniFunzioniForm.updateValueAndValidity();
  }

  formatNparere(index, input) {
    input = input.replace(/[\W\s\._\-]+/g, '');
    let split = 4;
    const chunk = [];
    for (let i = 0, len = input.length; i < len; i += split) {
      split = ( i >= 0 && i <= 4 ) ? 4 : 100;
      chunk.push( input.substr( i, split ) );
    }
    // this.valutazioniFunzioniForm.controls[index].get('nparere').setValue(chunk.join('_'));
    this.valutazioniFunzioniForm.get('pareresuiContrattiComplianceList')['controls'][index].get('nparere').setValue(chunk.join('_'));
    this.valutazioniFunzioniForm.get('pareresuiContrattiComplianceList').updateValueAndValidity();
    this.valutazioniFunzioniForm.updateValueAndValidity();
  }

  formatNparereRischio(index, input) {
    input = input.replace(/[\W\s\._\-]+/g, '');
    let split = 4;
    const chunk = [];
    for (let i = 0, len = input.length; i < len; i += split) {
      split = ( i >= 0 && i <= 4 ) ? 4 : 100;
      chunk.push( input.substr( i, split ) );
    }
    this.valutazioniFunzioniForm.get('parereSuiContrattiRischiList')['controls'][index].get('nparereRischio').setValue(chunk.join('_'));
    this.valutazioniFunzioniForm.get('parereSuiContrattiRischiList').updateValueAndValidity();
    this.valutazioniFunzioniForm.updateValueAndValidity();
  }

  inserisciNuovoParere() {
    const pareresuiContrattiComplianceFormGroup = new FormGroup({
      parereSuiContrattiComplianceId: new FormControl(null),
      contrattoId: new FormControl(null),
      dataParere: new FormControl(null, [Validators.required]),
      areaNormativa: new FormControl('', [Validators.required]),
      livelloRischioNonConformita: new FormControl('', [Validators.required]),
      livelloDiAdeguatezza: new FormControl('', [Validators.required]),
      statoCompletoCompliance: new FormControl('complete'),
      // nparere: new FormControl('', [Validators.required, Validators.pattern('[0-9]{4}_[0-9]{3}')])
      nparere: new FormControl('', [Validators.required, Validators.minLength(5), Validators.maxLength(8)]),
    });
    this.valutazioniFunzioniForm.get('pareresuiContrattiComplianceList')['controls'].push(pareresuiContrattiComplianceFormGroup);
    // this.valutazioniFunzioniForm.markAsDirty();
    this.valutazioniFunzioniForm.get('pareresuiContrattiComplianceList').markAsDirty();
    this.valutazioniFunzioniForm.get('pareresuiContrattiComplianceList').markAsTouched();
    this.valutazioniFunzioniForm.get('pareresuiContrattiComplianceList').updateValueAndValidity();
    this.valutazioniFunzioniForm.markAsDirty();
    this.valutazioniFunzioniForm.markAsDirty();
    this.valutazioniFunzioniForm.updateValueAndValidity();
  }

  inserisciNuovoRischiParere() {
    const parereSuiContrattiRischiFormGroup = new FormGroup({
      parereSuiContrattiRischiId: new FormControl(null),
      contrattoId: new FormControl(null),
      dataParere: new FormControl(null, [Validators.required]),
      livelloDiRischiosita: new FormControl('', [Validators.required]),
      statoCompletoRischi: new FormControl('complete'),
      nparereRischio: new FormControl('', [Validators.minLength(5), Validators.maxLength(8)]),
    });
    this.valutazioniFunzioniForm.get('parereSuiContrattiRischiList')['controls'].push(parereSuiContrattiRischiFormGroup);
    this.valutazioniFunzioniForm.get('parereSuiContrattiRischiList').markAsTouched();
    this.valutazioniFunzioniForm.get('parereSuiContrattiRischiList').markAsDirty();
    this.valutazioniFunzioniForm.get('parereSuiContrattiRischiList').updateValueAndValidity();
    this.valutazioniFunzioniForm.markAsDirty();
    this.valutazioniFunzioniForm.markAsTouched();
    this.valutazioniFunzioniForm.updateValueAndValidity();
  }

  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasRegistroReadOnly = operationModel ? operationModel.hasRegistroReadOnly : '';
    this.checkValiidation();
  }
}
