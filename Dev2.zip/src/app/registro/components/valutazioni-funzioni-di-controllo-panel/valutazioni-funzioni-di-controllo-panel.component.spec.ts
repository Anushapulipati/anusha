import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ValutazioniFunzioniDiControlloPanelComponent } from './valutazioni-funzioni-di-controllo-panel.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';
import { LoginService } from 'src/app/shared/services/login.service';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('ValutazioniFunzioniDiControlloPanelComponent', () => {
  let component: ValutazioniFunzioniDiControlloPanelComponent;
  let fixture: ComponentFixture<ValutazioniFunzioniDiControlloPanelComponent>;
  let dettaglioRegistroForm;
  let loginService;

  beforeEach(async(() => {
    loginService = jasmine.createSpyObj(['getOperationModel']);
    TestBed.configureTestingModule({
      declarations: [ ValutazioniFunzioniDiControlloPanelComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        NgbModule,
        HttpClientModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers : [
        { provide: LoginService, useValue: loginService},
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    const operationModel = {
      hasRegistroReadOnly: true,
    };

    fixture = TestBed.createComponent(ValutazioniFunzioniDiControlloPanelComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
    loginService.getOperationModel.and.returnValue(of(operationModel));
    dettaglioRegistroForm = new FormGroup({
      idRegistro: new FormControl(''),
      statoServizio: new FormControl('selezionare valore', Validators.required),
      slaMonitorati: new FormControl('', Validators.required),
      referenteDiContratto: new FormControl('', Validators.required),
      nomesocietaCliente: new FormControl(''),
      societàDelReferenteErogatoreServiziIT: new FormControl(''),
      clienteInterno: new FormControl(''),
      fornitoreInfragruppo: new FormControl(''),
      gestoreDiBudget: new FormControl(''),
      fornituraNonICTRilevante: new FormControl('', Validators.required),
      perimetroMonitoraggioICTVendor: new FormControl(''),
      note: new FormControl(''),
      referenteErogatoreServiziIT: new FormControl(''),
      fornituraICTRilevanterischioalto: new FormControl('', Validators.required),
      dataDelUltimoAudit: new FormControl(null),
      dataDelProssimoAudit: new FormControl(null),
      dataDiUltimaValutazione: new FormControl(null, Validators.required),
      dataDiDecorrenza: new FormControl(null, Validators.required),
      dataDiSottoscrizione: new FormControl(null, Validators.required),
      dataCessazioneDelContratto: new FormControl(null, Validators.required),
      dataDiUltimoRinnovoDelContratto: new FormControl(null, Validators.required),
      statoContratto: new FormControl(''),
      classificazione: new FormControl(''),
      codiceContratto: new FormControl(''),
      codiceContrattoPadre: new FormControl(''),
      oggettoDelContratto: new FormControl('', Validators.required),
      // descrizioneServizioErogato: new FormControl('', Validators.required),
      descrizioneServizioErogato:  new FormControl('', Validators.required),
      statodelContratto: new FormControl('', Validators.required),
      durataDelRinnovo: new FormControl('', Validators.required),
      tacitoRinnovo: new FormControl('', Validators.required),
      costoTotaleDelContratto: new FormControl(''),
      terminiPreavvisoCliente: new FormControl('', Validators.required),
      terminiPreavvisoFornitore: new FormControl('', Validators.required),
      possibilitaDiRecesso: new FormControl(''),
      sogliaDiImpattoDellinterruzioneDellaFunzione: new FormControl('', Validators.required),
      costoAnnuoDiEsercizio: new FormControl(''),
      sostituibilità: new FormControl('', Validators.required),
      fornitoriAlternativi: new FormControl('', Validators.required),
      possibilitàDiReinternalizzazione: new FormControl('', Validators.required),
      subFornitore: new FormControl(''),
      numeroSubfornitori: new FormControl('', Validators.required),
      costoStimatoDelContratto: new FormControl('', Validators.required),
      dataDiDecorrenzaDelServizio: new FormControl(''),
      dataSottoscrizioneDelServizio: new FormControl(''),
      dataDiScadenzaDelServizio: new FormControl(''),
      breveSintesiDeiMotivi: new FormControl('', Validators.required),
      // sintesideiMotivi: new FormControl('', Validators.required),
      dataDellUltimaValutazione: new FormControl(null, Validators.required),
      dataCessazioneDelServizio: new FormControl(''),
      breveSintesiSulLivello: new FormControl('', Validators.required),
      // breveRischiosita: new FormControl('', Validators.required),
      // NPareredirischio: new FormControl(''),
      // Dataparere: new FormControl(null, Validators.required),
      // livellodiRischiosita: new FormControl('', Validators.required),
      dataDiScadenzaDelContratto: new FormControl('', Validators.required),
      pareresuiContrattiComplianceList: new FormArray([]),
      parereSuiContrattiRischiList: new FormArray([]),
      oggDellaProposta: new FormControl(''),
      datiPersonali: new FormControl(''),
      funzioneEsternalizzata: new FormControl(''),
      paeseDiVieneSvolto: new FormControl(''),
      paesediconDati: new FormControl(''),
      marcoProcesso: new FormControl(''),
      racConDeiPro: new FormControl(''),
      trasferimentoDati: new FormControl(''),
      servizioInfrastrttra:  new FormControl(''),
      tipologiaDiCloud:  new FormControl(''),
      cloudpaesediCon:  new FormControl(''),
      categorieBankIt:  new FormControl(''),
      sottoCategorieBankIt:  new FormControl(''),
      categoriaEba:  new FormControl(''),
      tipologiaDaDati: new FormControl(''),
      cloudNaturaDaDati: new FormControl('')
    });
    component.valutazioniFunzioniForm = dettaglioRegistroForm;
  });


   it('should create', () => {
    expect(component).toBeTruthy();
  });
 
 
  it('should call inserisciNuovoParere', () => {
  
    component.inserisciNuovoParere();
    dettaglioRegistroForm.get('pareresuiContrattiComplianceList').markAsDirty();
    dettaglioRegistroForm.get('pareresuiContrattiComplianceList').markAsTouched();
    dettaglioRegistroForm.get('pareresuiContrattiComplianceList').updateValueAndValidity();
    dettaglioRegistroForm.markAsDirty();
    dettaglioRegistroForm.markAsDirty();
    dettaglioRegistroForm.updateValueAndValidity();
    component.changeValue();
    component.ngOnInit();
    component.inserisciNuovoRischiParere();
   
    expect(component.valutazioniFunzioniForm).toBeDefined();
  });
  
  
});
