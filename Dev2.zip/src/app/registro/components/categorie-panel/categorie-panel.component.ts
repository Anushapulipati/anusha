import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { SelectView } from 'src/app/shared/models/selectView';
import { ServizioDetailsVm } from 'src/app/shared/models/servizioDetailsVm';

@Component({
  selector: 'reg-categorie-panel',
  templateUrl: './categorie-panel.component.html',
  styleUrls: ['./categorie-panel.component.scss']
})
export class CategoriePanelComponent implements OnInit {
  @Input() categoriaBankIT: SelectView[];
  @Input() categoriaEBA: SelectView[];
  @Input() categorieForm: FormGroup;
  @Input() filters: any;
  opened: boolean;
  @Input() registroDetails: any;
  @Input() servizioDetails: ServizioDetailsVm;
  @Input() subCategoriaBankIT: SelectView[];
  constructor() { }

  private getDropdownData(filters) {
    const items: SelectView[] = [];
    filters.map((filter, index) => {
      const item = new SelectView(filter.itemName, filter.itemName);
      items.push({
        description: filter.itemName,
        value: filter.itemName
      });
    });
    return items;
  }

  ngOnInit() {
  }

  setCategoriaBankIT(selectedBankIT) {
    this.filters['Categorie BankIT'].forEach(async filter => {
      if (filter.itemName === selectedBankIT) {
        if (filter.subDomainList && filter.subDomainList.length > 0) {
          this.subCategoriaBankIT = await this.getDropdownData(filter.subDomainList);
          this.categorieForm.get('sottoCategorieBankIt').setValue(this.subCategoriaBankIT[0].value);
          this.categorieForm.get('sottoCategorieBankIt').updateValueAndValidity();
        }
      }
    });
  }
}
