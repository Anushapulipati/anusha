import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CategoriePanelComponent } from './categorie-panel.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { NgbDateParserFormatter } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from 'src/app/shared/services/dateFormat';
import { FormGroup, FormControl, Validators, FormArray } from '@angular/forms';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('CategoriePanelComponent', () => {
  let component: CategoriePanelComponent;
  let fixture: ComponentFixture<CategoriePanelComponent>;
  let dropdownResponse;
  let dettaglioRegistroForm;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CategoriePanelComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    dropdownResponse = {
      'Categorie BankIT': [
         {
            'itemId':  '1',
            'tableId':  'Categorie BankIT',
            'itemName':  'Credito / cartolarizzazioni',
            'subDomainList': [
               {
                  'itemId':  '128',
                  'tableId':  'SottoCategorie BankIT',
                  'itemName':  'Fasi o specifiche attivitÃ  del processo di istruttoria',
                  'subDomainList':   null
               },
               {
                  'itemId':  '129',
                  'tableId':  'SottoCategorie BankIT',
                  'itemName':  'Fasi o specifiche attivitÃ  del processo di monitoraggio',
                  'subDomainList':   null
               },

            ]
         },
         {
            'itemId':  '2',
            'tableId':  'Categorie BankIT',
            'itemName':  'Servizi di pagamento 123',
            'subDomainList': [
               {
                  'itemId':  '135',
                  'tableId':  'SottoCategorie BankIT',
                  'itemName':  'Gestione conti di pagamento',
                  'subDomainList':   null
               },
               {
                  'itemId':  '136',
                  'tableId':  'SottoCategorie BankIT',
                  'itemName':  'Gestione processing carte',
                  'subDomainList':   null
               },

            ]
         },


      ],
      'STATO_SERVIZIO': [
         {
            'itemId':  '1',
            'tableId':  'STATO_SERVIZIO',
            'itemName':  'In attesa sottoscrizione',
            'subDomainList':   null
         },
         {
            'itemId':  '2',
            'tableId':  'STATO_SERVIZIO',
            'itemName':  'In vigore',
            'subDomainList':   null
         },

      ],
      'Categorie EBA': [
         {
            'itemId':  '1',
            'tableId':  'Categorie EBA',
            'itemName':  'Infrastruttura globale di messaggistica finanziaria soggetta alla vigilanza delle pertinenti autorità',
            'subDomainList':   null
         },
         {
            'itemId':  '2',
            'tableId':  'Categorie EBA',
            // tslint:disable-next-line: max-line-length
            'itemName':  'Acquisizione di beni (e.g. tessere di plastica, lettori di carte, forniture per ufficio, personal computer, mobilio)',
            'subDomainList':   null
         },

      ],
      'Ordina per Registro': [
         {
            'itemId':  '1',
            'tableId':  'Ordina per Registro',
            'itemName':  'Fornitore A-Z',
            'subDomainList':   null
         },
         {
            'itemId':  '2',
            'tableId':  'Ordina per Registro',
            'itemName':  'Fornitore Z-A',
            'subDomainList':   null
         },

      ]
   };
   dettaglioRegistroForm = new FormGroup({
    idRegistro: new FormControl(''),
    statoServizio: new FormControl('selezionare valore', Validators.required),
    slaMonitorati: new FormControl('', Validators.required),
    referenteDiContratto: new FormControl('', Validators.required),
    nomesocietaCliente: new FormControl(''),
    societàDelReferenteErogatoreServiziIT: new FormControl(''),
    clienteInterno: new FormControl(''),
    fornitoreInfragruppo: new FormControl(''),
    gestoreDiBudget: new FormControl(''),
    fornituraNonICTRilevante: new FormControl('', Validators.required),
    perimetroMonitoraggioICTVendor: new FormControl(''),
    note: new FormControl(''),
    referenteErogatoreServiziIT: new FormControl(''),
    fornituraICTRilevanterischioalto: new FormControl('', Validators.required),
    dataDelUltimoAudit: new FormControl(null),
    dataDelProssimoAudit: new FormControl(null),
    dataDiUltimaValutazione: new FormControl(null, Validators.required),
    dataDiDecorrenza: new FormControl(null, Validators.required),
    dataDiSottoscrizione: new FormControl(null, Validators.required),
    dataCessazioneDelContratto: new FormControl(null, Validators.required),
    dataDiUltimoRinnovoDelContratto: new FormControl(null, Validators.required),
    statoContratto: new FormControl(''),
    classificazione: new FormControl(''),
    codiceContratto: new FormControl(''),
    codiceContrattoPadre: new FormControl(''),
    oggettoDelContratto: new FormControl('', Validators.required),
    // descrizioneServizioErogato: new FormControl('', Validators.required),
    descrizioneServizioErogato:  new FormControl('', Validators.required),
    statodelContratto: new FormControl('', Validators.required),
    durataDelRinnovo: new FormControl('', Validators.required),
    tacitoRinnovo: new FormControl('', Validators.required),
    costoTotaleDelContratto: new FormControl(''),
    terminiPreavvisoCliente: new FormControl('', Validators.required),
    terminiPreavvisoFornitore: new FormControl('', Validators.required),
    possibilitaDiRecesso: new FormControl(''),
    sogliaDiImpattoDellinterruzioneDellaFunzione: new FormControl('', Validators.required),
    costoAnnuoDiEsercizio: new FormControl(''),
    sostituibilità: new FormControl('', Validators.required),
    fornitoriAlternativi: new FormControl('', Validators.required),
    possibilitàDiReinternalizzazione: new FormControl('', Validators.required),
    subFornitore: new FormControl(''),
    numeroSubfornitori: new FormControl('', Validators.required),
    costoStimatoDelContratto: new FormControl('', Validators.required),
    dataDiDecorrenzaDelServizio: new FormControl(''),
    dataSottoscrizioneDelServizio: new FormControl(''),
    dataDiScadenzaDelServizio: new FormControl(''),
    breveSintesiDeiMotivi: new FormControl('', Validators.required),
    // sintesideiMotivi: new FormControl('', Validators.required),
    dataDellUltimaValutazione: new FormControl(null, Validators.required),
    dataCessazioneDelServizio: new FormControl(''),
    breveSintesiSulLivello: new FormControl('', Validators.required),
    // breveRischiosita: new FormControl('', Validators.required),
    // NPareredirischio: new FormControl(''),
    // Dataparere: new FormControl(null, Validators.required),
    // livellodiRischiosita: new FormControl('', Validators.required),
    dataDiScadenzaDelContratto: new FormControl('', Validators.required),
    pareresuiContrattiComplianceList: new FormArray([]),
    parereSuiContrattiRischiList: new FormArray([]),
    oggDellaProposta: new FormControl(''),
    datiPersonali: new FormControl(''),
    funzioneEsternalizzata: new FormControl(''),
    paeseDiVieneSvolto: new FormControl(''),
    paesediconDati: new FormControl(''),
    marcoProcesso: new FormControl(''),
    racConDeiPro: new FormControl(''),
    trasferimentoDati: new FormControl(''),
    servizioInfrastrttra:  new FormControl(''),
    tipologiaDiCloud:  new FormControl(''),
    cloudpaesediCon:  new FormControl(''),
    categorieBankIt:  new FormControl(''),
    sottoCategorieBankIt:  new FormControl(''),
    categoriaEba:  new FormControl(''),
    tipologiaDaDati: new FormControl(''),
    cloudNaturaDaDati: new FormControl('')
  });
    fixture = TestBed.createComponent(CategoriePanelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.filters = dropdownResponse;
    component.categorieForm = dettaglioRegistroForm;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should show label names', () => {
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('label').textContent).toContain('label.dettaglioRegistro.Raccordoconalberodeiprocessi');
  });

  it('should call ngoninit', () => {
    component.ngOnInit();
  });
  it('should call setCategoriaBankIT', () => {
   
   //  spyOn(component, 'setCategoriaBankIT');
    component.setCategoriaBankIT('Credito / cartolarizzazioni');
    // expect(component.setCategoriaBankIT).toHaveBeenCalled();
  });
});
