import { Component, Input, OnInit } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { SelectView } from 'src/app/shared/models/selectView';
import { ContrattoDetailsVm } from 'src/app/shared/models/contrattoDetailsVm';
import { ServizioDetailsVm } from 'src/app/shared/models/servizioDetailsVm';
import { LoginService } from '../../../shared/services/login.service';

@Component({
  selector: 'reg-contratto-panel',
  templateUrl: './contratto-panel.component.html',
  styleUrls: ['./contratto-panel.component.scss']
})
export class ContrattoPanelComponent implements OnInit {
  @Input() allSupplierDetails:  SelectView[];
  // canaledisegnalazione: any;
  commonDropdown = [
    {
      value: 'Si',
      description: 'Si'
    },
    {
      value: 'No',
      description: 'No',
    }
  ];
  contrattoControls = [
    'codiceContratto',
    'codiceContrattoPadre',
    'oggettoDelContratto',
    'descrizioneServizioErogato',
    'statoContratto',
    'dataDiDecorrenza',
    'dataDiSottoscrizione',
    'tacitoRinnovo',
    'durataDelRinnovo',
    'dataCessazioneDelContratto',
    'dataDiUltimoRinnovoDelContratto',
    'costoTotaleDelContratto',
    'dataDiScadenzaDelContratto',
    'terminiPreavvisoCliente',
    'terminiPreavvisoFornitore',
    'possibilitaDiRecesso',
    'sogliaDiImpattoDellinterruzioneDellaFunzione',
    'costoAnnuoDiEsercizio',
    'sostituibilità',
    'fornitoriAlternativi',
    'possibilitàDiReinternalizzazione',
    'subFornitore',
    'numeroSubfornitori',
    'costoStimatoDelContratto',
    'statoServizio',
    'dataDiDecorrenzaDelServizio',
    'dataSottoscrizioneDelServizio',
    'dataDiScadenzaDelServizio',
    'dataCessazioneDelServizio'
  ];
  @Input() contrattoDetails: ContrattoDetailsVm;
  @Input() contrattoForm: FormGroup;
  hasRegistroReadOnly: boolean;
  isRequired: boolean;
  isValidContrattoPanel: boolean;
  opened: boolean;
  @Input() servizioDetails: ServizioDetailsVm;
  @Input() sostituibilita: SelectView[];
  @Input() statoServizio: SelectView[];
  fornitoreDropdownSettings = {
    singleSelection: false,
    idField: 'fornitoreId',
    textField: 'nomeSocieta',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    itemsShowLimit: 3,
    allowSearchFilter: false
  };
  constructor(private loginService: LoginService) { }

  ngOnInit() {
    const operationModel: any = this.loginService.getOperationModel();
    this.hasRegistroReadOnly = operationModel ? operationModel.hasRegistroReadOnly : '';
    this.contrattoForm.get('numeroSubfornitori').valueChanges.subscribe(changes => {
      if (changes > 0) {
        this.isRequired = true;
        this.contrattoForm.get('subFornitore').setValidators([Validators.required]);
        this.contrattoForm.get('subFornitore').updateValueAndValidity();
      } else {
        this.isRequired = false;
        this.contrattoForm.get('subFornitore').setValidators(null);
        this.contrattoForm.get('subFornitore').updateValueAndValidity();
      }
    });
    // this.contrattoForm.get('sostituibilità').setValue(this.servizioDetails.sostituibilità);
    this.contrattoForm.valueChanges.subscribe(changes => {
      this.isValidContrattoPanel = this.contrattoControls.every(control => {
        return this.contrattoForm.get(control).valid;
      });
    });
  }

}
