import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ContrattoPanelComponent } from './contratto-panel.component';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { NgbDateParserFormatter, NgbActiveModal, NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgbDateCustomParserFormatter } from 'src/app/shared/services/dateFormat';
import { HttpClientModule } from '@angular/common/http';
import { LoginService } from 'src/app/shared/services/login.service';
import { DettaglioRigaRegistroComponent } from '../../pages/dettaglio-riga-registro/dettaglio-riga-registro.component';
import { FormGroup, FormControl, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ServizioDetailsVm } from 'src/app/shared/models/servizioDetailsVm';
import { browser } from 'protractor';


const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('ContrattoPanelComponent', () => {
  let component: ContrattoPanelComponent;
  let fixture: ComponentFixture<ContrattoPanelComponent>;
  let loginService;

  beforeEach(async(() => {
    loginService = jasmine.createSpyObj(['getOperationModel']);

    TestBed.configureTestingModule({
      declarations: [ ContrattoPanelComponent, DettaglioRigaRegistroComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        ReactiveFormsModule,
        FormsModule,
        HttpClientModule,
        NgbModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: NgbDateParserFormatter, useClass: NgbDateCustomParserFormatter },
        NgbActiveModal,
        { provide: LoginService, useValue: loginService }
      ]

    })
    .compileComponents();
  }));

  beforeEach(() => {

    const operationModel = {
      hasRegistroReadOnly : false
    };
    fixture = TestBed.createComponent(ContrattoPanelComponent);
    component = fixture.componentInstance;
    // fixture.detectChanges();
    const contrattoForm = new FormGroup({

      codiceContratto: new FormControl(),
      codiceContrattoPadre: new FormControl(),
      oggettoDelContratto: new FormControl(),
      descrizioneServizioErogato: new FormControl(),
      statoContratto: new FormControl(),
      dataDiDecorrenza: new FormControl(),
      dataDiSottoscrizione: new FormControl(),
      tacitoRinnovo: new FormControl(),
      durataDelRinnovo: new FormControl(),
      dataCessazioneDelContratto: new FormControl(),
      dataDiUltimoRinnovoDelContratto: new FormControl(),
      costoTotaleDelContratto: new FormControl(),
      dataDiScadenzaDelContratto: new FormControl(),
      terminiPreavvisoCliente: new FormControl(),
      terminiPreavvisoFornitore: new FormControl(),
      possibilitaDiRecesso: new FormControl(),
      sogliaDiImpattoDellinterruzioneDellaFunzione: new FormControl(),
      costoAnnuoDiEsercizio: new FormControl(),
      sostituibilità : new FormControl(),
      fornitoriAlternativi: new FormControl(),
      possibilitàDiReinternalizzazione: new FormControl(),
      subFornitore: new FormControl(),
      numeroSubfornitori: new FormControl('numero'),
      costoStimatoDelContratto: new FormControl(),
      statoServizio: new FormControl(),
      dataDiDecorrenzaDelServizio: new FormControl(),
      dataSottoscrizioneDelServizio: new FormControl(),
      dataDiScadenzaDelServizio: new FormControl(),
      dataCessazioneDelServizio: new FormControl()
    });
    // component.contrattoForm.controls['numeroSubfornitori'].setValue('numeroooo');
    component.contrattoForm = contrattoForm;
    console.log(component.contrattoForm.get('numeroSubfornitori').value);
    const servizioDetails: any = [];
    component.servizioDetails = servizioDetails;
    const sostituibilita: any = {};
    component.sostituibilita = sostituibilita;
    const statoServizio: any = {};
    component.statoServizio = statoServizio;
    const contrattoDetails: any = {};
    component.contrattoDetails = contrattoDetails;
    const allSupplierDetails: any = {};
    component.allSupplierDetails = allSupplierDetails;


  });

   it('should create', () => {
    component.hasRegistroReadOnly = true;
    expect(component).toBeTruthy();
  });
  it('should call ngoninit', () => {
    // spyOn(component, 'ngOnInit');
    component.ngOnInit();
    // expect(component.ngOnInit).toHaveBeenCalled();
  });
});
