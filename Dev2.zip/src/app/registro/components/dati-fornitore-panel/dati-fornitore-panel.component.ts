import { Component, Input, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FornitoreDetailsVm } from 'src/app/shared/models/fornitoreDetailsVm';

@Component({
  selector: 'reg-dati-fornitore-panel',
  templateUrl: './dati-fornitore-panel.component.html',
  styleUrls: ['./dati-fornitore-panel.component.scss']
})
export class DatiFornitorePanelComponent implements OnInit {
  @Input() dateFornitoreForm: FormGroup;
  @Input() fornitoreDetails: FornitoreDetailsVm;
  @Input() hasRegistroReadOnly: boolean;
  opened: boolean;

  constructor() { }

  ngOnInit() {
  }

}
