import {Component, OnInit} from '@angular/core';
import {Language} from '../shared/enumerations/language';
import {environment} from 'src/environments/environment';
import {UserVm} from '../shared/models/userVm';
import {Router} from '@angular/router';
import {LoginService} from '../shared/services/login.service';
import { SearchInputService } from '../shared/services/search-input.service';

@Component({
  selector: 'reg-registro-header',
  templateUrl: './registro-header.component.html',
  styleUrls: ['./registro-header.component.scss']
})
export class RegistroHeaderComponent implements OnInit {
  currentRoute = 'registro';
  hasAllTabAccess: boolean;
  hasAnagraficheReadOnly: boolean;
  hasLogActivityReadOnly: boolean;
  hasPropostaReadOnly: boolean;
  hasRegistroReadOnly: boolean;
  inputValue: string;
  isDevelopmentEnv: boolean;
  Language = Language;
  selectedOption = 'registro';
  selectedOptionLabel = 'label.header.register';
  userInfo: UserVm;
userProfile: any;
  constructor(
    private router: Router,
    private loginService: LoginService,
    private searchInputService: SearchInputService
  ) {
  }

  logout(): void {
    this.loginService.logout().subscribe( () => window.open('https://www.bper.it/', '_self'));
  }

  ngOnInit(): void {
    this.searchInputService.getSelectedOption().subscribe((selectedOption: any) => {
      this.selectedOption = selectedOption;
      // this.inputValue = '';
    });
    this.isDevelopmentEnv = !environment.production;
    this.loginService.login().subscribe(response => {
      this.userInfo = response;
      this.loginService.setOperationalModel(response.operationVm);
      this.hasRegistroReadOnly = response.operationVm.hasRegistroReadOnly;
      this.hasAllTabAccess = response.operationVm.hasAllTabAccess;
      this.hasPropostaReadOnly = response.operationVm.hasPropostaReadOnly;
      this.hasAnagraficheReadOnly = response.operationVm.hasAnagraficheReadOnly;
      this.hasLogActivityReadOnly = response.operationVm.hasLogActivityReadOnly;
      this.router.navigate(['registro']);
    }, (error) => {
      this.router.navigate(['loginfailed']);
    });

  }


  redirectTo(route) {
    this.inputValue = '';
    this.searchInputService.setSearchInput(false);
    this.currentRoute = route;
    // this.router.navigate([route]);
  }

  searchEmitter(inputValue) {
    const  searchData = {
      inputValue,
      page: this.selectedOption
    };
    this.searchInputService.setSearchInput(searchData);
    this.router.navigate([this.currentRoute]);
  }

  selectedValue(route, value, label): void {
    this.selectedOption = value;
    this.selectedOptionLabel = label;
    this.currentRoute = route;
  }
}
