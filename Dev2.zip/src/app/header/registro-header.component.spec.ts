import { async, ComponentFixture, TestBed, inject, fakeAsync } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { RouterTestingModule } from '@angular/router/testing';
import { of, Observable } from 'rxjs';
import { RegistroHeaderComponent } from './registro-header.component';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { FormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Router, RouterModule } from '@angular/router';
import { LoginService } from '../shared/services/login.service';
import { SearchInputService } from '../shared/services/search-input.service';
import { AppRoutingModule } from '../app-routing.module';
import { RegistroPageComponent } from '../registro/pages/registro-page/registro-page.component';
import { AppModule } from '../app.module';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('RegistroHeaderComponent', () => {
  let component: RegistroHeaderComponent;
  let fixture: ComponentFixture<RegistroHeaderComponent>;
  let loginService;
  let searchInputService;
  let router;
  const mockUserVm = {
    matricola : 1234,
    name : 'Luke',
    surname : 'Jackson',
    office: 'Italy',
    profile : {
      code : 'Code 1.2',
      description : 'Admin'
    }
  };

  beforeEach(() => {
    loginService =  jasmine.createSpyObj(['login', 'logout', 'setOperationalModel']);
    // tslint:disable-next-line: max-line-length
    searchInputService = jasmine.createSpyObj(['setSearchInput', 'setSelectedOption', 'getSearchResults', 'getSelectedOption', 'getSearchInput']);
    TestBed.configureTestingModule({
      declarations: [
        
      ],
      imports: [
        FormsModule,
        AppModule,
        RouterTestingModule.withRoutes([
          { path: 'registro', component: RegistroPageComponent }
      ]),
        HttpClientTestingModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
      ],
      providers: [
        { provide: LoginService, useValue: loginService},
      /*   { provide: Router, useValue: router }, */
        {provide: SearchInputService, useValue: searchInputService}
       ]
    })
      .compileComponents();
  });

  beforeEach(() => {
    const inputValue = 'registro';
    const  searchData = {
      inputValue,
      page:  'registro'
    };
    const searchInput = {
      name : 'registro',
      startIndex : '1',
      value : '177'
    };
    // tslint:disable-next-line: max-line-length
    const searchResponse = {'suppliers': null, 'registro': [{'registroId': 177, 'societaDelGruppoCliente': 'SV Banca', 'fornitore': 'Capgemini Italia update', 'fornitoreInfraExtraGruppo': 'Infragruppo', 'classificazione': 'Fornitura', 'perimetroMonitoraggioICTVendor': 'No', 'statoDelServizio': 'In attesa sottoscrizione', 'ogettoDelContratto': 'Oggetto ', 'descrizioneDelServizioErogato': 'description', 'contrattoId': null, 'fornitoreId': null}], 'anagrafe': null, 'logActivity': null, 'count': 1};
    const logoutResponse = {};
    // tslint:disable-next-line: max-line-length
    const loginResponse = {'name': 'Mario', 'surname': 'Rasso', 'matricola': '23456', 'office': null, 'id': null, 'profile': {'code': 'Amministratore', 'description': null}, 'operationVm': {'hasExportAllAccess': true, 'hasAllTabAccess': true, 'hasRegistroReadOnly': false, 'hasNewPropostaAccess': true, 'hasNewContrattoAccess': true, 'hasNewFornitoreAccess': true, 'hasNewClienteAccess': true, 'hasPropostaReadOnly': false, 'hasAnagraficheReadOnly': false, 'hasLogActivityReadOnly': false, 'hasExportBySystemDate': false, 'hasRegistroStatoFilter': false, 'hasRegistroFornitoreDisabled': false}};
    loginService.login.and.returnValue(of(loginResponse));
    loginService.setOperationalModel(loginResponse.operationVm);
    loginService.logout.and.returnValue(of(logoutResponse));
    searchInputService.setSearchInput(searchData);
    searchInputService.getSearchInput.and.returnValue(of(inputValue));
    searchInputService.setSelectedOption('registro');
    searchInputService.getSelectedOption.and.returnValue(of(inputValue));
    searchInputService.getSearchResults.and.returnValue(of(searchResponse));
    fixture = TestBed.createComponent(RegistroHeaderComponent);
    component = fixture.componentInstance;
    // component.userInfo = mockUserVm;
    // fixture.detectChanges();
  });

  it('should create successfully', () => {
    expect(component).toBeTruthy();
  });

  it('should have respective routerLink values', () => {
    fixture.detectChanges();
    // expect(fixture.debugElement.queryAll(By.css('a'))[1].nativeElement.href.split('/').pop()).toBe('registro');
    // expect(fixture.debugElement.queryAll(By.css('a'))[2].nativeElement.href.split('/').pop()).toBe('proposte');
    // expect(fixture.debugElement.queryAll(By.css('a'))[3].nativeElement.href.split('/').pop()).toBe('anagarfe');
    // expect(fixture.debugElement.queryAll(By.css('a'))[4].nativeElement.href.split('/').pop()).toBe('logactivity');
    expect(fixture.debugElement.queryAll(By.css('a'))[1].nativeElement.textContent).toBe('REGISTRO');
    expect(fixture.debugElement.queryAll(By.css('a'))[2].nativeElement.textContent).toBe('PROPOSTE');
    expect(fixture.debugElement.queryAll(By.css('a'))[3].nativeElement.textContent).toBe('ANAGRAFICHE');
    expect(fixture.debugElement.queryAll(By.css('a'))[4].nativeElement.textContent).toBe('LOG ATTIVITA');
    // expect(fixture.debugElement.queryAll(By.css('a'))[9].nativeElement.href).toBe('https://www.bper.it/');
  });

  it('should chcek selcted value method', () => {
     component.selectedValue('registro', 'Registro', 'label.header.register');
     fixture.detectChanges();
    expect(component.selectedOption).toBe('registro');
    expect(component.selectedOptionLabel).toBe('label.header.register');
    expect(component.currentRoute).toBe('registro');
   });

 /*  it('should call logout  method', () => {
    fixture.detectChanges();
    component.logout();
  }); */

  it('should call redirectTo  method', () => {
    component.redirectTo('registro');
    expect(component.currentRoute).toBe('registro');
  });

  it('should call searchEmitter  method', fakeAsync(() => {
    component.searchEmitter('registro');
    fixture.whenStable().then(() => {
      expect(component.currentRoute).toBe('registro');
    });
  }));
});


