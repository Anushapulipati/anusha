import { HashLocationStrategy, LocationStrategy, registerLocaleData } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import localeIt from '@angular/common/locales/it';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { TranslateModule, TranslateService } from '@ngx-translate/core';
import { AngularFontAwesomeModule } from 'angular-font-awesome';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Language } from './shared/enumerations/language';
import { SharedModule } from './shared/shared.module';
import { RegistroHeaderComponent } from './header/registro-header.component';
import {en} from './i18n/en';
import {it} from './i18n/it';
import { AddServizioPopUpComponent } from './modules/proposte/components/add-servizio-pop-up/add-servizio-pop-up.component';
import {LoginComponent} from './shared/components/login/login.component';
import {LoginfailedComponent} from './shared/components/loginfailed/loginfailed.component';
// tslint:disable-next-line: max-line-length
import { LinkContrattoServizioPopUpComponent } from './modules/proposte/components/link-contratto-servizio-pop-up/link-contratto-servizio-pop-up.component';
import { ContrattoPanelComponent } from './registro/components/contratto-panel/contratto-panel.component';
import { DatiFornitorePanelComponent } from './registro/components/dati-fornitore-panel/dati-fornitore-panel.component';
import { RegistroPageComponent } from './registro/pages/registro-page/registro-page.component';
import { DettaglioRigaRegistroComponent } from './registro/pages/dettaglio-riga-registro/dettaglio-riga-registro.component';
import { CategoriePanelComponent } from './registro/components/categorie-panel/categorie-panel.component';
import { ValutazioniFunzioniDiControlloPanelComponent } from './registro/components/valutazioni-funzioni-di-controllo-panel/valutazioni-funzioni-di-controllo-panel.component';
import { LoginService } from './shared/services/login.service';
import { ResponseCommonPopUpComponent } from './modules/anagrafiche/pages/download-popup/response-common-pop-up.component';
import { ErrorPopupComponent } from './shared/components/error-popup/error-popup.component';

registerLocaleData(localeIt, 'it');

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LoginfailedComponent,
    RegistroPageComponent,
    RegistroHeaderComponent,
    AddServizioPopUpComponent,
    LinkContrattoServizioPopUpComponent,
    DettaglioRigaRegistroComponent,
    ContrattoPanelComponent,
    DatiFornitorePanelComponent,
    CategoriePanelComponent,
    ValutazioniFunzioniDiControlloPanelComponent,
    ResponseCommonPopUpComponent,
    ErrorPopupComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    TranslateModule.forRoot(),
    SharedModule,
    AngularFontAwesomeModule
  ],
  bootstrap: [AppComponent],
  providers: [
    { provide: LocationStrategy, useClass: HashLocationStrategy },
    LoginService
  ],
  entryComponents: [
    AddServizioPopUpComponent,
    LinkContrattoServizioPopUpComponent,
    ResponseCommonPopUpComponent,
    ErrorPopupComponent
  ]
})
export class AppModule {
  constructor(private translate: TranslateService) {
    this.translate.setDefaultLang(Language.IT);
    this.translate.addLangs([Language.EN, Language.IT]);
    this.translate.use(Language.IT);
    this.translate.setTranslation(Language.EN, en);
    this.translate.setTranslation(Language.IT, it);
  }
}
