import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DettaglioRigaRegistroComponent } from './registro/pages/dettaglio-riga-registro/dettaglio-riga-registro.component';
import { RegistroPageComponent } from './registro/pages/registro-page/registro-page.component';
import { LoginComponent } from './shared/components/login/login.component';
import { LoginfailedComponent } from './shared/components/loginfailed/loginfailed.component';
import { AuthGuard } from './shared/guards/auth.guard';

const routes: Routes = [
  {
    path: 'login', component: LoginComponent
  },
  {
    path: 'loginfailed', component: LoginfailedComponent
  },
  {
    path: 'registro',
     canActivate: [AuthGuard],
     component: RegistroPageComponent,
  },
  {
      path: 'proposte',
      loadChildren: './modules/proposte/proposte.module#ProposteModule',
  },
  {
    path: 'anagarfe',
    loadChildren: './modules/anagrafiche/anagrafiche.module#AnagraficheModule',
  },
  {
    path: 'logactivity',
    loadChildren: './modules/log-activity/log-activity.module#LogActivityModule',
  },
  {
    path: 'dettaglio-registro/:registroId',
    component: DettaglioRigaRegistroComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {useHash: true})],
  exports: [RouterModule]
})
export class AppRoutingModule { }
