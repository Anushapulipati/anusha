import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { UrlProviderService } from './url-provider.service';

@Injectable({
  providedIn: 'root'
})
export class SearchInputService {
  private searchInput: BehaviorSubject<string> = new BehaviorSubject(null);
  private selectedOption: BehaviorSubject<string> = new BehaviorSubject(null);

  constructor(
    private httpClient: HttpClient,
    private urlProviderService: UrlProviderService
  ) { }

  getSearchInput(): Observable<string> {
    return this.searchInput;
  }

  setSearchInput(input: any): void {
    this.searchInput.next(input);
  }

  // tslint:disable-next-line: member-ordering
  getSearchResults(searchInput) {
    // return this.httpClient.post<any>(this.urlProviderService.getSearchResults, searchInput);
    const params = new HttpParams();
    const parameters = params.append('name', searchInput.name)
    .append('startIndex', searchInput.startIndex)
    .append('value', searchInput.value);
    return this.httpClient.get<any>(this.urlProviderService.getSearchResults, { params: parameters });
  }

  // tslint:disable-next-line: member-ordering
  getSelectedOption(): Observable<string> {
    return this.selectedOption;
  }

  setSelectedOption(option) {
    this.selectedOption.next(option);
  }


}
