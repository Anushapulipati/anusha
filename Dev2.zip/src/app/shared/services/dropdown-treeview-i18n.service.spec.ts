import { TestBed } from '@angular/core/testing';

import { DropdownTreeviewI18nService } from './dropdown-treeview-i18n.service';

describe('DropdownTreeviewI18nService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  /* it('should be created', () => {
    const service: DropdownTreeviewI18nService = TestBed.get(DropdownTreeviewI18nService);
    expect(service).toBeTruthy();
  }); */
});
