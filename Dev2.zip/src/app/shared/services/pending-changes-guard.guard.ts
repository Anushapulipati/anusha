import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { Observable } from 'rxjs';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ConfirmationComponentComponent } from '../components/confirmation-component/confirmation-component.component';

export interface ComponentCanDeactivate {
  canDeactivate: () => boolean | Observable<boolean>;
}

@Injectable({
  providedIn: 'root'
})
export class PendingChangesGuardGuard implements CanDeactivate<ComponentCanDeactivate>  {

  constructor(private _modalService: NgbModal) {}

  canDeactivate(component: ComponentCanDeactivate): boolean | Observable<boolean> | Promise<any> {
    if (component.canDeactivate()) {
      return true;
    } else {
      return this.openConfirmDialog();
    }
  }

  openConfirmDialog() {
    const confirmationModal = this._modalService.open(ConfirmationComponentComponent);
    return confirmationModal.result.then((result) => {
      return result;
    });
  }
}
