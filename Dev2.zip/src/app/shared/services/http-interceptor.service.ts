import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { DghubInterceptorService } from 'fe-dghub-component-library';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ErrorPopupComponent } from '../components/error-popup/error-popup.component';

@Injectable({
  providedIn: 'root'
})

export class HttpInterceptorService implements HttpInterceptor {
  spinnerComponentRef: any;
  constructor(
    private dgHubInterceptorService: DghubInterceptorService,
    private _modalService: NgbModal
  ) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    req = this.dgHubInterceptorService.modifyRequest(req);
    this.dgHubInterceptorService.showLoader();
    return new Observable(observer => {
      const subscription = next.handle(req).subscribe(event => {
        if (event instanceof HttpResponse) {
          this.dgHubInterceptorService.removeRequest(req);
          observer.next(event);
        }
      }, (err) => {
        // this.dgHubInterceptorService.handleError(err, '');
        this.handleError(err);
        this.dgHubInterceptorService.removeRequest(req);
        observer.error(err);
      }, () => {
        this.dgHubInterceptorService.removeRequest(req);
        observer.complete();
      });
      return () => {
        this.dgHubInterceptorService.removeRequest(req);
        subscription.unsubscribe();
      };
    });
  }

  // tslint:disable-next-line: member-ordering
  handleError(err) {
    const hasAlreadyOpenedModal = this._modalService.hasOpenModals();
    if (!hasAlreadyOpenedModal) {
      const serviceModalRef = this._modalService.open(ErrorPopupComponent, {
        backdrop: 'static',
        // centered: true
      });
      serviceModalRef.componentInstance.err = err;
      serviceModalRef.result.then((linkedServices) => {});
    }
  }
}
