import { TestBed } from '@angular/core/testing';

import { SearchInputService } from './search-input.service';
import { UrlProviderService } from './url-provider.service';
import { HttpClientTestingModule, HttpTestingController, TestRequest } from '@angular/common/http/testing';
import { HttpParams } from '@angular/common/http';

describe('SearchInputService', () => {
  let searchInputService;
  let httpTestingController;
  let urlProviderService;
  beforeEach(() =>{
    TestBed.configureTestingModule({
    providers: [
      SearchInputService,
     UrlProviderService],
    imports: [HttpClientTestingModule],

  });
  searchInputService  = TestBed.get(SearchInputService);
  httpTestingController = TestBed.get(HttpTestingController);
  urlProviderService = TestBed.get(UrlProviderService);
});

  it('should be created', () => {
    const service: SearchInputService = TestBed.get(SearchInputService);
    expect(service).toBeTruthy();
  });

  it('should call getSearchResults with this request method and url', () => {
    const excelId = 20;
    const checkExcelResponse = {};
    const searchInput = {
      name : 'name',
      startIndex : 'startIndex',
      value : 'value'
    };
    const params = new HttpParams();
    const parameters = params.append('name', searchInput.name)
    .append('startIndex', searchInput.startIndex)
    .append('value', searchInput.value);
    // searchInputService.getSearchResults().subscribe();
     /* const req: TestRequest = httpTestingController.expectOne(urlProviderService.getSearchResults, { params: parameters });
     expect(req.request.method).toEqual('GET');
     req.flush(checkExcelResponse); */
   });
});
