import { Injectable } from '@angular/core';
import { environment } from '../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UrlProviderService {

  constructor() { }

  public get getUserProfile() {
    return environment.apiUrl + '/login/userDetails';
  }

  public get getLoginUrl() {
    return environment.apiUrl + '/login/authenticate';
  }

  public get getLoggedInUserDetails() {
    return environment.apiUrl + '/securityData/getLoggedInUserDetails';
  }

  public get getDomainTableKeys() {
    return environment.apiUrl + '/navigate/proposta/domaintablekeys';
  }

  public get getDomainTableData() {
    return environment.apiUrl + '/navigate/proposta/domaintableData';
  }

  public get getPropostaDetails() {
    return environment.apiUrl + '/navigate/proposta/getPropostaDetails';
  }

  public get getContrattoDetails() {
    return environment.apiUrl + '/navigate/contratto/getContrattoDetails';
  }

  public get getContrattoServizioDetails() {
    return environment.apiUrl + '/navigate/contratto/getContrattoServizioDetails';
  }

  public get filterRegistroData() {
    return environment.apiUrl + '/navigate/registro/filterRegistroData';
  }

  public get getFornitourDropdownDetails() {
    return environment.apiUrl + '/navigate/proposta/suppilerDetails';
  }

  public get getFornitoredetailsWithFornitoreId() {
    return environment.apiUrl + '/navigate/anagrafe/getFornitoredetailsWithFornitoreId';
  }

  public get getSupplierDetails() {
    return environment.apiUrl + '/navigate/proposta/savePropostaDetail';
  }

  public get saveServizioListInServizioPage() {
    return environment.apiUrl + '/navigate/contratto/saveServizioListInServizioPage';
  }

  public get updateSupplierDetails() {
    return environment.apiUrl + '/navigate/proposta/updatePropostaDetail';
  }

  public get getProposals() {
    return environment.apiUrl + '/navigate/proposta/pageRequest';
  }

  public get exportToFilterPropostaExcel() {
    return environment.apiUrl + '/navigate/proposta/filteredExportToExcel';
  }
  public get exportToFilterRegistroExcel() {
    return environment.apiUrl + '/navigate/registro/filteredExportToExcel';
  }

  public get getServizioList() {
    return environment.apiUrl + '/navigate/proposta/getServizioList';
  }

  public get saveContratto() {
    return environment.apiUrl + '/navigate/contratto/saveContrattoDetails';
  }

  public get updateContratto () {
    return environment.apiUrl + '/navigate/contratto/updateContrattoDetails ';
  }

  public get getAllClientiDetails() {
    return environment.apiUrl + '/navigate/contratto/getAllClientiDetails';
  }

  public get getFornitoreClientDetails() {
    return environment.apiUrl + '/navigate/anagrafe/getFornitoreClientDetails';
  }

  public get getCategoryBankIt() {
    return environment.apiUrl + '/navigate/anagrafe/getCategoryBankIt';
  }

  public get getElencoTrattamentoDatiPersonali() {
    return environment.apiUrl + '/navigate/anagrafe/getElencoTrattamentoDatiPersonali';
  }

  public get getCategoriaInterna() {
    return environment.apiUrl + '/navigate/anagrafe/getCategoriaInterna';
  }

  public get saveElencoTrattamentoDatiPersonali() {
    return environment.apiUrl + '/navigate/anagrafe/saveElencoTrattamentoDatiPersonali';
  }

  public get saveCategoriaInterna() {
    return environment.apiUrl + '/navigate/anagrafe/saveCategoriaInterna';
  }

  public get getFornitoreClientDetailsByFilters() {
    return environment.apiUrl + '/navigate/anagrafe/getFornitoreClientDetailsByFilters';
  }

  public get saveCategoryBankIt() {
    return environment.apiUrl + '/navigate/anagrafe/saveCategoryBankIt';
  }

  public get exportToExcel() {
    return environment.apiUrl + '/navigate/proposta/exportToExcel';
  }
  public get verifyPropostaExport() {
    return environment.apiUrl + '/navigate/proposta/verifyPropostaExport';
  }
  public get downloadProposta() {
    return environment.apiUrl + '/navigate/proposta/downloadProposta';
  }

  public get getsaveServizio() {
    return environment.apiUrl + '/navigate/proposta/saveServizio';
  }

  public get getPropostadetailswithSuppliers() {
    return environment.apiUrl + '/navigate/proposta/getPropostadetailswithSuppliers';
  }

  public get getRegistroDetails() {
    return environment.apiUrl + '/navigate/registro/GetRegistroDetails';
  }


  public get logout() {
    return environment.apiUrl + '/logout/invalidateToken';
  }
  public get updateRegistro() {
    return environment.apiUrl + '/navigate/registro/UpdateRegistro';
  }

  public get saveFornitoredetails() {
    return environment.apiUrl + '/navigate/anagrafe/saveFornitoredetails';
  }
  public get UpdateFornitoredetails() {
    return environment.apiUrl + '/navigate/anagrafe/UpdateFornitoredetails';
  }
  public get getFornitoredetails() {
    return environment.apiUrl + '/navigate/anagrafe/getFornitoredetailsWithFornitoreId';
  }

  public get saveCliente() {
    return environment.apiUrl + '/navigate/anagrafe/saveCliente';
  }

  public get updateCliente() {
    return environment.apiUrl + '/navigate/anagrafe/updateCliente';
  }

  public get getClienteDetails() {
    return environment.apiUrl + '/navigate/anagrafe/getClienteById';
  }

  public get getLogDetails() {
    return environment.apiUrl + '/navigate/logActivity/getLogActivity';
  }
  public get getFilteredLogDetails() {
    return environment.apiUrl + '/navigate/logActivity/searchLogActivity';
  }
  public get exportToRegistroExcel() {
    return environment.apiUrl + '/navigate/registro/exportToExcel';
  }
  public get getSearchResults() {
    return environment.apiUrl + '/navigate/logActivity/getSearchResults';
  }
  public get downloadRegistroExcel() {
    return environment.apiUrl + '/navigate/registro/downloadRegistro';
  }
  public get verifyRegistroExcel() {
    return environment.apiUrl + '/navigate/registro/verifyRegistroExport';
  }
  public get exportToAnagraficheExcel() {
    return environment.apiUrl + '/navigate/anagrafe/anagraficaEsporta';
  }
  public get downloadAnagraficheExcel() {
    return environment.apiUrl + '/navigate/anagrafe/downloadAnagrafe';
  }
  public get verifyAnagraficheExcel() {
    return environment.apiUrl + '/navigate/anagrafe/verifyAnagrafeExport';
  }
  public get registroOggiExcel() {
    return environment.apiUrl + '/navigate/registro/exportToOggiExcel';
  }
}
