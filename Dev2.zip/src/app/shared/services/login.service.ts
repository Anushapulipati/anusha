import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpHeaders } from '@angular/common/http';

import { UrlProviderService } from './url-provider.service';
import {Observable, of} from 'rxjs';
import { AccessOperationVm } from '../models/operationVm';

const URL = 'this.urlProviderService.getLoginUrl';

@Injectable({
  providedIn: 'root'
})
export class LoginService {
  public operationModel: any;
  public userProfile = sessionStorage.getItem('userProfile');
  constructor(
    private httpClient: HttpClient,
    private urlProviderService: UrlProviderService
  ) { }

  public getOperationModel() {​​​​​
    return this.operationModel;
  }​​​​​

  public login(): Observable<any> {
    const response = this.httpClient.get<any>(this.urlProviderService.getLoginUrl);
    response.subscribe(data => { this.operationModel = data.operationVm; });
    return response;
  }

  public logout(): Observable<any> {
    return this.httpClient.get(this.urlProviderService.logout);
  }

  public setOperationalModel(operation: AccessOperationVm) {
    this.operationModel = operation;
  }
}
