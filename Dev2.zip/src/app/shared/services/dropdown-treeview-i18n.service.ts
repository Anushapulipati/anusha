import { Injectable } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { TreeviewItem, TreeviewSelection, TreeviewI18n } from 'ngx-treeview';
import { Language } from '../../shared/enumerations/language';

@Injectable({
  providedIn: 'root'
})
export class DropdownTreeviewI18nService extends TreeviewI18n {

  constructor(
    private translateService: TranslateService
  ) {
    super();
  }

  getText(selection: TreeviewSelection): string {
    if (selection.uncheckedItems.length === 0) {
      if (selection.checkedItems.length > 0) {
        return this.translateService.currentLang === Language.EN ? 'All' : 'Tutte';
      } else {
        return '';
      }
    }

    switch (selection.checkedItems.length) {
      case 0:
        return this.translateService.currentLang === Language.EN ? 'Select options' : 'Seleziona le opzioni';
      case 1:
        return selection.checkedItems[0].text;
      default:
        return this.translateService.currentLang === Language.EN
          ? `${selection.checkedItems.length} options selected`
          : `${selection.checkedItems.length} opzioni selezionate`;
    }
  }

  getAllCheckboxText(): string {
    if (this.translateService.currentLang === Language.EN) {
      return 'All';
    } else {
      return 'Tutte';
    }
  }

  getFilterPlaceholder(): string {
    if (this.translateService.currentLang === Language.EN) {
      return 'Filter';
    } else {
      return 'Filtro';
    }
  }

  getFilterNoItemsFoundText(): string {
    if (this.translateService.currentLang === Language.EN) {
      return 'No items found';
    } else {
      return 'Nessun elementi trovato';
    }
  }

  getTooltipCollapseExpandText(isCollapse: boolean): string {
    return isCollapse
      ? this.translateService.currentLang === Language.EN ? 'Expand' : 'Espandere'
      : this.translateService.currentLang === Language.EN ? 'Collapse' : 'Crollo';
  }
}
