export const REGISTRO_URL = 'registro';
export const PROPOSTE_URL = 'proposte';
export const ANAGRAFICHE_URL = 'anagrafe';
export const LOGACTIVITY_URL = 'logactivity';
