export class FornitoreDetailsVm {
  atecoBankIt: string;
  capoGruppo: string;
  ccnl: string;
  codice: number;
  codiceFiscale: number;
  dataInserimento: Date;
  description: string;
  email: string;
  fornitoreConRatingNegativo: string;
  fornitoreCosti: number;
  fornitoreId: number;
  grouppo: string;
  indirizzoFornitore: string;
  infraGruppoExtraGruppo: string;
  legislazioneApplicataNazione: string;
  nation: string;
  ncommerico: string;
  ndg: number;
  nomeSocieta: string;
  numeroFornitore: string;
  paeseFornitore: string;
  partitaIva: string;
}
