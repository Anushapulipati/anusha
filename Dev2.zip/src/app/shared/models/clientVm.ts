export class ClientVm {
    abi: string;
    classeSocieta: string;
    clientiId: number;
    codiceFiscale: string;
    nomeSocieta: string;
    partitaIva: string;
}
