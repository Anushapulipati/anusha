export class ContrattoDetailsVm {
    autoritaCompetente: string;
    completoOrInCompleto: boolean;
    contrattoId: number;
    costoAttivita: number;
    dataInvioComunicazione: Date;
    dataInvioComunicazioneAdv: Date;
    fornitoreInfragruppoDataDi: Date;
    fornitoreInfragruppoFinale: string;
    fornitoreResponseList: string;
    fornitoriAlternativi: string;
    necessariaProceduraSindacale: string;
    numeroSubfornitori: number;
    oggettoDelContratto: string;
    pareresuiContrattiComplianceList: string;
    parereSuiContrattiRischiList: string;
    periodoAttesaEsito: number;
    propostaFornitoreId: number;
    scadenzaRiscontro: Date;
    servizioContrattoId: number;
    servizioList: string;
    servizioResponseList: string;
    societaClienteApprovatoreFinale: string;
    societaClienteDatApprovazione: Date;
    societaClientiId: number;
    societaGruppoCliente: string;
    statoCompletoAdv: string;
    statoCompletoCDA: string;
    statoCompletoProcedura: string;
    statoComunicazione: string;
    statoComunicazioneAdv: string;
    subFornitore: string;
    terminiPreavvisoCliente: string;
    terminiPreavvisoFornitore: string;

}
