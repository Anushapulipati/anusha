import { SelectView } from './selectView';

export class NuovoResponse {
    Canaledisegnalazione: SelectView[];
    StatoProposta: SelectView[];
}
