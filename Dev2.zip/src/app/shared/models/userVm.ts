import { AccessOperationVm } from './operationVm';

export class UserVm {
    id: number;
    matricola: number;
    name: string;
    operationVm: AccessOperationVm;
    profile: {
        code: string,
        description: string
    };
    surname: string;
    office: string;
}
