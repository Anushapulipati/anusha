import { FornitoreVm } from './fornitoreVm';

export class NuovoProposta {
  cambioFornitore: string;
  canDiSegnalazione: string;
  codCanSegnalazione: string;
  completoOrInCompleto: boolean;
  dataDelCensimento: Date;
  dataDellaProposta: Date;
  dataFineProposta: Date;
  gestionePraticaBackup: string;
  id: number;
  numeroProposta: number;
  oggDellaProposta: string;
  praticaOwner: string;
  proposalId: number;
  propostaName: string;
  segnalante: string;
  societaDelSegnalante: string;
  sotoStatoProposta: string;
  statoProposta: string;
  uosegnalante: string;

}
