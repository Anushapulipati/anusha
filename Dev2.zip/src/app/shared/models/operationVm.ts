export class AccessOperationVm {
    hasAllTabAccess: boolean;
    hasAnagraficheReadOnly: boolean;
    hasExportAllAccess: boolean;
    hasExportBySystemDate: boolean;
    hasLogActivityReadOnly: boolean;
    hasNewClienteAccess: boolean;
    hasNewContrattoAccess: boolean;
    hasNewFornitoreAccess: boolean;
    hasNewPropostaAccess: boolean;
    hasPropostaReadOnly: boolean;
    hasRegistroFornitoreDisabled: boolean;
    hasRegistroReadOnly: boolean;
    hasRegistroStatoFilter: boolean;
}
