export class SupplierVm {
    dataDellaProposta: Date;
    fornitoreId: number;
    // id: number;
    nomeSocieta: string;
    numeroProposta: number;
    oggDellaProposta: string;
    proposalId: number;
    societa: string;
    statoProposta: string;
}
