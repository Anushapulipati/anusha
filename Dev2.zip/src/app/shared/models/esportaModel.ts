export class EsportaModel {
    id: number;
    endTime: Date;
    fileContent: number;
    startTime: Date;
    status: string;
    error: string;
   
}