export class FornitoreVm {
    fornitoreId: number;
    nomeSocieta: string;
}
