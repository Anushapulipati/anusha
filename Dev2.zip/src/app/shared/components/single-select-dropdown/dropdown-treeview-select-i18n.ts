import { Injectable } from '@angular/core';
import { TreeviewItem, TreeviewSelection, DefaultTreeviewI18n } from 'ngx-treeview';
import { TranslateService } from '@ngx-translate/core';
import { Language } from '../../../shared/enumerations/language';

@Injectable()
export class DropdownTreeviewSelectI18n extends DefaultTreeviewI18n {
  private internalSelectedItem: TreeviewItem[];

  set selectedItem(value: TreeviewItem[]) {
    this.internalSelectedItem = value;
  }

  get selectedItem(): TreeviewItem[] {
    return this.internalSelectedItem;
  }

  constructor(
    private translateService: TranslateService
  ) {
    super();
  }

  getText(selection: TreeviewSelection): string {
    return this.internalSelectedItem
    ? this.internalSelectedItem['text']
    : this.translateService.currentLang === Language.IT ? 'Seleziona le opzioni' : 'Select options';
    // return this.translateService.currentLang === Language.EN ? 'All' : 'Tutte';

    // if (this.internalSelectedItem) {
    //   if (this.internalSelectedItem.length > 1) {
    //     return `${this.internalSelectedItem.length} options selected`;
    //   } else if (this.internalSelectedItem.length === 1) {
    //     return  this.internalSelectedItem[0].text;
    //   } else {
    //     return 'Select Option';
    //   }
    // } else {
    //   return 'Select Option';
    // }
  }

  getFilterPlaceholder(): string {
    if (this.translateService.currentLang === Language.EN) {
      return 'Filter';
    } else {
      return 'Filtro';
    }
  }

  getFilterNoItemsFoundText(): string {
    if (this.translateService.currentLang === Language.EN) {
      return 'No items found';
    } else {
      return 'Nessun elementi trovato';
    }
  }
}
