import { Component, Input, Output, EventEmitter, ViewChild, OnChanges } from '@angular/core';
import { isNil } from 'lodash';
import { TreeviewI18n, TreeviewItem, TreeviewConfig, DropdownTreeviewComponent, TreeviewHelper } from 'ngx-treeview';
import { DropdownTreeviewSelectI18n } from './dropdown-treeview-select-i18n';

@Component({
  selector: 'reg-single-select-dropdown',
  templateUrl: './single-select-dropdown.component.html',
  styleUrls: ['./single-select-dropdown.component.scss'],
  providers: [
    { provide: TreeviewI18n, useClass: DropdownTreeviewSelectI18n }
  ]
})
export class SingleSelectDropdownComponent implements OnChanges {
  private dropdownTreeviewSelectI18n: any;
  allCheckSelections = [];
  allSelections = [];
  @Input() config: TreeviewConfig;
  @ViewChild(DropdownTreeviewComponent) dropdownTreeviewComponent: DropdownTreeviewComponent;
  filterText: string;
  groupOneCheckSelections = [];
  groupOneSelections = [];
  groupThreeCheckSelections = [];
  groupThreeSelections = [];
  groupFourSelections = [];
  groupFourCheckSelections = [];
  groupFiveSelections = [];
  groupFiveCheckSelections = [];
  groupTwoCheckSelections = [];
  groupTwoSelections = [];
  @Input() defaultSelectdItem: any;
  @Input() items: TreeviewItem[];
  @Input() value: any;
  @Output() valueChange = new EventEmitter<any>();

  constructor(
    public i18n: TreeviewI18n
  ) {
    this.config = TreeviewConfig.create({
      hasAllCheckBox: false,
      hasCollapseExpand: false,
      hasFilter: true,
      maxHeight: 500
    });
    this.dropdownTreeviewSelectI18n = i18n as DropdownTreeviewSelectI18n;
  }

  // private selectItem(item: TreeviewItem, isChecked?): void {
  //   if (item) {
  //     if ((item.value === 'Fornitore A-Z' || item.value === 'Fornitore Z-A') && isChecked) {
  //       this.groupOneSelections = [item];
  //       this.groupOneCheckSelections = [item.value];
  //     } else if ((item.value === 'Fornitore A-Z' || item.value === 'Fornitore Z-A') && !isChecked) {
  //       this.groupOneSelections = [];
  //       this.groupOneCheckSelections = [];
  //     }
  //     if ((item.value === 'Società del Gruppo Cliente A-Z' || item.value === 'Società del Gruppo Cliente Z-A') && isChecked) {
  //       this.groupTwoSelections = [item];
  //       this.groupTwoCheckSelections = [item.value];
  //     } else if ((item.value === 'Società del Gruppo Cliente A-Z' || item.value === 'Società del Gruppo Cliente Z-A') && !isChecked) {
  //       this.groupTwoSelections = [];
  //       this.groupTwoCheckSelections = [];
  //     }
  //     if ((item.value === 'Numero Proposta (crescente)' || item.value === 'Numero Proposta (decrescente)') && isChecked) {
  //       this.groupThreeSelections = [item];
  //       this.groupThreeCheckSelections = [item.value];
  //     } else if ((item.value === 'Numero Proposta (crescente)' || item.value === 'Numero Proposta (decrescente)') && !isChecked) {
  //       this.groupThreeSelections = ['Numero Proposta (decrescente)'];
  //       this.groupThreeCheckSelections = ['Numero Proposta (decrescente)'];
  //     }

  //     if ((item.value === 'Meno recenti' || item.value === 'Più recenti') && isChecked) {
  //       this.groupFourSelections = [item];
  //       this.groupFourCheckSelections = [item.value];
  //     } else if ((item.value === 'Meno recenti' || item.value === 'Più recenti') && !isChecked) {
  //       this.groupFourSelections = [];
  //       this.groupFourCheckSelections = [];
  //     }


  //     if ((item.value === 'Nome fornitore/Società cliente A-Z' || item.value === 'Nome fornitore/Società cliente Z-A') && isChecked) {
  //       this.groupFiveSelections = [item];
  //       this.groupFiveCheckSelections = [item.value];
  //     } else if ((item.value === 'Nome fornitore/Società cliente A-Z' || item.value === 'Nome fornitore/Società cliente Z-A') && !isChecked) {
  //       this.groupFiveSelections = [];
  //       this.groupFiveCheckSelections = [];
  //     }

  //     this.allSelections = [...this.groupOneSelections, ...this.groupTwoSelections, ...this.groupThreeSelections, ...this.groupFourSelections, ...this.groupFiveSelections];
  //     this.allCheckSelections = [...this.groupOneCheckSelections, ...this.groupTwoCheckSelections, ...this.groupThreeCheckSelections, ...this.groupFourCheckSelections, ... this.groupFiveCheckSelections];
  //     this.dropdownTreeviewSelectI18n.selectedItem = [...this.allSelections];
  //     if (this.dropdownTreeviewComponent) {
  //       this.dropdownTreeviewComponent.onSelectedChange([...this.allSelections]);
  //     }
  //     this.value = this.allCheckSelections;
  //     this.valueChange.emit(this.allCheckSelections);
  //   }
  //   // if (this.dropdownTreeviewSelectI18n.selectedItem !== item) {
  //   //   this.dropdownTreeviewSelectI18n.selectedItem = item;
  //   //   if (this.dropdownTreeviewComponent) {
  //   //     this.dropdownTreeviewComponent.onSelectedChange([item]);
  //   //   }
  //   //   if (item) {
  //   //     if (this.value !== item.value) {
  //   //       this.value = item.value;
  //   //       this.valueChange.emit(item.value);
  //   //     }
  //   //   }
  //   // }
  // }

  private selectItem(item: TreeviewItem): void {
    // if (this.dropdownTreeviewSelectI18n.selectedItem !== item) {
      this.dropdownTreeviewSelectI18n.selectedItem = item;
      if (this.dropdownTreeviewComponent) {
        this.dropdownTreeviewComponent.onSelectedChange([item]);
      }
      if (item) {
        if (this.value !== item.value) {
          this.value = item.value;
          this.valueChange.emit(item.value);
        }
      }
    // }
  }

  // private updateSelectedItem(): void {
  //   if (!isNil(this.items)) {
  //     const selectedItem = TreeviewHelper.findItemInList(this.items, this.value);
  //     this.selectItem(selectedItem);
  //   }
  // }

  private updateSelectedItem(): void {
    if (!isNil(this.items)) {
      const selectedItem = TreeviewHelper.findItemInList(this.items, this.value);
      this.selectItem(selectedItem);
    }
  }

  ngOnChanges(): void {
    this.updateSelectedItem();
    // this.value = this.defaultSelectdItem;
  }

  // select(item: TreeviewItem, event): void {
  //   if (!item.children) {
  //     this.selectItem(item, event.target.checked);
  //   }
  // }
  select(item: TreeviewItem): void {
    if (!item.children) {
      this.selectItem(item);
    }
  }
}
