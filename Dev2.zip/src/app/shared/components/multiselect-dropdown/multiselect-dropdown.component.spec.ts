import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiselectDropdownComponent } from './multiselect-dropdown.component';
import { TreeviewItem, TreeviewConfig } from 'ngx-treeview';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

describe('MultiselectDropdownComponent', () => {
  let component: MultiselectDropdownComponent;
  let fixture: ComponentFixture<MultiselectDropdownComponent>;
  let treeViewItem: TreeviewItem;
  let treeViewConfig: TreeviewConfig;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiselectDropdownComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TreeviewItem, useValue: treeViewItem },
        { provide: TreeviewConfig, useValue: treeViewConfig }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiselectDropdownComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
