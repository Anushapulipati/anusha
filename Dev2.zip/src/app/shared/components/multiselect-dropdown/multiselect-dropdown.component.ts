import { ChangeDetectionStrategy, Component, forwardRef, Input, OnInit } from '@angular/core';
import { ControlValueAccessor, NG_VALUE_ACCESSOR } from '@angular/forms';
import { TreeviewConfig, TreeviewItem } from 'ngx-treeview';
import { isEqual } from 'lodash';

export const MULTI_SELECT_INPUT_CONTROL_VALUE_ACCESSOR: any = {
  provide: NG_VALUE_ACCESSOR,
  // tslint:disable-next-line: no-use-before-declare
  useExisting: forwardRef(() => MultiselectDropdownComponent),
  multi: true
};

const updateTreeLeaf = (item: TreeviewItem, selected: string[]) => {
  return new TreeviewItem(item);
};

const mapItem = (item: TreeviewItem, selected: string[]) => {
  if (item.children && item.children.length > 0) {
    // tslint:disable-next-line: no-use-before-declare
    return updateTreeParent(item, selected);
  }
  return updateTreeLeaf(item, selected);
};

const updateTreeParent = (item: TreeviewItem, selected: string[]) => {
  const children = item.children.map(child => mapItem(child, selected));
  if (isEqual(children, item.children)) {
    return item;
  }
  const modifiedParent = {
    ...item,
    children
  };
  return new TreeviewItem(modifiedParent, true);
};

@Component({
  selector: 'reg-multiselect-dropdown',
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './multiselect-dropdown.component.html',
  styleUrls: ['./multiselect-dropdown.component.scss'],
  providers: [
    MULTI_SELECT_INPUT_CONTROL_VALUE_ACCESSOR,
  ]
})
export class MultiselectDropdownComponent implements OnInit {
  private _items: TreeviewItem[];
  private onModelChange: Function;
  private onTouched: Function;
  private selected: string[] = [];
  @Input() config: TreeviewConfig = TreeviewConfig.create( {
    hasAllCheckBox: true,
    hasFilter: true,
    hasCollapseExpand: true,
    decoupleChildFromParent: false,
    maxHeight: 400
  });

  @Input( 'items' )
  set items(items: TreeviewItem[]) {
    this.updateItems(items, this.selected);
  }

  get items() {
    return this._items;
  }

  constructor() {}

  private updateItems(items: TreeviewItem[], selected: string[]) {
    if (items) {
      this._items = items.map(item => mapItem(item, selected));
      this.selected = selected;
    }
  }

  ngOnInit() {}

  public onSelect(items) {
    let selected = [];
    this._items.forEach(element => {
      if (element.checked) {
        selected = [...selected, element.value];
      }
      if (element.children) {
        (element.children.forEach(ch => {
          if (ch.checked) {
            selected = [...selected, ch.value];
          }
        }));
      }
    });
    this.selected = selected;
    this.onModelChange(selected);
  }

  registerOnChange(fn: Function) {
    this.onModelChange = fn;
  }

  registerOnTouched(fn: () => any): void {
    this.onTouched = fn;
  }

  setDisabledState?(isDisabled: boolean): void {
    throw new Error( 'Method not implemented.' );
  }

  writeValue(selected: string[]): void {
    selected = selected ? [ ...selected ].sort() : [ ...selected ];
    if (isEqual( this.selected, selected)) { return; }
    this.updateItems(this.items, selected );
  }
}
