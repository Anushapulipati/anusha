import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';
import { NgbAccordionConfig } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'reg-accordion',
  templateUrl: './accordion.component.html',
  styleUrls: ['./accordion.component.scss']
})
export class AccordionComponent implements OnInit {
  @Input() anagrafeCodeControl: string;
  @Input() anagrafeControl: string;
  @Input() code: string;
  @Input() color = 'text-primary';
  @Input() id: boolean;
  @Input() isDisabled: boolean;
  @Input() isShowPencil: string;
  @Input() isShowStatus = true;
  @Input() opened = false;
  @Input() status: boolean;
  @Input() statusText: any;
  @Input() title: string;
  @Output() titleClickEvent: EventEmitter<any> = new EventEmitter<any>();
  @Output() toggleEvent: EventEmitter<any> = new EventEmitter<any>();

  constructor(
    config: NgbAccordionConfig
  ) {
    // config.type = 'secondary';
  }

  ngOnInit() {
  }

  panelChange(event) {
  }

  titleClicked() {
    this.titleClickEvent.next(true);
  }

  toggled(opened) {
    this.toggleEvent.next(!opened);
  }
}
