import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Language } from '../../../shared/enumerations/language';
import { Router } from '@angular/router';
import { BreadcrumbModel } from 'fe-dghub-component-library/lib/models/breadcrumb-model';
import { SelectOptionModel } from 'fe-dghub-component-library/lib/models/select-option-model';
import { EventsModel } from 'fe-dghub-component-library/lib/models/event-model';

@Component({
  selector: 'reg-custom-components',
  templateUrl: './custom-components.component.html',
  styleUrls: ['./custom-components.component.scss']
})
export class CustomComponentsComponent implements OnInit {
  breadcrumbs: BreadcrumbModel[] = [
    {
      label: 'home',
      url: ''
    },
    {
      label: 'breadcrumb1',
      url: 'breadcrumb-examples'
    }
  ];
  colors: SelectOptionModel[] = [
    {
      value: 'red',
      description: 'Red'
    },
    {
      value: 'purple',
      description: 'Purple',
      checked: true
    }
  ];
  @Output() emitBreadcrumb: EventEmitter<any> = new EventEmitter<any>();
  caratterTitle: string;
  check = 'java 8';
  disabled = false;
  dropdownList = [];
  dropdownSettings = {};
  isOpened = true;
  opened = true;
  page = 4;
  selectedItems = [];
  options = [{ key: 'ONE CRI', value: '1' }, { key: 'TWO CRI', value: '2' }, { key: 'THREE CRI', value: '3' }];
  simpleOptions = ['FOUR HUNDRED ONE ', 'five', 'six', '7', '8', '9', '10', '11', '112', '1123', '1111', '123444', '543333', '67ree333'];
  someVariable = '1';
  someVariable2 = 'seven';
  panel_name = 'SERVIZIO 1 - LOREM IPSUM AD SINQUA ORAM';
  anotherDemoVariable: string;
  demoVariable: any;
  demoEvents: EventsModel[] = [];
  anotherDemoEvents: EventsModel[] = [];
  myErrorMessage: string;
  minImporto: string;
  maxImporto: string;
  error: boolean;
  amount: number;
  isDecimal: boolean;
  alignment1 = true;
  alignment2 = false;
  input_name = 'Capgemini Italia s.p.a';
  label = 'Nome Societa';
  select_name = '';
  showTab1 = true;
  showTab2 = false;
  showTab3 = false;
  showTab4 = true;
  completed: true;
  title = 'registro-fe-angular';
  disabledControl: true;
  constructor(
    private translateService: TranslateService,
    public router: Router
  ) { }


  changeLang(): void {
    this.translateService.currentLang === Language.IT ? this.translateService.use(Language.EN) : this.translateService.use(Language.IT);
  }

  getCurrentLang(): string {
    return this.translateService.currentLang;
  }

  rerouteMethod(breadcrumb) {
    this.router.navigate([breadcrumb.url]);
  }

  /* rerouteMethod(breadcrumb) {
    const serviceCallbackUrl = 'https://intrawsealcol.gbbper.priv/bstore-evo-2/dghub-vendita';
    console.log(breadcrumb.label);
    // this.router.navigate([currentBreadCrumb.url]);
    this.finanziamentiCrossJumpService.doCrossJummp(serviceCallbackUrl, breadcrumb.url, '');
  } */

  breadcrumbOnClick(breadcrumb) {
    this.emitBreadcrumb.emit(breadcrumb);
  }

  ngOnInit() {
    this.dropdownList = [
      { item_id: 1, item_text: 'Capgemini Italia s.p.a' },
      { item_id: 2, item_text: 'DOING s.r.l' },
      { item_id: 3, item_text: 'Lorem Ipsum srl' },
      { item_id: 4, item_text: 'BPER Banca' },
      { item_id: 5, item_text: 'Banco di Sardegna' }
    ];
    this.selectedItems = [
      { item_id: 3, item_text: 'Capgemini Italia s.p.a' },
      { item_id: 4, item_text: 'DOING s.r.l' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'DeSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: true
    };
  }

  onItemSelect(item: any) {
    console.log(item);
  }
  onSelectAll(items: any) {
    console.log(items);
  }

  panelChange(event) {
    // console.log(event);
  }

  setNewError(event) {
    // console.log(event);
  }

  toggleAccordion($event) {
  }

  changeCallBack(event) {
    console.log(event);
  }
}
