import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomComponentsComponent } from './custom-components.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { NgbPagination, NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { Observable, of } from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
import { NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';

const translation: any = {
};

class FakeLoader implements TranslateLoader {
  getTranslation(lang: string): Observable<any> {
    return of(translation);
  }
}

describe('CustomComponentsComponent', () => {
  let component: CustomComponentsComponent;
  let fixture: ComponentFixture<CustomComponentsComponent>;
  let route;
  const router = { events: of({ tipsId: '4' }) };
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CustomComponentsComponent ],
      schemas: [NO_ERRORS_SCHEMA, CUSTOM_ELEMENTS_SCHEMA],
      imports: [
        FormsModule,
        ReactiveFormsModule,
        FeDghubComponentLibraryModule,
        NgbPaginationModule,
        TranslateModule.forRoot({
          loader: {
            provide: TranslateLoader,
            useClass: FakeLoader
          }
        })
       ],
       providers: [
        { provide: ActivatedRoute, useValue: route },
        { provide: Router, useValue: router },
        ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomComponentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
