import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { LoginService } from '../../services/login.service';
import {UserVm} from '../../models/userVm';

@Component({
  selector: 'reg-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {
  userInfo: UserVm = new UserVm();
 // public userProfile: any;

  constructor(
    private route: ActivatedRoute
  ) {
    sessionStorage.clear();
    if (!environment.developmentMode) {
      //  caso reale
      route.queryParams.subscribe(
        params => {
          console.log('queryParams', JSON.parse(params['data']));
          sessionStorage.setItem('inputData', params['data']);
          console.log('received', sessionStorage.getItem('inputData'));
        });
    } else {
       //this.userProfile = prompt('Enter User profile');
      // sessionStorage.setItem('userProfile', this.userProfile);

    }
  }
}
