import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal, NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'reg-confirmation-component',
  templateUrl: './confirmation-component.component.html',
  styleUrls: ['./confirmation-component.component.scss']
})
export class ConfirmationComponentComponent implements OnInit {
  @Input() isConclusaWarning: any;
  constructor(private activeModal: NgbActiveModal) { }

  closeModal(action) {
    this.activeModal.close(action);
  }

  ngOnInit() {
  }

}
