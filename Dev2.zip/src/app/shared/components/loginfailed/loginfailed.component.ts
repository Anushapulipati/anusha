import { Component, OnInit } from '@angular/core';

@Component({
  templateUrl: './loginfailed.component.html',
  styleUrls: ['./loginfailed.component.scss']
})
export class LoginfailedComponent {

}
