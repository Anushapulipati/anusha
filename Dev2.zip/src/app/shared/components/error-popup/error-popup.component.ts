import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'reg-error-popup',
  templateUrl: './error-popup.component.html',
  styleUrls: ['./error-popup.component.scss']
})
export class ErrorPopupComponent implements OnInit {
  @Input() err: any;

  constructor(
    private activeModal: NgbActiveModal
  ) { }

  closeModal() {
    this.activeModal.close();
  }

  ngOnInit() {
    console.log('err', this.err);
  }
}
