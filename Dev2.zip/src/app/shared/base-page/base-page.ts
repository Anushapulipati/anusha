import { Injector } from '@angular/core';
import { TreeviewItem } from 'ngx-treeview';

export abstract class BasePage {

  constructor(injector:  Injector) {}

  private createTreeview(currentNode, treeview, isRegistro?) {
    const tempChildren = [];
    const onlyParentFilters = ['Sospesa', 'Annullata', 'Conclusa'];
    if (currentNode && currentNode.subDomainList && !onlyParentFilters.includes(currentNode.itemName)) {
      currentNode.subDomainList.forEach(child => {
        tempChildren.push(this.createTreeview(child, [], isRegistro));
      });
    }
    // ||  currentNode.tableId === 'Categorie BankIT'

    if (isRegistro) {
      // tslint:disable-next-line: max-line-length
      const isInCorso = (currentNode.tableId === 'Categorie BankIT' || (currentNode.tableId === 'Stato Proposta' && currentNode.itemName === 'In corso'));
      if (isInCorso) {
        tempChildren.forEach(element => {
          element['checked'] = isInCorso;
        });
      }
    } else {
      const isInCorso = ((currentNode.tableId === 'Stato Proposta' && currentNode.itemName === 'In corso'));
      if (isInCorso) {
        tempChildren.forEach(element => {
          element['checked'] = isInCorso;
        });
      }
    }



    // currentNode.tableId === 'Categorie EBA' || currentNode.tableId === 'Categorie BankIT' ||
    let isChecked;
    if (isRegistro) {
      // tslint:disable-next-line: max-line-length
      isChecked = (currentNode.tableId === 'Categorie EBA' || currentNode.tableId === 'Categorie BankIT' || currentNode.itemName === 'In attesa sottoscrizione' || currentNode.itemName === 'A-Z Nome fornitore/Società cliente' || currentNode.itemName === 'In vigore' || currentNode.itemName === 'Numero Proposta (decrescente)')
      ? true :  false;
    } else {
      // tslint:disable-next-line: max-line-length
      isChecked = (currentNode.itemName === 'In attesa sottoscrizione' || currentNode.itemName === 'A-Z Nome fornitore/Società cliente' || currentNode.itemName === 'In vigore' || currentNode.itemName === 'Numero Proposta (decrescente)')
    ? true :  false;
    }
    return {
      text:  currentNode.itemName,
      value:  currentNode.itemName,
      checked:  isChecked,
      children:  tempChildren
    };
  }

  public getFilterdData(filters, isRegistro?) {
    if (!filters) {
      return [];
    }
    const items:  TreeviewItem[] = [];
    filters.map(async filter => {
      const node = await this.createTreeview(filter, [], isRegistro);
      const item = new TreeviewItem(node);
      item.correctChecked();
      items.push(item);
    });
    return items;
  }
}
