import { CommonModule, DatePipe } from '@angular/common';
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { FeDghubComponentLibraryModule } from 'fe-dghub-component-library';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { CustomComponentsComponent } from './components/custom-components/custom-components.component';
import { AccordionComponent } from './components/accordion/accordion.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { TreeviewModule } from 'ngx-treeview';
import { MultiselectDropdownComponent } from './components/multiselect-dropdown/multiselect-dropdown.component';
import { HttpInterceptorService } from './services/http-interceptor.service';
import { ConfirmationComponentComponent } from './components/confirmation-component/confirmation-component.component';
import { SingleSelectDropdownComponent } from './components/single-select-dropdown/single-select-dropdown.component';
import { FooterActionComponent } from '../modules/proposte/components/footer-action/footer-action.component';
import { BreadcrumbComponent } from './components/breadcrumb/breadcrumb.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    CustomComponentsComponent,
    AccordionComponent,
    MultiselectDropdownComponent,
    ConfirmationComponentComponent,
    SingleSelectDropdownComponent,
    FooterActionComponent,
    BreadcrumbComponent
  ],
  imports: [
    CommonModule,
    TranslateModule,
    NgSelectModule,
    FormsModule,
    ReactiveFormsModule,
    FeDghubComponentLibraryModule,
    NgbModule,
    HttpClientModule,
    TreeviewModule.forRoot(),
    RouterModule
  ],
  exports: [
    CommonModule,
    TranslateModule,
    NgSelectModule,
    FormsModule,
    ReactiveFormsModule,
    FeDghubComponentLibraryModule,
    NgbModule,
    HttpClientModule,
    CustomComponentsComponent,
    AccordionComponent,
    HttpClientModule,
    MultiselectDropdownComponent,
    ConfirmationComponentComponent,
    TreeviewModule,
    SingleSelectDropdownComponent,
    FooterActionComponent,
    BreadcrumbComponent,
    RouterModule
  ],
  entryComponents: [ ConfirmationComponentComponent, SingleSelectDropdownComponent ],
  schemas: [ CUSTOM_ELEMENTS_SCHEMA ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpInterceptorService,
      multi: true
    },
    DatePipe
  ]
})
export class SharedModule {
}
