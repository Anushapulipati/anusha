export const environment = {
  production: true,
  developmentMode: false,
  apiUrl: '/${giunzione}/registro-fe-presentation/api',
  // apiUrl: 'http://10.26.20.243:8080/registro-fe-presentation/api',
  dummyUrl: '/id'
};
