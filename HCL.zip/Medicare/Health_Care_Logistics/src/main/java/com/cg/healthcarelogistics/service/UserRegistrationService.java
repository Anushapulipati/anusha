package com.cg.healthcarelogistics.service;

import java.util.List;

import com.cg.healthcarelogistics.dto.UserRegistration;

public interface UserRegistrationService {
	public boolean validateUserLogin(Long mobileNo,String password);
	public UserRegistration addUser(UserRegistration user);
	public List<UserRegistration> getAllUserDetails();
	public String getDetailsBasedOnRole(Long mobile,String password);
	public UserRegistration getUserMobile(Long mobile);
	public Integer booking(String umail,String tmail);
	public List<UserRegistration> getDetails(String tmail);
	public void delete(Long mobile);
	
	


}
