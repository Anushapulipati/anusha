package com.cg.healthcarelogistics.service;

import java.util.List;

import com.cg.healthcarelogistics.dto.Test;
import com.cg.healthcarelogistics.dto.UserRegistration;

public interface TestService {
	public Test addTest(Test test);
	public void updateTest(Long testId,Integer price);
	public List<Test> getAllTests();
	public void deleteTest(Long testId);
	public Integer getPrice(String cmail,Integer price);
	public void setprice(String cmail);
	public List<Test> getTestByName(String name);
	

}
