package com.cg.healthcarelogistics.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.healthcarelogistics.dto.Technician;
import com.cg.healthcarelogistics.dto.Test;
import com.cg.healthcarelogistics.dto.UserRegistration;
import com.cg.healthcarelogistics.service.TechnicianService;

@RestController
@RequestMapping("/managercontrol")
@CrossOrigin(origins="http://localhost:4200")
public class TechnicianController {
	@Autowired
	TechnicianService managerService;
	
	Logger logger=LoggerFactory.getLogger(UserRegistrationController.class);
	
	
	@PostMapping("/addtechnician")
	public Technician addTechnician(@RequestBody Technician managerRole) {
		logger.info("adding new te hnician to db");
		return managerService.addTechnician(managerRole);
		
	}
	@GetMapping("/getalltechnician")
	public List<Technician> getAllTechnician(){
		logger.info("getting all the technicians");
		return managerService.getAllTechnician();	
	}
	@PutMapping("/updatetechnician/{mobileNo}/{salary}/{experience}")
	public void updateTechnician(@PathVariable("mobileNo") Long mobile,@PathVariable("salary")Integer salary,@PathVariable("experience")Integer experience) {
		logger.info("updating the technicians");
		managerService.updateTechnician(mobile, salary, experience);
	}
	
	@DeleteMapping("/deletetechnician/{mobileNo}")
	public void deleteTechnician(@PathVariable("mobileNo") Long mobile) {
		managerService.deleteTechnician(mobile);
	}
	
	@GetMapping("/getbyid/{mobileNo}")
	public Technician getById(@PathVariable("mobileNo") Long mobile) {
		return managerService.getById(mobile);
	}
	
	@GetMapping("/getroledetails/{mobile}/{password}")
	public boolean getTechnicianDetails(@PathVariable("mobile") Long mob,@PathVariable("password") String pwd) {
		boolean validUser=managerService.getTechnicianDetails(mob, pwd);
	
		if(validUser==true) {
			return true;
		}
		
			
		return false;
	}
	@GetMapping("gettechbyname/{name}")
	public List<Technician> gettechnicianbyName(@PathVariable("name") String name) {
		logger.info("getting details of technician by name");
		return managerService.getTechnicianByName(name);
	}
		
		
	
	
	

	


}
