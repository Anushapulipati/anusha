package com.cg.healthcarelogistics.dto;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Managers_Roles")
public class Technician {

@Id
@Indexed(name="_id")
private Long mobileNo;
private String technicianName;
private Integer salary;
private String gender;
private Integer experience;
private String technicianDescription;
private String technicianEmail;
private String password;

public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getTechnicianName() {
	return technicianName;
}
public void setTechnicianName(String technicianName) {
	this.technicianName = technicianName;
}
public Long getMobileNo() {
	return mobileNo;
}
public void setMobileNo(Long mobileNo) {
	this.mobileNo = mobileNo;
}
public Integer getSalary() {
	return salary;
}
public void setSalary(Integer salary) {
	this.salary = salary;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public Integer getExperience() {
	return experience;
}
public void setExperience(Integer experience) {
	this.experience = experience;
}
public String getTechnicianDescription() {
	return technicianDescription;
}
public void setTechnicianDescription(String technicianDescription) {
	this.technicianDescription = technicianDescription;
}


public String getTechnicianEmail() {
	return technicianEmail;
}
public void setTechnicianEmail(String technicianEmail) {
	this.technicianEmail = technicianEmail;
}
public Technician() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "ManagerRole [mobileNo=" + mobileNo + ", technicianName=" + technicianName + ", salary=" + salary
			+ ", gender=" + gender + ", experience=" + experience + ", technicianDescription=" + technicianDescription
			+ ", technicianEmail=" + technicianEmail + ", password=" + password + "]";
}
public Technician(Long mobileNo, String technicianName, Integer salary, String gender, Integer experience,
		String technicianDescription, String technicianEmail, String password) {
	super();
	this.mobileNo = mobileNo;
	this.technicianName = technicianName;
	this.salary = salary;
	this.gender = gender;
	this.experience = experience;
	this.technicianDescription = technicianDescription;
	this.technicianEmail = technicianEmail;
	this.password = password;
}




}