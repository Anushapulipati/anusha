package com.cg.healthcarelogistics.dao;

import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.cg.healthcarelogistics.dto.Technician;
import com.cg.healthcarelogistics.dto.UserRegistration;


@Repository
public class UserRegistrationDaoImpl implements UserRegistrationDao{
	@Autowired

	MongoTemplate mongotemplate;
	String str;


	//method for validating the user based on credentials
	@Override
	public boolean validateUserLogin(Long mobileNo, String password) {

		boolean flag=false;

		List<UserRegistration> userRegistration=mongotemplate.findAll(UserRegistration.class);
		System.out.println("list is:"+userRegistration);
		for(UserRegistration user:userRegistration) {

			if(user.getMobileNo().equals(mobileNo)) {
				if(user.getPassword().equals(password)) {
					flag=true;
				}

			}
		}
		return flag;
	}

	//method for adding the new user
	@Override
	public UserRegistration addUser(UserRegistration user) {
		
		
		return mongotemplate.insert(user);
	}

	//method for fetching all the user details
	@Override
	public List<UserRegistration> getAllUserDetails() {
		// TODO Auto-generated method stub
		return mongotemplate.findAll(UserRegistration.class);
	}

	//
	//method for getting user details based on the role
	@Override
	public String getDetailsBasedOnRole(Long mobile, String password) {
		// TODO Auto-generated method stub
		System.out.println("in dao roles details"+mobile+password);
		String role="";
		List<UserRegistration> rolesdetails=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration details:rolesdetails) {
			if(details.getMobileNo().equals(mobile)) {
				if(details.getPassword().equals(password)) {
					role=details.getRole();
				}
			}
		}
		return role;
	}

	//method for fetching details based on the mobile number (customer details in technician page)
	@Override
	public UserRegistration getUserMobile(Long mobile) {
		// TODO Auto-generated method stub
		List<UserRegistration> user=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration mobileDetails:user) {
			if(mobileDetails.getMobileNo().equals(mobile)) {
				return mobileDetails;
			}

		}
		return null;
	}

	//method for setting the technician mailId for a particular user
	@Override
	public Integer booking(String umail, String tmail) {
		// TODO Auto-generated method stub
		UserRegistration user=mongotemplate.findOne(Query.query(Criteria.where("email").is(umail)),UserRegistration.class );
		user.setTechnicianEmail(tmail);
		mongotemplate.save(user);
		return 1;
	}

	//method for  fetching all the booked customers for a particular technician
	@Override
	public List<UserRegistration> getDetails(String tmail) {
		// TODO Auto-generated method stub
		List<UserRegistration> user=getAllUserDetails();
		List<UserRegistration> userdetails=new ArrayList<>();
		for(UserRegistration details:user) {
			if(details.getTechnicianEmail()!=null) {
				if(details.getTechnicianEmail().equalsIgnoreCase(tmail)){
					userdetails.add(details);

				}
			}
		}
		return userdetails;
	}

	//method for deleting a user
	@Override
	public void delete(Long mobile) {
		// TODO Auto-generated method stub
		List<UserRegistration> data3=mongotemplate.findAll(UserRegistration.class);
		for(UserRegistration data4:data3) {
			if(data4.getMobileNo().equals(mobile)) {
				mongotemplate.remove(data4);
			}
		}

	}




}




