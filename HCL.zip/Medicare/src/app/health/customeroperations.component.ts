import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customeroperations',
  templateUrl: './customeroperations.component.html',
  styleUrls: ['./customeroperations.component.css']
})
export class CustomeroperationsComponent implements OnInit {
data:any=[];
result:any=[];
data4:any=[];
res:any;
  constructor(private service:HealthService, private router:Router) { }
 
    
  /* Method for booking the technician */
Booking(technicianEmail:String)
{
  console.log("CO"+this.service.currentUserMailId);
  console.log("in CUSTOMER operation"+this.data4.password);

  console.log("in technician mail is "+technicianEmail);
  console.log(this.service.currentUser);
  /* let details=(this.service.getMobile(this.service.currentUser));
  console.log(details.mobileNo);
  console.log(details.userName);
  console.log(details.gender);
  console.log(details.role);
  console.log(details.password);
  console.log(details.dob); */
  console.log("current user mail id is "+this.service.currentUserMailId);
  return this.service.addBooking(this.service.currentUserMailId,technicianEmail).subscribe((data:number)=>{
    this.res=data;
    if(this.res==1)
    alert("booked successfully");
  });
  
}

Logout(){
  let mail=localStorage.getItem("mail");
  console.log("cust mail in logout"+mail);
  this.service.setTotalPricetoZero(mail).subscribe();

  this.router.navigate(['/logout'])
}
next(){
  this.router.navigate(['/billing'])
}
onSearch(value){
  console.log(value);
  this.data=this.data.filter(b=>b.technicianName.toLowerCase().match(value.toLowerCase()) || b.technicianDescription.toLowerCase().match(value.toLowerCase()) || b.mobileNo.toString().match(value.toString()) || b.salary.toString().match(value.toString()) || b.experience.toString().match(value.toString()) || b.technicianEmail.toLowerCase().match(value.toLowerCase()));
}

  ngOnInit() {
    this.service.getAllTechnician().subscribe(result=>{this.data=result;console.log(this.data)});
     
  }
  
}
