import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-managerupdatetests',
  templateUrl: './managerupdatetests.component.html',
  styleUrls: ['./managerupdatetests.component.css']
})
export class ManagerupdatetestsComponent implements OnInit {

  constructor(private service:HealthService,private router:Router) { }
  data:any=[];
  result:any=[];

  /* method for updating particular test */
updateTests(testId){
  console.log(testId+"is testId")
  this.router.navigate(['/updatetests'])

}
  ngOnInit() {
    this.service.getAllTests().subscribe(result=>{this.data=result;
      console.log("data"+this.data.test)});
  }

}
