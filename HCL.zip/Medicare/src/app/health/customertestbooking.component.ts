import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-customertestbooking',
  templateUrl: './customertestbooking.component.html',
  styleUrls: ['./customertestbooking.component.css']
})
export class CustomertestbookingComponent implements OnInit {

  constructor(private router:Router,private service:HealthService) { }
  bookTechnician(){
    console.log("in "+this.service.currentUserMailId);
this.router.navigate(['/customeroperations'])
  }
  viewTests(){
  this.router.navigate(['/customerviewtests'])

}

status(){
  
}
  ngOnInit() {
  }

}
 