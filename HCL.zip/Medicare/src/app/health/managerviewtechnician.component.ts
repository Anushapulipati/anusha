import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-managerviewtechnician',
  templateUrl: './managerviewtechnician.component.html',
  styleUrls: ['./managerviewtechnician.component.css']
})
export class ManagerviewtechnicianComponent implements OnInit {
  data:any=[];
  result:any=[];
  constructor(private router:Router,private service:HealthService) { }
/* Method for adding new technician */
addTechnician(){

  this.router.navigate(['/managertechnician'])
}

/* Method for deleting particular technician */
deleteTechnician(mobile:any){
  
  console.log("in delete technician ts file"+mobile);
 let index=this.data.indexOf(mobile);
  this.data.splice(index,1);  
  window.location.reload();
    this.service.deleteTechnician(mobile).subscribe();
  
  }
  
  /* method for displaying all the technicians */
getAllTechnician()
{
  this.service.getAllTechnician().subscribe(result=>{this.data=result;
    console.log("in manager delete technician"+this.data);
  
})
}
/* method for logout */
Logout(){
  this.router.navigate(['/logout']);
}
onSearch(value){
  console.log(value);
  this.data=this.data.filter(b=>b.technicianName.toLowerCase().match(value.toLowerCase()) || b.technicianDescription.toLowerCase().match(value.toLowerCase()) || b.mobileNo.toString().match(value.toString()) || b.salary.toString().match(value.toString()) || b.experience.toString().match(value.toString()) || b.technicianEmail.toLowerCase().match(value.toLowerCase()));
}
ngOnInit() {
  this.service.getAllTechnician().subscribe(result=>{this.data=result;
    console.log("data"+this.data)});

}
}
