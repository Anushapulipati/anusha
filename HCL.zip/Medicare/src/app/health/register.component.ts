import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor(private service:HealthService,private router:Router) { }
model:any={}
result:boolean=false;
pass:string;

onSubmit(model):any{
  this.result=true;
  this.pass=btoa(this.model.password);
  this.model.password=this.pass;
  this.service.addUserRegister(this.model).subscribe((data)=>{
    
  });
  window.location.reload();
}
back(){
this.router.navigate(['/home'])
}
  ngOnInit() {
  }

}
