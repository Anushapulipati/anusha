import { Component, OnInit, Input } from '@angular/core';
import { HealthService } from '../health.service';
import {  Router } from '@angular/router';
import { toBase64String } from '@angular/compiler/src/output/source_map';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
message:boolean=false;
  mobile:number;
password:any;
email:any;
result:any;
@Input() data1:any=[];
@Input() data10:String="anu";
result1:any=[];
pwd:string;
pass:string;
  constructor(private service:HealthService,private router:Router) { }

  /* Method for checking user credentials */
  check(mobile,password,mail){
    console.log("hello"+mobile+password+mail);
     this.pwd=btoa(password);
     console.log(btoa(password));
     console.log(btoa(password));
    this.service.checkMobile(mobile,this.pwd).subscribe((data:any)=>{
      if(data)
      this.router.navigate(['/customerviewtests'])
      console.log(btoa(password)); 
    });
    console.log("customer mail is"+mail);
    localStorage.setItem("mail",mail);
    console.log("mobile and password is"+mobile+password)
    this.service.getMobile(mobile).subscribe(result1=>{
      this.data1=result1;
    console.log("checking user mobile"+this.data1.mobileNo)
    /* this.service.setDetails(this.data1); */
    
    this.service.setDetails(this.data1);
    /* this.service.gettingData("good afternoon"); */
    console.log("initially"+this.service.currentUser);
    this.service.currentUser=this.data1.mobileNo;
    console.log("checking current user"+ this.service.currentUser)
    console.log("checking emailid"+this.data1.email);
    this.service.currentUserMailId=this.data1.email;
    console.log("finally"+this.service.currentUserMailId);
    

   
  });
    this.pass=btoa(password);
    this.service.getAllRoleDetails(mobile,this.pass).subscribe(data=>{
      this.result=data;
      if(this.result==3)
      {
        this.router.navigate(['/customerviewtests'])

       
      }
    
      else {
       this.message=true;
      }

    });
  }
  


  ngOnInit() {

 
  }

}
