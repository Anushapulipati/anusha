package com.cg.project.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlAttribute;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.mongodb.core.mapping.Document;
@Document(collection = "delivery")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Delivery {
	@XmlAttribute
	private String deliveryValue;
	@XmlElement
	private String deliveryStatus;
	public String getDeliveryValue() {
		return deliveryValue;
	}
	public void setDeliveryValue(String deliveryValue) {
		this.deliveryValue = deliveryValue;
	}
	public String getDeliveryStatus() {
		return deliveryStatus;
	}
	public void setDeliveryStatus(String deliveryStatus) {
		this.deliveryStatus = deliveryStatus;
	}
	public Delivery(String deliveryValue, String deliveryStatus) {
		super();
		this.deliveryValue = deliveryValue;
		this.deliveryStatus = deliveryStatus;
	}
	public Delivery() {
		super();
	}
	@Override
	public String toString() {
		return "Delivery [deliveryValue=" + deliveryValue + ", deliveryStatus=" + deliveryStatus + "]";
	}
	
	
}
