package com.cg.project.dto;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "transactiondetails")
@XmlRootElement(name="transactiondetails")
@XmlAccessorType(XmlAccessType.FIELD)
public class TransactionDetails {
	@XmlElement
	private String businessDayDate;
	@XmlElement
	private PurchaseDetails purchaseDetails;
	@XmlElement
	private Delivery delivery;
	@XmlElement
	private String paymentMode;
	public String getBusinessDayDate() {
		return businessDayDate;
	}
	public void setBusinessDayDate(String businessDayDate) {
		this.businessDayDate = businessDayDate;
	}
	public PurchaseDetails getPurchaseDetails() {
		return purchaseDetails;
	}
	public void setPurchaseDetails(PurchaseDetails purchaseDetails) {
		this.purchaseDetails = purchaseDetails;
	}
	public Delivery getDelivery() {
		return delivery;
	}
	public void setDelivery(Delivery delivery) {
		this.delivery = delivery;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public TransactionDetails(String businessDayDate, PurchaseDetails purchaseDetails, Delivery delivery,
			String paymentMode) {
		super();
		this.businessDayDate = businessDayDate;
		this.purchaseDetails = purchaseDetails;
		this.delivery = delivery;
		this.paymentMode = paymentMode;
	}
	public TransactionDetails() {
		super();
	}
	@Override
	public String toString() {
		return "TransactionDetails [businessDayDate=" + businessDayDate + ", purchaseDetails=" + purchaseDetails
				+ ", delivery=" + delivery + ", paymentMode=" + paymentMode + "]";
	}
	
	

}
