package com.cg.project.dto;


import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.springframework.data.mongodb.core.mapping.Document; 
@Document(collection = "item")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Item {
	@XmlElement
	private Integer itemId;
	@XmlElement
	private String itemName;
	@XmlElement
	private Double amount;
	@XmlElement
	private Integer quantity;
	public Integer getItemID() {
		return itemId;
	}
	public void setItemID(Integer itemID) {
		this.itemId = itemID;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public Item(Integer itemId, String itemName, Double amount, Integer quantity) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.amount = amount;
		this.quantity = quantity;
	}
	public Item() {
		super();
	}
	@Override
	public String toString() {
		return "Item [itemId=" + itemId + ", itemName=" + itemName + ", amount=" + amount + ", quantity=" + quantity
				+ "]";
	}
	
	

}
