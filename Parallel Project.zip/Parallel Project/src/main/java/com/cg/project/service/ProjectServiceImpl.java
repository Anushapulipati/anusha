package com.cg.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.project.dao.ProjectDao;
import com.cg.project.dto.Item;
import com.cg.project.dto.PurchaseDetails;
import com.cg.project.dto.Transaction;

@Service
public class ProjectServiceImpl implements ProjectService{

	@Autowired
	ProjectDao projectDao;
	

	@Override
	public Transaction create(Transaction transaction) {
		// TODO Auto-generated method stub
		return projectDao.create(transaction);
	}

	@Override
	public List<Transaction> getAll() {
		System.out.println("service");
		return projectDao.getAll();
	}

	@Override
	public Transaction update(Transaction j) {
		// TODO Auto-generated method stub
		return projectDao.update(j);
	}

	@Override
	public List<Item> getByOrderId(Integer orderId) {
		
		return projectDao.getByOrderId(orderId);
	}

	@Override
	public List<Item> getByName(String itemName) {
		// TODO Auto-generated method stub
		return projectDao.getByName(itemName);
	}

	@Override
	public String getDeliveryDetail(Integer orderId) {
		
		return projectDao.getDeliveryDetail(orderId);
	}

	@Override
	public Integer getByNameId(String itemName) {
		// TODO Auto-generated method stub
		return projectDao.getByNameId(itemName);
	}

}
