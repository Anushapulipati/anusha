package com.cg.project.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.xml.bind.Binder;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.cg.project.dto.Delivery;
import com.cg.project.dto.Item;
import com.cg.project.dto.Transaction;
import com.cg.project.dto.TransactionDetails;
import com.cg.project.dto.Validate;
import com.cg.project.service.ProjectService;

@RestController
@RequestMapping("/mapping")
@CrossOrigin(origins="http://localhost:4200")
public class ProjectController {

	@Autowired
	ProjectService service;
	
	@Autowired
	Validate validate;

	@PutMapping("/validating XSD")
	public void validating() {
		File file=new File("C:\\Users\\knavyaga\\Desktop\\ref.xml");
		boolean result=validate.validateXMLSchema("C:\\Users\\knavyaga\\Desktop\\ref.xsd",file);
		if(result) {
		try {
			JAXBContext jc=JAXBContext.newInstance(Transaction.class);
			Unmarshaller ums=jc.createUnmarshaller();
			Transaction trans=(Transaction) ums.unmarshal(file);
			System.out.println("Your file is valid");
			service.create(trans);	
		} 
		catch (JAXBException e) {
			e.printStackTrace();
		}	
		}
		else {
			System.out.println("Invalid xml data");
		}
	}
	
	
	@PostMapping("/create")
	public void create() throws JAXBException, ParserConfigurationException, SAXException, IOException, TransformerException  {
		try {    
			File file = new File("C:\\Users\\knavyaga\\Desktop\\ref.xml");
			 JAXBContext jaxbContext = JAXBContext.newInstance(Transaction.class);
			 Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			 Transaction j=(Transaction) jaxbUnmarshaller.unmarshal(file); 
	           service.create(j);
		}catch (JAXBException e) {
			e.printStackTrace();
        }   
	}  
	
	@PostMapping("/update")
    public void update() throws SAXException, IOException, ParserConfigurationException, TransformerException {
  try {
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    DocumentBuilder db = dbf.newDocumentBuilder();
    File xml = new File("C:\\Users\\knavyaga\\Desktop\\ref.xml");
    Document document = db.parse(xml);
    JAXBContext jaxbContext = JAXBContext.newInstance(Transaction.class);
    Binder<Node> binder = jaxbContext.createBinder();
    
    Transaction transaction = (Transaction) binder.unmarshal(document);
    List<TransactionDetails> transaction1=transaction.getTransactionDetails();
    System.out.println(transaction1);  
    for (TransactionDetails del : transaction1) {    
    	if(del.getPurchaseDetails().getOrderId()==122) {
    	Delivery delivery=del.getDelivery();
    	delivery.setDeliveryStatus("Pending");    	
    	}
    }
    binder.updateXML(transaction);
    TransformerFactory tf = TransformerFactory.newInstance();
    Transformer t = tf.newTransformer();
    DOMSource source = new DOMSource(document);
    StreamResult result = new StreamResult("C:\\Users\\knavyaga\\Desktop\\ref.xml");	        
    t.transform(source, result);
    
    //update dbbb
    
    File file1 = new File("C:\\Users\\knavyaga\\Desktop\\ref.xml");
	 JAXBContext jaxbContext1 = JAXBContext.newInstance(Transaction.class);
	 
	 Unmarshaller jaxbUnmarshaller1 = jaxbContext1.createUnmarshaller();
	 Transaction j1=(Transaction) jaxbUnmarshaller1.unmarshal(file1); 
	 System.out.println(j1.getTransactionDetails());
       
        service.update(j1);

      } catch (JAXBException e) {e.printStackTrace();
      }    
  		System.out.println("done");
	}
	
	@GetMapping("/getById/{id}")
	public List<Item> getById(@PathVariable("id") int orderId) {
		return service.getByOrderId(orderId);
	}
	
	@GetMapping("/getByName/{name}")
	public List<Item> getByName(@PathVariable("name") String itemName) {
		return service.getByName(itemName);
	}
	
	@GetMapping("/getIdByName/{name}")
	public Integer getIdByName(@PathVariable("name") String itemName) {
		return service.getByNameId(itemName);
	}
	
	
	@PostMapping("/updateNewXml")
    public void updateIntoFile() throws SAXException, IOException, ParserConfigurationException, TransformerException {
  try {
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    DocumentBuilder db = dbf.newDocumentBuilder();
    File xml = new File("C:\\Users\\knavyaga\\Desktop\\ref.xml");
    File xml1 = new File("C:\\Users\\knavyaga\\Desktop\\ref1.xml");
    File xml2 = new File("C:\\Users\\knavyaga\\Desktop\\ref2.xml");
   

    Document document = db.parse(xml);
    Document document1 = db.parse(xml1);
    Document document2 = db.parse(xml2);
   
    
    JAXBContext jaxbContext = JAXBContext.newInstance(Transaction.class);
    Marshaller jaxbMarshaller = jaxbContext.createMarshaller();
    Binder<Node> binder = jaxbContext.createBinder();
    Transaction transaction = (Transaction) binder.unmarshal(document);
    List<TransactionDetails> transaction1=transaction.getTransactionDetails();
    
    Transaction transaction5 = (Transaction) binder.unmarshal(document1);
    List<TransactionDetails> transaction6=transaction5.getTransactionDetails();
    
    Transaction transaction7 = (Transaction) binder.unmarshal(document2);
    List<TransactionDetails> transaction8=transaction7.getTransactionDetails();
    
    File file = new File("C:\\Users\\knavyaga\\Desktop\\result5.xml");
    for (TransactionDetails del : transaction1) {    	
    	if(del.getPaymentMode().equalsIgnoreCase("cash")) {
    binder.updateXML(del);
    jaxbMarshaller.marshal(del, file);
    	}
    }
    
    File file1 = new File("C:\\Users\\knavyaga\\Desktop\\result6.xml");
    for (TransactionDetails del : transaction1) {    	
    	if(del.getPaymentMode().equalsIgnoreCase("debit")) {
    binder.updateXML(del);
    jaxbMarshaller.marshal(del, file1);
    	}
    }
    
   
    File file2 = new File("C:\\Users\\knavyaga\\Desktop\\result7.xml");
    for (TransactionDetails del : transaction1) {    	
    	if(del.getPaymentMode().equalsIgnoreCase("credit")) {
    binder.updateXML(del);
    jaxbMarshaller.marshal(del, file2);
    	}
    }
  	}catch (JAXBException e) {
	  e.printStackTrace();
  	} 
	}
	
	
	@PostMapping("/updateById/{oid}")
    public void update1(@PathVariable ("oid") Integer id) throws SAXException, IOException, ParserConfigurationException, TransformerException {
  try {
    DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
    DocumentBuilder db = dbf.newDocumentBuilder();
    File xml = new File("C:\\Users\\knavyaga\\Desktop\\ref.xml");
    Document document = db.parse(xml);
    JAXBContext jaxbContext = JAXBContext.newInstance(Transaction.class);
    Binder<Node> binder = jaxbContext.createBinder();
    
    Transaction transaction = (Transaction) binder.unmarshal(document);
    List<TransactionDetails> transaction1=transaction.getTransactionDetails();
    for (TransactionDetails del : transaction1) {    
    	if(del.getPurchaseDetails().getOrderId()==id) {
    	Delivery delivery=del.getDelivery();
    	delivery.setDeliveryStatus("Initiated");    	
    	}
    }
    binder.updateXML(transaction);
    TransformerFactory tf = TransformerFactory.newInstance();
    Transformer t = tf.newTransformer();
    DOMSource source = new DOMSource(document);
    StreamResult result = new StreamResult("C:\\Users\\knavyaga\\Desktop\\ref.xml");	        
    t.transform(source, result);
    
    //update dbbb
    
    File file1 = new File("C:\\Users\\knavyaga\\Desktop\\ref.xml");
	 JAXBContext jaxbContext1 = JAXBContext.newInstance(Transaction.class);
	 
	 Unmarshaller jaxbUnmarshaller1 = jaxbContext1.createUnmarshaller();
	 Transaction trans=(Transaction) jaxbUnmarshaller1.unmarshal(file1); 
	 System.out.println(trans.getTransactionDetails());
       
        service.update(trans);

      } catch (JAXBException e) {e.printStackTrace();
      }    
	}
	
	@GetMapping("/getDeliveryDetail/{orderId}")
	public Integer getDeliveryStatus(@PathVariable("orderId") Integer id) {
		
		String result=service.getDeliveryDetail(id);
		System.out.println("done"+result);
		if(result.equalsIgnoreCase("Not Initiated")){
			return 1;
		}
		else if(result.equalsIgnoreCase("Initiated")) {
			return 2;
		}
		else if(result.equalsIgnoreCase("Completed")) {
			return 3;
		}
		else if(result.equalsIgnoreCase("Not Applicable")) {
			return 4;
		}
		return 0;
	}
	
	
	
}
