package com.cg.project.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;

import com.cg.project.dto.Delivery;
import com.cg.project.dto.Item;
import com.cg.project.dto.PurchaseDetails;
import com.cg.project.dto.Transaction;
import com.cg.project.dto.TransactionDetails;

class ProductTest {

	
	  @Test 
	  public void test() { 
		  Transaction transaction =new Transaction();
		  transaction.setRetailStoreID(441);
	  	  assertNotNull(transaction.getRetailStoreID());
	  }
	  

		@Test
		public void itemTesting() {
			ProjectServiceImpl service=new ProjectServiceImpl();
			List<Item> details=new ArrayList<Item>();
			PurchaseDetails purchase=new PurchaseDetails();
			for (Item items2 : details) {
				items2.setItemID(102);
				items2.setAmount(1223.678);
				items2.setItemName("clothes");
				items2.setQuantity(2);
			}
			purchase.setItems(details);
			assertNotNull(purchase);
		}
		
	
		@Test
		public void testGet() {
			Transaction transaction=new Transaction();
			TransactionDetails details=new TransactionDetails();
			Delivery delivery=new Delivery();
			delivery.setDeliveryStatus("assigned");
			delivery.setDeliveryValue("yes");
			details.setBusinessDayDate("2019-23-05");
			details.setPaymentMode("credit");
			details.setDelivery(delivery);
			transaction.setRetailStoreID(01);
			PurchaseDetails purchase=new PurchaseDetails();
			purchase.setOrderId(1001);
			purchase.setTotalAmount(123.456);
			List<Item> items=new ArrayList<Item>();
			for (Item items2 : items) {
				items2.setItemID(102);
				items2.setAmount(1223.678);
				items2.setItemName("clothes");
				items2.setQuantity(2);
			}
			purchase.setItems(items);
			details.setPurchaseDetails(purchase);
			assertNotNull(transaction);
		}
		
		
		

}
