package com.cg.product.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="dherbe_sanitationProduct")
public class DherbeSanitation {
	@Id
	private String prodId;
	private String prodName;
	private String prodPrice;
	private String stock;
	private String weight;
	private String guidelines;
	private String eDate;
	private String image;
	
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getProdId() {
		return prodId;
	}
	public void setProdId(String prodId) {
		this.prodId = prodId;
	}
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getProdPrice() {
		return prodPrice;
	}
	public void setProdPrice(String prodPrice) {
		this.prodPrice = prodPrice;
	}
	public String getStock() {
		return stock;
	}
	public void setStock(String stock) {
		this.stock = stock;
	}
	public String getWeight() {
		return weight;
	}
	public void setWeight(String weight) {
		this.weight = weight;
	}
	public String getGuidelines() {
		return guidelines;
	}
	public void setGuidelines(String guidelines) {
		this.guidelines = guidelines;
	}
	public String geteDate() {
		return eDate;
	}
	public void seteDate(String eDate) {
		this.eDate = eDate;
	}

	@Override
	public String toString() {
		return "DherbeSanitation [prodId=" + prodId + ", prodName=" + prodName + ", prodPrice=" + prodPrice + ", stock="
				+ stock + ", weight=" + weight + ", guidelines=" + guidelines + ", eDate=" + eDate + ", image=" + image
				+ "]";
	}
	public DherbeSanitation(String prodId, String prodName, String prodPrice, String stock, String weight,
			String guidelines, String eDate, String image) {
		super();
		this.prodId = prodId;
		this.prodName = prodName;
		this.prodPrice = prodPrice;
		this.stock = stock;
		this.weight = weight;
		this.guidelines = guidelines;
		this.eDate = eDate;
		this.image = image;
	}
	public DherbeSanitation() {
		super();
	}
	
		


	
}
