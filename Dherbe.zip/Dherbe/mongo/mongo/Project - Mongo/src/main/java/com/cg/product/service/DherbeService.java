package com.cg.product.service;

import java.util.List;

import com.cg.product.dto.DherbeBeauty;

public interface DherbeService {
public List<DherbeBeauty> showAllProducts();
	
	public DherbeBeauty searchByProductId(int proId);

	public void saveProduct(DherbeBeauty cust);
	public void deleteProduct(String proId); 
	public DherbeBeauty updateProduct(String proid,String price,String stock);

}
