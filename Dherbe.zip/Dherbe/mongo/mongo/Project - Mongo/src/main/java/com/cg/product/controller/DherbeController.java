package com.cg.product.controller;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.cg.product.dto.DherbeBeauty;
import com.cg.product.dto.DherbeSanitation;
import com.cg.product.service.DherbeService;

@RestController
@RequestMapping("/dherbe")
@CrossOrigin(origins="http://localhost:4200")
public class DherbeController {
	@Autowired
	DherbeService service;
	@GetMapping("/getalldata")
	public ResponseEntity<List<DherbeBeauty>> getAllEmployees() {
		List<DherbeBeauty> myList=service.showAllProducts();
		if(myList.isEmpty()) {
			return new ResponseEntity("No Product found",HttpStatus.NOT_FOUND);
			
		}
		return new ResponseEntity(myList,HttpStatus.OK);
	}
	
	@PostMapping("/saveBeautyProduct")
	public ResponseEntity<String> saveProfile(@RequestParam("file") MultipartFile file1) throws IOException{

		System.out.println("oy");
		String line,name="C:\\Users\\sapemmas\\"+file1.getOriginalFilename();
		FileReader fr=new FileReader(name);
	    BufferedReader br=new BufferedReader(fr);
	    DherbeBeauty dherbebeauty=new DherbeBeauty();
		while((line=br.readLine())!=null) { 
			DherbeBeauty dherbebeauty1=new DherbeBeauty();
			String[] data=line.split(",");
			dherbebeauty1.setProdId(data[0]);
			for (String string : data) {
				System.out.println(string);
			}
			dherbebeauty1.setProdName(data[1]);	
			dherbebeauty1.setProdPrice(data[2]);
			dherbebeauty1.setWeight(data[3]);
			dherbebeauty1.setStock(data[4]);
			dherbebeauty1.setGuidelines(data[5]);
			dherbebeauty1.seteDate(data[6]);
			dherbebeauty1.setImage(data[7]); 	
			service.saveProduct(dherbebeauty1);
		}	
		if(dherbebeauty!=null)
			return new ResponseEntity<String>("User saved",HttpStatus.OK);
		return new ResponseEntity<String>("not saved",HttpStatus.NOT_FOUND);	
	}
	@DeleteMapping("/deleteProduct/{proid}")
	public void deleteProduct(@PathVariable("proid") String proId) {
		System.out.println("deleted"+proId);
		service.deleteProduct(proId);
	}
	
	 @PutMapping("/updateProduct/{id}/{price}/{stock}")
	  public DherbeBeauty updateEmployee(@PathVariable("id") String proid,@PathVariable("price") String prices,@PathVariable("stock") String stocks){
	System.out.println(proid+""+prices+""+stocks);
		  return service.updateProduct(proid,prices,stocks);
	
	  }
	 
	
		
	

}
