import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee/employee-list.component';
import { EmployeeAddComponent } from './employee/employee-add.component';
import { PageNotFoundComponent } from './employee/page-not-found.component';
import { BranchComponent } from './dherbe/branch.component';
import { BrandComponent } from './dherbe/brand.component';
import { ContactComponent } from './dherbe/contact.component';
import { HomeComponent } from './dherbe/home.component';
import { UserroleComponent } from './dherbe/userrole.component';
import { UseregisterComponent } from './dherbe/useregister.component';
import { UserloginComponent } from './dherbe/userlogin.component';
import { ProductComponent } from './dherbe/product.component';
import { EcobeautyComponent } from './dherbe/ecobeauty.component';
import { EcosanitationComponent } from './dherbe/ecosanitation.component';

import { EcosanitationAdminComponent } from './dherbe/ecosanitation-admin.component';
import { ForgotpasswordComponent } from './dherbe/forgotpassword.component';
import { ChangepasswordComponent } from './dherbe/changepassword.component';
import { EcobeautyAdminComponent } from './dherbe/ecobeauty-admin.component';
import { AdminComponent } from './dherbe/admin.component';
import { LoginEcoBeautyComponent } from './dherbe/login-eco-beauty.component';
import { ProductsLoginComponent } from './dherbe/products-login.component';
import { LoginEcoSanitationComponent } from './dherbe/login-eco-sanitation.component';
import { UpdateSanitationComponent } from './dherbe/update-sanitation.component';
import { UpdateBeautyComponent } from './dherbe/update-beauty.component';
import { SuperUserComponent } from './dherbe/super-user.component';
import { LogoutComponent } from './dherbe/logout.component';
import { LogoutSuccessComponent } from './dherbe/logout-success.component';


const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'brand',component:BrandComponent},
  {path:'branch',component:BranchComponent},
  {path:'contact',component:ContactComponent},
  {path:'userrole',component:UserroleComponent},
  {path:'product',component:ProductComponent},
  {path:'userregister',component:UseregisterComponent},
   {path:'userrole',component:UserroleComponent},
   {path:'userlogin',component:UserloginComponent},
   {path:'ecobeauty',component:EcobeautyComponent},
   {path:'ecosanitation',component:EcosanitationComponent},
   {path:'forgorpassword',component:ForgotpasswordComponent},
   {path:'changepassword',component:ChangepasswordComponent},
   {path:'ecobeautyadmin',component:EcobeautyAdminComponent},
   {path:'ecosanitationadmin',component:EcosanitationAdminComponent},
   {path:'loginEcoBeauty',component:LoginEcoBeautyComponent},
   {path:'loginEcoSanitation',component:LoginEcoSanitationComponent},
   {path:'updateSanitation',component:UpdateSanitationComponent},
   {path:'updateBeauty',component:UpdateBeautyComponent},
   {path:'superUser',component:SuperUserComponent},
   {path:'Logout',component:LogoutComponent},
   {path:'products',component:ProductsLoginComponent},
   {path:'admin',component:AdminComponent},
   {path:'logoutsuccess',component:LogoutSuccessComponent},

  {path:'',redirectTo:'/home',pathMatch:'full'},
 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
