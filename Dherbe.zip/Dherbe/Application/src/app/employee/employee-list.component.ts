import { Component, OnInit } from '@angular/core';
import { IEmployee } from './employee.interface';
import { EmployeeService } from './employee.service';
import { ThrowStmt } from '../../../node_modules/@angular/compiler';
import { observable } from '../../../node_modules/rxjs';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {
  employees:IEmployee[];
  constructor(private employeeservice:EmployeeService) { }

  ngOnInit() {
/*  storing the added employee details */
    this.employeeservice.getEmployees().subscribe((data)=>{
      this.employees=data
      let db=this.employeeservice.getDb();
      for(let emp of db){
        this.employees.push(emp);
      }
    
    });
    
  }

 /*  deleting an employee from the employee table */
  onDelete(emp){
    let a=this.employees.indexOf(emp);
    this.employees.splice(a,1);
  }

  

}
