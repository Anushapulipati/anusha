import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-update-sanitation',
  templateUrl: './update-sanitation.component.html',
  styleUrls: ['./update-sanitation.component.css']
})
export class UpdateSanitationComponent implements OnInit {
  model1:any={};
  constructor(private service:ProductserviceService,private router:Router) { }

  ngOnInit() {
  }
  submit(id:String,price:String,stock:String):any{
    console.log(this.model1);
    this.service.updateSanitationProduct(id,price,stock).subscribe();
    this.router.navigate(['/ecosanitationadmin']);
  }
    
  

}
