import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-products-login',
  templateUrl: './products-login.component.html',
  styleUrls: ['./products-login.component.css']
})
export class ProductsLoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
