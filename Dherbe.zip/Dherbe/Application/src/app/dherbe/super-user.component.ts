import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';

@Component({
  selector: 'app-super-user',
  templateUrl: './super-user.component.html',
  styleUrls: ['./super-user.component.css']
})
export class SuperUserComponent implements OnInit {
  userdata:any[]=[];
  constructor(private service:ProductserviceService) { }

  ngOnInit() {
    this.service.getUserdata().subscribe((data:any)=>this.userdata=data);
  }
  DeleteUser(data){
    this.service.deleteUser(data).subscribe();
  }
}
