import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-login-eco-beauty',
  templateUrl: './login-eco-beauty.component.html',
  styleUrls: ['./login-eco-beauty.component.css']
})
export class LoginEcoBeautyComponent implements OnInit {

  constructor(private service:ProductserviceService,private router:Router) { }
  proddata:any[]=[];
  selectedFiles:FileList;
  currentFileUpload:File;
 
 ngOnInit(){
    console.log("haiii");
    this.service.getBeautydata().subscribe((data:any)=>this.proddata=data);
 }

 onSearch(value){
  console.log(value);
  this.proddata=this.proddata.filter(b=>b.prodName.toLowerCase().match(value.toLowerCase()) || b.stock.toLowerCase().indexOf(value.toLowerCase())!=-1 || b.eDate.toLowerCase().indexOf(value.toLowerCase())!=-1);
}



}
