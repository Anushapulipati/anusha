import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {
  model1:any={}; 
  constructor(private service:ProductserviceService,private router:Router) { }

  ngOnInit() {
  }

  updatePassword(mobile:number,pwd:string):any{
    console.log(mobile)
    this.service.changePassword(mobile,pwd).subscribe();
    this.router.navigate(['/userlogin']);
    
  }

}
