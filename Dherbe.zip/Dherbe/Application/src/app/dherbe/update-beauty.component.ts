import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from './productservice.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-update-beauty',
  templateUrl: './update-beauty.component.html',
  styleUrls: ['./update-beauty.component.css']
})
export class UpdateBeautyComponent implements OnInit {
  model1:any={};
  constructor(private service:ProductserviceService,private router:Router) { }

  ngOnInit() {
  }
  submit(id:String,price:String,stock:String):any{
    console.log(this.model1);
    this.service.updateBeautyProduct(id,price,stock).subscribe();
    this.router.navigate(['/ecobeautyadmin']);

  }
    
  
}
