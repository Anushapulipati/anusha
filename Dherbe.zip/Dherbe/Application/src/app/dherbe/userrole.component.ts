import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-userrole',
  templateUrl: './userrole.component.html',
  styleUrls: ['./userrole.component.css']
})
export class UserroleComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit() {
  }
  onregister(){
    this.router.navigate(['/userregister']);
   
   } 
   onlogin(){
    this.router.navigate(['/userlogin']);
   
   } 

}
