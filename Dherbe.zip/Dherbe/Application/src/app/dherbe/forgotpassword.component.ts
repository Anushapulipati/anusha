import { Component, OnInit } from '@angular/core';
import { Router } from '../../../node_modules/@angular/router';
import { ProductserviceService } from './productservice.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  model:any={};
  mobile:number;
result:any;
message:String;
  constructor(private service1:ProductserviceService,private router:Router) { }

  ngOnInit() {
  }
  verify(mobile:number,answer:String){
    console.log("Ints"+mobile+""+answer)
    return this.service1.checkForgotPassword(mobile,answer).subscribe(data=>{this.result=data;
      console.log(this.result);
      if(this.result){
        this.router.navigate(['/changepassword']); 
        }else 
        {
        
        }
    });
  
   
  }


}
