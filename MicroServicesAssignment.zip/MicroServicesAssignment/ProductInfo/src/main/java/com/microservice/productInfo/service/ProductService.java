package com.microservice.productInfo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.productInfo.dao.ProductDaoI;
import com.microservice.productInfo.dto.Product;

@Service
public class ProductService implements ProductServiceI {

	@Autowired
	ProductDaoI productDao;

	@Override
	public Boolean addProduct(Product product) {
		return productDao.addProduct(product);
	}

	@Override
	public List<Product> getAllProducts() {
		return productDao.getAllProducts();
	}

	@Override
	public boolean deleteProduct(String productId) {
		return productDao.deleteProduct(productId);
	}

	@Override
	public Product getProductById(String productId) {
		return productDao.getProductById(productId);
	}
}
